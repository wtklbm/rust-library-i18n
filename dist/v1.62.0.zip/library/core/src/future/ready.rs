use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// 一个立即准备好值的 future。
///
/// 该 `struct` 由 [`ready()`] 创建。
/// 有关更多信息，请参见其文档。
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("`Ready` polled after completion"))
    }
}

/// 创建一个立即准备好值的 future。
///
/// 通过此函数创建的 Futures 在功能上类似于通过 `async {}` 创建的 Futures。
/// 主要区别在于，通过此函数创建的 futures 被命名并实现 `Unpin`。
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}
