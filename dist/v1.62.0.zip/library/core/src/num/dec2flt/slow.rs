//! 对于 Eisel-Lemire 算法无法舍入的情况，慢速回退算法。

use crate::num::dec2flt::common::BiasedFp;
use crate::num::dec2flt::decimal::{parse_decimal, Decimal};
use crate::num::dec2flt::float::RawFloat;

/// 解析浮点数的有效数字和有偏差的二进制指数。
///
/// 这是一种回退算法，它使用浮点数的大整数表示，因此比更快的近似值慢得多。
/// 但是，它将始终确定如何将有效数字舍入到最近的机器浮点数，从而允许使用处理接近一半的情况。
///
/// 接近中途的情况是在两个连续的机器浮动之间。
/// 例如，浮点数 `16777217.0` 具有 `100000000000000000000000 1` 的按位表示。
/// 舍入为单精度浮点数，尾随的 `1` 被截断。
/// 使用最接近的平局，任何高于 `16777217.0` 的值都必须向上舍入为 `16777218.0`，而任何等于或等于 `16777217.0` 的值必须向下舍入为 `16777216.0`。
///
/// 因此，这些接近一半的转换可能需要大量数字来明确确定如何舍入。
///
/// 此处描述的算法基于 "快速处理长数字"，可在此处获得: <https://arxiv.org/pdf/2101.11408.pdf#section.11>。
///
///
///
///
///
///
pub(crate) fn parse_long_mantissa<F: RawFloat>(s: &[u8]) -> BiasedFp {
    const MAX_SHIFT: usize = 60;
    const NUM_POWERS: usize = 19;
    const POWERS: [u8; 19] =
        [0, 3, 6, 9, 13, 16, 19, 23, 26, 29, 33, 36, 39, 43, 46, 49, 53, 56, 59];

    let get_shift = |n| {
        if n < NUM_POWERS { POWERS[n] as usize } else { MAX_SHIFT }
    };

    let fp_zero = BiasedFp::zero_pow2(0);
    let fp_inf = BiasedFp::zero_pow2(F::INFINITE_POWER);

    let mut d = parse_decimal(s);

    // 短路如果值只能是一个字面量 0 或无穷大。
    if d.num_digits == 0 || d.decimal_point < -324 {
        return fp_zero;
    } else if d.decimal_point >= 310 {
        return fp_inf;
    }
    let mut exp2 = 0_i32;
    // 向右移动 (1/2 ... 1].
    while d.decimal_point > 0 {
        let n = d.decimal_point as usize;
        let shift = get_shift(n);
        d.right_shift(shift);
        if d.decimal_point < -Decimal::DECIMAL_POINT_RANGE {
            return fp_zero;
        }
        exp2 += shift as i32;
    }
    // 向左移动 (1/2 ... 1].
    while d.decimal_point <= 0 {
        let shift = if d.decimal_point == 0 {
            match d.digits[0] {
                digit if digit >= 5 => break,
                0 | 1 => 2,
                _ => 1,
            }
        } else {
            get_shift((-d.decimal_point) as _)
        };
        d.left_shift(shift);
        if d.decimal_point > Decimal::DECIMAL_POINT_RANGE {
            return fp_inf;
        }
        exp2 -= shift as i32;
    }
    // 我们现在在 [1/2 ... 1] 范围内，但二进制格式使用 [1 ... 2]。
    exp2 -= 1;
    while (F::MINIMUM_EXPONENT + 1) > exp2 {
        let mut n = ((F::MINIMUM_EXPONENT + 1) - exp2) as usize;
        if n > MAX_SHIFT {
            n = MAX_SHIFT;
        }
        d.right_shift(n);
        exp2 += n as i32;
    }
    if (exp2 - F::MINIMUM_EXPONENT) >= F::INFINITE_POWER {
        return fp_inf;
    }
    // 将小数移到隐藏位，然后将值四舍五入得到高尾数 + 1 位。
    //
    d.left_shift(F::MANTISSA_EXPLICIT_BITS + 1);
    let mut mantissa = d.round();
    if mantissa >= (1_u64 << (F::MANTISSA_EXPLICIT_BITS + 1)) {
        // 向上舍入溢出到进位位，需要移回隐藏位。
        //
        d.right_shift(1);
        exp2 += 1;
        mantissa = d.round();
        if (exp2 - F::MINIMUM_EXPONENT) >= F::INFINITE_POWER {
            return fp_inf;
        }
    }
    let mut power2 = exp2 - F::MINIMUM_EXPONENT;
    if mantissa < (1_u64 << F::MANTISSA_EXPLICIT_BITS) {
        power2 -= 1;
    }
    // 将显式尾数位上方的所有位清零。
    mantissa &= (1_u64 << F::MANTISSA_EXPLICIT_BITS) - 1;
    BiasedFp { f: mantissa, e: power2 }
}
