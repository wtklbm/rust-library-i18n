//! `Saturating<T>` 的定义。

use crate::fmt;
use crate::ops::{Add, AddAssign, BitAnd, BitAndAssign, BitOr, BitOrAssign};
use crate::ops::{BitXor, BitXorAssign, Div, DivAssign};
use crate::ops::{Mul, MulAssign, Neg, Not, Rem, RemAssign};
use crate::ops::{Shl, ShlAssign, Shr, ShrAssign, Sub, SubAssign};

/// 在 `T` 上提供有意饱和的算法。
///
/// `u32` 值上的 `+` 之类的操作旨在永不溢出，并且在某些调试配置中，检测到溢出并导致 panic。
/// 虽然大多数算术都属于这一类，但有些代码明确期望并依赖于饱和算术。
///
/// 饱和算术可以通过像 `saturating_add` 这样的方法或通过 `Saturating<T>` 类型来实现，它表示对底层值的所有标准算术运算都旨在具有饱和语义。
///
///
/// 可以通过 `Saturating` 元组的 `.0` 索引检索底层值。
///
/// # Examples
///
/// ```
/// #![feature(saturating_int_impl)]
/// use std::num::Saturating;
///
/// let max = Saturating(u32::MAX);
/// let one = Saturating(1u32);
///
/// assert_eq!(u32::MAX, (max + one).0);
/// ```
///
///
///
///
///
#[unstable(feature = "saturating_int_impl", issue = "87920")]
#[derive(PartialEq, Eq, PartialOrd, Ord, Clone, Copy, Default, Hash)]
#[repr(transparent)]
pub struct Saturating<T>(#[unstable(feature = "saturating_int_impl", issue = "87920")] pub T);

#[unstable(feature = "saturating_int_impl", issue = "87920")]
impl<T: fmt::Debug> fmt::Debug for Saturating<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[unstable(feature = "saturating_int_impl", issue = "87920")]
impl<T: fmt::Display> fmt::Display for Saturating<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[unstable(feature = "saturating_int_impl", issue = "87920")]
impl<T: fmt::Binary> fmt::Binary for Saturating<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[unstable(feature = "saturating_int_impl", issue = "87920")]
impl<T: fmt::Octal> fmt::Octal for Saturating<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[unstable(feature = "saturating_int_impl", issue = "87920")]
impl<T: fmt::LowerHex> fmt::LowerHex for Saturating<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[unstable(feature = "saturating_int_impl", issue = "87920")]
impl<T: fmt::UpperHex> fmt::UpperHex for Saturating<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}
#[allow(unused_macros)]
macro_rules! sh_impl_signed {
    ($t:ident, $f:ident) => {
        // FIXME 这里的正确实现是什么？ 参见讨论 https://github.com/rust-lang/rust/pull/87921#discussion_r695870065
        //
        // #[unstable(feature = "saturating_int_impl", issue = "87920")]
        // impl Shl<$f> for Saturating<$t> { type Output = Saturating<$t>;
        //
        //     #[inline]
        //     fn shl(self, other: $f) -> Saturating<$t> { if other < 0 { Saturating(self.0.shr((-other & self::shift_max::$t as $f) as u32)) } else { Saturating(self.0.shl((other & self::shift_max::$t as $f) as u32)) } } } forward_ref_binop!  { impl Shl, shl for Saturating<$t>, $f, #[unstable(feature = "saturating_int_impl", issue = "87920")] }
        //
        //
        // #[unstable(feature = "saturating_int_impl", issue = "87920")]
        // impl ShlAssign<$f> for Saturating<$t> {
        //     #[inline]
        //     fn shl_assign(&mut self, other: $f) { *self = *self << other; } } forward_ref_op_assign!  { impl ShlAssign, shl_assign for Saturating<$t>, $f }
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl Shr<$f> for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn shr(self, other: $f) -> Saturating<$t> {
                if other < 0 {
                    Saturating(self.0.shl((-other & self::shift_max::$t as $f) as u32))
                } else {
                    Saturating(self.0.shr((other & self::shift_max::$t as $f) as u32))
                }
            }
        }
        forward_ref_binop! { impl Shr, shr for Saturating<$t>, $f,
        #[unstable(feature = "saturating_int_impl", issue = "87920")] }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl ShrAssign<$f> for Saturating<$t> {
            #[inline]
            fn shr_assign(&mut self, other: $f) {
                *self = *self >> other;
            }
        }
        forward_ref_op_assign! { impl ShrAssign, shr_assign for Saturating<$t>, $f }
    };
}

macro_rules! sh_impl_unsigned {
    ($t:ident, $f:ident) => {
        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl Shl<$f> for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn shl(self, other: $f) -> Saturating<$t> {
                Saturating(self.0.wrapping_shl(other as u32))
            }
        }
        forward_ref_binop! { impl Shl, shl for Saturating<$t>, $f,
        #[unstable(feature = "saturating_int_impl", issue = "87920")] }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl ShlAssign<$f> for Saturating<$t> {
            #[inline]
            fn shl_assign(&mut self, other: $f) {
                *self = *self << other;
            }
        }
        forward_ref_op_assign! { impl ShlAssign, shl_assign for Saturating<$t>, $f }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl Shr<$f> for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn shr(self, other: $f) -> Saturating<$t> {
                Saturating(self.0.wrapping_shr(other as u32))
            }
        }
        forward_ref_binop! { impl Shr, shr for Saturating<$t>, $f,
        #[unstable(feature = "saturating_int_impl", issue = "87920")] }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl ShrAssign<$f> for Saturating<$t> {
            #[inline]
            fn shr_assign(&mut self, other: $f) {
                *self = *self >> other;
            }
        }
        forward_ref_op_assign! { impl ShrAssign, shr_assign for Saturating<$t>, $f }
    };
}

// FIXME (#23545): 取消对其余 impls 的注释
macro_rules! sh_impl_all {
    ($($t:ident)*) => ($(
        // sh_impl_unsigned! { $t, u8 } sh_impl_unsigned! { $t, u16 } sh_impl_unsigned! { $t, u32 } sh_impl_unsigned! { $t, u64 } sh_impl_unsigned! { $t, u128 }
        //
        //
        //
        //
        sh_impl_unsigned! { $t, usize }

        // sh_impl_signed! { $t, i8 } sh_impl_signed! { $t, i16 } sh_impl_signed! { $t, i32 } sh_impl_signed! { $t, i64 } sh_impl_signed! { $t, i128 } sh_impl_signed! { $t, isize }
        //
        //
        //
        //
        //
    )*)
}

sh_impl_all! { u8 u16 u32 u64 u128 usize i8 i16 i32 i64 i128 isize }

// FIXME(30524): impl Op<T> for Saturating<T>, impl OpAssign<T> for Saturating<T>
macro_rules! saturating_impl {
    ($($t:ty)*) => ($(
        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl Add for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn add(self, other: Saturating<$t>) -> Saturating<$t> {
                Saturating(self.0.saturating_add(other.0))
            }
        }
        forward_ref_binop! { impl Add, add for Saturating<$t>, Saturating<$t>,
                #[unstable(feature = "saturating_int_impl", issue = "87920")] }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl AddAssign for Saturating<$t> {
            #[inline]
            fn add_assign(&mut self, other: Saturating<$t>) {
                *self = *self + other;
            }
        }
        forward_ref_op_assign! { impl AddAssign, add_assign for Saturating<$t>, Saturating<$t> }

        #[unstable(feature = "saturating_int_assign_impl", issue = "92354")]
        impl AddAssign<$t> for Saturating<$t> {
            #[inline]
            fn add_assign(&mut self, other: $t) {
                *self = *self + Saturating(other);
            }
        }
        forward_ref_op_assign! { impl AddAssign, add_assign for Saturating<$t>, $t }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl Sub for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn sub(self, other: Saturating<$t>) -> Saturating<$t> {
                Saturating(self.0.saturating_sub(other.0))
            }
        }
        forward_ref_binop! { impl Sub, sub for Saturating<$t>, Saturating<$t>,
                #[unstable(feature = "saturating_int_impl", issue = "87920")] }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl SubAssign for Saturating<$t> {
            #[inline]
            fn sub_assign(&mut self, other: Saturating<$t>) {
                *self = *self - other;
            }
        }
        forward_ref_op_assign! { impl SubAssign, sub_assign for Saturating<$t>, Saturating<$t> }

        #[unstable(feature = "saturating_int_assign_impl", issue = "92354")]
        impl SubAssign<$t> for Saturating<$t> {
            #[inline]
            fn sub_assign(&mut self, other: $t) {
                *self = *self - Saturating(other);
            }
        }
        forward_ref_op_assign! { impl SubAssign, sub_assign for Saturating<$t>, $t }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl Mul for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn mul(self, other: Saturating<$t>) -> Saturating<$t> {
                Saturating(self.0.saturating_mul(other.0))
            }
        }
        forward_ref_binop! { impl Mul, mul for Saturating<$t>, Saturating<$t>,
                #[unstable(feature = "saturating_int_impl", issue = "87920")] }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl MulAssign for Saturating<$t> {
            #[inline]
            fn mul_assign(&mut self, other: Saturating<$t>) {
                *self = *self * other;
            }
        }
        forward_ref_op_assign! { impl MulAssign, mul_assign for Saturating<$t>, Saturating<$t> }

        #[unstable(feature = "saturating_int_assign_impl", issue = "92354")]
        impl MulAssign<$t> for Saturating<$t> {
            #[inline]
            fn mul_assign(&mut self, other: $t) {
                *self = *self * Saturating(other);
            }
        }
        forward_ref_op_assign! { impl MulAssign, mul_assign for Saturating<$t>, $t }

        /// # Examples
        ///
        /// 基本用法：
        ///
        /// ```
        /// #![feature(saturating_int_impl)]
        /// use std::num::Saturating;
        ///
        #[doc = concat!("assert_eq!(Saturating(2", stringify!($t), "), Saturating(5", stringify!($t), ") / Saturating(2));")]
        #[doc = concat!("assert_eq!(Saturating(", stringify!($t), "::MAX), Saturating(", stringify!($t), "::MAX) / Saturating(1));")]
        #[doc = concat!("assert_eq!(Saturating(", stringify!($t), "::MIN), Saturating(", stringify!($t), "::MIN) / Saturating(1));")]
        /// ```
        ///
        /// ```should_panic
        /// #![feature(saturating_int_impl)]
        /// use std::num::Saturating;
        ///
        #[doc = concat!("let _ = Saturating(0", stringify!($t), ") / Saturating(0);")]
        /// ```
        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl Div for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn div(self, other: Saturating<$t>) -> Saturating<$t> {
                Saturating(self.0.saturating_div(other.0))
            }
        }
        forward_ref_binop! { impl Div, div for Saturating<$t>, Saturating<$t>,
                #[unstable(feature = "saturating_int_impl", issue = "87920")] }


        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl DivAssign for Saturating<$t> {
            #[inline]
            fn div_assign(&mut self, other: Saturating<$t>) {
                *self = *self / other;
            }
        }
        forward_ref_op_assign! { impl DivAssign, div_assign for Saturating<$t>, Saturating<$t> }

        #[unstable(feature = "saturating_int_assign_impl", issue = "92354")]
        impl DivAssign<$t> for Saturating<$t> {
            #[inline]
            fn div_assign(&mut self, other: $t) {
                *self = *self / Saturating(other);
            }
        }
        forward_ref_op_assign! { impl DivAssign, div_assign for Saturating<$t>, $t }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl Rem for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn rem(self, other: Saturating<$t>) -> Saturating<$t> {
                Saturating(self.0.rem(other.0))
            }
        }
        forward_ref_binop! { impl Rem, rem for Saturating<$t>, Saturating<$t>,
                #[unstable(feature = "saturating_int_impl", issue = "87920")] }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl RemAssign for Saturating<$t> {
            #[inline]
            fn rem_assign(&mut self, other: Saturating<$t>) {
                *self = *self % other;
            }
        }
        forward_ref_op_assign! { impl RemAssign, rem_assign for Saturating<$t>, Saturating<$t> }

        #[unstable(feature = "saturating_int_assign_impl", issue = "92354")]
        impl RemAssign<$t> for Saturating<$t> {
            #[inline]
            fn rem_assign(&mut self, other: $t) {
                *self = *self % Saturating(other);
            }
        }
        forward_ref_op_assign! { impl RemAssign, rem_assign for Saturating<$t>, $t }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl Not for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn not(self) -> Saturating<$t> {
                Saturating(!self.0)
            }
        }
        forward_ref_unop! { impl Not, not for Saturating<$t>,
                #[unstable(feature = "saturating_int_impl", issue = "87920")] }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl BitXor for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn bitxor(self, other: Saturating<$t>) -> Saturating<$t> {
                Saturating(self.0 ^ other.0)
            }
        }
        forward_ref_binop! { impl BitXor, bitxor for Saturating<$t>, Saturating<$t>,
                #[unstable(feature = "saturating_int_impl", issue = "87920")] }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl BitXorAssign for Saturating<$t> {
            #[inline]
            fn bitxor_assign(&mut self, other: Saturating<$t>) {
                *self = *self ^ other;
            }
        }
        forward_ref_op_assign! { impl BitXorAssign, bitxor_assign for Saturating<$t>, Saturating<$t> }

        #[unstable(feature = "saturating_int_assign_impl", issue = "92354")]
        impl BitXorAssign<$t> for Saturating<$t> {
            #[inline]
            fn bitxor_assign(&mut self, other: $t) {
                *self = *self ^ Saturating(other);
            }
        }
        forward_ref_op_assign! { impl BitXorAssign, bitxor_assign for Saturating<$t>, $t }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl BitOr for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn bitor(self, other: Saturating<$t>) -> Saturating<$t> {
                Saturating(self.0 | other.0)
            }
        }
        forward_ref_binop! { impl BitOr, bitor for Saturating<$t>, Saturating<$t>,
                #[unstable(feature = "saturating_int_impl", issue = "87920")] }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl BitOrAssign for Saturating<$t> {
            #[inline]
            fn bitor_assign(&mut self, other: Saturating<$t>) {
                *self = *self | other;
            }
        }
        forward_ref_op_assign! { impl BitOrAssign, bitor_assign for Saturating<$t>, Saturating<$t> }

        #[unstable(feature = "saturating_int_assign_impl", issue = "92354")]
        impl BitOrAssign<$t> for Saturating<$t> {
            #[inline]
            fn bitor_assign(&mut self, other: $t) {
                *self = *self | Saturating(other);
            }
        }
        forward_ref_op_assign! { impl BitOrAssign, bitor_assign for Saturating<$t>, $t }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl BitAnd for Saturating<$t> {
            type Output = Saturating<$t>;

            #[inline]
            fn bitand(self, other: Saturating<$t>) -> Saturating<$t> {
                Saturating(self.0 & other.0)
            }
        }
        forward_ref_binop! { impl BitAnd, bitand for Saturating<$t>, Saturating<$t>,
                #[unstable(feature = "saturating_int_impl", issue = "87920")] }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl BitAndAssign for Saturating<$t> {
            #[inline]
            fn bitand_assign(&mut self, other: Saturating<$t>) {
                *self = *self & other;
            }
        }
        forward_ref_op_assign! { impl BitAndAssign, bitand_assign for Saturating<$t>, Saturating<$t> }

        #[unstable(feature = "saturating_int_assign_impl", issue = "92354")]
        impl BitAndAssign<$t> for Saturating<$t> {
            #[inline]
            fn bitand_assign(&mut self, other: $t) {
                *self = *self & Saturating(other);
            }
        }
        forward_ref_op_assign! { impl BitAndAssign, bitand_assign for Saturating<$t>, $t }

    )*)
}

saturating_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! saturating_int_impl {
    ($($t:ty)*) => ($(
        impl Saturating<$t> {
            /// 返回此整数类型可以表示的最小值。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("assert_eq!(<Saturating<", stringify!($t), ">>::MIN, Saturating(", stringify!($t), "::MIN));")]
            /// ```
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const MIN: Self = Self(<$t>::MIN);

            /// 返回此整数类型可以表示的最大值。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("assert_eq!(<Saturating<", stringify!($t), ">>::MAX, Saturating(", stringify!($t), "::MAX));")]
            /// ```
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const MAX: Self = Self(<$t>::MAX);

            /// 以位为单位返回此整数类型的大小。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("assert_eq!(<Saturating<", stringify!($t), ">>::BITS, ", stringify!($t), "::BITS);")]
            /// ```
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const BITS: u32 = <$t>::BITS;

            /// 返回 `self` 二进制表示形式中的位数。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("let n = Saturating(0b01001100", stringify!($t), ");")]
            ///
            /// assert_eq!(n.count_ones(), 3);
            /// ```
            #[inline]
            #[doc(alias = "popcount")]
            #[doc(alias = "popcnt")]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const fn count_ones(self) -> u32 {
                self.0.count_ones()
            }

            /// 返回 `self` 二进制表示形式中的零数。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("assert_eq!(Saturating(!0", stringify!($t), ").count_zeros(), 0);")]
            /// ```
            #[inline]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const fn count_zeros(self) -> u32 {
                self.0.count_zeros()
            }

            /// 返回 `self` 二进制表示形式中的尾随零数。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("let n = Saturating(0b0101000", stringify!($t), ");")]
            ///
            /// assert_eq!(n.trailing_zeros(), 3);
            /// ```
            #[inline]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const fn trailing_zeros(self) -> u32 {
                self.0.trailing_zeros()
            }

            /// 将位向左移动指定的量 `n`，将截断的位饱和到结果整数的末尾。
            ///
            ///
            /// 请注意，此操作与 `<<` 移位运算符不同！
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            /// let n: Saturating<i64> = Saturating(0x0123456789ABCDEF);
            /// let m: Saturating<i64> = Saturating(-0x76543210FEDCBA99);
            ///
            /// assert_eq!(n.rotate_left(32), m);
            /// ```
            ///
            ///
            #[inline]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const fn rotate_left(self, n: u32) -> Self {
                Saturating(self.0.rotate_left(n))
            }

            /// 将位右移指定的量 `n`，将截断的位饱和到结果整数的开头。
            ///
            ///
            /// 请注意，此操作与 `>>` 移位运算符不同！
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            /// let n: Saturating<i64> = Saturating(0x0123456789ABCDEF);
            /// let m: Saturating<i64> = Saturating(-0xFEDCBA987654322);
            ///
            /// assert_eq!(n.rotate_right(4), m);
            /// ```
            ///
            ///
            #[inline]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const fn rotate_right(self, n: u32) -> Self {
                Saturating(self.0.rotate_right(n))
            }

            /// 反转整数的字节顺序。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            /// let n: Saturating<i16> = Saturating(0b0000000_01010101);
            /// assert_eq!(n, Saturating(85));
            ///
            /// let m = n.swap_bytes();
            ///
            /// assert_eq!(m, Saturating(0b01010101_00000000));
            /// assert_eq!(m, Saturating(21760));
            /// ```
            #[inline]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const fn swap_bytes(self) -> Self {
                Saturating(self.0.swap_bytes())
            }

            /// 反转整数的位模式。
            ///
            /// # Examples
            ///
            /// 请注意，此示例在整数类型之间共享。
            /// 这就解释了为什么在这里使用 `i16`。
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            /// let n = Saturating(0b0000000_01010101i16);
            /// assert_eq!(n, Saturating(85));
            ///
            /// let m = n.reverse_bits();
            ///
            /// assert_eq!(m.0 as u16, 0b10101010_00000000);
            /// assert_eq!(m, Saturating(-22016));
            /// ```
            #[inline]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            #[rustc_const_unstable(feature = "saturating_int_impl", issue = "87920")]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            pub const fn reverse_bits(self) -> Self {
                Saturating(self.0.reverse_bits())
            }

            /// 将整数从大端字节序转换为目标的字节序。
            ///
            /// 在大端节序序上，这是个禁忌。
            /// 在小端字节序上，字节被交换。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("let n = Saturating(0x1A", stringify!($t), ");")]
            ///
            /// if cfg!(target_endian = "big") {
            #[doc = concat!("    assert_eq!(<Saturating<", stringify!($t), ">>::from_be(n), n)")]
            /// } else {
            #[doc = concat!("    assert_eq!(<Saturating<", stringify!($t), ">>::from_be(n), n.swap_bytes())")]
            /// }
            /// ```
            #[inline]
            #[must_use]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const fn from_be(x: Self) -> Self {
                Saturating(<$t>::from_be(x.0))
            }

            /// 将整数从小端字节序转换为目标的字节序。
            ///
            /// 在小端字节序上，这是个禁忌。
            /// 在大字节序中，字节被交换。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("let n = Saturating(0x1A", stringify!($t), ");")]
            ///
            /// if cfg!(target_endian = "little") {
            #[doc = concat!("    assert_eq!(<Saturating<", stringify!($t), ">>::from_le(n), n)")]
            /// } else {
            #[doc = concat!("    assert_eq!(<Saturating<", stringify!($t), ">>::from_le(n), n.swap_bytes())")]
            /// }
            /// ```
            #[inline]
            #[must_use]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const fn from_le(x: Self) -> Self {
                Saturating(<$t>::from_le(x.0))
            }

            /// 将 `self` 从目标的字节序转换为大字节序。
            ///
            /// 在大端节序序上，这是个禁忌。
            /// 在小端字节序上，字节被交换。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("let n = Saturating(0x1A", stringify!($t), ");")]
            ///
            /// if cfg!(target_endian = "big") {
            ///     assert_eq!(n.to_be(), n)
            /// } else {
            ///     assert_eq!(n.to_be(), n.swap_bytes())
            /// }
            /// ```
            #[inline]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            pub const fn to_be(self) -> Self {
                Saturating(self.0.to_be())
            }

            /// 将 `self` 从目标的字节序转换为 Little Endian。
            ///
            /// 在小端字节序上，这是个禁忌。
            /// 在大字节序中，字节被交换。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("let n = Saturating(0x1A", stringify!($t), ");")]
            ///
            /// if cfg!(target_endian = "little") {
            ///     assert_eq!(n.to_le(), n)
            /// } else {
            ///     assert_eq!(n.to_le(), n.swap_bytes())
            /// }
            /// ```
            #[inline]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            pub const fn to_le(self) -> Self {
                Saturating(self.0.to_le())
            }

            /// 通过平方运算，将自己提升到 `exp` 的功效。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("assert_eq!(Saturating(3", stringify!($t), ").pow(4), Saturating(81));")]
            /// ```
            ///
            /// 过大的结果是饱和的：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            /// assert_eq!(Saturating(3i8).pow(5), Saturating(127));
            /// assert_eq!(Saturating(3i8).pow(6), Saturating(127));
            /// ```
            #[inline]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            pub fn pow(self, exp: u32) -> Self {
                Saturating(self.0.saturating_pow(exp))
            }
        }
    )*)
}

saturating_int_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! saturating_int_impl_signed {
    ($($t:ty)*) => ($(
        impl Saturating<$t> {
            /// 返回 `self` 二进制表示形式中前导零的数目。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("let n = Saturating(", stringify!($t), "::MAX >> 2);")]
            ///
            /// assert_eq!(n.leading_zeros(), 3);
            /// ```
            #[inline]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            pub const fn leading_zeros(self) -> u32 {
                self.0.leading_zeros()
            }

            /// 饱和绝对值。
            /// 计算 `self.abs()`，如果 `self == MIN` 则返回 `MAX` 而不是溢出。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("assert_eq!(Saturating(100", stringify!($t), ").abs(), Saturating(100));")]
            #[doc = concat!("assert_eq!(Saturating(-100", stringify!($t), ").abs(), Saturating(100));")]
            #[doc = concat!("assert_eq!(Saturating(", stringify!($t), "::MIN).abs(), Saturating((", stringify!($t), "::MIN + 1).abs()));")]
            #[doc = concat!("assert_eq!(Saturating(", stringify!($t), "::MIN).abs(), Saturating(", stringify!($t), "::MIN.saturating_abs()));")]
            #[doc = concat!("assert_eq!(Saturating(", stringify!($t), "::MIN).abs(), Saturating(", stringify!($t), "::MAX));")]
            /// ```
            #[inline]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            pub fn abs(self) -> Saturating<$t> {
                Saturating(self.0.saturating_abs())
            }

            /// 返回一个表示 `self` 的符号的数字。
            ///
            ///  - `0` 如果数字为零
            ///  - `1` 如果数字是正数
            ///  - `-1` 如果数字是负数
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("assert_eq!(Saturating(10", stringify!($t), ").signum(), Saturating(1));")]
            #[doc = concat!("assert_eq!(Saturating(0", stringify!($t), ").signum(), Saturating(0));")]
            #[doc = concat!("assert_eq!(Saturating(-10", stringify!($t), ").signum(), Saturating(-1));")]
            /// ```
            #[inline]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            pub fn signum(self) -> Saturating<$t> {
                Saturating(self.0.signum())
            }

            /// 如果 `self` 为正数，则返回 `true`; 如果数字为零或负数，则返回 `false`。
            ///
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("assert!(Saturating(10", stringify!($t), ").is_positive());")]
            #[doc = concat!("assert!(!Saturating(-10", stringify!($t), ").is_positive());")]
            /// ```
            #[must_use]
            #[inline]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const fn is_positive(self) -> bool {
                self.0.is_positive()
            }

            /// 如果 `self` 为负，则返回 `true`; 如果数字为零或正，则返回 `false`。
            ///
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("assert!(Saturating(-10", stringify!($t), ").is_negative());")]
            #[doc = concat!("assert!(!Saturating(10", stringify!($t), ").is_negative());")]
            /// ```
            #[must_use]
            #[inline]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub const fn is_negative(self) -> bool {
                self.0.is_negative()
            }
        }

        #[unstable(feature = "saturating_int_impl", issue = "87920")]
        impl Neg for Saturating<$t> {
            type Output = Self;
            #[inline]
            fn neg(self) -> Self {
                Saturating(self.0.saturating_neg())
            }
        }
        forward_ref_unop! { impl Neg, neg for Saturating<$t>,
                #[unstable(feature = "saturating_int_impl", issue = "87920")] }
    )*)
}

saturating_int_impl_signed! { isize i8 i16 i32 i64 i128 }

macro_rules! saturating_int_impl_unsigned {
    ($($t:ty)*) => ($(
        impl Saturating<$t> {
            /// 返回 `self` 二进制表示形式中前导零的数目。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("let n = Saturating(", stringify!($t), "::MAX >> 2);")]
            ///
            /// assert_eq!(n.leading_zeros(), 2);
            /// ```
            #[inline]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
            pub const fn leading_zeros(self) -> u32 {
                self.0.leading_zeros()
            }

            /// 当且仅当某些 `k` 的 `self == 2^k` 时，才返回 `true`。
            ///
            /// # Examples
            ///
            /// 基本用法：
            ///
            /// ```
            /// #![feature(saturating_int_impl)]
            /// use std::num::Saturating;
            ///
            #[doc = concat!("assert!(Saturating(16", stringify!($t), ").is_power_of_two());")]
            #[doc = concat!("assert!(!Saturating(10", stringify!($t), ").is_power_of_two());")]
            /// ```
            #[must_use]
            #[inline]
            #[unstable(feature = "saturating_int_impl", issue = "87920")]
            pub fn is_power_of_two(self) -> bool {
                self.0.is_power_of_two()
            }

        }
    )*)
}

saturating_int_impl_unsigned! { usize u8 u16 u32 u64 u128 }

// 与潜在的 Shl 和 ShlAssign 实现相关
//
//
// mod shift_max {    #![allow(non_upper_case_globals)]
//
//     #[cfg(target_pointer_width = "16")]
//     mod platform { pub const usize: u32 = super::u16;
//         pub const isize: u32 = super::i16; }
//
//     #[cfg(target_pointer_width = "32")]
//     mod platform { pub const usize: u32 = super::u32;
//         pub const isize: u32 = super::i32; }
//
//     #[cfg(target_pointer_width = "64")]
//     mod platform { pub const usize: u32 = super::u64;
//         pub const isize: u32 = super::i64; }
//
//     pub const i8: u32 = (1 << 3) - 1;
//     pub const i16: u32 = (1 << 4) - 1;
//     pub const i32: u32 = (1 << 5) - 1;
//     pub const i64: u32 = (1 << 6) - 1;
//     pub const i128: u32 = (1 << 7) - 1;
//     pub use self::platform::isize;
//
//     pub const u8: u32 = i8;
//     pub const u16: u32 = i16;
//     pub const u32: u32 = i32;
//     pub const u64: u32 = i64;
//     pub const u128: u32 = i128;
//     pub use self::platform::usize;  }
//
//
//
//
//
//
//
