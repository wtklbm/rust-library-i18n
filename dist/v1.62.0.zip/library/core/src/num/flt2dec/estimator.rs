//! 指数估计量。

/// 查找 `k_0`，如 `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`。
///
/// 这用于近似 `k = ceil(log_10 (mant * 2^exp))`；
/// 真正的 `k` 是 `k_0` 或 `k_0+1`。
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2^(nbits-1) < mant <= 2^nbits if mant > 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986 = floor(2^32 * log_10 2) 因此，这总是低估 (或准确)，但幅度不大。
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}
