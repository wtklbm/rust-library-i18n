//! 64 位有符号整数类型的常量。
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! 新代码应直接在原始类型上使用关联的常量。

#![stable(feature = "rust1", since = "1.0.0")]
#![deprecated(
    since = "TBD",
    note = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }
