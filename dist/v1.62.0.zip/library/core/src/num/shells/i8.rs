//! 8 位带符号整数类型的常量。
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! 新代码应直接在原始类型上使用关联的常量。

#![stable(feature = "rust1", since = "1.0.0")]
#![deprecated(
    since = "TBD",
    note = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }
