//! # Rust 核心库
//!
//! Rust 核心库是 [Rust 标准库](../std/index.html) 的无依赖 [^free] 基础。
//! 它是语言和标准库库之间的可移植粘合剂，它定义了所有 Rust 代码的内在和原始构建块。
//!
//! 它没有链接到上游库，没有系统库，也没有 libc。
//!
//! [^free]: 严格来说，有些符号是需要的，但是
//!          它们并不总是必需的。
//!
//! 核心库是 *最小的*: 它甚至不知道堆分配，也不提供并发或 I/O。
//! 这些东西都需要平台集成，而核心库是与平台无关的。
//!
//! # 如何使用核心库
//!
//! 请注意，所有这些细节目前都被认为是不稳定的。
//!
//!
//!
// FIXME: 当接口稳定后，请向我提供更多细节
//! 这个库建立在一些现有符号的假设之上：
//!
//! * `memcpy`、`memcmp`、`memset`、`strlen` - 这些是通常由 LLVM 生成的核心内存例程。
//! 此外，这个库可以显式地调用这些函数。
//! 它们的签名与 C 中的签名相同。
//!   这些函数通常由系统 libc 提供，但也可以由 [编译器内置 crate](https://crates.io/crates/compiler_builtins) 提供。
//!
//!
//! * `rust_begin_panic` - 这个函数需要四个参数，一个 `fmt::Arguments`、一个 `&'static str` 和两个 `u32`。
//! 这四个参数指示 panic 消息，调用 panic 的文件以及文件中的行和列。
//! 定义此 panic 函数由该核心库的消费者决定； 它只要求返回 never。
//! 这需要一个名为 `panic_impl` 的 `lang` 属性。
//!
//! * `rust_eh_personality` - 由编译器的故障机制使用。
//! 这通常映射到 GCC 的 personality 函数，但是可以确保不会触发 panic 的 crate 永远不会调用此函数。
//! `lang` 属性称为 `eh_personality`。
//!
//!
//!

// 由于 libcore 定义了许多基本 lang 项，因此所有测试都位于单独的 crate libcoretest 中，以避免出现奇怪的问题。
//
// 在这里，当测试时，我们显式 #[cfg]- 输出整个 crate。
// 如果我们不这样做，那么生成的测试工件和链接的 libtest (可传递地包括 libcore) 都将定义相同的 lang 项集，这将导致 E0152 "发现重复的 lang 项" 错误。
//
// 有关详细信息，请参见 #50466 中的讨论。
//
// 此 cfg 不会影响文档测试。
//
//
#![cfg(not(test))]
// 要在没有 x.py 的情况下运行 libcore 测试而不最终得到两个 libcore 副本，Miri 需要能够 "empty" 这个 crate。
// 请参见 <https://github.com/rust-lang/miri-test-libstd/issues/4>。
// rustc 本身从不设置该特性，因此这一行在那里没有影响。
#![cfg(any(not(feature = "miri-test-libstd"), test, doctest))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![doc(cfg_hide(
    not(test),
    any(not(feature = "miri-test-libstd"), test, doctest),
    no_fp_fmt_parse,
    target_pointer_width = "16",
    target_pointer_width = "32",
    target_pointer_width = "64",
    target_has_atomic = "8",
    target_has_atomic = "16",
    target_has_atomic = "32",
    target_has_atomic = "64",
    target_has_atomic = "ptr",
    target_has_atomic_equal_alignment = "8",
    target_has_atomic_equal_alignment = "16",
    target_has_atomic_equal_alignment = "32",
    target_has_atomic_equal_alignment = "64",
    target_has_atomic_equal_alignment = "ptr",
    target_has_atomic_load_store = "8",
    target_has_atomic_load_store = "16",
    target_has_atomic_load_store = "32",
    target_has_atomic_load_store = "64",
    target_has_atomic_load_store = "ptr",
))]
#![no_core]
#![rustc_coherence_is_core]
//
// Lints:
#![deny(rust_2021_incompatible_or_patterns)]
#![deny(unsafe_op_in_unsafe_fn)]
#![warn(deprecated_in_future)]
#![warn(missing_debug_implementations)]
#![warn(missing_docs)]
#![allow(explicit_outlives_requirements)]
//
// 库特性：
#![feature(const_align_offset)]
#![feature(const_align_of_val)]
#![feature(const_arguments_as_str)]
#![feature(const_array_into_iter_constructors)]
#![feature(const_bigint_helper_methods)]
#![feature(const_black_box)]
#![feature(const_caller_location)]
#![feature(const_cell_into_inner)]
#![feature(const_char_convert)]
#![feature(const_clone)]
#![feature(const_discriminant)]
#![feature(const_eval_select)]
#![feature(const_float_bits_conv)]
#![feature(const_float_classify)]
#![feature(const_fmt_arguments_new)]
#![feature(const_heap)]
#![feature(const_convert)]
#![feature(const_inherent_unchecked_arith)]
#![feature(const_int_unchecked_arith)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_likely)]
#![feature(const_maybe_uninit_uninit_array)]
#![feature(const_maybe_uninit_as_mut_ptr)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_nonnull_new)]
#![feature(const_num_from_num)]
#![feature(const_ops)]
#![feature(const_option)]
#![feature(const_option_ext)]
#![feature(const_pin)]
#![feature(const_ptr_sub_ptr)]
#![feature(const_replace)]
#![feature(const_ptr_as_ref)]
#![feature(const_ptr_is_null)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_size_of_val)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_str_from_utf8_unchecked_mut)]
#![feature(const_swap)]
#![feature(const_trait_impl)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_default_impls)]
#![feature(const_unsafecell_get_mut)]
#![feature(core_panic)]
#![feature(duration_consts_float)]
#![feature(maybe_uninit_uninit_array)]
#![feature(ptr_metadata)]
#![feature(slice_ptr_get)]
#![feature(str_internals)]
#![feature(utf16_extra)]
#![feature(utf16_extra_const)]
#![feature(variant_count)]
#![feature(const_array_from_ref)]
#![feature(const_slice_from_ref)]
#![feature(const_slice_index)]
#![feature(const_is_char_boundary)]
//
// 语言特性：
#![feature(abi_unadjusted)]
#![feature(allow_internal_unsafe)]
#![feature(allow_internal_unstable)]
#![feature(associated_type_bounds)]
#![feature(auto_traits)]
#![feature(cfg_target_has_atomic)]
#![feature(cfg_target_has_atomic_equal_alignment)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_mut_refs)]
#![feature(const_precise_live_drops)]
#![feature(const_refs_to_cell)]
#![feature(decl_macro)]
#![cfg_attr(bootstrap, feature(derive_default_enum))]
#![feature(deprecated_suggestion)]
#![feature(doc_cfg)]
#![feature(doc_notable_trait)]
#![feature(rustdoc_internals)]
#![feature(exhaustive_patterns)]
#![feature(doc_cfg_hide)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(if_let_guard)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(macro_metavar_expr)]
#![feature(min_specialization)]
#![feature(mixed_integer_ops)]
#![feature(must_not_suspend)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(no_core)]
#![feature(no_coverage)] // rust-lang/rust#84605
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(platform_intrinsics)]
#![feature(prelude_import)]
#![feature(repr_simd)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(staged_api)]
#![feature(stmt_expr_attributes)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(asm_const)]
//
// 目标特性：
#![feature(arm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(mips_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(rtm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(tbm_target_feature)]
#![feature(wasm_target_feature)]

// 允许在文档内部链接中使用 `core::`
#[allow(unused_extern_crates)]
extern crate self as core;

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // 请参见 #65860
#[macro_use]
mod macros;

// 我们暂时不通过 #[macro_export] 导出它，以避免损坏。
// See https://github.com/rust-lang/rust/issues/82913
#[cfg(not(test))]
#[unstable(feature = "assert_matches", issue = "82775")]
/// Unstable 模块包含不稳定的 `assert_matches` 宏。
pub mod assert_matches {
    #[unstable(feature = "assert_matches", issue = "82775")]
    pub use crate::macros::{assert_matches, debug_assert_matches};
}

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
#[unstable(feature = "async_iterator", issue = "79024")]
pub mod async_iter;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod result;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: 不需要公开
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// 将 `core_arch` crate 直接放到 libcore 中。`core_arch` 的内容在不同的仓库: rust-lang/stdarch.
//
// `core_arch` 依赖于 libcore，但此模块的内容设置为直接将其拉到此处工作，以便 crate 使用此 crate 作为它的 libcore。
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[allow(rustdoc::bare_urls)]
// FIXME: 合并 clashing_extern_declarations 后，应将该注解移动到 rust-lang/stdarch 中。
// 当前不能，因为引导失败，因为尚未定义 lint。
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[doc = include_str!("../../stdarch/crates/core_arch/src/core_arch_docs.md")]
#[stable(feature = "simd_arch", since = "1.27.0")]
pub mod arch {
    #[stable(feature = "simd_arch", since = "1.27.0")]
    pub use crate::core_arch::arch::*;

    /// 内联汇编。
    ///
    /// 有关使用指南，请参见 [rust by example]，有关语法和可用选项的详细信息，请参见 [reference]。
    ///
    ///
    /// [rust by example]: https://doc.rust-lang.org/nightly/rust-by-example/unsafe/asm.html
    /// [reference]: https://doc.rust-lang.org/nightly/reference/inline-assembly.html
    #[stable(feature = "asm", since = "1.59.0")]
    #[rustc_builtin_macro]
    pub macro asm("assembly template", $(operands,)* $(options($(option),*))?) {
        /* compiler built-in */
    }

    /// 模块级内联汇编。
    ///
    /// 有关使用指南，请参见 [rust by example]，有关语法和可用选项的详细信息，请参见 [reference]。
    ///
    ///
    /// [rust by example]: https://doc.rust-lang.org/nightly/rust-by-example/unsafe/asm.html
    /// [reference]: https://doc.rust-lang.org/nightly/reference/inline-assembly.html
    #[stable(feature = "global_asm", since = "1.59.0")]
    #[rustc_builtin_macro]
    pub macro global_asm("assembly template", $(operands,)* $(options($(option),*))?) {
        /* compiler built-in */
    }
}

// 将 `core_simd` crate 直接拉取到 libcore 中。`core_simd` 的内容在不同的仓库: rust-lang/portable-simd.
//
// `core_simd` 依赖于 libcore，但此模块的内容设置为直接将其拉到此处工作，以便 crate 使用此 crate 作为它的 libcore。
//
//
//
#[path = "../../portable-simd/crates/core_simd/src/mod.rs"]
#[allow(missing_debug_implementations, dead_code, unsafe_op_in_unsafe_fn, unused_unsafe)]
#[allow(rustdoc::bare_urls)]
#[unstable(feature = "portable_simd", issue = "86656")]
mod core_simd;

#[doc = include_str!("../../portable-simd/crates/core_simd/src/core_simd_docs.md")]
#[unstable(feature = "portable_simd", issue = "86656")]
pub mod simd {
    #[unstable(feature = "portable_simd", issue = "86656")]
    pub use crate::core_simd::simd::*;
}

include!("primitive_docs.rs");
