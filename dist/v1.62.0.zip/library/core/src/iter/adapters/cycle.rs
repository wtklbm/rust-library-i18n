use crate::{iter::FusedIterator, ops::Try};

/// 无限重复的迭代器。
///
/// 该 `struct` 是通过 [`Iterator`] 上的 [`cycle`] 方法创建的。
/// 有关更多信息，请参见其文档。
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // 循环迭代器为空或无限
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Output = Acc>,
    {
        // 完全迭代当前的迭代器。
        // 这是必要的，因为即使 `self.orig` 不是，`self.iter` 可能还是为空
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // 完成一个完整的周期，跟踪循环的迭代器是否为空。
        // 我们需要在迭代器为空的情况下尽早返回，以防止无限循环
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        let mut rem = n;
        match self.iter.advance_by(rem) {
            ret @ Ok(_) => return ret,
            Err(advanced) => rem -= advanced,
        }

        while rem > 0 {
            self.iter = self.orig.clone();
            match self.iter.advance_by(rem) {
                ret @ Ok(_) => return ret,
                Err(0) => return Err(n - rem),
                Err(advanced) => rem -= advanced,
            }
        }

        Ok(())
    }

    // 没有 `fold` 替代，因为 `fold` 对 `Cycle` 没有多大意义，我们无法做得比默认更好。
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}
