use crate::{fmt, iter::FusedIterator};

/// 创建一个新的迭代器，在该迭代器的基础上，每个连续项都根据前一个进行计算。
///
/// 迭代器从给定的第一个项 (如果有) 开始，并调用给定的 `FnMut(&T) -> Option<T>` 闭包以计算每个项的后继项。
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // 如果此函数返回 `impl Iterator<Item=T>`，则它可能基于 `unfold`，并且不需要专用类型。
    //
    // 但是，当 `T` 和 `F` 存在时，具有命名的 `Successors<T, F>` 类型可以使其成为 `Clone`。
    Successors { next: first, succ }
}

/// 一个新的迭代器，其中每个连续项都是根据前一个进行计算的。
///
/// 该 `struct` 由 [`iter::successors()`] 函数创建。
/// 有关更多信息，请参见其文档。
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}
