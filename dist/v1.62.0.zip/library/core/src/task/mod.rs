#![stable(feature = "futures_api", since = "1.36.0")]

//! 类型和 Traits 用于处理异步任务。

mod poll;
#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::poll::Poll;

mod wake;
#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::wake::{Context, RawWaker, RawWakerVTable, Waker};

mod ready;
#[unstable(feature = "ready_macro", issue = "70922")]
pub use ready::ready;
#[unstable(feature = "poll_ready", issue = "89780")]
pub use ready::Ready;
