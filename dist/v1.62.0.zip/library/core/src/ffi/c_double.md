等效于 C 的 `double` 类型。

此类型几乎总是 [`f64`]，并保证它是 Rust 中的 [IEEE-754 双精度浮点数][IEEE-754 double-precision float]。也就是说，该标准从技术上仅保证它是至少具有 [`float`] 精度的浮点数，并且它可以是 `f32` 或与 IEEE-754 标准完全不同的东西。

[IEEE-754 double-precision float]: https://en.wikipedia.org/wiki/IEEE_754
[`float`]: c_float
