//! 可重载的运算符。
//!
//! 实现这些 traits 可使您重载某些运算符。
//!
//! 其中的某些 traits 由 prelude 导入，因此在每个 Rust 程序中都可用。只能重载由 traits 支持的运算符。
//! 例如，可以通过 [`Add`] trait 重载加法运算符 (`+`)，但是由于赋值运算符 (`=`) 没有后备 trait，因此无法重载其语义。
//! 此外，此模块不提供任何机制来创建新的运算符。
//! 如果需要无特征重载或自定义运算符，则应使用宏或编译器插件来扩展 Rust 的语法。
//!
//! 考虑到它们的通常含义和 [运算符优先级][operator precedence]，运算符 traits 的实现在它们各自的上下文中应该不足为奇。
//! 例如，当实现 [`Mul`] 时，该操作应与乘法有些相似 (并共享期望的属性，如关联性)。
//!
//! 请注意，`&&` 和 `||` 运算符发生短路，即，它们仅在第二操作数对结果有贡献的情况下才对其求值。由于 traits 无法强制执行此行为，因此不支持 `&&` 和 `||` 作为可重载的运算符。
//!
//! 许多运算符都按值取其操作数。在涉及内置类型的非泛型上下文中，这通常不是问题。
//! 但是，如果必须重用值，而不是让运算符使用它们，那么在泛型代码中使用这些运算符就需要引起注意。一种选择是偶尔使用 [`clone`]。
//! 另一个选择是依靠所涉及的类型，为引用提供其他运算符实现。
//! 例如，对于应该支持加法的用户定义类型 `T`，将 `T` 和 `&T` 都实现 traits [`Add<T>`][`Add`] 和 [`Add<&T>`][`Add`] 可能是一个好主意，这样就可以编写泛型代码而不必进行不必要的克隆。
//!
//!
//! # Examples
//!
//! 本示例创建一个实现 [`Add`] 和 [`Sub`] 的 `Point` 结构体，然后演示加减两个 Point。
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! 有关示例实现，请参见每个 trait 的文档。
//!
//! [`Fn`]，[`FnMut`] 和 [`FnOnce`] traits 由可以像函数一样调用的类型实现。请注意，[`Fn`] 占用 `&self`，[`FnMut`] 占用 `&mut self`，[`FnOnce`] 占用 `self`。
//! 这些对应于可以在实例上调用的三种方法：引用调用、可变引用调用和值调用。
//! 这些 traits 的最常见用法是充当以函数或闭包为参数的高级函数的界限。
//!
//! 以 [`Fn`] 作为参数：
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! 以 [`FnMut`] 作为参数：
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! 以 [`FnOnce`] 作为参数：
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` 消耗其捕获的变量，因此不能多次运行
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // 再次尝试调用 `func()` 将为 `func` 引发 `use of moved value` 错误
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // 此时无法再调用 `consume_and_return_x`
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod try_trait;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "one_sided_range", issue = "69780")]
pub use self::range::OneSidedRange;

#[unstable(feature = "try_trait_v2", issue = "84277")]
pub use self::try_trait::{FromResidual, Try};

#[unstable(feature = "try_trait_v2_yeet", issue = "96374")]
pub use self::try_trait::Yeet;

#[unstable(feature = "try_trait_v2_residual", issue = "91285")]
pub use self::try_trait::Residual;

pub(crate) use self::try_trait::{ChangeOutputType, NeverShortCircuit};

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;
