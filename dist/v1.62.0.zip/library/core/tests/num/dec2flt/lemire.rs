use core::num::dec2flt::lemire::compute_float;

fn compute_float32(q: i64, w: u64) -> (i32, u64) {
    let fp = compute_float::<f32>(q, w);
    (fp.e, fp.f)
}

fn compute_float64(q: i64, w: u64) -> (i32, u64) {
    let fp = compute_float::<f64>(q, w);
    (fp.e, fp.f)
}

#[test]
fn compute_float_f32_rounding() {
    // 这些测试单精度浮点数的接近一半的情况。
    assert_eq!(compute_float32(0, 16777216), (151, 0));
    assert_eq!(compute_float32(0, 16777217), (151, 0));
    assert_eq!(compute_float32(0, 16777218), (151, 1));
    assert_eq!(compute_float32(0, 16777219), (151, 2));
    assert_eq!(compute_float32(0, 16777220), (151, 2));

    // 这些是上述测试的示例，从指数到尾数的数字。
    //
    assert_eq!(compute_float32(-10, 167772160000000000), (151, 0));
    assert_eq!(compute_float32(-10, 167772170000000000), (151, 0));
    assert_eq!(compute_float32(-10, 167772180000000000), (151, 1));
    // 让我们检查一下这些行，看看表中是否有任何不同...
    assert_eq!(compute_float32(-10, 167772190000000000), (151, 2));
    assert_eq!(compute_float32(-10, 167772200000000000), (151, 2));
}

#[test]
fn compute_float_f64_rounding() {
    // 这些测试双精度浮点数的接近一半的情况。
    assert_eq!(compute_float64(0, 9007199254740992), (1076, 0));
    assert_eq!(compute_float64(0, 9007199254740993), (1076, 0));
    assert_eq!(compute_float64(0, 9007199254740994), (1076, 1));
    assert_eq!(compute_float64(0, 9007199254740995), (1076, 2));
    assert_eq!(compute_float64(0, 9007199254740996), (1076, 2));
    assert_eq!(compute_float64(0, 18014398509481984), (1077, 0));
    assert_eq!(compute_float64(0, 18014398509481986), (1077, 0));
    assert_eq!(compute_float64(0, 18014398509481988), (1077, 1));
    assert_eq!(compute_float64(0, 18014398509481990), (1077, 2));
    assert_eq!(compute_float64(0, 18014398509481992), (1077, 2));

    // 这些是上述测试的示例，从指数到尾数的数字。
    //
    assert_eq!(compute_float64(-3, 9007199254740992000), (1076, 0));
    assert_eq!(compute_float64(-3, 9007199254740993000), (1076, 0));
    assert_eq!(compute_float64(-3, 9007199254740994000), (1076, 1));
    assert_eq!(compute_float64(-3, 9007199254740995000), (1076, 2));
    assert_eq!(compute_float64(-3, 9007199254740996000), (1076, 2));
}
