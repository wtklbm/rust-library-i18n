// 其他 Unix (例如
// Linux) 平台使用 ELF 作为对象文件格式，并且通常实现称为 `dl_iterate_phdr` 的 API 来加载原生库。
//

use super::mystd::borrow::ToOwned;
use super::mystd::env;
use super::mystd::ffi::{CStr, OsStr};
use super::mystd::os::unix::prelude::*;
use super::{Library, LibrarySegment, OsString, Vec};
use core::slice;

pub(super) fn native_libraries() -> Vec<Library> {
    let mut ret = Vec::new();
    unsafe {
        libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
    }
    return ret;
}

// `info` 应该是一个有效的指针。
// `vec` 应该是指向 `std::Vec` 的有效指针。
unsafe extern "C" fn callback(
    info: *mut libc::dl_phdr_info,
    _size: libc::size_t,
    vec: *mut libc::c_void,
) -> libc::c_int {
    let info = &*info;
    let libs = &mut *(vec as *mut Vec<Library>);
    let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
    let name = if is_main_prog {
        if libs.is_empty() {
            env::current_exe().map(|e| e.into()).unwrap_or_default()
        } else {
            OsString::new()
        }
    } else {
        let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
        OsStr::from_bytes(bytes).to_owned()
    };
    let headers = slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
    libs.push(Library {
        name,
        segments: headers
            .iter()
            .map(|header| LibrarySegment {
                len: (*header).p_memsz as usize,
                stated_virtual_memory_address: (*header).p_vaddr as usize,
            })
            .collect(),
        bias: info.dlpi_addr as usize,
    });
    0
}
