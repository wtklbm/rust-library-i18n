//! 平台相关的类型。

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// 字符串的平台无关表示。
/// 在启用 `std` 的情况下，建议使用方便的方法来提供到 `std` 类型的转换。
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// 切片，通常在 Unix 平台上提供。
    Bytes(&'a [u8]),
    /// 宽字符串通常来自 Windows。
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// 有损转换为 `Cow<str>`，将在 `Bytes` 无效 UTF-8 或 `BytesOrWideString` 为 `Wide` 时进行分配。
    ///
    /// # 要求的特性
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 特性，并且默认启用 `std` 特性。
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// 提供 `BytesOrWideString` 的 `Path` 表示形式。
    ///
    /// # 要求的特性
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 特性，并且默认启用 `std` 特性。
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}
