// 基于
// https://github.com/matthieu-m/rfc2580/blob/b58d1d3cba0d4b5e859d3617ea2d0943aaa31329/examples/thin.rs
// by matthieu-m
use crate::alloc::{self, Layout, LayoutError};
use core::fmt::{self, Debug, Display, Formatter};
use core::marker::{PhantomData, Unsize};
use core::mem;
use core::ops::{Deref, DerefMut};
use core::ptr::Pointee;
use core::ptr::{self, NonNull};

/// ThinBox.
///
/// 用于堆分配的瘦指针，与 T 无关。
///
/// # Examples
///
/// ```
/// #![feature(thin_box)]
/// use std::boxed::ThinBox;
///
/// let five = ThinBox::new(5);
/// let thin_slice = ThinBox::<[i32]>::new_unsize([1, 2, 3, 4]);
///
/// use std::mem::{size_of, size_of_val};
/// let size_of_ptr = size_of::<*const ()>();
/// assert_eq!(size_of_ptr, size_of_val(&five));
/// assert_eq!(size_of_ptr, size_of_val(&thin_slice));
/// ```
#[unstable(feature = "thin_box", issue = "92791")]
pub struct ThinBox<T: ?Sized> {
    ptr: WithHeader<<T as Pointee>::Metadata>,
    _marker: PhantomData<T>,
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T> ThinBox<T> {
    /// 将类型移动到堆中，其 `Metadata` 存储在堆分配中，而不是栈中。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(thin_box)]
    /// use std::boxed::ThinBox;
    ///
    /// let five = ThinBox::new(5);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    pub fn new(value: T) -> Self {
        let meta = ptr::metadata(&value);
        let ptr = WithHeader::new(meta, value);
        ThinBox { ptr, _marker: PhantomData }
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<Dyn: ?Sized> ThinBox<Dyn> {
    /// 将类型移动到堆中，其 `Metadata` 存储在堆分配中，而不是栈中。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(thin_box)]
    /// use std::boxed::ThinBox;
    ///
    /// let thin_slice = ThinBox::<[i32]>::new_unsize([1, 2, 3, 4]);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    pub fn new_unsize<T>(value: T) -> Self
    where
        T: Unsize<Dyn>,
    {
        let meta = ptr::metadata(&value as &Dyn);
        let ptr = WithHeader::new(meta, value);
        ThinBox { ptr, _marker: PhantomData }
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized + Debug> Debug for ThinBox<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        Debug::fmt(self.deref(), f)
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized + Display> Display for ThinBox<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        Display::fmt(self.deref(), f)
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized> Deref for ThinBox<T> {
    type Target = T;

    fn deref(&self) -> &T {
        let value = self.data();
        let metadata = self.meta();
        let pointer = ptr::from_raw_parts(value as *const (), metadata);
        unsafe { &*pointer }
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized> DerefMut for ThinBox<T> {
    fn deref_mut(&mut self) -> &mut T {
        let value = self.data();
        let metadata = self.meta();
        let pointer = ptr::from_raw_parts_mut::<T>(value as *mut (), metadata);
        unsafe { &mut *pointer }
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized> Drop for ThinBox<T> {
    fn drop(&mut self) {
        unsafe {
            let value = self.deref_mut();
            let value = value as *mut T;
            self.ptr.drop::<T>(value);
        }
    }
}

#[unstable(feature = "thin_box", issue = "92791")]
impl<T: ?Sized> ThinBox<T> {
    fn meta(&self) -> <T as Pointee>::Metadata {
        // Safety:
        //  -   非空且有效。
        unsafe { *self.ptr.header() }
    }

    fn data(&self) -> *mut u8 {
        self.ptr.value()
    }
}

/// 指向 erased 类型数据的指针，保证在指向的位置之前有一个标头 `H`。
struct WithHeader<H>(NonNull<u8>, PhantomData<H>);

impl<H> WithHeader<H> {
    #[cfg(not(no_global_oom_handling))]
    fn new<T>(header: H, value: T) -> WithHeader<H> {
        let value_layout = Layout::new::<T>();
        let Ok((layout, value_offset)) = Self::alloc_layout(value_layout) else {
            // 我们在这里传递一个空布局，因为我们不知道是哪个布局导致了 `Layout::extend` 中的算术溢出，并且 `handle_alloc_error` 将 `Layout` 作为它的参数，而不是 `Result<Layout, LayoutError>`，而且这个函数自 1.28 ._ 以来一直很稳定。
            //
            //
            // 另一方面，看看这条华丽的比目鱼!
            //
            //
            alloc::handle_alloc_error(Layout::new::<()>());
        };

        unsafe {
            let ptr = alloc::alloc(layout);

            if ptr.is_null() {
                alloc::handle_alloc_error(layout);
            }
            // Safety:
            //  -   大小至少为 `aligned_header_size`。
            let ptr = ptr.add(value_offset) as *mut _;

            let ptr = NonNull::new_unchecked(ptr);

            let result = WithHeader(ptr, PhantomData);
            ptr::write(result.header(), header);
            ptr::write(result.value().cast(), value);

            result
        }
    }

    // Safety:
    //  -   假设 `value` 可以被解引用。
    unsafe fn drop<T: ?Sized>(&self, value: *mut T) {
        unsafe {
            // SAFETY: 如果我们正在丢弃，布局必须是可计算的
            let (layout, value_offset) =
                Self::alloc_layout(Layout::for_value_raw(value)).unwrap_unchecked();

            ptr::drop_in_place::<T>(value);
            // 我们之所以丢弃该值，是因为 Pointee trait 要求元数据是可复制的，也就是可轻易丢弃的
            //
            alloc::dealloc(self.0.as_ptr().sub(value_offset), layout);
        }
    }

    fn header(&self) -> *mut H {
        // Safety:
        //  - 在指针之前至少分配了 `size_of::<H>()` 个字节。
        //  - 我们知道 H 将被对齐，因为中间指针与头部和数据的对齐方式中的较大者对齐，并且头部大小包括对齐头部所需的填充。
        //  从对齐的数据指针中减去头大小总是会导致对齐的头指针，它只是可能不指向分配的开始。
        //
        //
        //
        unsafe { self.0.as_ptr().sub(Self::header_size()) as *mut H }
    }

    fn value(&self) -> *mut u8 {
        self.0.as_ptr()
    }

    const fn header_size() -> usize {
        mem::size_of::<H>()
    }

    fn alloc_layout(value_layout: Layout) -> Result<(Layout, usize), LayoutError> {
        Layout::new::<H>().extend(value_layout)
    }
}
