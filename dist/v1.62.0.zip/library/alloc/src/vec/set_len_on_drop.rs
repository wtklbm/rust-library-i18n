// 当 `SetLenOnDrop` 值离开作用域时，设置 vec 的长度。
//
// 这个想法是: SetLenOnDrop 中的 length 字段是一个局部变量，优化器将看到该变量不会通过 Vec 的数据指针与任何存储空间产生别名。
// 这是别名分析问题的解决方法 #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}
