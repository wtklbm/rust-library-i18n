use core::mem::ManuallyDrop;
use core::ptr::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter 使用的专业化 trait
///
/// ## 委托关系图：
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // 常见的情况是将 vector 传递到函数中，该函数立即重新收集到 vector 中。
        // 如果 IntoIter 根本没有改进，我们可以将其短路。
        // 升级后，我们还可以重用内存并将数据移到最前面。
        // 但是，只有在生成的 Vec 没有比通过泛型 FromIterator 实现创建它的未使用容量多的情况下，我们才这样做。
        //
        // 由于故意未指定 Vec 的分配行为，因此此限制并非严格必要。
        // 但这是一个保守的选择。
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // 必须委托给 spec_extend()，因为 extend() 本身委托给空空的 Vecs 的 spec_from
        //
        vec.spec_extend(iterator);
        vec
    }
}
