//! 与 FFI 绑定有关的实用工具。
//!
//! 该模块提供了实用工具来处理跨非 Rust 接口的数据，例如其他编程语言和底层操作系统。它主要用于 FFI (外部函数接口) 绑定和需要与其他语言交换类 C 字符串的代码。
//!
//! # Overview
//!
//! Rust 代表 [`String`] 类型的拥有的字符串，而借用 [`str`] 原语的字符串切片。两者始终都是 UTF-8 编码，并且中间可能包含 nul 个字节，即，如果您查看组成字符串的字节，则其中可能有一个 `\0`。
//! `String` 和 `str` 都明确存储它们的长度。像 C 中的字符串末尾没有 nul 终止符。
//!
//! C 字符串不同于 Rust 字符串：
//!
//! * **编码**-Rust 字符串是 UTF-8，但是 C 字符串可以使用其他编码。如果使用的是来自 C 的字符串，则应显式检查其编码，而不是像在 Rust 中那样假定它是 UTF-8。
//!
//! * **字符大小**-C 字符串可以使用 `char` 或 `wchar_t` 大小的字符； 请 **注意** C 的 `char` 与 Rust 的不同。
//! C 标准使这些类型的实际大小易于解释，但是为由每个字符类型组成的字符串定义了不同的 API。Rust 字符串始终为 UTF-8，因此每个不同的 Unicode 字符将以可变的字节数进行编码。
//! Rust 类型 [`char`] 表示 `[Unicode 标量值]`，与 `[Unicode 代码点]` 相似但不相同。
//!
//! * **Nul 终止符和隐式字符串长度**-C 字符串通常以 Nul 终止，即，它们的末尾有 `\0` 字符。
//! 字符串缓冲区的长度不存储，而是必须计算； 要计算字符串的长度，C 代码必须手动调用一个函数，例如 `strlen()` 表示基于 char 的字符串，`wcslen()` 表示基于 wchar_t 的字符串。
//! 这些函数返回字符串中不包括 nul 终止符的字符数，因此缓冲区长度实际上是 `len+1` 字符。
//! Rust 字符串没有 nul 终止符； 它们的长度总是存储的，不需要计算。
//! 而在 Rust 中，访问字符串的长度是一个 *O*(1) 操作 (因为长度是被存储的) ； 在 C 中，它是一个 *O*(*n*) 操作，因为需要通过扫描字符串中的 nul 终止符来计算长度。
//!
//! * **内部 nul 字符**- 当 C 字符串具有 nul 终止符时，这通常意味着它们中间不能包含 nul 字符 - nul 字符实际上会截断字符串。
//! Rust 字符串 *可以* 中间有 nul 个字符，因为 nul 不必在 Rust 中标记字符串的结尾。
//!
//! # 非 Rust 字符串的表示形式
//!
//! [`CString`] 和 [`CStr`] 在您需要将 UTF-8 字符串与带有 C ABI 的语言 (如 Python) 相互传输时很有用。
//!
//! * **从 Rust 到 C:**[`CString`] 表示一个拥有的，对 C 友好的字符串：它是 nul 终止的，并且没有内部 nul 字符。
//! Rust 代码可以从一个普通字符串中创建一个 [`CString`] (前提是该字符串中间没有 nul 字符)，然后使用多种方法获得一个原始的 <code>\*mut [u8]</code>，然后可以作为参数传递给使用字符串的 C 约定的函数。
//!
//!
//! * **从 C 到 Rust:**[`CStr`] 表示借用的 C 字符串； 它是您用来包装从 C 函数获得的原始 <code>\*const [u8]</code> 的内容。[`CStr`] 保证是一个以 nul 结尾的字节数组。
//! 一旦您有了 [`CStr`]，您可以将它转换为 Rust <code>&[str]</code>，如果它是有效的 UTF-8，或者通过添加替换字符来有损地转换它。
//!
//! [`String`]: crate::string::String
//! [`CStr`]: core::ffi::CStr
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(feature = "alloc_ffi", issue = "94079")]

#[cfg(bootstrap)]
#[unstable(feature = "cstr_internals", issue = "none")]
pub use self::c_str::CStrExt;
#[unstable(feature = "alloc_c_string", issue = "94079")]
pub use self::c_str::FromVecWithNulError;
#[unstable(feature = "alloc_c_string", issue = "94079")]
pub use self::c_str::{CString, IntoStringError, NulError};

mod c_str;
