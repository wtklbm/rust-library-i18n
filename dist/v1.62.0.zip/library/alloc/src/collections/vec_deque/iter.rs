use core::fmt;
use core::iter::{FusedIterator, TrustedLen, TrustedRandomAccess, TrustedRandomAccessNoCoerce};
use core::mem::MaybeUninit;
use core::ops::Try;

use super::{count, wrap_index, RingSlices};

/// `VecDeque` 元素上的迭代器。
///
/// 该 `struct` 是通过 [`super::VecDeque`] 上的 [`iter`] 方法创建的。
/// 有关更多信息，请参见其文档。
///
/// [`iter`]: super::VecDeque::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    pub(crate) ring: &'a [MaybeUninit<T>],
    pub(crate) tail: usize,
    pub(crate) head: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let (front, back) = RingSlices::ring_slices(self.ring, self.head, self.tail);
        // Safety:
        // - 环形缓冲区中的 `self.head` 和 `self.tail` 始终是有效索引。
        // - `RingSlices::ring_slices` 保证根据 `self.head` 和 `self.tail` 分割的切片被初始化。
        unsafe {
            f.debug_tuple("Iter")
                .field(&MaybeUninit::slice_assume_init_ref(front))
                .field(&MaybeUninit::slice_assume_init_ref(back))
                .finish()
        }
    }
}

// FIXME(#26925) 删除以支持 `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ring: self.ring, tail: self.tail, head: self.head }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.tail == self.head {
            return None;
        }
        let tail = self.tail;
        self.tail = wrap_index(self.tail.wrapping_add(1), self.ring.len());
        // Safety:
        // - 环形缓冲区中的 `self.tail` 始终是有效索引。
        // - 上面检查了 `self.head` 和 `self.tail` 是否相等。
        unsafe { Some(self.ring.get_unchecked(tail).assume_init_ref()) }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = count(self.tail, self.head, self.ring.len());
        (len, Some(len))
    }

    fn fold<Acc, F>(self, mut accum: Acc, mut f: F) -> Acc
    where
        F: FnMut(Acc, Self::Item) -> Acc,
    {
        let (front, back) = RingSlices::ring_slices(self.ring, self.head, self.tail);
        // Safety:
        // - 环形缓冲区中的 `self.head` 和 `self.tail` 始终是有效索引。
        // - `RingSlices::ring_slices` 保证根据 `self.head` 和 `self.tail` 分割的切片被初始化。
        unsafe {
            accum = MaybeUninit::slice_assume_init_ref(front).iter().fold(accum, &mut f);
            MaybeUninit::slice_assume_init_ref(back).iter().fold(accum, &mut f)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Output = B>,
    {
        let (mut iter, final_res);
        if self.tail <= self.head {
            // 安全性: 单个切片 self.ring [self.tail..self.head] 已初始化。
            iter = unsafe { MaybeUninit::slice_assume_init_ref(&self.ring[self.tail..self.head]) }
                .iter();
            final_res = iter.try_fold(init, &mut f);
        } else {
            // 安全性: 两个切片: self.ring [self.tail..]、self.ring [..self.head] 都已初始化。
            let (front, back) = self.ring.split_at(self.tail);

            let mut back_iter = unsafe { MaybeUninit::slice_assume_init_ref(back).iter() };
            let res = back_iter.try_fold(init, &mut f);
            let len = self.ring.len();
            self.tail = (self.ring.len() - back_iter.len()) & (len - 1);
            iter = unsafe { MaybeUninit::slice_assume_init_ref(&front[..self.head]).iter() };
            final_res = iter.try_fold(res?, &mut f);
        }
        self.tail = self.head - iter.len();
        final_res
    }

    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        if n >= count(self.tail, self.head, self.ring.len()) {
            self.tail = self.head;
            None
        } else {
            self.tail = wrap_index(self.tail.wrapping_add(n), self.ring.len());
            self.next()
        }
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        // 安全性: TrustedRandomAccess 契约要求调用者只传递一个在边界内的索引。
        //
        unsafe {
            let idx = wrap_index(self.tail.wrapping_add(idx), self.ring.len());
            self.ring.get_unchecked(idx).assume_init_ref()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.tail == self.head {
            return None;
        }
        self.head = wrap_index(self.head.wrapping_sub(1), self.ring.len());
        // Safety:
        // - 环形缓冲区中的 `self.head` 始终是有效索引。
        // - 上面检查了 `self.head` 和 `self.tail` 是否相等。
        unsafe { Some(self.ring.get_unchecked(self.head).assume_init_ref()) }
    }

    fn rfold<Acc, F>(self, mut accum: Acc, mut f: F) -> Acc
    where
        F: FnMut(Acc, Self::Item) -> Acc,
    {
        let (front, back) = RingSlices::ring_slices(self.ring, self.head, self.tail);
        // Safety:
        // - 环形缓冲区中的 `self.head` 和 `self.tail` 始终是有效索引。
        // - `RingSlices::ring_slices` 保证根据 `self.head` 和 `self.tail` 分割的切片被初始化。
        unsafe {
            accum = MaybeUninit::slice_assume_init_ref(back).iter().rfold(accum, &mut f);
            MaybeUninit::slice_assume_init_ref(front).iter().rfold(accum, &mut f)
        }
    }

    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Output = B>,
    {
        let (mut iter, final_res);
        if self.tail <= self.head {
            // 安全性: 单个切片 self.ring [self.tail..self.head] 已初始化。
            iter = unsafe {
                MaybeUninit::slice_assume_init_ref(&self.ring[self.tail..self.head]).iter()
            };
            final_res = iter.try_rfold(init, &mut f);
        } else {
            // 安全性: 两个切片: self.ring [self.tail..]、self.ring [..self.head] 都已初始化。
            let (front, back) = self.ring.split_at(self.tail);

            let mut front_iter =
                unsafe { MaybeUninit::slice_assume_init_ref(&front[..self.head]).iter() };
            let res = front_iter.try_rfold(init, &mut f);
            self.head = front_iter.len();
            iter = unsafe { MaybeUninit::slice_assume_init_ref(back).iter() };
            final_res = iter.try_rfold(res?, &mut f);
        }
        self.head = self.tail + iter.len();
        final_res
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.head == self.tail
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Iter<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<T> TrustedRandomAccess for Iter<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<T> TrustedRandomAccessNoCoerce for Iter<'_, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}
