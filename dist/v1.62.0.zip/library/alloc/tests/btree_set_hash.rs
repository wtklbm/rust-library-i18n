use crate::hash;
use std::collections::BTreeSet;

#[test]
fn test_hash() {
    let mut x = BTreeSet::new();
    let mut y = BTreeSet::new();

    x.insert(1);
    x.insert(2);
    x.insert(3);

    y.insert(3);
    y.insert(2);
    y.insert(1);

    assert_eq!(hash(&x), hash(&y));
}

#[test]
fn test_prefix_free() {
    let x = BTreeSet::from([1, 2, 3]);
    let y = BTreeSet::<i32>::new();

    // 如果单独通过迭代进行散列，`(x, y)` 和 `(y, x)` 将访问相同顺序的元素，从而产生相同的散列。
    // 但是现在我们也对长度进行了散列，他们得到了不同的散列数据序列。
    //
    assert_ne!(hash(&(&x, &y)), hash(&(&y, &x)));
}
