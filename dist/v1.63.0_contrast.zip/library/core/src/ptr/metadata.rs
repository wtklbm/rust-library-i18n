#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Provides the pointer metadata type of any pointed-to type. <br>提供任何指向类型的指针元数据类型。<br>
///
/// # Pointer metadata <br>指针元数据<br>
///
/// Raw pointer types and reference types in Rust can be thought of as made of two parts: <br>Rust 中的裸指针类型和引用类型可以认为是由两部分组成：<br>
/// a data pointer that contains the memory address of the value, and some metadata. <br>包含该值的内存地址和一些元数据的数据指针。<br>
///
/// For statically-sized types (that implement the `Sized` traits) as well as for `extern` types, pointers are said to be “thin”: metadata is zero-sized and its type is `()`. <br>对于静态大小的类型 (实现 `Sized` traits) 以及 `extern` 类型，指针被称为 `thin`: 元数据的大小为零，其类型为 `()`。<br>
///
///
/// Pointers to [dynamically-sized types][dst] are said to be “wide” or “fat”, they have non-zero-sized metadata: <br>指向 [动态大小的类型][dst] 的指针被称为 `wide` 或 `fat`，它们具有非零大小的元数据：<br>
///
/// * For structs whose last field is a DST, metadata is the metadata for the last field <br>对于最后一个字段是 DST 的结构体，元数据是最后一个字段的元数据<br>
/// * For the `str` type, metadata is the length in bytes as `usize` <br>对于 `str` 类型，元数据是 `usize` 的长度 (以字节为单位)<br>
/// * For slice types like `[T]`, metadata is the length in items as `usize` <br>对于 `[T]` 之类的切片类型，元数据是 `usize` 中项的长度<br>
/// * For trait objects like `dyn SomeTrait`, metadata is [`DynMetadata<Self>`][DynMetadata] (e.g. `DynMetadata<dyn SomeTrait>`) <br>对于 `dyn SomeTrait` 之类的 trait 对象，元数据为 [`DynMetadata<Self>`][DynMetadata] (例如 `DynMetadata<dyn SomeTrait>`)<br>
///
/// In the future, the Rust language may gain new kinds of types that have different pointer metadata. <br>在 future 中，Rust 语言可能会获得具有不同指针元数据的新型类型。<br>
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # The `Pointee` trait
///
/// The point of this trait is its `Metadata` associated type, which is `()` or `usize` or `DynMetadata<_>` as described above. <br>这个 trait 的重点是它的 `Metadata` 关联类型，像上面讲的一样，它是 `()` 或 `usize` 或 `DynMetadata<_>`。<br>
/// It is automatically implemented for every type. <br>它会针对每种类型自动实现。<br>
/// It can be assumed to be implemented in a generic context, even without a corresponding bound. <br>即使没有相应的限制，也可以假定它是在泛型上下文中实现的。<br>
///
/// # Usage
///
/// Raw pointers can be decomposed into the data address and metadata components with their [`to_raw_parts`] method. <br>可以使用 [`to_raw_parts`] 方法将裸指针分解为数据地址和元数据组件。<br>
///
/// Alternatively, metadata alone can be extracted with the [`metadata`] function. <br>或者，可以使用 [`metadata`] 函数单独提取元数据。<br>
/// A reference can be passed to [`metadata`] and implicitly coerced. <br>可以将引用传递给 [`metadata`] 并进行隐式强制。<br>
///
/// A (possibly-wide) pointer can be put back together from its address and metadata with [`from_raw_parts`] or [`from_raw_parts_mut`]. <br>可以使用 [`from_raw_parts`] 或 [`from_raw_parts_mut`] 将 (possibly-wide) 指针从其地址和元数据放回原处。<br>
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// The type for metadata in pointers and references to `Self`. <br>指针中的元数据类型，并引用 `Self`。<br>
    #[lang = "metadata_type"]
    // NOTE: Keep trait bounds in `static_assert_expected_bounds_for_metadata` in `library/core/src/ptr/metadata.rs` in sync with those here: <br>保持 `library/core/src/ptr/metadata.rs` 中 `static_assert_expected_bounds_for_metadata` 中的 trait bounds 与此处的同步：<br>
    //
    //
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Pointers to types implementing this trait alias are “thin”. <br>实现此 trait 别名的类型的指针为 `thin`。<br>
///
/// This includes statically-`Sized` types and `extern` types. <br>这包括静态 `Sized` 类型和 `extern` 类型。<br>
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: don’t stabilize this before trait aliases are stable in the language? <br>在 trait 别名在语言中稳定之前难道不能稳定它吗？<br>
pub trait Thin = Pointee<Metadata = ()>;

/// Extract the metadata component of a pointer. <br>提取指针的元数据组件。<br>
///
/// Values of type `*mut T`, `&T`, or `&mut T` can be passed directly to this function as they implicitly coerce to `*const T`. <br>`*mut T`，`&T` 或 `&mut T` 类型的值可以隐式强制转换为 `*const T`，因此可以直接传递给此函数。<br>
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SAFETY: Accessing the value from the `PtrRepr` union is safe since *const T and PtrComponents<T> have the same memory layouts. <br>因为 *const T 和 PtrComponents<T> 具有相同的内存布局，所以从 `PtrRepr` union 访问值是安全的。<br>
    // Only std can make this guarantee. <br>只有 std 可以做出此保证。<br>
    //
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Forms a (possibly-wide) raw pointer from a data address and metadata. <br>根据数据地址和元数据形成 (possibly-wide) 裸指针。<br>
///
/// This function is safe but the returned pointer is not necessarily safe to dereference. <br>此函数是安全的，但是返回的指针对于解引用并不一定是安全的。<br>
/// For slices, see the documentation of [`slice::from_raw_parts`] for safety requirements. <br>对于切片，请参见 [`slice::from_raw_parts`] 的文档以了解安全要求。<br>
/// For trait objects, the metadata must come from a pointer to the same underlying erased type. <br>对于 trait 对象，元数据必须来自指向相同底层 erased 类型的指针。<br>
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SAFETY: Accessing the value from the `PtrRepr` union is safe since *const T and PtrComponents<T> have the same memory layouts. <br>因为 *const T 和 PtrComponents<T> 具有相同的内存布局，所以从 `PtrRepr` union 访问值是安全的。<br>
    // Only std can make this guarantee. <br>只有 std 可以做出此保证。<br>
    //
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Performs the same functionality as [`from_raw_parts`], except that a raw `*mut` pointer is returned, as opposed to a raw `*const` pointer. <br>执行与 [`from_raw_parts`] 相同的功能，除了返回原始 `*mut` 指针 (与原始 `*const` 指针相反) 之外。<br>
///
///
/// See the documentation of [`from_raw_parts`] for more details. <br>有关更多详细信息，请参见 [`from_raw_parts`] 的文档。<br>
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SAFETY: Accessing the value from the `PtrRepr` union is safe since *const T and PtrComponents<T> have the same memory layouts. <br>因为 *const T 和 PtrComponents<T> 具有相同的内存布局，所以从 `PtrRepr` union 访问值是安全的。<br>
    // Only std can make this guarantee. <br>只有 std 可以做出此保证。<br>
    //
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manual impl needed to avoid `T: Copy` bound. <br>需要避免 `T: Copy` 绑定的手动提示。<br>
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manual impl needed to avoid `T: Clone` bound. <br>需要避免 `T: Clone` 绑定的手动提示。<br>
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// The metadata for a `Dyn = dyn SomeTrait` trait object type. <br>`Dyn = dyn SomeTrait` trait 对象类型的元数据。<br>
///
/// It is a pointer to a vtable (virtual call table) that represents all the necessary information to manipulate the concrete type stored inside a trait object. <br>它是指向 vtable (虚拟调用表) 的指针，该表表示操作存储在 trait 对象内部的具体类型所需的所有信息。<br>
/// The vtable notably it contains: <br>该 vtable 尤其包含：<br>
///
/// * type size <br>类型大小<br>
/// * type alignment <br>类型对齐<br>
/// * a pointer to the type’s `drop_in_place` impl (may be a no-op for plain-old-data) <br>指向该类型的 `drop_in_place` impl 的指针 (对于纯旧数据，它可能是 no-op)<br>
/// * pointers to all the methods for the type’s implementation of the trait <br>指向 trait 类型实现的所有方法的指针<br>
///
/// Note that the first three are special because they’re necessary to allocate, drop, and deallocate any trait object. <br>请注意，前三个是特殊的，因为它们是分配，丢弃和释放任何 trait 对象所必需的。<br>
///
/// It is possible to name this struct with a type parameter that is not a `dyn` trait object (for example `DynMetadata<u64>`) but not to obtain a meaningful value of that struct. <br>可以使用不是 `dyn` trait 对象 (例如 `DynMetadata<u64>`) 的类型参数来命名此结构体，但不能获得该结构体的有意义的值。<br>
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// The common prefix of all vtables. <br>所有 vtable 的通用前缀。<br> It is followed by function pointers for trait methods. <br>其后是 trait 方法的函数指针。<br>
///
/// Private implementation detail of `DynMetadata::size_of` etc. <br>`DynMetadata::size_of` 等的私有实现详细信息<br>
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Returns the size of the type associated with this vtable. <br>返回与此 vtable 关联的类型的大小。<br>
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Returns the alignment of the type associated with this vtable. <br>返回与此 vtable 关联的类型的对齐方式。<br>
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Returns the size and alignment together as a `Layout` <br>将大小和对齐方式一起返回为 `Layout`<br>
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SAFETY: the compiler emitted this vtable for a concrete Rust type which is known to have a valid layout. <br>编译器针对特定的 Rust 类型发出此 vtable，已知该类型具有有效的布局。<br>
        // Same rationale as in `Layout::for_value`. <br>与 `Layout::for_value` 中的原理相同。<br>
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manual impls needed to avoid `Dyn: $Trait` bounds. <br>避免 `Dyn: $Trait` 边界所需的手动提示。<br>

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}
