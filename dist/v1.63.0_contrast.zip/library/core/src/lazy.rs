//! Lazy values and one-time initialization of static data. <br>惰性值和静态数据的一次性初始化。<br>
