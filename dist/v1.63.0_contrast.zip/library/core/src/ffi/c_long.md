Equivalent to C's `signed long` (`long`) type. <br>等效于 C 的 `signed long` (`long`) 类型。<br>

This type will always be [`i32`] or [`i64`]. <br>此类型将始终为 [`i32`] 或 [`i64`]。<br> Most notably, many Linux-based systems assume an `i64`, but Windows assumes `i32`. <br>最值得注意的是，许多基于 Linux 的系统都使用 `i64`，但 Windows 则使用 `i32`。<br> The C standard technically only requires that this type be a signed integer that is at least 32 bits and at least the size of an [`int`], although in practice, no system would have a `long` that is neither an `i32` nor `i64`. <br>从技术上讲，C 标准仅要求该类型为至少 32 位且至少为 [`int`] 大小的有符号整数，尽管实际上，没有系统会拥有既不是 `i32` 也不是 `i64` 的 `long`。<br>

[`int`]: c_int
