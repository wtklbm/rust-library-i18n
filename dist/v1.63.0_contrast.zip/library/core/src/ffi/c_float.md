Equivalent to C's `float` type. <br>等效于 C 的 `float` 类型。<br>

This type will almost always be [`f32`], which is guaranteed to be an [IEEE-754 single-precision float] in Rust. <br>此类型几乎总是 [`f32`]，并保证它是 Rust 中的 [IEEE-754 单精度浮点数][IEEE-754 single-precision float]。<br> That said, the standard technically only guarantees that it be a floating-point number, and it may have less precision than `f32` or not follow the IEEE-754 standard at all. <br>就是说，该标准从技术上仅保证它是浮点数，并且它的精度可能低于 `f32` 或完全不遵循 IEEE-754 标准。<br>

[IEEE-754 single-precision float]: https://en.wikipedia.org/wiki/IEEE_754
