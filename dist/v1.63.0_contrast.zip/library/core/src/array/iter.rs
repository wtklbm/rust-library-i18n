//! Defines the `IntoIter` owned iterator for arrays. <br>为数组定义 `IntoIter` 拥有的迭代器。<br>

use crate::{
    cmp, fmt,
    iter::{self, ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A by-value [array] iterator. <br>一个按值的 [array] 迭代器。<br>
#[stable(feature = "array_value_iter", since = "1.51.0")]
#[rustc_insignificant_dtor]
pub struct IntoIter<T, const N: usize> {
    /// This is the array we are iterating over. <br>这是我们要遍历的数组。<br>
    ///
    /// Elements with index `i` where `alive.start <= i < alive.end` have not been yielded yet and are valid array entries. <br>索引为 `i` 的元素 (尚未生成 `alive.start <= i < alive.end`) 是有效的数组条目。<br>
    /// Elements with indices `i < alive.start` or `i >= alive.end` have been yielded already and must not be accessed anymore! <br>索引为 `i < alive.start` 或 `i >= alive.end` 的元素已经产生，不能再访问了！<br> Those dead elements might even be in a completely uninitialized state! <br>那些死元素甚至可能处于完全未初始化的状态！<br>
    ///
    ///
    /// So the invariants are: <br>因此，不变量是：<br>
    /// - `data[alive]` is alive (i.e. contains valid elements) <br>`data[alive]` 是活动的 (即包含有效元素)<br>
    /// - `data[..alive.start]` and `data[alive.end..]` are dead (i.e. the elements were already read and must not be touched anymore!) <br>`data[..alive.start]` 和 `data[alive.end..]` 已经失效 (即元素已被读取，不能再被触碰！)<br>
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// The elements in `data` that have not been yielded yet. <br>`data` 中尚未产生的元素。<br>
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

// Note: the `#[rustc_skip_array_during_method_dispatch]` on `trait IntoIterator` hides this implementation from explicit `.into_iter()` calls on editions < 2021, so those calls will still resolve to the slice implementation, by reference. <br>`trait IntoIterator` 上的 `#[rustc_skip_array_during_method_dispatch]` 对小于 2021 的版本显式 `.into_iter()` 调用隐藏了此实现，因此这些调用仍将通过引用解析为 slice 实现。<br>
//
//
#[stable(feature = "array_into_iter_impl", since = "1.53.0")]
impl<T, const N: usize> IntoIterator for [T; N] {
    type Item = T;
    type IntoIter = IntoIter<T, N>;

    /// Creates a consuming iterator, that is, one that moves each value out of the array (from start to end). <br>创建一个消费迭代器，即将每个值移出数组 (从开始到结束)。<br>
    /// The array cannot be used after calling this unless `T` implements `Copy`, so the whole array is copied. <br>除非 `T` 实现了 `Copy`，否则调用此数组后不能使用数组，因此整个数组都会被复制。<br>
    ///
    ///
    /// Arrays have special behavior when calling `.into_iter()` prior to the <br>在调用 `.into_iter()` 之前，数组具有特殊行为<br>
    /// 2021 edition -- see the [array] Editions section for more information. <br>2021 版 -- 有关更多信息，请参见 [array] 版本部分。<br>
    ///
    /// [array]: prim@array
    fn into_iter(self) -> Self::IntoIter {
        // SAFETY: The transmute here is actually safe. <br>此处的转换实际上是安全的。<br> The docs of `MaybeUninit` promise: <br>`MaybeUninit` promise 的文档：<br>
        //
        // > `MaybeUninit<T>` is guaranteed to have the same size and alignment <br>`MaybeUninit<T>` 保证具有相同的大小和对齐方式<br>
        // > as `T`. <br>作为 `T`。<br>
        //
        // The docs even show a transmute from an array of `MaybeUninit<T>` to an array of `T`. <br>该文档甚至显示了从 `MaybeUninit<T>` 数组到 `T` 数组的转换。<br>
        //
        //
        // With that, this initialization satisfies the invariants. <br>这样，该初始化就满足了不变性。<br>
        //

        // FIXME(LukasKalbertodt): actually use `mem::transmute` here, once it works with const generics:     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)` <br>在这里实际使用 `mem::transmute`，一旦它与 const 泛型一起工作: `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`<br>
        //
        //
        // Until then, we can use `mem::transmute_copy` to create a bitwise copy as a different type, then forget `array` so that it is not dropped. <br>在此之前，我们可以使用 `mem::transmute_copy` 创建不同类型的按位副本，然后忘记 `array`，这样它就不会被丢弃。<br>
        //
        //
        unsafe {
            let iter = IntoIter { data: mem::transmute_copy(&self), alive: 0..N };
            mem::forget(self);
            iter
        }
    }
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Creates a new iterator over the given `array`. <br>在给定的 `array` 上创建一个新的迭代器。<br>
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    #[deprecated(since = "1.59.0", note = "use `IntoIterator::into_iter` instead")]
    pub fn new(array: [T; N]) -> Self {
        IntoIterator::into_iter(array)
    }

    /// Creates an iterator over the elements in a partially-initialized buffer. <br>在部分初始化的缓冲区中的元素上创建迭代器。<br>
    ///
    /// If you have a fully-initialized array, then use [`IntoIterator`]. <br>如果您有一个完全初始化的数组，则使用 [`IntoIterator`]。<br>
    /// But this is useful for returning partial results from unsafe code. <br>但这对于从不安全代码中返回部分结果很有用。<br>
    ///
    /// # Safety
    ///
    /// - The `buffer[initialized]` elements must all be initialized. <br>`buffer[initialized]` 元素必须全部初始化。<br>
    /// - The range must be canonical, with `initialized.start <= initialized.end`. <br>范围必须是规范的，并带有 `initialized.start <= initialized.end`。<br>
    /// - The range must be in-bounds for the buffer, with `initialized.end <= N`. <br>该范围必须在缓冲区的界限内，同时 `initialized.end <= N`。<br>
    ///   (Like how indexing `[0][100..100]` fails despite the range being empty.) <br>(就像索引 `[0][100..100]` 失败一样，尽管范围为空。)<br>
    ///
    /// It's sound to have more elements initialized than mentioned, though that will most likely result in them being leaked. <br>初始化的元素比提到的多是合理的，尽管这很可能会导致它们被泄露。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_into_iter_constructors)]
    ///
    /// #![feature(maybe_uninit_array_assume_init)]
    /// #![feature(maybe_uninit_uninit_array)]
    /// use std::array::IntoIter;
    /// use std::mem::MaybeUninit;
    ///
    /// # // Hi!  Thanks for reading the code. <br>您好！感谢您阅读代码。<br> This is restricted to `Copy` because <br>这仅限于 `Copy`，因为<br>
    /// # // otherwise it could leak. <br>否则可能会泄漏。<br> A fully-general version this would need a drop <br>一个完全通用的版本，这需要一个丢弃<br>
    /// # // guard to handle panics from the iterator, but this works for an example. <br>守卫处理来自迭代器的 panics，但这仅适用于示例。<br>
    /// fn next_chunk<T: Copy, const N: usize>(
    ///     it: &mut impl Iterator<Item = T>,
    /// ) -> Result<[T; N], IntoIter<T, N>> {
    ///     let mut buffer = MaybeUninit::uninit_array();
    ///     let mut i = 0;
    ///     while i < N {
    ///         match it.next() {
    ///             Some(x) => {
    ///                 buffer[i].write(x);
    ///                 i += 1;
    ///             }
    ///             None => {
    ///                 // SAFETY: We've initialized the first `i` items <br>我们已经初始化了第一个 `i` 项<br>
    ///                 unsafe {
    ///                     return Err(IntoIter::new_unchecked(buffer, 0..i));
    ///                 }
    ///             }
    ///         }
    ///     }
    ///
    ///     // SAFETY: We've initialized all N items <br>我们已经初始化了所有 N 项<br>
    ///     unsafe { Ok(MaybeUninit::array_assume_init(buffer)) }
    /// }
    ///
    /// let r: [_; 4] = next_chunk(&mut (10..16)).unwrap();
    /// assert_eq!(r, [10, 11, 12, 13]);
    /// let r: IntoIter<_, 40> = next_chunk(&mut (10..16)).unwrap_err();
    /// assert_eq!(r.collect::<Vec<_>>(), vec![10, 11, 12, 13, 14, 15]);
    /// ```
    #[unstable(feature = "array_into_iter_constructors", issue = "91583")]
    #[rustc_const_unstable(feature = "const_array_into_iter_constructors", issue = "91583")]
    pub const unsafe fn new_unchecked(
        buffer: [MaybeUninit<T>; N],
        initialized: Range<usize>,
    ) -> Self {
        Self { data: buffer, alive: initialized }
    }

    /// Creates an iterator over `T` which returns no elements. <br>在 `T` 上创建一个迭代器，该迭代器不返回任何元素。<br>
    /// If you just need an empty iterator, then use [`iter::empty()`](crate::iter::empty) instead. <br>如果您只需要一个空的迭代器，请使用 [`iter::empty()`](crate::iter::empty)。<br>
    /// And if you need an empty array, use `[]`. <br>如果您需要一个空数组，请使用 `[]`。<br>
    ///
    /// But this is useful when you need an `array::IntoIter<T, N>` *specifically*. <br>但是当您需要 `array::IntoIter<T, N>` 时，这非常有用。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_into_iter_constructors)]
    /// use std::array::IntoIter;
    ///
    /// let empty = IntoIter::<i32, 3>::empty();
    /// assert_eq!(empty.len(), 0);
    /// assert_eq!(empty.as_slice(), &[]);
    ///
    /// let empty = IntoIter::<std::convert::Infallible, 200>::empty();
    /// assert_eq!(empty.len(), 0);
    /// ```
    ///
    /// `[1, 2].into_iter()` and `[].into_iter()` have different types <br>`[1, 2].into_iter()` 和 `[].into_iter()` 有不同的类型<br>
    ///
    /// ```should_fail,edition2021
    /// #![feature(array_into_iter_constructors)]
    /// use std::array::IntoIter;
    ///
    /// pub fn get_bytes(b: bool) -> IntoIter<i8, 4> {
    ///     if b {
    ///         [1, 2, 3, 4].into_iter()
    ///     } else {
    ///         [].into_iter() // error[E0308]: mismatched types <br>error[E0308]: 类型不匹配<br>
    ///     }
    /// }
    /// ```
    ///
    /// But using this method you can get an empty iterator of appropriate size: <br>但是，使用此方法您可以得到一个适当大小的空迭代器：<br>
    ///
    /// ```edition2021
    /// #![feature(array_into_iter_constructors)]
    /// use std::array::IntoIter;
    ///
    /// pub fn get_bytes(b: bool) -> IntoIter<i8, 4> {
    ///     if b {
    ///         [1, 2, 3, 4].into_iter()
    ///     } else {
    ///         IntoIter::empty()
    ///     }
    /// }
    ///
    /// assert_eq!(get_bytes(true).collect::<Vec<_>>(), vec![1, 2, 3, 4]);
    /// assert_eq!(get_bytes(false).collect::<Vec<_>>(), vec![]);
    /// ```
    #[unstable(feature = "array_into_iter_constructors", issue = "91583")]
    #[rustc_const_unstable(feature = "const_array_into_iter_constructors", issue = "91583")]
    pub const fn empty() -> Self {
        let buffer = MaybeUninit::uninit_array();
        let initialized = 0..0;

        // SAFETY: We're telling it that none of the elements are initialized, which is trivially true. <br>我们告诉它，没有任何一个元素被初始化，这是非常正确的。<br>
        // And ∀N: usize, 0 <= N. <br>And ∀N: usize, 0 <= N。<br>
        unsafe { Self::new_unchecked(buffer, initialized) }
    }

    /// Returns an immutable slice of all elements that have not been yielded yet. <br>返回尚未产生的所有元素的不可变切片。<br>
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SAFETY: We know that all elements within `alive` are properly initialized. <br>我们知道 `alive` 中的所有元素都已正确初始化。<br>
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Returns a mutable slice of all elements that have not been yielded yet. <br>返回尚未生成的所有元素的可变切片。<br>
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SAFETY: We know that all elements within `alive` are properly initialized. <br>我们知道 `alive` 中的所有元素都已正确初始化。<br>
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Get the next index from the front. <br>从前面获取下一个索引。<br>
        //
        // Increasing `alive.start` by 1 maintains the invariant regarding `alive`. <br>`alive.start` 增加 1 将保持 `alive` 的不变性。<br>
        // However, due to this change, for a short time, the alive zone is not `data[alive]` anymore, but `data[idx..alive.end]`. <br>但是，由于此更改，在短时间内，活动区域不再是 `data[alive]`，而是 `data[idx..alive.end]`。<br>
        //
        self.alive.next().map(|idx| {
            // Read the element from the array. <br>从数组中读取元素。<br>
            // SAFETY: `idx` is an index into the former "alive" region of the array. <br>`idx` 是数组前 "alive" 区域的索引。<br>
            // Reading this element means that `data[idx]` is regarded as dead now (i.e. <br>读取此元素意味着 `data[idx]` 现在被视为已失效 (即<br>
            // do not touch). <br>请勿触摸)。<br>
            // As `idx` was the start of the alive-zone, the alive zone is now `data[alive]` again, restoring all invariants. <br>由于 `idx` 是活动区域的开始，因此活动区域现在又是 `data[alive]`，恢复了所有不变量。<br>
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    #[inline]
    fn fold<Acc, Fold>(mut self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let data = &mut self.data;
        iter::ByRefSized(&mut self.alive).fold(init, |acc, idx| {
            // SAFETY: idx is obtained by folding over the `alive` range, which implies the value is currently considered alive but as the range is being consumed each value we read here will only be read once and then considered dead. <br>idx 是通过折叠 `alive` 范围获得的，这意味着该值当前被认为是活动的，但是随着范围被消耗，我们在这里读取的每个值只会被读取一次，然后被认为是死的。<br>
            //
            //
            fold(acc, unsafe { data.get_unchecked(idx).assume_init_read() })
        })
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }

    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        let len = self.len();

        // The number of elements to drop. <br>要丢弃的元素数量。<br> Always in-bounds by construction. <br>总是在施工范围内。<br>
        let delta = cmp::min(n, len);

        let range_to_drop = self.alive.start..(self.alive.start + delta);

        // Moving the start marks them as conceptually "dropped", so if anything goes bad then our drop impl won't double-free them. <br>移动开始标记会在概念上将它们标记为 "dropped"，因此如果出现任何问题，我们的 drop impl 将不会双重释放它们。<br>
        //
        self.alive.start += delta;

        // SAFETY: These elements are currently initialized, so it's fine to drop them. <br>这些元素当前已初始化，因此可以将它们丢弃。<br>
        unsafe {
            let slice = self.data.get_unchecked_mut(range_to_drop);
            ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(slice));
        }

        if n > len { Err(len) } else { Ok(()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Get the next index from the back. <br>从后面获取下一个索引。<br>
        //
        // Decreasing `alive.end` by 1 maintains the invariant regarding `alive`. <br>`alive.end` 减 1 保持 `alive` 不变。<br>
        // However, due to this change, for a short time, the alive zone is not `data[alive]` anymore, but `data[alive.start..=idx]`. <br>但是，由于此更改，在短时间内，活动区域不再是 `data[alive]`，而是 `data[alive.start..=idx]`。<br>
        //
        self.alive.next_back().map(|idx| {
            // Read the element from the array. <br>从数组中读取元素。<br>
            // SAFETY: `idx` is an index into the former "alive" region of the array. <br>`idx` 是数组前 "alive" 区域的索引。<br>
            // Reading this element means that `data[idx]` is regarded as dead now (i.e. <br>读取此元素意味着 `data[idx]` 现在被视为已失效 (即<br>
            // do not touch). <br>请勿触摸)。<br>
            // As `idx` was the end of the alive-zone, the alive zone is now `data[alive]` again, restoring all invariants. <br>由于 `idx` 是活动区域的结尾，因此活动区域现在又是 `data[alive]`，还原了所有不变量。<br>
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    #[inline]
    fn rfold<Acc, Fold>(mut self, init: Acc, mut rfold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let data = &mut self.data;
        iter::ByRefSized(&mut self.alive).rfold(init, |acc, idx| {
            // SAFETY: idx is obtained by folding over the `alive` range, which implies the value is currently considered alive but as the range is being consumed each value we read here will only be read once and then considered dead. <br>idx 是通过折叠 `alive` 范围获得的，这意味着该值当前被认为是活动的，但是随着范围被消耗，我们在这里读取的每个值只会被读取一次，然后被认为是死的。<br>
            //
            //
            rfold(acc, unsafe { data.get_unchecked(idx).assume_init_read() })
        })
    }

    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        let len = self.len();

        // The number of elements to drop. <br>要丢弃的元素数量。<br> Always in-bounds by construction. <br>总是在施工范围内。<br>
        let delta = cmp::min(n, len);

        let range_to_drop = (self.alive.end - delta)..self.alive.end;

        // Moving the end marks them as conceptually "dropped", so if anything goes bad then our drop impl won't double-free them. <br>移动结束标记在概念上将它们标记为 "dropped"，因此如果出现任何问题，我们的 drop impl 将不会双重释放它们。<br>
        //
        self.alive.end -= delta;

        // SAFETY: These elements are currently initialized, so it's fine to drop them. <br>这些元素当前已初始化，因此可以将它们丢弃。<br>
        unsafe {
            let slice = self.data.get_unchecked_mut(range_to_drop);
            ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(slice));
        }

        if n > len { Err(len) } else { Ok(()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SAFETY: This is safe: `as_mut_slice` returns exactly the sub-slice of elements that have not been moved out yet and that remain to be dropped. <br>这是安全的: `as_mut_slice` 精确地返回尚未移出但仍要丢弃的元素的子切片。<br>
        //
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Will never underflow due to the invariant `alive.start <= alive.end`. <br>不会因 `alive.start <= alive.end` 不变而下溢。<br>
        //
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// The iterator indeed reports the correct length. <br>迭代器确实报告了正确的长度。<br>
// The number of "alive" elements (that will still be yielded) is the length of the range `alive`. <br>"alive" 元素的数量 (仍将产生) 是 `alive` 范围的长度。<br>
// This range is decremented in length in either `next` or `next_back`. <br>在 `next` 或 `next_back` 中，此范围的长度减小。<br>
// It is always decremented by 1 in those methods, but only if `Some(_)` is returned. <br>在这些方法中，它总是减 1，但前提是要返回 `Some(_)`。<br>
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Note, we don't really need to match the exact same alive range, so we can just clone into offset 0 regardless of where `self` is. <br>注意，我们实际上并不需要完全匹配相同的有效范围，因此无论 `self` 在哪里，我们都可以克隆到偏移量 0 中。<br>
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clone all alive elements. <br>克隆所有活动元素。<br>
        for (src, dst) in iter::zip(self.as_slice(), &mut new.data) {
            // Write a clone into the new array, then update its alive range. <br>将克隆写入新阵列，然后更新其有效范围。<br>
            // If cloning panics, we'll correctly drop the previous items. <br>如果克隆发生 panics，我们将正确丢弃前一个项。<br>
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Only print the elements that were not yielded yet: we cannot access the yielded elements anymore. <br>只打印尚未产生的元素：我们不能再访问产生的元素。<br>
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}
