//! This module contains the `Any` trait, which enables dynamic typing of any `'static` type through runtime reflection. <br>该模块包含 `Any` trait，它可以通过运行时反射对任何 `'static` 类型进行动态类型化。<br>
//! It also contains the `Provider` trait and accompanying API, which enable trait objects to provide data based on typed requests, an alternate form of runtime reflection. <br>它还包含 `Provider` trait 和随附的 API，使 trait 对象能够根据类型化请求提供数据，这是运行时反射的另一种形式。<br>
//!
//! # `Any` and `TypeId` <br>`Any` 和 `TypeId`<br>
//!
//! `Any` itself can be used to get a `TypeId`, and has more features when used as a trait object. <br>`Any` 本身可以用来得到一个 `TypeId`，当用作 trait 对象时，它有更多的特性。<br>
//! As `&dyn Any` (a borrowed trait object), it has the `is` and `downcast_ref` methods, to test if the contained value is of a given type, and to get a reference to the inner value as a type. <br>作为 `&dyn Any` (借用的 trait 对象)，它具有 `is` 和 `downcast_ref` 方法，以测试所包含的值是否为给定类型，并对该类型的内部值进行引用。<br>
//! As `&mut dyn Any`, there is also the `downcast_mut` method, for getting a mutable reference to the inner value. <br>作为 `&mut dyn Any`，还有 `downcast_mut` 方法，用于获取内部值的变量引用。<br>
//! `Box<dyn Any>` adds the `downcast` method, which attempts to convert to a `Box<T>`. <br>`Box<dyn Any>` 添加了 `downcast` 方法，该方法尝试转换为 `Box<T>`。<br>
//! See the [`Box`] documentation for the full details. <br>有关完整的详细信息，请参见 [`Box`] 文档。<br>
//!
//! Note that `&dyn Any` is limited to testing whether a value is of a specified concrete type, and cannot be used to test whether a type implements a trait. <br>请注意，`&dyn Any` 仅限于测试值是否为指定的具体类型，而不能用于测试某个类型是否实现 trait。<br>
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Smart pointers and `dyn Any` <br>智能指针和 `dyn Any`<br>
//!
//! One piece of behavior to keep in mind when using `Any` as a trait object, especially with types like `Box<dyn Any>` or `Arc<dyn Any>`, is that simply calling `.type_id()` on the value will produce the `TypeId` of the *container*, not the underlying trait object. <br>将 `Any` 用作 trait 对象时要记住的一种行为，尤其是对于 `Box<dyn Any>` 或 `Arc<dyn Any>` 之类的类型，只需在值上调用 `.type_id()` 即可生成容器的 `TypeId`，而不是底层 trait 对象。<br>
//!
//! This can be avoided by converting the smart pointer into a `&dyn Any` instead, which will return the object's `TypeId`. <br>可以通过将智能指针转换为 `&dyn Any` 来避免，这将返回对象的 `TypeId`。<br>
//! For example: <br>例如：<br>
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // You're more likely to want this: <br>您更可能希望这样做：<br>
//! let actual_id = (&*boxed).type_id();
//! // ... than this: <br>比这个：<br>
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! ## Examples
//!
//! Consider a situation where we want to log out a value passed to a function. <br>考虑一下我们要注销传递给函数的值的情况。<br>
//! We know the value we're working on implements Debug, but we don't know its concrete type. <br>我们知道我们正在实现的值实现了 Debug，但是我们不知道它的具体类型。<br> We want to give special treatment to certain types: in this case printing out the length of String values prior to their value. <br>我们要对某些类型进行特殊处理：在这种情况下，应先打印 String 值的长度，然后再打印它们的值。<br>
//! We don't know the concrete type of our value at compile time, so we need to use runtime reflection instead. <br>我们在编译时不知道我们值的具体类型，因此我们需要使用运行时反射。<br>
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger function for any type that implements Debug. <br>用于实现 Debug 的任何类型的 Logger 函数。<br>
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Try to convert our value to a `String`. <br>尝试将我们的值转换为 `String`。<br>
//!     // If successful, we want to output the String`'s length as well as its value. <br>如果成功，我们要输出 String 的长度及其值。<br>
//!     // If not, it's a different type: just print it out unadorned. <br>如果不是，那就是另一种类型：只需将其打印出来即可。<br>
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{value:?}");
//!         }
//!     }
//! }
//!
//! // This function wants to log its parameter out prior to doing work with it. <br>该函数要先注销其参数，然后再使用它。<br>
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ...do some other work <br>... 做一些其他的工作<br>
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//! # `Provider` and `Demand` <br>`Provider` 和 `Demand`<br>
//!
//! `Provider` and the associated APIs support generic, type-driven access to data, and a mechanism for implementers to provide such data. <br>`Provider` 和相关的 API 支持泛型、类型驱动的数据访问，以及实现者提供此类数据的机制。<br>
//! The key parts of the interface are the `Provider` trait for objects which can provide data, and the [`request_value`] and [`request_ref`] functions for requesting data from an object which implements `Provider`. <br>该接口的关键部分是用于提供数据的对象的 `Provider` trait，以及用于从实现 `Provider` 的对象请求数据的 [`request_value`] 和 [`request_ref`] 函数。<br>
//! Generally, end users should not call `request_*` directly, they are helper functions for intermediate implementers to use to implement a user-facing interface. <br>通常，最终用户不应该直接调用 `request_*`，它们是中间实现者用来实现面向用户的接口的辅助函数。<br>
//! This is purely for the sake of ergonomics, there is no safety concern here; <br>这纯粹是为了人体工程学，这里没有安全问题;<br> intermediate implementers can typically support methods rather than free functions and use more specific names. <br>中间实现者通常可以支持方法而不是 free 函数，并使用更具体的名称。<br>
//!
//! Typically, a data provider is a trait object of a trait which extends `Provider`. <br>通常，数据提供者是扩展 `Provider` 的 trait 的 trait 对象。<br> A user will request data from a trait object by specifying the type of the data. <br>用户将通过指定数据的类型从 trait 对象请求数据。<br>
//!
//! ## Data flow <br>数据流<br>
//!
//! * A user requests an object of a specific type, which is delegated to `request_value` or   `request_ref` <br>用户请求特定类型的对象，该对象委托给 `request_value` 或 `request_ref`<br>
//! * `request_*` creates a `Demand` object and passes it to `Provider::provide` <br>`request_*` 创建一个 `Demand` 对象并将其传递给 `Provider::provide`<br>
//! * The data provider's implementation of `Provider::provide` tries providing values of different types using `Demand::provide_*`. <br>`Provider::provide` 的数据提供者实现尝试使用 `Demand::provide_*` 提供不同类型的值。<br> If the type matches the type requested by the user, the value will be stored in the `Demand` object. <br>如果类型与用户请求的类型匹配，则该值将存储在 `Demand` 对象中。<br>
//! * `request_*` unpacks the `Demand` object and returns any stored value to the user. <br>`request_*` 解包 `Demand` 对象并将任何存储的值返回给用户。<br>
//!
//! ## Examples
//!
//! ```
//! # #![feature(provide_any)]
//! use std::any::{Provider, Demand, request_ref};
//!
//! // Definition of MyTrait, a data provider. <br>MyTrait 的定义，一个数据提供者。<br>
//! trait MyTrait: Provider {
//!     // ...
//! }
//!
//! // Methods on `MyTrait` trait objects. <br>`MyTrait` trait 对象的方法。<br>
//! impl dyn MyTrait + '_ {
//!     /// Get a reference to a field of the implementing struct. <br>获取对实现结构体的字段的引用。<br>
//!     pub fn get_context_by_ref<T: ?Sized + 'static>(&self) -> Option<&T> {
//!         request_ref::<T, _>(self)
//!     }
//! }
//!
//! // Downstream implementation of `MyTrait` and `Provider`. <br>`MyTrait` 和 `Provider` 的下游实现。<br>
//! # struct SomeConcreteType { some_string: String }
//! impl MyTrait for SomeConcreteType {
//!     // ...
//! }
//!
//! impl Provider for SomeConcreteType {
//!     fn provide<'a>(&'a self, demand: &mut Demand<'a>) {
//!         // Provide a string reference. <br>提供一个字符串引用。<br>
//!         // We could provide multiple values with different types here. <br>我们可以在这里提供不同类型的多个值。<br>
//!         demand.provide_ref::<String>(&self.some_string);
//!     }
//! }
//!
//! // Downstream usage of `MyTrait`. <br>`MyTrait` 的下游用法。<br>
//! fn use_my_trait(obj: &dyn MyTrait) {
//!     // Request a &String from obj. <br>向 obj 请求 &String。<br>
//!     let _ = obj.get_context_by_ref::<String>().unwrap();
//! }
//! ```
//!
//! In this example, if the concrete type of `obj` in `use_my_trait` is `SomeConcreteType`, then the `get_context_ref` call will return a reference to `obj.some_string` with type `&String`. <br>在这个例子中，如果 `use_my_trait` 中 `obj` 的具体类型是 `SomeConcreteType`，那么 `get_context_ref` 调用将返回一个 `obj.some_string` 类型为 `&String` 的引用。<br>
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Any trait <br>任何 trait<br>
///////////////////////////////////////////////////////////////////////////////

/// A trait to emulate dynamic typing. <br>一个用来模拟动态类型的 trait。<br>
///
/// Most types implement `Any`. <br>大多数类型都实现了 `Any`。<br> However, any type which contains a non-`'static` reference does not. <br>但是，任何包含非 `static' 引用的类型都不会。<br>
/// See the [module-level documentation][mod] for more details. <br>有关更多详细信息，请参见 [模块级文档][mod]。<br>
///
/// [mod]: crate::any
// This trait is not unsafe, though we rely on the specifics of it's sole impl's `type_id` function in unsafe code (e.g., `downcast`). <br>这个 trait 并不是不安全的，尽管我们依靠不安全代码 (例如 `downcast`) 中唯一的 impl 的 `type_id` 函数的细节。<br> Normally, that would be a problem, but because the only impl of `Any` is a blanket implementation, no other code can implement `Any`. <br>通常，这将是一个问题，但是由于 `Any` 的唯一含义是全面实现，因此没有其他代码可以实现 `Any`。<br>
//
// We could plausibly make this trait unsafe -- it would not cause breakage, since we control all the implementations -- but we choose not to as that's both not really necessary and may confuse users about the distinction of unsafe traits and unsafe methods (i.e., `type_id` would still be safe to call, but we would likely want to indicate as such in documentation). <br>我们可以合理地使此 trait 不安全 - 因为我们控制所有实现，因此不会造成破坏 - 但我们选择不这样做，因为这既不是真正必要的，并且可能使用户混淆不安全的 traits 和不安全的方法 (即，`type_id` 仍然可以安全调用，但我们可能希望在文档中对此进行说明。<br>
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "Any")]
pub trait Any: 'static {
    /// Gets the `TypeId` of `self`. <br>获取 `self` 的 `TypeId`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Extension methods for Any trait objects. <br>任何 trait 对象的扩展方法。<br>
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Any").finish_non_exhaustive()
    }
}

// Ensure that the result of e.g., joining a thread can be printed and hence used with `unwrap`. <br>确保可以打印出例如连接螺纹的结果，并因此可以与 `unwrap` 一起使用。<br>
// May eventually no longer be needed if dispatch works with upcasting. <br>如果调度与向上转换一起使用，则最终可能不再需要。<br>
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Any").finish_non_exhaustive()
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Any").finish_non_exhaustive()
    }
}

impl dyn Any {
    /// Returns `true` if the inner type is the same as `T`. <br>如果内部类型与 `T` 相同，则返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Get `TypeId` of the type this function is instantiated with. <br>获取实例化此函数的类型的 `TypeId`。<br>
        let t = TypeId::of::<T>();

        // Get `TypeId` of the type in the trait object (`self`). <br>在 trait 对象 (`self`) 中获取该类型的 `TypeId`。<br>
        let concrete = self.type_id();

        // Compare both `TypeId`s on equality. <br>比较两个 `TypeId` 的相等性。<br>
        t == concrete
    }

    /// Returns some reference to the inner value if it is of type `T`, or `None` if it isn't. <br>如果内部值的类型为 `T` 类型，则返回一些对内部值的引用，如果不是，则返回 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SAFETY: just checked whether we are pointing to the correct type, and we can rely on that check for memory safety because we have implemented Any for all types; <br>只需检查我们是否指向正确的类型，就可以依靠该检查来检查内存安全性，因为我们对所有类型都实现了 Any；<br> no other impls can exist as they would conflict with our impl. <br>没有其他迹象可能会存在，因为它们会与我们的迹象发生冲突。<br>
            //
            //
            unsafe { Some(self.downcast_ref_unchecked()) }
        } else {
            None
        }
    }

    /// Returns some mutable reference to the inner value if it is of type `T`, or `None` if it isn't. <br>如果内部值的类型为 `T` 类型，则返回一些对内部值的引用，如果不是，则返回 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SAFETY: just checked whether we are pointing to the correct type, and we can rely on that check for memory safety because we have implemented Any for all types; <br>只需检查我们是否指向正确的类型，就可以依靠该检查来检查内存安全性，因为我们对所有类型都实现了 Any；<br> no other impls can exist as they would conflict with our impl. <br>没有其他迹象可能会存在，因为它们会与我们的迹象发生冲突。<br>
            //
            //
            unsafe { Some(self.downcast_mut_unchecked()) }
        } else {
            None
        }
    }

    /// Returns a reference to the inner value as type `dyn T`. <br>返回对内部值的引用，类型为 `dyn T`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(downcast_unchecked)]
    ///
    /// use std::any::Any;
    ///
    /// let x: Box<dyn Any> = Box::new(1_usize);
    ///
    /// unsafe {
    ///     assert_eq!(*x.downcast_ref_unchecked::<usize>(), 1);
    /// }
    /// ```
    ///
    /// # Safety
    ///
    /// The contained value must be of type `T`. <br>包含的值必须是 `T` 类型。<br>
    /// Calling this method with the incorrect type is *undefined behavior*. <br>使用不正确的类型调用此方法是 *未定义的行为*。<br>
    #[unstable(feature = "downcast_unchecked", issue = "90850")]
    #[inline]
    pub unsafe fn downcast_ref_unchecked<T: Any>(&self) -> &T {
        debug_assert!(self.is::<T>());
        // SAFETY: caller guarantees that T is the correct type <br>调用者保证 T 是正确的类型<br>
        unsafe { &*(self as *const dyn Any as *const T) }
    }

    /// Returns a mutable reference to the inner value as type `dyn T`. <br>返回对内部值的可变引用，类型为 `dyn T`<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(downcast_unchecked)]
    ///
    /// use std::any::Any;
    ///
    /// let mut x: Box<dyn Any> = Box::new(1_usize);
    ///
    /// unsafe {
    ///     *x.downcast_mut_unchecked::<usize>() += 1;
    /// }
    ///
    /// assert_eq!(*x.downcast_ref::<usize>().unwrap(), 2);
    /// ```
    ///
    /// # Safety
    ///
    /// The contained value must be of type `T`. <br>包含的值必须是 `T` 类型。<br>
    /// Calling this method with the incorrect type is *undefined behavior*. <br>使用不正确的类型调用此方法是 *未定义的行为*。<br>
    #[unstable(feature = "downcast_unchecked", issue = "90850")]
    #[inline]
    pub unsafe fn downcast_mut_unchecked<T: Any>(&mut self) -> &mut T {
        debug_assert!(self.is::<T>());
        // SAFETY: caller guarantees that T is the correct type <br>调用者保证 T 是正确的类型<br>
        unsafe { &mut *(self as *mut dyn Any as *mut T) }
    }
}

impl dyn Any + Send {
    /// Forwards to the method defined on the type `dyn Any`. <br>转发到在类型 `dyn Any` 上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Forwards to the method defined on the type `dyn Any`. <br>转发到在类型 `dyn Any` 上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Forwards to the method defined on the type `dyn Any`. <br>转发到在类型 `dyn Any` 上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }

    /// Forwards to the method defined on the type `dyn Any`. <br>转发到在类型 `dyn Any` 上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(downcast_unchecked)]
    ///
    /// use std::any::Any;
    ///
    /// let x: Box<dyn Any> = Box::new(1_usize);
    ///
    /// unsafe {
    ///     assert_eq!(*x.downcast_ref_unchecked::<usize>(), 1);
    /// }
    /// ```
    ///
    /// # Safety
    ///
    /// Same as the method on the type `dyn Any`. <br>与 `dyn Any` 类型上的方法相同。<br>
    #[unstable(feature = "downcast_unchecked", issue = "90850")]
    #[inline]
    pub unsafe fn downcast_ref_unchecked<T: Any>(&self) -> &T {
        // SAFETY: guaranteed by caller <br>由调用者保证<br>
        unsafe { <dyn Any>::downcast_ref_unchecked::<T>(self) }
    }

    /// Forwards to the method defined on the type `dyn Any`. <br>转发到在类型 `dyn Any` 上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(downcast_unchecked)]
    ///
    /// use std::any::Any;
    ///
    /// let mut x: Box<dyn Any> = Box::new(1_usize);
    ///
    /// unsafe {
    ///     *x.downcast_mut_unchecked::<usize>() += 1;
    /// }
    ///
    /// assert_eq!(*x.downcast_ref::<usize>().unwrap(), 2);
    /// ```
    ///
    /// # Safety
    ///
    /// Same as the method on the type `dyn Any`. <br>与 `dyn Any` 类型上的方法相同。<br>
    #[unstable(feature = "downcast_unchecked", issue = "90850")]
    #[inline]
    pub unsafe fn downcast_mut_unchecked<T: Any>(&mut self) -> &mut T {
        // SAFETY: guaranteed by caller <br>由调用者保证<br>
        unsafe { <dyn Any>::downcast_mut_unchecked::<T>(self) }
    }
}

impl dyn Any + Send + Sync {
    /// Forwards to the method defined on the type `Any`. <br>转发到在 `Any` 类型上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Forwards to the method defined on the type `Any`. <br>转发到在 `Any` 类型上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Forwards to the method defined on the type `Any`. <br>转发到在 `Any` 类型上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }

    /// Forwards to the method defined on the type `Any`. <br>转发到在 `Any` 类型上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(downcast_unchecked)]
    ///
    /// use std::any::Any;
    ///
    /// let x: Box<dyn Any> = Box::new(1_usize);
    ///
    /// unsafe {
    ///     assert_eq!(*x.downcast_ref_unchecked::<usize>(), 1);
    /// }
    /// ```
    #[unstable(feature = "downcast_unchecked", issue = "90850")]
    #[inline]
    pub unsafe fn downcast_ref_unchecked<T: Any>(&self) -> &T {
        // SAFETY: guaranteed by caller <br>由调用者保证<br>
        unsafe { <dyn Any>::downcast_ref_unchecked::<T>(self) }
    }

    /// Forwards to the method defined on the type `Any`. <br>转发到在 `Any` 类型上定义的方法。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(downcast_unchecked)]
    ///
    /// use std::any::Any;
    ///
    /// let mut x: Box<dyn Any> = Box::new(1_usize);
    ///
    /// unsafe {
    ///     *x.downcast_mut_unchecked::<usize>() += 1;
    /// }
    ///
    /// assert_eq!(*x.downcast_ref::<usize>().unwrap(), 2);
    /// ```
    #[unstable(feature = "downcast_unchecked", issue = "90850")]
    #[inline]
    pub unsafe fn downcast_mut_unchecked<T: Any>(&mut self) -> &mut T {
        // SAFETY: guaranteed by caller <br>由调用者保证<br>
        unsafe { <dyn Any>::downcast_mut_unchecked::<T>(self) }
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID and its methods <br>TypeID 及其方法<br>
///////////////////////////////////////////////////////////////////////////////

/// A `TypeId` represents a globally unique identifier for a type. <br>`TypeId` 代表类型的全局唯一标识符。<br>
///
/// Each `TypeId` is an opaque object which does not allow inspection of what's inside but does allow basic operations such as cloning, comparison, printing, and showing. <br>每个 `TypeId` 是不透明的对象，它不允许检查内部内容，但可以进行基本操作，例如克隆，比较，打印和显示。<br>
///
///
/// A `TypeId` is currently only available for types which ascribe to `'static`, but this limitation may be removed in the future. <br>`TypeId` 当前仅适用于归因于 `'static` 的类型，但是可以在 future 中消除此限制。<br>
///
/// While `TypeId` implements `Hash`, `PartialOrd`, and `Ord`, it is worth noting that the hashes and ordering will vary between Rust releases. <br>虽然 `TypeId` 实现 `Hash`，`PartialOrd` 和 `Ord`，但值得注意的是，在 Rust 版本之间，哈希值和顺序将有所不同。<br>
/// Beware of relying on them inside of your code! <br>注意不要在代码中依赖它们！<br>
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Returns the `TypeId` of the type this generic function has been instantiated with. <br>返回已实例化此泛型函数的类型的 `TypeId`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Returns the name of a type as a string slice. <br>以字符串切片的形式返回类型的名称。<br>
///
/// # Note
///
/// This is intended for diagnostic use. <br>这旨在用于诊断。<br>
/// The exact contents and format of the string returned are not specified, other than being a best-effort description of the type. <br>除了作为尽力而为的类型描述之外，未指定返回的字符串的确切内容和格式。<br>
/// For example, amongst the strings that `type_name::<Option<String>>()` might return are `"Option<String>"` and `"std::option::Option<std::string::String>"`. <br>例如，在 `type_name::<Option<String>>()` 可能返回的字符串中，有 `"Option<String>"` 和 `"std::option::Option<std::string::String>"`。<br>
///
///
/// The returned string must not be considered to be a unique identifier of a type as multiple types may map to the same type name. <br>返回的字符串不得视为类型的唯一标识符，因为多个类型可能会 map 变为相同的类型名称。<br>
/// Similarly, there is no guarantee that all parts of a type will appear in the returned string: for example, lifetime specifiers are currently not included. <br>同样，不能保证类型的所有部分都将出现在返回的字符串中：例如，当前不包括生命周期说明符。<br>
/// In addition, the output may change between versions of the compiler. <br>此外，输出可能会在编译器的版本之间改变。<br>
///
/// The current implementation uses the same infrastructure as compiler diagnostics and debuginfo, but this is not guaranteed. <br>当前的实现使用与编译器诊断和 debuginfo 相同的基础结构，但这不能保证。<br>
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[must_use]
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Returns the name of the type of the pointed-to value as a string slice. <br>以字符串切片的形式返回指向的值的类型的名称。<br>
/// This is the same as `type_name::<T>()`, but can be used where the type of a variable is not easily available. <br>这与 `type_name::<T>()` 相同，但是可以在不容易获得变量类型的地方使用。<br>
///
/// # Note
///
/// This is intended for diagnostic use. <br>这旨在用于诊断。<br> The exact contents and format of the string are not specified, other than being a best-effort description of the type. <br>没有指定字符串的确切内容和格式，只是对类型的尽力描述。<br>
/// For example, `type_name_of_val::<Option<String>>(None)` could return `"Option<String>"` or `"std::option::Option<std::string::String>"`, but not `"foobar"`. <br>例如，`type_name_of_val::<Option<String>>(None)` 可以返回 `"Option<String>"` 或 `"std::option::Option<std::string::String>"`，但不能返回 `"foobar"`。<br>
///
/// In addition, the output may change between versions of the compiler. <br>此外，输出可能会在编译器的版本之间改变。<br>
///
/// This function does not resolve trait objects, meaning that `type_name_of_val(&7u32 as &dyn Debug)` may return `"dyn Debug"`, but not `"u32"`. <br>此函数不能解析 trait 对象，这意味着 `type_name_of_val(&7u32 as &dyn Debug)` 可以返回 `"dyn Debug"`，但不能返回 `"u32"`。<br>
///
/// The type name should not be considered a unique identifier of a type; <br>类型名称不应视为类型的唯一标识符；<br>
/// multiple types may share the same type name. <br>多个类型可以共享相同的类型名称。<br>
///
/// The current implementation uses the same infrastructure as compiler diagnostics and debuginfo, but this is not guaranteed. <br>当前的实现使用与编译器诊断和 debuginfo 相同的基础结构，但这不能保证。<br>
///
/// # Examples
///
/// Prints the default integer and float types. <br>打印默认的整数和浮点类型。<br>
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[must_use]
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}

///////////////////////////////////////////////////////////////////////////////
// Provider trait
///////////////////////////////////////////////////////////////////////////////

/// Trait implemented by a type which can dynamically provide values based on type. <br>Trait 由可以根据类型动态提供值的类型实现。<br>
#[unstable(feature = "provide_any", issue = "96024")]
pub trait Provider {
    /// Data providers should implement this method to provide *all* values they are able to provide by using `demand`. <br>数据提供者应实现此方法以提供他们能够通过使用 `demand` 提供的*所有*值。<br>
    ///
    /// Note that the `provide_*` methods on `Demand` have short-circuit semantics: if an earlier method has successfully provided a value, then later methods will not get an opportunity to provide. <br>请注意，`Demand` 上的 `provide_*` 方法具有短路语义: 如果较早的方法已成功提供值，则以后的方法将没有机会提供。<br>
    ///
    ///
    /// # Examples
    ///
    /// Provides a reference to a field with type `String` as a `&str`, and a value of type `i32`. <br>提供对类型为 `String` 的字段的引用作为 `&str`，以及类型为 `i32` 的值。<br>
    ///
    /// ```rust
    /// # #![feature(provide_any)]
    /// use std::any::{Provider, Demand};
    /// # struct SomeConcreteType { field: String, num_field: i32 }
    ///
    /// impl Provider for SomeConcreteType {
    ///     fn provide<'a>(&'a self, demand: &mut Demand<'a>) {
    ///         demand.provide_ref::<str>(&self.field)
    ///             .provide_value::<i32, _>(|| self.num_field);
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "provide_any", issue = "96024")]
    fn provide<'a>(&'a self, demand: &mut Demand<'a>);
}

/// Request a value from the `Provider`. <br>从 `Provider` 请求一个值。<br>
///
/// # Examples
///
/// Get a string value from a provider. <br>从提供者处获取字符串值。<br>
///
/// ```rust
/// # #![feature(provide_any)]
/// use std::any::{Provider, request_value};
///
/// fn get_string<P: Provider>(provider: &P) -> String {
///     request_value::<String, _>(provider).unwrap()
/// }
/// ```
#[unstable(feature = "provide_any", issue = "96024")]
pub fn request_value<'a, T, P>(provider: &'a P) -> Option<T>
where
    T: 'static,
    P: Provider + ?Sized,
{
    request_by_type_tag::<'a, tags::Value<T>, P>(provider)
}

/// Request a reference from the `Provider`. <br>从 `Provider` 请求引用。<br>
///
/// # Examples
///
/// Get a string reference from a provider. <br>从提供者处获取字符串引用。<br>
///
/// ```rust
/// # #![feature(provide_any)]
/// use std::any::{Provider, request_ref};
///
/// fn get_str<P: Provider>(provider: &P) -> &str {
///     request_ref::<str, _>(provider).unwrap()
/// }
/// ```
#[unstable(feature = "provide_any", issue = "96024")]
pub fn request_ref<'a, T, P>(provider: &'a P) -> Option<&'a T>
where
    T: 'static + ?Sized,
    P: Provider + ?Sized,
{
    request_by_type_tag::<'a, tags::Ref<tags::MaybeSizedValue<T>>, P>(provider)
}

/// Request a specific value by tag from the `Provider`. <br>通过 `Provider` 的标签请求特定值。<br>
fn request_by_type_tag<'a, I, P>(provider: &'a P) -> Option<I::Reified>
where
    I: tags::Type<'a>,
    P: Provider + ?Sized,
{
    let mut tagged = TaggedOption::<'a, I>(None);
    provider.provide(tagged.as_demand());
    tagged.0
}

///////////////////////////////////////////////////////////////////////////////
// Demand and its methods <br>需求及其方法<br>
///////////////////////////////////////////////////////////////////////////////

/// A helper object for providing data by type. <br>用于按类型提供数据的帮助器对象。<br>
///
/// A data provider provides values by calling this type's provide methods. <br>数据提供者通过调用此类型的提供方法来提供值。<br>
#[unstable(feature = "provide_any", issue = "96024")]
#[repr(transparent)]
pub struct Demand<'a>(dyn Erased<'a> + 'a);

impl<'a> Demand<'a> {
    /// Create a new `&mut Demand` from a `&mut dyn Erased` trait object. <br>从 `&mut dyn Erased` trait 对象创建一个新的 `&mut Demand`。<br>
    fn new<'b>(erased: &'b mut (dyn Erased<'a> + 'a)) -> &'b mut Demand<'a> {
        // SAFETY: transmuting `&mut (dyn Erased<'a> + 'a)` to `&mut Demand<'a>` is safe since `Demand` is repr(transparent). <br>将 `&mut (dyn Erased<'a> + 'a)` 转换为 `&mut Demand<'a>` 是安全的，因为 `Demand` 是 repr(transparent)。<br>
        //
        unsafe { &mut *(erased as *mut dyn Erased<'a> as *mut Demand<'a>) }
    }

    /// Provide a value or other type with only static lifetimes. <br>提供仅具有静态生命周期的值或其他类型。<br>
    ///
    /// # Examples
    ///
    /// Provides a `String` by cloning. <br>通过克隆提供 `String`。<br>
    ///
    /// ```rust
    /// # #![feature(provide_any)]
    /// use std::any::{Provider, Demand};
    /// # struct SomeConcreteType { field: String }
    ///
    /// impl Provider for SomeConcreteType {
    ///     fn provide<'a>(&'a self, demand: &mut Demand<'a>) {
    ///         demand.provide_value::<String, _>(|| self.field.clone());
    ///     }
    /// }
    /// ```
    #[unstable(feature = "provide_any", issue = "96024")]
    pub fn provide_value<T, F>(&mut self, fulfil: F) -> &mut Self
    where
        T: 'static,
        F: FnOnce() -> T,
    {
        self.provide_with::<tags::Value<T>, F>(fulfil)
    }

    /// Provide a reference, note that the referee type must be bounded by `'static`, but may be unsized. <br>提供一个引用，注意裁判类型必须以 `'static` 为界，但可能是未定义大小的。<br>
    ///
    ///
    /// # Examples
    ///
    /// Provides a reference to a field as a `&str`. <br>以 `&str` 的形式提供对字段的引用。<br>
    ///
    /// ```rust
    /// # #![feature(provide_any)]
    /// use std::any::{Provider, Demand};
    /// # struct SomeConcreteType { field: String }
    ///
    /// impl Provider for SomeConcreteType {
    ///     fn provide<'a>(&'a self, demand: &mut Demand<'a>) {
    ///         demand.provide_ref::<str>(&self.field);
    ///     }
    /// }
    /// ```
    #[unstable(feature = "provide_any", issue = "96024")]
    pub fn provide_ref<T: ?Sized + 'static>(&mut self, value: &'a T) -> &mut Self {
        self.provide::<tags::Ref<tags::MaybeSizedValue<T>>>(value)
    }

    /// Provide a value with the given `Type` tag. <br>使用给定的 `Type` 标记提供一个值。<br>
    fn provide<I>(&mut self, value: I::Reified) -> &mut Self
    where
        I: tags::Type<'a>,
    {
        if let Some(res @ TaggedOption(None)) = self.0.downcast_mut::<I>() {
            res.0 = Some(value);
        }
        self
    }

    /// Provide a value with the given `Type` tag, using a closure to prevent unnecessary work. <br>使用给定的 `Type` 标记提供一个值，使用闭包来防止不必要的工作。<br>
    fn provide_with<I, F>(&mut self, fulfil: F) -> &mut Self
    where
        I: tags::Type<'a>,
        F: FnOnce() -> I::Reified,
    {
        if let Some(res @ TaggedOption(None)) = self.0.downcast_mut::<I>() {
            res.0 = Some(fulfil());
        }
        self
    }
}

#[unstable(feature = "provide_any", issue = "96024")]
impl<'a> fmt::Debug for Demand<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Demand").finish_non_exhaustive()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Type tags <br>类型标签<br>
///////////////////////////////////////////////////////////////////////////////

mod tags {
    //! Type tags are used to identify a type using a separate value. <br>类型标签用于使用单独的值来标识类型。<br> This module includes type tags for some very common types. <br>这个模块包括一些非常常见的类型的类型标签。<br>
    //!
    //! Currently type tags are not exposed to the user. <br>当前类型标签不向用户公开。<br>
    //! But in the future, if you want to use the Provider API with more complex types (typically those including lifetime parameters), you will need to write your own tags. <br>但是在 future 中，如果您想使用更复杂类型的 Provider API (通常包括生命周期参数)，您需要编写自己的标签。<br>
    //!
    //!

    use crate::marker::PhantomData;

    /// This trait is implemented by specific tag types in order to allow describing a type which can be requested for a given lifetime `'a`. <br>这个 trait 由特定的标签类型实现，以便允许描述可以为给定的生命周期 `'a` 请求的类型。<br>
    ///
    /// A few example implementations for type-driven tags can be found in this module, although crates may also implement their own tags for more complex types with internal lifetimes. <br>在这个模块中可以找到一些类型驱动标签的示例实现，尽管 crates 也可以为具有内部生命周期的更复杂类型实现自己的标签。<br>
    ///
    ///
    ///
    pub trait Type<'a>: Sized + 'static {
        /// The type of values which may be tagged by this tag for the given lifetime. <br>对于给定的生命周期，此标签可能标记的值的类型。<br>
        ///
        type Reified: 'a;
    }

    /// Similar to the [`Type`] trait, but represents a type which may be unsized (i.e., has a `?Sized` bound). <br>与 [`Type`] trait 类似，但表示可能是未定义大小的类型 (即，具有 `?Sized` 边界)。<br>
    /// E.g., `str`. <br>例如，`str`。<br>
    pub trait MaybeSizedType<'a>: Sized + 'static {
        type Reified: 'a + ?Sized;
    }

    impl<'a, T: Type<'a>> MaybeSizedType<'a> for T {
        type Reified = T::Reified;
    }

    /// Type-based tag for types bounded by `'static`, i.e., with no borrowed elements. <br>以 `'static` 为界的类型的基于类型的标记，即没有借用元素。<br>
    #[derive(Debug)]
    pub struct Value<T: 'static>(PhantomData<T>);

    impl<'a, T: 'static> Type<'a> for Value<T> {
        type Reified = T;
    }

    /// Type-based tag similar to [`Value`] but which may be unsized (i.e., has a `?Sized` bound). <br>基于类型的标记类似于 [`Value`]，但可能是未定义大小的 (即，具有 `?Sized` 边界)。<br>
    #[derive(Debug)]
    pub struct MaybeSizedValue<T: ?Sized + 'static>(PhantomData<T>);

    impl<'a, T: ?Sized + 'static> MaybeSizedType<'a> for MaybeSizedValue<T> {
        type Reified = T;
    }

    /// Type-based tag for reference types (`&'a T`, where T is represented by `<I as MaybeSizedType<'a>>::Reified`. <br>引用类型的基于类型的标记 (`&'a T`，其中 T 由 `<I as MaybeSizedType<'a>>::Reified` 表示。<br>
    ///
    #[derive(Debug)]
    pub struct Ref<I>(PhantomData<I>);

    impl<'a, I: MaybeSizedType<'a>> Type<'a> for Ref<I> {
        type Reified = &'a I::Reified;
    }
}

/// An `Option` with a type tag `I`. <br>带有类型标签 `I` 的 `Option`。<br>
///
/// Since this struct implements `Erased`, the type can be erased to make a dynamically typed option. <br>由于这个结构体实现了 `Erased`，所以类型可以是 erased 来做一个动态类型的选项。<br>
/// The type can be checked dynamically using `Erased::tag_id` and since this is statically checked for the concrete type, there is some degree of type safety. <br>可以使用 `Erased::tag_id` 动态检查类型，并且由于这是针对具体类型静态检查的，因此存在一定程度的类型安全性。<br>
///
#[repr(transparent)]
struct TaggedOption<'a, I: tags::Type<'a>>(Option<I::Reified>);

impl<'a, I: tags::Type<'a>> TaggedOption<'a, I> {
    fn as_demand(&mut self) -> &mut Demand<'a> {
        Demand::new(self as &mut (dyn Erased<'a> + 'a))
    }
}

/// Represents a type-erased but identifiable object. <br>表示一个类型为 erased 但可识别的对象。<br>
///
/// This trait is exclusively implemented by the `TaggedOption` type. <br>这个 trait 是由 `TaggedOption` 类型专门实现的。<br>
unsafe trait Erased<'a>: 'a {
    /// The `TypeId` of the erased type. <br>erased 类型的 `TypeId`。<br>
    fn tag_id(&self) -> TypeId;
}

unsafe impl<'a, I: tags::Type<'a>> Erased<'a> for TaggedOption<'a, I> {
    fn tag_id(&self) -> TypeId {
        TypeId::of::<I>()
    }
}

#[unstable(feature = "provide_any", issue = "96024")]
impl<'a> dyn Erased<'a> + 'a {
    /// Returns some reference to the dynamic value if it is tagged with `I`, or `None` otherwise. <br>如果它被标记为 `I`，则返回一些对动态值的引用，否则返回 `None`。<br>
    ///
    #[inline]
    fn downcast_mut<I>(&mut self) -> Option<&mut TaggedOption<'a, I>>
    where
        I: tags::Type<'a>,
    {
        if self.tag_id() == TypeId::of::<I>() {
            // SAFETY: Just checked whether we're pointing to an I. <br>刚刚检查了我们是否指向一个 I。<br>
            Some(unsafe { &mut *(self as *mut Self).cast::<TaggedOption<'a, I>>() })
        } else {
            None
        }
    }
}
