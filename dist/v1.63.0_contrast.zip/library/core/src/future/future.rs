#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future represents an asynchronous computation obtained by use of [`async`]. <br>future 表示通过使用 [`async`] 获得的异步计算。<br>
///
/// A future is a value that might not have finished computing yet. <br>future 是一个可能尚未完成计算的值。<br>
/// This kind of "asynchronous value" makes it possible for a thread to continue doing useful work while it waits for the value to become available. <br>这种异步值使得，线程在等待值变为可用时，可以继续执行有用的工作。<br>
///
///
/// # The `poll` method <br>`poll` 方法<br>
///
/// The core method of future, `poll`, *attempts* to resolve the future into a final value. <br>future 的核心方法 `poll` 试图将 future 解析为最终值。<br>
/// This method does not block if the value is not ready. <br>如果值未准备好，则此方法不会阻塞。<br>
/// Instead, the current task is scheduled to be woken up when it's possible to make further progress by `poll`ing again. <br>取而代之的是，如果有可能通过再次轮询来取得进一步的进展，则计划将当前任务唤醒。<br>
/// The `context` passed to the `poll` method can provide a [`Waker`], which is a handle for waking up the current task. <br>传递给 `poll` 方法的 `context` 可以提供 [`Waker`]，它是唤醒当前任务的句柄。<br>
///
/// When using a future, you generally won't call `poll` directly, but instead `.await` the value. <br>当使用 future 时，通常不会直接调用 `poll`，而是 `.await` 该值。<br>
///
/// [`async`]: ../../std/keyword.async.html
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(notable_trait)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(
    label = "`{Self}` is not a future",
    message = "`{Self}` is not a future",
    note = "{Self} must be a future or must implement `IntoFuture` to be awaited"
)]
pub trait Future {
    /// The type of value produced on completion. <br>完成时产生的值类型。<br>
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Attempt to resolve the future to a final value, registering the current task for wakeup if the value is not yet available. <br>尝试将 future 解析为最终值，如果该值尚不可用，请注册当前任务以进行唤醒。<br>
    ///
    /// # Return value <br>返回值<br>
    ///
    /// This function returns: <br>该函数返回：<br>
    ///
    /// - [`Poll::Pending`] if the future is not ready yet <br>[`Poll::Pending`] 如果 future 还没有准备好<br>
    /// - [`Poll::Ready(val)`] with the result `val` of this future if it finished successfully. <br>[`Poll::Ready(val)`] 与此 future 的结果 `val` 如果它成功完成。<br>
    ///
    /// Once a future has finished, clients should not `poll` it again. <br>future 完成后，客户端不应再次对其进行 `poll`。<br>
    ///
    /// When a future is not ready yet, `poll` returns `Poll::Pending` and stores a clone of the [`Waker`] copied from the current [`Context`]. <br>当 future 尚未准备好时，`poll` 返回 `Poll::Pending` 并存储从当前 [`Context`] 复制的 [`Waker`] 的副本。<br>
    /// This [`Waker`] is then woken once the future can make progress. <br>future 可以取得进展后，将唤醒该 [`Waker`]。<br>
    /// For example, a future waiting for a socket to become readable would call `.clone()` on the [`Waker`] and store it. <br>例如，等待套接字可读的 future 将在 [`Waker`] 上调用 `.clone()` 并将其存储。<br>
    /// When a signal arrives elsewhere indicating that the socket is readable, [`Waker::wake`] is called and the socket future's task is awoken. <br>当信号到达其他地方指示套接字可读时，将调用 [`Waker::wake`]，并且唤醒套接字 future 的任务。<br>
    /// Once a task has been woken up, it should attempt to `poll` the future again, which may or may not produce a final value. <br>一旦任务被唤醒，它应该尝试再次 `poll` future，这可能会或可能不会产生最终值。<br>
    ///
    /// Note that on multiple calls to `poll`, only the [`Waker`] from the [`Context`] passed to the most recent call should be scheduled to receive a wakeup. <br>请注意，在多次调用 `poll` 时，应仅计划将 [`Context`] 中传递给最新调用的 [`Waker`] 接收唤醒。<br>
    ///
    /// # Runtime characteristics <br>运行时特征<br>
    ///
    /// Futures alone are *inert*; <br>单独的 Futures 是惰性的；<br> they must be *actively* `poll`ed to make progress, meaning that each time the current task is woken up, it should actively re-`poll` pending futures that it still has an interest in. <br>必须对它们进行主动轮询以取得进展，这意味着每次唤醒当前任务时，它都应主动重新轮询以等待仍对其感兴趣的 futures。<br>
    ///
    /// The `poll` function is not called repeatedly in a tight loop -- instead, it should only be called when the future indicates that it is ready to make progress (by calling `wake()`). <br>`poll` 函数不会在紧密循环中重复调用 - 而是仅在 future 指示已准备好进行调用时 (通过调用 `wake()`) 才应调用它。<br>
    /// If you're familiar with the `poll(2)` or `select(2)` syscalls on Unix it's worth noting that futures typically do *not* suffer the same problems of "all wakeups must poll all events"; <br>如果您熟悉 Unix 上的 `poll(2)` 或 `select(2)` 系统调用，则值得注意的是 futures 通常不会遭受与 "所有唤醒都必须轮询所有事件" 相同的问题；<br> they are more like `epoll(4)`. <br>他们更像 `epoll(4)`。<br>
    ///
    /// An implementation of `poll` should strive to return quickly, and should not block. <br>`poll` 的实现应努力迅速返回，并且不应阻塞。<br> Returning quickly prevents unnecessarily clogging up threads or event loops. <br>快速返回可防止不必要地阻塞线程或事件循环。<br>
    /// If it is known ahead of time that a call to `poll` may end up taking awhile, the work should be offloaded to a thread pool (or something similar) to ensure that `poll` can return quickly. <br>如果提前得知对 `poll` 的调用可能要花一点时间，则应将工作卸载到线程池 (或类似的线程) 中，以确保 `poll` 可以快速返回。<br>
    ///
    /// # Panics
    ///
    /// Once a future has completed (returned `Ready` from `poll`), calling its `poll` method again may panic, block forever, or cause other kinds of problems; <br>future 完成后 (从 `poll` 返回 `Ready`)，再次调用其 `poll` 方法可能会导致 panic 永久阻塞或引起其他类型的问题。<br> the `Future` trait places no requirements on the effects of such a call. <br>`Future` trait 对这种调用的效果没有任何要求。<br>
    /// However, as the `poll` method is not marked `unsafe`, Rust's usual rules apply: calls must never cause undefined behavior (memory corruption, incorrect use of `unsafe` functions, or the like), regardless of the future's state. <br>但是，由于 `poll` 方法未标记为 `unsafe`，因此适用 Rust 的通常规则：调用绝不能引起未定义的行为 (内存损坏，`unsafe` 函数的错误使用等)，而与 future 的状态无关。<br>
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        <P::Target as Future>::poll(self.as_deref_mut(), cx)
    }
}
