use crate::marker::Unsize;

/// Trait that indicates that this is a pointer or a wrapper for one, where unsizing can be performed on the pointee. <br>一个 trait，指示这是一个指针或一个包装器，其中可以对指针调整大小。<br>
///
/// See the [DST coercion RFC][dst-coerce] and [the nomicon entry on coercion][nomicon-coerce] for more details. <br>有关更多详细信息，请参见 [DST 强制 RFC][dst-coerce] 和 [关于强制的 nomicon 入口][nomicon-coerce]。<br>
///
/// For builtin pointer types, pointers to `T` will coerce to pointers to `U` if `T: Unsize<U>` by converting from a thin pointer to a fat pointer. <br>对于内置指针类型，如果 `T: Unsize<U>` 通过从精简指针转换为胖指针，则指向 `T` 的指针将强制指向指向 `U` 的指针。<br>
///
/// For custom types, the coercion here works by coercing `Foo<T>` to `Foo<U>` provided an impl of `CoerceUnsized<Foo<U>> for Foo<T>` exists. <br>对于自定义类型，这里的强制通过将 `Foo<T>` 强制为 `Foo<U>` 来工作 (如果存在 `CoerceUnsized<Foo<U>> for Foo<T>` 的实现)。<br>
/// Such an impl can only be written if `Foo<T>` has only a single non-phantomdata field involving `T`. <br>仅当 `Foo<T>` 仅具有涉及 `T` 的单个非虚拟数据字段时，才可以写这样的 impl。<br>
/// If the type of that field is `Bar<T>`, an implementation of `CoerceUnsized<Bar<U>> for Bar<T>` must exist. <br>如果该字段的类型为 `Bar<T>`，则必须存在 `CoerceUnsized<Bar<U>> for Bar<T>` 的实现。<br>
/// The coercion will work by coercing the `Bar<T>` field into `Bar<U>` and filling in the rest of the fields from `Foo<T>` to create a `Foo<U>`. <br>coercion 将通过将 `Bar<T>` 字段强制转换为 `Bar<U>` 并填充 `Foo<T>` 的其余字段以创建 `Foo<U>` 来起作用。<br>
/// This will effectively drill down to a pointer field and coerce that. <br>这将有效地向下钻取指针字段并将其强制。<br>
///
/// Generally, for smart pointers you will implement `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, with an optional `?Sized` bound on `T` itself. <br>通常，对于智能指针，您将实现 `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`，并在 `T` 本身上绑定了可选的 `?Sized`。<br>
/// For wrapper types that directly embed `T` like `Cell<T>` and `RefCell<T>`, you can directly implement `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`. <br>对于直接嵌入 `T` 的包装器类型 (例如 `Cell<T>` 和 `RefCell<T>`)，您可以直接实现 `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`。<br>
///
/// This will let coercions of types like `Cell<Box<T>>` work. <br>这将使像 `Cell<Box<T>>` 这样的强制类型起作用。<br>
///
/// [`Unsize`][unsize] is used to mark types which can be coerced to DSTs if behind pointers. <br>[`Unsize`][unsize] 用于标记在指针后面可以强制转换为 DST 的类型。<br> It is implemented automatically by the compiler. <br>它由编译器自动实现。<br>
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T -> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T -> *mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T -> *const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> *const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T -> *mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T -> *const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T -> *const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// `DispatchFromDyn` is used in the implementation of object safety checks (specifically allowing arbitrary self types), to guarantee that a method's receiver type can be dispatched on. <br>`DispatchFromDyn` 用于对象安全检查的实现 (特别允许任意 self 类型)，以保证可以调度方法的接收者类型。<br>
///
/// Note: `DispatchFromDyn` was briefly named `CoerceSized` (and had a slightly different interpretation). <br>`DispatchFromDyn` 被简称为 `CoerceSized` (并有略微不同的解释)。<br>
///
/// Imagine we have a trait object `t` with type `&dyn Tr`, where `Tr` is some trait with a method `m` defined as `fn m(&self);`. <br>想象一下，我们有一个类型为 `&dyn Tr` 的 trait 对象 `t`，其中 `Tr` 是一些 trait，其方法 `m` 定义为 `fn m(&self);`。<br> When calling `t.m()`, the receiver `t` is a wide pointer, but an implementation of `m` will expect a narrow pointer as `&self` (a reference to the concrete type). <br>当调用 `t.m()` 时，接收者 `t` 是一个宽指针，但 `m` 的实现将期望一个 narrow 指针为 `&self` (对具体类型的引用)。<br>
/// The compiler must generate an implicit conversion from the trait object/wide pointer to the concrete reference/narrow pointer. <br>编译器必须生成从 trait object 或 wide 指针到具体 reference 或 narrow 指针的隐式转换。<br>
/// Implementing `DispatchFromDyn` indicates that that conversion is allowed and thus that the type implementing `DispatchFromDyn` is safe to use as the self type in an object-safe method. <br>实现 `DispatchFromDyn` 表示允许这种转换，因此实现 `DispatchFromDyn` 的类型可以安全地用作对象安全方法中的 self 类型。<br>
/// (in the above example, the compiler will require `DispatchFromDyn` is implemented for `&'a U`). <br>(在上面的例子中，编译器将要求为 `&'a U` 实现 `DispatchFromDyn`)。<br>
///
/// `DispatchFromDyn` does not specify the conversion from wide pointer to narrow pointer; <br>`DispatchFromDyn` 没有指定从 wide 指针到 narrow 指针的转换;<br> the conversion is hard-wired into the compiler. <br>转换被硬连接到编译器中。<br>
/// For the conversion to work, the following properties must hold (i.e., it is only safe to implement `DispatchFromDyn` for types which have these properties, these are also checked by the compiler): <br>为使转换工作，以下属性必须保持 (即，只有对具有这些属性的类型实现 `DispatchFromDyn` 才是安全的，编译器也会检查这些属性) :<br>
///
/// * EITHER `Self` and `T` are either both references or both raw pointers; <br>`Self` 和 `T` 要么都是引用，要么都是裸指针;<br> in either case, with the same mutability. <br>无论是哪种情况，都具有相同的可变性。<br>
/// * OR, all of the following hold <br>或者，以下所有条件都成立<br>
///   - `Self` and `T` must have the same type constructor, and only vary in a single type parameter formal (the *coerced type*, e.g., `impl DispatchFromDyn<Rc<T>> for Rc<U>` is ok and the single type parameter (instantiated with `T` or `U`) is the coerced type, `impl DispatchFromDyn<Arc<T>> for Rc<U>` is not ok). <br>`Self` 和 `T` 必须具有相同的类型构造函数，仅在单个类型参数形式上有所不同 (*coerced 类型 *，例如 `impl DispatchFromDyn<Rc<T>> for Rc<U>` 可以，单个类型参数 (用 `T` 或 `U` 实例化) 是强制类型，`impl DispatchFromDyn<Arc<T>> for Rc<U>` 不是行)。<br>
///
///   - The definition for `Self` must be a struct. <br>`Self` 的定义必须是结构体。<br>
///   - The definition for `Self` must not be `#[repr(packed)]` or `#[repr(C)]`. <br>`Self` 的定义不能是 `#[repr(packed)]` 或 `#[repr(C)]`。<br>
///   - Other than one-aligned, zero-sized fields, the definition for `Self` must have exactly one field and that field's type must be the coerced type. <br>除了一对齐的零大小字段，`Self` 的定义必须只有一个字段，并且该字段的类型必须是强制类型。<br> Furthermore, `Self`'s field type must implement `DispatchFromDyn<F>` where `F` is the type of `T`'s field type. <br>此外，`Self` 的字段类型必须实现 `DispatchFromDyn<F>`，其中 `F` 是 `T` 的字段类型的类型。<br>
///
/// An example implementation of the trait: <br>trait 的一个示例实现：<br>
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T -> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T -> *const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T -> *mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}
