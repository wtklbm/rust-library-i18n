//! Converting decimal strings into IEEE 754 binary floating point numbers. <br>将十进制字符串转换为 IEEE 754 二进制浮点数。<br>
//!
//! # Problem statement <br>问题陈述<br>
//!
//! We are given a decimal string such as `12.34e56`. <br>我们给了一个十进制字符串，例如 `12.34e56`。<br>
//! This string consists of integral (`12`), fractional (`34`), and exponent (`56`) parts. <br>该字符串由整数 (`12`)，小数 (`34`) 和指数 (`56`) 组成。<br> All parts are optional and interpreted as zero when missing. <br>所有部分都是可选的，缺少则解释为零。<br>
//!
//! We seek the IEEE 754 floating point number that is closest to the exact value of the decimal string. <br>我们寻求最接近十进制字符串确切值的 IEEE 754 浮点数。<br>
//! It is well-known that many decimal strings do not have terminating representations in base two, so we round to 0.5 units in the last place (in other words, as well as possible). <br>众所周知，许多十进制字符串在基数 2 中都没有终止表示，因此我们将 0.5 单位最后舍入 (换句话说，尽可能)。<br>
//! Ties, decimal values exactly half-way between two consecutive floats, are resolved with the half-to-even strategy, also known as banker's rounding. <br>领带 (精确到两个连续浮点之间的中间的十进制值) 通过半对偶策略 (也称为银行家舍入) 来解决。<br>
//!
//! Needless to say, this is quite hard, both in terms of implementation complexity and in terms of CPU cycles taken. <br>不用说，这在实现复杂性和所用的 CPU 周期方面都相当困难。<br>
//!
//! # Implementation
//!
//! First, we ignore signs. <br>首先，我们忽略迹象。<br> Or rather, we remove it at the very beginning of the conversion process and re-apply it at the very end. <br>或者更确切地说，我们在转换过程的开始就将其删除，然后在结束时将其重新应用。<br>
//! This is correct in all edge cases since IEEE floats are symmetric around zero, negating one simply flips the first bit. <br>这在所有 edge 情况下都是正确的，因为 IEEE 浮点数对称于零左右，取反则仅翻转第一位。<br>
//!
//! Then we remove the decimal point by adjusting the exponent: Conceptually, `12.34e56` turns into `1234e54`, which we describe with a positive integer `f = 1234` and an integer `e = 54`. <br>然后，我们通过调整指数来删除小数点：从概念上讲，`12.34e56` 变为 `1234e54`，我们用正整数 `f = 1234` 和整数 `e = 54` 对其进行描述。<br>
//! The `(f, e)` representation is used by almost all code past the parsing stage. <br>在解析阶段之后，几乎所有代码都使用 `(f, e)` 表示形式。<br>
//!
//! We then try a long chain of progressively more general and expensive special cases using machine-sized integers and small, fixed-sized floating point numbers (first `f32`/`f64`, then a type with 64 bit significand). <br>然后，我们尝试使用机器大小的整数和固定大小的小浮点数 (首先是 `f32`/`f64`，然后是具有 64 位有效数的类型) 的一长串越来越普遍和昂贵的特殊情况。<br>
//!
//! The extended-precision algorithm uses the Eisel-Lemire algorithm, which uses a 128-bit (or 192-bit) representation that can accurately and quickly compute the vast majority of floats. <br>扩展精度算法使用 Eisel-Lemire 算法，该算法使用 128 位 (或 192 位) 表示，可以准确快速地计算绝大多数浮点数。<br>
//! When all these fail, we bite the bullet and resort to using a large-decimal representation, shifting the digits into range, calculating the upper significant bits and exactly round to the nearest representation. <br>当所有这些都失败时，我们硬着头皮求助于使用大十进制表示，将数字移入范围，计算高位有效位并精确四舍五入到最近的表示。<br>
//!
//! Another aspect that needs attention is the ``RawFloat`` trait by which almost all functions are parametrized. <br>需要注意的另一个方面是 ``RawFloat`` trait，几乎所有函数都通过 ``RawFloat`` trait 进行了参数化。<br> One might think that it's enough to parse to `f64` and cast the result to `f32`. <br>有人可能认为解析为 `f64` 并将结果转换为 `f32` 就足够了。<br>
//! Unfortunately this is not the world we live in, and this has nothing to do with using base two or half-to-even rounding. <br>不幸的是，这不是我们生活的世界，这与使用基数二进位或半到四舍五入四舍五入无关。<br>
//!
//! Consider for example two types `d2` and `d4` representing a decimal type with two decimal digits and four decimal digits each and take "0.01499" as input. <br>例如，考虑两种类型的 `d2` 和 `d4`，它们代表具有两个十进制数字和四个十进制数字的十进制类型，并以 "0.01499" 作为输入。<br> Let's use half-up rounding. <br>让我们使用向上舍入。<br>
//! Going directly to two decimal digits gives `0.01`, but if we round to four digits first, we get `0.0150`, which is then rounded up to `0.02`. <br>直接转到两位十进制数字将得到 `0.01`，但是如果我们首先四舍五入到四位数字，则会得到 `0.0150`，然后将其四舍五入为 `0.02`。<br>
//! The same principle applies to other operations as well, if you want 0.5 ULP accuracy you need to do *everything* in full precision and round *exactly once, at the end*, by considering all truncated bits at once. <br>同样的原理也适用于其他操作，如果要获得 0.5 ULP 精度，则需要 *进行全精度的所有操作，并在末尾将* exactly once 舍入*，同时考虑所有截断的位。<br>
//!
//! Primarily, this module and its children implement the algorithms described in: <br>首先，此模块及其子级实现以下算法：<br>
//! "Number Parsing at a Gigabyte per Second", available online: <https://arxiv.org/abs/2101.11408>. <br>"以每秒千兆字节的速度进行数字解析"，在线提供: <https://arxiv.org/abs/2101.11408>。<br>
//!
//! # Other
//!
//! The conversion should *never* panic. <br>转换应 *从不* panic。<br>
//! There are assertions and explicit panics in the code, but they should never be triggered and only serve as internal sanity checks. <br>在代码中有断言和显式的 panics，但是它们绝不应该被触发，而仅用作内部的健全性检查。<br> Any panics should be considered a bug. <br>任何 panics 都应视为错误。<br>
//!
//! There are unit tests but they are woefully inadequate at ensuring correctness, they only cover a small percentage of possible errors. <br>虽然有单元测试，但它们在确保正确性上还远远不够，它们只覆盖了很小一部分可能的错误。<br>
//! Far more extensive tests are located in the directory `src/etc/test-float-parse` as a Python script. <br>更广泛的测试作为 Python 脚本位于目录 `src/etc/test-float-parse` 中。<br>
//!
//! A note on integer overflow: Many parts of this file perform arithmetic with the decimal exponent `e`. <br>关于整型溢出的注意事项：该文件的许多部分都使用十进制指数 `e` 来执行算术运算。<br>
//! Primarily, we shift the decimal point around: Before the first decimal digit, after the last decimal digit, and so on. <br>首先，我们将小数点移动：在第一个十进制数字之前，在最后一个十进制数字之后，依此类推。<br> This could overflow if done carelessly. <br>如果不小心这样做可能会溢出。<br>
//! We rely on the parsing submodule to only hand out sufficiently small exponents, where "sufficient" means "such that the exponent +/- the number of decimal digits fits into a 64 bit integer". <br>我们依靠解析子模块仅分发足够小的指数，其中 "sufficient" 表示 "such that the exponent +/- the number of decimal digits fits into a 64 bit integer"。<br>
//! Larger exponents are accepted, but we don't do arithmetic with them, they are immediately turned into {positive,negative} {zero,infinity}. <br>较大的指数被接受，但是我们不对它们进行算术运算，它们立即变成 {positive,negative} {zero,infinity}。<br>
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::common::{BiasedFp, ByteSlice};
use self::float::RawFloat;
use self::lemire::compute_float;
use self::parse::{parse_inf_nan, parse_number};
use self::slow::parse_long_mantissa;

mod common;
mod decimal;
mod fpu;
mod slow;
mod table;
// float is used in flt2dec, and all are used in unit tests. <br>在 flt2dec 中使用 float，在单元测试中全部使用。<br>
pub mod float;
pub mod lemire;
pub mod number;
pub mod parse;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// Converts a string in base 10 to a float. <br>将以 10 为底的字符串转换为浮点数。<br>
            /// Accepts an optional decimal exponent. <br>接受可选的十进制指数。<br>
            ///
            /// This function accepts strings such as <br>该函数接受诸如以下的字符串<br>
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', or equivalently, '2.5e10' <br>'2.5E10'，或等效的 '2.5e10'<br>
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', or, equivalently, '0.5' <br>'.5'，或等效地，'0.5'<br>
            /// * 'inf', '-inf', '+infinity', 'NaN'
            ///
            /// Note that alphabetical characters are not case-sensitive. <br>请注意，字母字符不区分大小写。<br>
            ///
            /// Leading and trailing whitespace represent an error. <br>前导和尾随空格表示错误。<br>
            ///
            /// # Grammar
            ///
            /// All strings that adhere to the following [EBNF] grammar when lowercased will result in an [`Ok`] being returned: <br>小写时遵循以下 [EBNF] 语法的所有字符串都将返回 [`Ok`]:<br>
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'infinity' | 'nan' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= 'e' Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Arguments
            ///
            /// * src - A string <br>src - 字符串<br>
            ///
            /// # Return value <br>返回值<br>
            ///
            /// `Err(ParseFloatError)` if the string did not represent a valid number. <br>`Err(ParseFloatError)` 如果字符串不代表有效数字。<br>
            /// Otherwise, `Ok(n)` where `n` is the closest representable floating-point number to the number represented by `src` (following the same rules for rounding as for the results of primitive operations). <br>否则，`Ok(n)`，其中 `n` 是与 `src` 表示的数字最接近的可表示浮点数 (遵循与原始运算结果相同的舍入规则)。<br>
            ///
            ///
            ///
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// An error which can be returned when parsing a float. <br>解析浮点数时可以返回的错误。<br>
///
/// This error is used as the error type for the [`FromStr`] implementation for [`f32`] and [`f64`]. <br>该错误用作 [`f32`] 和 [`f64`] 的 [`FromStr`] 实现的错误类型。<br>
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {e}");
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

pub(super) fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

// Used in unit tests, keep public. <br>用于单元测试，保持公开。<br>
// This is much better than making FloatErrorKind and ParseFloatError::kind public. <br>这比公开 FloatErrorKind 和 ParseFloatError::kind 好得多。<br>
pub fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// Converts a `BiasedFp` to the closest machine float type. <br>将 `BiasedFp` 转换为最接近的机器浮点类型。<br>
fn biased_fp_to_float<T: RawFloat>(x: BiasedFp) -> T {
    let mut word = x.f;
    word |= (x.e as u64) << T::MANTISSA_EXPLICIT_BITS;
    T::from_u64_bits(word)
}

/// Converts a decimal string into a floating point number. <br>将十进制字符串转换为浮点数。<br>
pub fn dec2flt<F: RawFloat>(s: &str) -> Result<F, ParseFloatError> {
    let mut s = s.as_bytes();
    let c = if let Some(&c) = s.first() {
        c
    } else {
        return Err(pfe_empty());
    };
    let negative = c == b'-';
    if c == b'-' || c == b'+' {
        s = s.advance(1);
    }
    if s.is_empty() {
        return Err(pfe_invalid());
    }

    let num = match parse_number(s, negative) {
        Some(r) => r,
        None if let Some(value) = parse_inf_nan(s, negative) => return Ok(value),
        None => return Err(pfe_invalid()),
    };
    if let Some(value) = num.try_fast_path::<F>() {
        return Ok(value);
    }

    // If significant digits were truncated, then we can have rounding error only if `mantissa + 1` produces a different result. <br>如果有效数字被截断，那么只有当 `mantissa + 1` 产生不同的结果时，我们才会有舍入错误。<br>
    // We also avoid redundantly using the Eisel-Lemire algorithm if it was unable to correctly round on the first pass. <br>如果 Eisel-Lemire 算法无法在第一次通过时正确取整，我们也会避免使用多余的 Eisel-Lemire 算法。<br>
    //
    //
    let mut fp = compute_float::<F>(num.exponent, num.mantissa);
    if num.many_digits && fp.e >= 0 && fp != compute_float::<F>(num.exponent, num.mantissa + 1) {
        fp.e = -1;
    }
    // Unable to correctly round the float using the Eisel-Lemire algorithm. <br>无法使用 Eisel-Lemire 算法正确舍入浮点数。<br>
    // Fallback to a slower, but always correct algorithm. <br>回退到较慢但始终正确的算法。<br>
    if fp.e < 0 {
        fp = parse_long_mantissa::<F>(s);
    }

    let mut float = biased_fp_to_float::<F>(fp);
    if num.negative {
        float = -float;
    }
    Ok(float)
}
