//! Constants for the 16-bit signed integer type. <br>16 位带符号整数类型的常量。<br>
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! New code should use the associated constants directly on the primitive type. <br>新代码应直接在原始类型上使用关联的常量。<br>

#![stable(feature = "rust1", since = "1.0.0")]
#![deprecated(
    since = "TBD",
    note = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }
