//! Constants for the pointer-sized signed integer type. <br>指针大小的有符号整数类型的常量。<br>
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! New code should use the associated constants directly on the primitive type. <br>新代码应直接在原始类型上使用关联的常量。<br>

#![stable(feature = "rust1", since = "1.0.0")]
#![deprecated(
    since = "TBD",
    note = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }
