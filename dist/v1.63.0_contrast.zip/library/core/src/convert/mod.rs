//! Traits for conversions between types. <br>用于类型之间的转换 traits。<br>
//!
//! The traits in this module provide a way to convert from one type to another type. <br>此模块中的 traits 提供了一种从一种类型转换为另一种类型的方法。<br>
//! Each trait serves a different purpose: <br>每个 trait 都有不同的用途：<br>
//!
//! - Implement the [`AsRef`] trait for cheap reference-to-reference conversions <br>实现 [`AsRef`] trait 以实现廉价的引用到引用转换<br>
//! - Implement the [`AsMut`] trait for cheap mutable-to-mutable conversions <br>实现 [`AsMut`] trait 进行廉价的变量到变量转换<br>
//! - Implement the [`From`] trait for consuming value-to-value conversions <br>实现 [`From`] trait 以进行值到值的转换<br>
//! - Implement the [`Into`] trait for consuming value-to-value conversions to types outside the current crate <br>实现 [`Into`] trait，以便将值转换为当前 crate 之外的类型<br>
//! - The [`TryFrom`] and [`TryInto`] traits behave like [`From`] and [`Into`], but should be implemented when the conversion can fail. <br>[`TryFrom`] 和 [`TryInto`] traits 的行为类似于 [`From`] 和 [`Into`]，但应在转换失败时实现。<br>
//!
//! The traits in this module are often used as trait bounds for generic functions such that to arguments of multiple types are supported. <br>此模块中的 traits 通常用作泛型函数的 trait bounds，以便支持多种类型的参数。<br> See the documentation of each trait for examples. <br>有关示例，请参见每个 trait 的文档。<br>
//!
//! As a library author, you should always prefer implementing [`From<T>`][`From`] or [`TryFrom<T>`][`TryFrom`] rather than [`Into<U>`][`Into`] or [`TryInto<U>`][`TryInto`], as [`From`] and [`TryFrom`] provide greater flexibility and offer equivalent [`Into`] or [`TryInto`] implementations for free, thanks to a blanket implementation in the standard library. <br>作为库作者，您应该总是更喜欢实现 [`From<T>`][`From`] 或 [`TryFrom<T>`][`TryFrom`]，而不是 [`Into<U>`][`Into`] 或 [`TryInto<U>`][`TryInto`]，因为 [`From`] 和 [`TryFrom`] 提供了更大的灵活性，并免费提供了等效的 [`Into`] 或 [`TryInto`] 实现，这要归功于标准库中的全面实现。<br>
//! When targeting a version prior to Rust 1.41, it may be necessary to implement [`Into`] or [`TryInto`] directly when converting to a type outside the current crate. <br>当定位到 Rust 1.41 之前的版本时，当转换为当前 crate 之外的类型时，可能有必要直接实现 [`Into`] 或 [`TryInto`]。<br>
//!
//! # Generic Implementations <br>泛型实现<br>
//!
//! - [`AsRef`] and [`AsMut`] auto-dereference if the inner type is a reference <br>如果内部类型是引用，则 [`AsRef`] 和 [`AsMut`] 自动解引用<br>
//! - [`From`]`<U> for T` implies [`Into`]`<T> for U` <br>[`From`]`<U> for T` 意味着 [`Into`]`<T> for U`<br>
//! - [`TryFrom`]`<U> for T` implies [`TryInto`]`<T> for U` <br>[`TryFrom`]`<U> for T` 意味着 [`TryInto`]`<T> for U`<br>
//! - [`From`] and [`Into`] are reflexive, which means that all types can `into` themselves and `from` themselves <br>[`From`] 和 [`Into`] 是反射的，这意味着所有类型都可以 `into` 自己和 `from` 自己<br>
//!
//! See each trait for usage examples. <br>有关用法示例，请参见每个 trait。<br>
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// The identity function. <br>identity 函数。<br>
///
/// Two things are important to note about this function: <br>关于此函数，有两点需要注意：<br>
///
/// - It is not always equivalent to a closure like `|x| x`, since the closure may coerce `x` into a different type. <br>它并不总是等同于 `|x| x` 之类的闭包，因为闭包可能会将 `x` 强制转换为其他类型。<br>
///
/// - It moves the input `x` passed to the function. <br>它将输入 `x` 传递给函数。<br>
///
/// While it might seem strange to have a function that just returns back the input, there are some interesting uses. <br>虽然有一个只返回输入的函数似乎很奇怪，但是有一些有趣的用法。<br>
///
///
/// # Examples
///
/// Using `identity` to do nothing in a sequence of other, interesting, functions: <br>使用 `identity` 在其他有趣的函数序列中什么也不做：<br>
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Let's pretend that adding one is an interesting function. <br>让我们假设添加一个是一个有趣的函数。<br>
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Using `identity` as a "do nothing" base case in a conditional: <br>在条件中将 `identity` 用作 "什么也不做" 的基本情况：<br>
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Do more interesting stuff... <br>做更多有趣的事情...<br>
///
/// let _results = do_stuff(42);
/// ```
///
/// Using `identity` to keep the `Some` variants of an iterator of `Option<T>`: <br>使用 `identity` 保留 `Option<T>` 迭代器的 `Some` 变体：<br>
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = [Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Used to do a cheap reference-to-reference conversion. <br>用于执行廉价的引用到引用转换。<br>
///
/// This trait is similar to [`AsMut`] which is used for converting between mutable references. <br>一个类似于 [`AsMut`] 的 trait，用于在可变引用之间进行转换。<br>
/// If you need to do a costly conversion it is better to implement [`From`] with type `&T` or write a custom function. <br>如果您需要进行代价高昂的转换，最好用 `&T` 类型实现 [`From`]，或者编写一个自定义函数。<br>
///
/// `AsRef` has the same signature as [`Borrow`], but [`Borrow`] is different in a few aspects: <br>`AsRef` 与 [`Borrow`] 具有相同的签名，但 [`Borrow`] 在以下几个方面有所不同:<br>
///
/// - Unlike `AsRef`, [`Borrow`] has a blanket impl for any `T`, and can be used to accept either a reference or a value. <br>与 `AsRef` 不同，[`Borrow`] 对任何 `T` 都有一个毯子暗示，可用于接受引用或值。<br>
/// - [`Borrow`] also requires that [`Hash`], [`Eq`] and [`Ord`] for a borrowed value are equivalent to those of the owned value. <br>[`Borrow`] 还要求借用值的 [`Hash`]、[`Eq`] 和 [`Ord`] 与拥有值的值相等。<br>
/// For this reason, if you want to borrow only a single field of a struct you can implement `AsRef`, but not [`Borrow`]. <br>因此，如果只想借用一个结构体的单个字段，则可以实现 `AsRef`，而不能实现 [`Borrow`]。<br>
///
/// **Note: This trait must not fail**. <br>**注意：此 trait 一定不能失败**。<br> If the conversion can fail, use a dedicated method which returns an [`Option<T>`] or a [`Result<T, E>`]. <br>如果转换失败，请使用专用方法返回 [`Option<T>`] 或 [`Result<T, E>`]。<br>
///
/// # Generic Implementations <br>泛型实现<br>
///
/// - `AsRef` auto-dereferences if the inner type is a reference or a mutable reference (e.g.: `foo.as_ref()` will work the same if `foo` has type `&mut Foo` or `&&mut Foo`) <br>如果内部类型是引用或可变引用，则 `AsRef` 自动解引用 (例如：如果 `foo` 具有类型 `&mut Foo` 或 `&&mut Foo`，则 `foo.as_ref()` 将同样有效)<br>
///
///
/// # Examples
///
/// By using trait bounds we can accept arguments of different types as long as they can be converted to the specified type `T`. <br>通过使用 trait bounds，我们可以接受不同类型的参数，只要它们可以转换为指定的 `T` 类型即可。<br>
///
/// For example: By creating a generic function that takes an `AsRef<str>` we express that we want to accept all references that can be converted to [`&str`] as an argument. <br>例如：通过创建一个采用 `AsRef<str>` 的泛型函数，我们表示我们希望接受所有可以转换为 [`&str`] 的引用作为参数。<br>
/// Since both [`String`] and [`&str`] implement `AsRef<str>` we can accept both as input argument. <br>由于 [`String`] 和 [`&str`] 都实现了 `AsRef<str>`，因此我们可以将两者都用作输入参数。<br>
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "AsRef")]
pub trait AsRef<T: ?Sized> {
    /// Converts this type into a shared reference of the (usually inferred) input type. <br>将此类型转换为 (通常是推断的) 输入类型的共享引用。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Used to do a cheap mutable-to-mutable reference conversion. <br>用于进行廉价的可变到可变引用转换。<br>
///
/// This trait is similar to [`AsRef`] but used for converting between mutable references. <br>一个与 [`AsRef`] 类似的 trait，但用于在可变引用之间进行转换。<br>
/// If you need to do a costly conversion it is better to implement [`From`] with type `&mut T` or write a custom function. <br>如果需要进行昂贵的转换，最好用 `&mut T` 类型实现 [`From`] 或编写自定义函数。<br>
///
/// **Note: This trait must not fail**. <br>**注意：此 trait 一定不能失败**。<br> If the conversion can fail, use a dedicated method which returns an [`Option<T>`] or a [`Result<T, E>`]. <br>如果转换失败，请使用专用方法返回 [`Option<T>`] 或 [`Result<T, E>`]。<br>
///
/// # Generic Implementations <br>泛型实现<br>
///
/// - `AsMut` auto-dereferences if the inner type is a mutable reference (e.g.: `foo.as_mut()` will work the same if `foo` has type `&mut Foo` or `&mut &mut Foo`) <br>如果内部类型是可变引用，则 `AsMut` 自动解引用（例如：如果 `foo` 具有类型 `&mut Foo` 或 `&mut &mut Foo`，则 `foo.as_mut ()` 将工作相同）<br>
///
///
/// # Examples
///
/// Using `AsMut` as trait bound for a generic function we can accept all mutable references that can be converted to type `&mut T`. <br>使用 `AsMut` 作为泛型函数的 trait bound，我们可以接受所有可以转换为 `&mut T` 类型的变量引用。<br>
/// Because [`Box<T>`] implements `AsMut<T>` we can write a function `add_one` that takes all arguments that can be converted to `&mut u64`. <br>因为 [`Box<T>`] 实现了 `AsMut<T>`，所以我们可以编写一个函数 `add_one`，该函数采用可以转换为 `&mut u64` 的所有参数。<br>
/// Because [`Box<T>`] implements `AsMut<T>`, `add_one` accepts arguments of type `&mut Box<u64>` as well: <br>由于 [`Box<T>`] 实现 `AsMut<T>`，因此 `add_one` 也接受 `&mut Box<u64>` 类型的参数：<br>
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "AsMut")]
pub trait AsMut<T: ?Sized> {
    /// Converts this type into a mutable reference of the (usually inferred) input type. <br>将此类型转换为 (通常是推断的) 输入类型的错误引用。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// A value-to-value conversion that consumes the input value. <br>消耗输入值的值到值转换。<br> The opposite of [`From`]. <br>与 [`From`] 相反。<br>
///
/// One should avoid implementing [`Into`] and implement [`From`] instead. <br>应该避免实现 [`Into`]，而应实现 [`From`]。<br>
/// Implementing [`From`] automatically provides one with an implementation of [`Into`] thanks to the blanket implementation in the standard library. <br>由于标准库中的全面实现，因此 [`From`] 的自动实现为 [`Into`] 的实现提供了一个实现。<br>
///
/// Prefer using [`Into`] over [`From`] when specifying trait bounds on a generic function to ensure that types that only implement [`Into`] can be used as well. <br>在泛型函数上指定 trait bounds 时，最好使用 [`Into`] 而不是 [`From`]，以确保也可以使用仅实现 [`Into`] 的类型。<br>
///
/// **Note: This trait must not fail**. <br>**注意：此 trait 一定不能失败**。<br> If the conversion can fail, use [`TryInto`]. <br>如果转换可能失败，请使用 [`TryInto`]。<br>
///
/// # Generic Implementations <br>泛型实现<br>
///
/// - [`From`]`<T> for U` implies `Into<U> for T` <br>[`From`]`<T> for U` 意味着 `Into<U> for T`<br>
/// - [`Into`] is reflexive, which means that `Into<T> for T` is implemented <br>[`Into`] 是反射的，这意味着 `Into<T> for T` 被实现<br>
///
/// # Implementing [`Into`] for conversions to external types in old versions of Rust <br>在旧版本的 Rust 中实现 [`Into`] 转换为外部类型<br>
///
/// Prior to Rust 1.41, if the destination type was not part of the current crate then you couldn't implement [`From`] directly. <br>在 Rust 1.41 之前，如果目标类型不是当前 crate 的一部分，那么您将无法直接实现 [`From`]。<br>
/// For example, take this code: <br>例如，使用以下代码：<br>
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// This will fail to compile in older versions of the language because Rust's orphaning rules used to be a little bit more strict. <br>由于 Rust 的孤儿规则过去要严格一些，因此无法在较旧的语言版本中进行编译。<br>
/// To bypass this, you could implement [`Into`] directly: <br>要绕过它，您可以直接实现 [`Into`]：<br>
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// It is important to understand that [`Into`] does not provide a [`From`] implementation (as [`From`] does with [`Into`]). <br>重要的是要了解 [`Into`] 不提供 [`From`] 实现 (就像 [`From`] 与 [`Into`] 一样)。<br>
/// Therefore, you should always try to implement [`From`] and then fall back to [`Into`] if [`From`] can't be implemented. <br>因此，您应该始终尝试实现 [`From`]，如果无法实现 [`From`]，则应回退到 [`Into`]。<br>
///
/// # Examples
///
/// [`String`] implements [`Into`]`<`[`Vec`]`<`[`u8`]`>>`: <br>[`String`] 实现 [`Into`]`<`[`Vec`]`<`[`u8`]`>>`：<br>
///
/// In order to express that we want a generic function to take all arguments that can be converted to a specified type `T`, we can use a trait bound of [`Into`]`<T>`. <br>为了表示我们希望泛型函数采用所有可以转换为指定类型 `T` 的参数，我们可以使用 [`Into`]`<T>` 的 trait bound。<br>
///
/// For example: The function `is_hello` takes all arguments that can be converted into a [`Vec`]`<`[`u8`]`>`. <br>例如：函数 `is_hello` 接受所有可以转换为 [`Vec`]`<`[`u8`]`>` 的参数。<br>
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "Into"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Converts this type into the (usually inferred) input type. <br>将此类型转换为 (通常是推断的) 输入类型。<br>
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Used to do value-to-value conversions while consuming the input value. <br>用于在消耗输入值的同时进行值到值的转换。<br> It is the reciprocal of [`Into`]. <br>它是 [`Into`] 的倒数。<br>
///
/// One should always prefer implementing `From` over [`Into`] because implementing `From` automatically provides one with an implementation of [`Into`] thanks to the blanket implementation in the standard library. <br>与标准 [`Into`] 相比，人们应该总是更喜欢实现 `From`，因为由于标准库中的全面实现，实现 `From` 会自动为 [`Into`] 提供一个 [`Into`] 的实现。<br>
///
///
/// Only implement [`Into`] when targeting a version prior to Rust 1.41 and converting to a type outside the current crate. <br>仅当针对 Rust 1.41 之前的版本并将其转换为当前 crate 以外的类型时，才实现 [`Into`]。<br>
/// `From` was not able to do these types of conversions in earlier versions because of Rust's orphaning rules. <br>由于 Rust 的孤儿规则，`From` 在早期版本中无法进行这些类型的转换。<br>
/// See [`Into`] for more details. <br>有关更多详细信息，请参见 [`Into`]。<br>
///
/// Prefer using [`Into`] over using `From` when specifying trait bounds on a generic function. <br>在泛型函数上指定 trait bounds 时，优先使用 [`Into`]。<br>
/// This way, types that directly implement [`Into`] can be used as arguments as well. <br>这样，直接实现 [`Into`] 的类型也可以用作参数。<br>
///
/// The `From` is also very useful when performing error handling. <br>`From` 在执行错误处理时也非常有用。<br> When constructing a function that is capable of failing, the return type will generally be of the form `Result<T, E>`. <br>当创建一个能够失败的函数时，返回类型通常为 `Result<T, E>` 形式。<br>
/// The `From` trait simplifies error handling by allowing a function to return a single error type that encapsulate multiple error types. <br>`From` trait 通过允许函数返回封装了多种错误类型的单个错误类型，简化了错误处理。<br> See the "Examples" section and [the book][book] for more details. <br>有关更多详细信息，请参见示例部分和这本 [书][book]。<br>
///
/// **Note: This trait must not fail**. <br>**注意：此 trait 一定不能失败**。<br> The `From` trait is intended for perfect conversions. <br>`From` trait 旨在实现完美转换。<br>
/// If the conversion can fail or is not perfect, use [`TryFrom`]. <br>如果转换失败或不完美，请使用 [`TryFrom`]。<br>
///
/// # Generic Implementations <br>泛型实现<br>
///
/// - `From<T> for U` implies [`Into`]`<U> for T` <br>`From<T> for U` 意味着 [`Into`]`<U> for T`<br>
/// - `From` is reflexive, which means that `From<T> for T` is implemented <br>`From` 是反射的，这意味着 `From<T> for T` 被实现<br>
///
/// # Examples
///
/// [`String`] implements `From<&str>`: <br>[`String`] 实现 `From<&str>`：<br>
///
/// An explicit conversion from a `&str` to a String is done as follows: <br>从 `&str` 到字符串的显式转换如下：<br>
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// While performing error handling it is often useful to implement `From` for your own error type. <br>在执行错误处理时，通常对于您自己的错误类型实现 `From` 很有用。<br>
/// By converting underlying error types to our own custom error type that encapsulates the underlying error type, we can return a single error type without losing information on the underlying cause. <br>通过将底层错误类型转换为封装底层错误类型的自定义错误类型，我们可以返回单个错误类型，而不会丢失有关底层原因的信息。<br>
/// The '?' operator automatically converts the underlying error type to our custom error type by calling `Into<CliError>::into` which is automatically provided when implementing `From`. <br>'?' 运算符通过调用 `Into<CliError>::into` 自动将底层错误类型转换为我们的自定义错误类型，该 `Into<CliError>::into` 是在实现 `From` 时自动提供的。<br>
/// The compiler then infers which implementation of `Into` should be used. <br>然后，编译器会推断应使用 `Into` 的哪种实现。<br>
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "From"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Converts to this type from the input type. <br>从输入类型转换为此类型。<br>
    #[lang = "from"]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// An attempted conversion that consumes `self`, which may or may not be expensive. <br>消耗 `self` 的尝试转换，这可能很昂贵，也可能不昂贵。<br>
///
/// Library authors should usually not directly implement this trait, but should prefer implementing the [`TryFrom`] trait, which offers greater flexibility and provides an equivalent `TryInto` implementation for free, thanks to a blanket implementation in the standard library. <br>库作者通常不应直接实现此 trait，而应首选实现 [`TryFrom`] trait，它具有更大的灵活性，并免费提供了等效的 `TryInto` 实现，这要归功于标准库中的全面实现。<br>
/// For more information on this, see the documentation for [`Into`]. <br>有关此的更多信息，请参见 [`Into`] 的文档。<br>
///
/// # Implementing `TryInto` <br>实现 `TryInto`<br>
///
/// This suffers the same restrictions and reasoning as implementing [`Into`], see there for details. <br>这与实现 [`Into`] 受到相同的限制和推理，有关详细信息，请参见此处。<br>
///
///
///
///
///
///
#[rustc_diagnostic_item = "TryInto"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// The type returned in the event of a conversion error. <br>发生转换错误时返回的类型。<br>
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Performs the conversion. <br>执行转换。<br>
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Simple and safe type conversions that may fail in a controlled way under some circumstances. <br>简单安全的类型转换在某些情况下可能会以受控方式失败。<br> It is the reciprocal of [`TryInto`]. <br>它是 [`TryInto`] 的倒数。<br>
///
/// This is useful when you are doing a type conversion that may trivially succeed but may also need special handling. <br>当您进行的类型转换可能会成功完成但可能还需要特殊处理时，这很有用。<br>
/// For example, there is no way to convert an [`i64`] into an [`i32`] using the [`From`] trait, because an [`i64`] may contain a value that an [`i32`] cannot represent and so the conversion would lose data. <br>例如，无法使用 [`From`] trait 将 [`i64`] 转换为 [`i32`]，因为 [`i64`] 可能包含 [`i32`] 无法表示的值，因此转换将丢失数据。<br>
///
/// This might be handled by truncating the [`i64`] to an [`i32`] (essentially giving the [`i64`]'s value modulo [`i32::MAX`]) or by simply returning [`i32::MAX`], or by some other method. <br>这可以通过将 [`i64`] 截断为 [`i32`] (本质上给 [`i64`] 的值取 [`i32::MAX`] 模) 或通过简单地返回 [`i32::MAX`] 或其他方法来处理。<br>
/// The [`From`] trait is intended for perfect conversions, so the `TryFrom` trait informs the programmer when a type conversion could go bad and lets them decide how to handle it. <br>[`From`] trait 用于完美的转换，因此 `TryFrom` trait 会通知程序员类型转换何时会变差，并让他们决定如何处理它。<br>
///
/// # Generic Implementations <br>泛型实现<br>
///
/// - `TryFrom<T> for U` implies [`TryInto`]`<U> for T` <br>`TryFrom<T> for U` 意味着 [`TryInto`]`<U> for T`<br>
/// - [`try_from`] is reflexive, which means that `TryFrom<T> for T` is implemented and cannot fail -- the associated `Error` type for calling `T::try_from()` on a value of type `T` is [`Infallible`]. <br>[`try_from`] 是反射的，这意味着 `TryFrom<T> for T` 已实现并且不会失败 -- 用于在类型 `T` 上调用 `T::try_from()` 的关联 `Error` 类型是 [`Infallible`]。<br>
/// When the [`!`] type is stabilized [`Infallible`] and [`!`] will be equivalent. <br>当 [`!`] 类型稳定后，[`Infallible`] 和 [`!`] 将等效。<br>
///
/// `TryFrom<T>` can be implemented as follows: <br>`TryFrom<T>` 可以实现如下：<br>
///
/// ```
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// As described, [`i32`] implements `TryFrom<`[`i64`]`>`: <br>如上所述，[`i32`] 实现了 `TryFrom<`[`i64`]`>`：<br>
///
/// ```
/// let big_number = 1_000_000_000_000i64;
/// // Silently truncates `big_number`, requires detecting and handling the truncation after the fact. <br>默默地截断 `big_number`，事实之后需要检测并处理该截断。<br>
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Returns an error because `big_number` is too big to fit in an `i32`. <br>由于 `big_number` 太大而无法容纳在 `i32` 中，因此返回错误。<br>
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Returns `Ok(3)`. <br>返回 `Ok(3)`。<br>
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "TryFrom"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// The type returned in the event of a conversion error. <br>发生转换错误时返回的类型。<br>
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Performs the conversion. <br>执行转换。<br>
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERIC IMPLS <br>泛型 IMPLS<br>
////////////////////////////////////////////////////////////////////////////////

// As lifts over &
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T: ?Sized, U: ?Sized> const AsRef<U> for &T
where
    T: ~const AsRef<U>,
{
    #[inline]
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// As lifts over &mut
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T: ?Sized, U: ?Sized> const AsRef<U> for &mut T
where
    T: ~const AsRef<U>,
{
    #[inline]
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): replace the above impls for &/&mut with the following more general one: <br>用以下更通用的替代替换 &/&mut 的上述 impls：<br>
// // As lifts over Deref <br>As lifts over &mut<br>
// impl<D: ?Sized + Deref<Target: AsRef<U>>, U: ?Sized> AsRef<U> for D { fn as_ref(&self) -> &U {        self.deref().as_ref() } }
//
//
//
//

// AsMut lifts over &mut
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T: ?Sized, U: ?Sized> const AsMut<U> for &mut T
where
    T: ~const AsMut<U>,
{
    #[inline]
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): replace the above impl for &mut with the following more general one: <br>用以下更通用的替代替换 &mut 的上述隐含内容：<br>
// // AsMut lifts over DerefMut
// impl<D: ?Sized + Deref<Target: AsMut<U>>, U: ?Sized> AsMut<U> for D { fn as_mut(&mut self) -> &mut U {        self.deref_mut().as_mut() } }
//
//
//
//

// From implies Into <br>From 暗指 Into<br>
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T, U> const Into<U> for T
where
    U: ~const From<T>,
{
    /// Calls `U::from(self)`. <br>调用 `U::from(self)`。<br>
    ///
    /// That is, this conversion is whatever the implementation of <code>[From]<T> for U</code> chooses to do. <br>也就是说，这种转换是 <code>[From]<T> for U</code> 实现选择执行的任何操作。<br>
    ///
    fn into(self) -> U {
        U::from(self)
    }
}

// From (and thus Into) is reflexive <br>From (因此 Into) 是反射性的<br>
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T> const From<T> for T {
    /// Returns the argument unchanged. <br>返回未更改的参数。<br>
    fn from(t: T) -> T {
        t
    }
}

/// **Stability note:** This impl does not yet exist, but we are "reserving space" to add it in the future. <br>**稳定性注意事项:** 该 impl 尚不存在，但我们 "保留空间" 以在将来添加它。<br>
/// See [rust-lang/rust#64715][#64715] for details. <br>有关详细信息，请参见 [rust-lang/rust#64715][#64715]。<br>
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): do a principled fix instead. <br>做一个有原则的修复。<br>
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T> const From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implies TryInto <br>TryFrom 表示 TryInto<br>
#[stable(feature = "try_from", since = "1.34.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T, U> const TryInto<U> for T
where
    U: ~const TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Infallible conversions are semantically equivalent to fallible conversions with an uninhabited error type. <br>可靠的转换在语义上等同于错误类型没有错误的可靠的转换。<br>
//
#[stable(feature = "try_from", since = "1.34.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T, U> const TryFrom<U> for T
where
    U: ~const Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// CONCRETE IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// THE NO-ERROR ERROR TYPE <br>NO-ERROR 错误类型<br>
////////////////////////////////////////////////////////////////////////////////

/// The error type for errors that can never happen. <br>永远不会发生的错误的错误类型。<br>
///
/// Since this enum has no variant, a value of this type can never actually exist. <br>由于此枚举没有变体，因此这种类型的值实际上永远不会存在。<br>
/// This can be useful for generic APIs that use [`Result`] and parameterize the error type, to indicate that the result is always [`Ok`]. <br>这对于使用 [`Result`] 并参数化错误类型的泛型 API 很有用，以指示结果始终为 [`Ok`]。<br>
///
/// For example, the [`TryFrom`] trait (conversion that returns a [`Result`]) has a blanket implementation for all types where a reverse [`Into`] implementation exists. <br>例如，对于存在反向 [`Into`] 实现的所有类型，[`TryFrom`] trait (返回 [`Result`] 的转换) 都具有通用实现。<br>
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err` <br>永不返回 `Err`<br>
///     }
/// }
/// ```
///
/// # Future compatibility <br>Future 兼容性<br>
///
/// This enum has the same role as [the `!` “never” type][never], which is unstable in this version of Rust. <br>该枚举与 [never 类型 (`!`)][never] 具有相同的作用，在此版本的 Rust 中是不稳定的。<br>
/// When `!` is stabilized, we plan to make `Infallible` a type alias to it: <br>当 `!` 稳定后，我们计划将 `Infallible` 用作它的类型别名：<br>
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// … and eventually deprecate `Infallible`. <br>并最终弃用 `Infallible`。<br>
///
/// However there is one case where `!` syntax can be used before `!` is stabilized as a full-fledged type: in the position of a function’s return type. <br>但是，在一种情况下，可以在将 `!` 稳定为完整类型之前使用 `!` 语法：在函数的返回类型位置。<br>
/// Specifically, it is possible to have implementations for two different function pointer types: <br>具体来说，可以实现两种不同的函数指针类型：<br>
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// With `Infallible` being an enum, this code is valid. <br>`Infallible` 是一个枚举，这个代码是有效的。<br>
/// However when `Infallible` becomes an alias for the never type, the two `impl`s will start to overlap and therefore will be disallowed by the language’s trait coherence rules. <br>但是，当 `Infallible` 成为 never type 的别名时，两个 `impl` 将开始重叠，因此将被语言的 trait 一致性规则所禁止。<br>
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
#[rustc_const_unstable(feature = "const_clone", issue = "91805")]
impl const Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl const From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}
