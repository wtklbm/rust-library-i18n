//! Basic functions for dealing with memory. <br>处理内存的基本函数。<br>
//!
//! This module contains functions for querying the size and alignment of types, initializing and manipulating memory. <br>该模块包含用于查询类型的大小和对齐，初始化和操作内存的函数。<br>
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

mod valid_align;
// For now this type is left crate-local. <br>现在这个类型是 crate-local。<br>
// It could potentially make sense to expose it publicly, as it would be a nice parameter type for methods which need to take alignment as a parameter, such as `Layout::padding_needed_for`. <br>公开公开它可能是有意义的，因为对于需要将对齐作为参数的方法 (例如 `Layout::padding_needed_for`) 来说，这将是一个很好的参数类型。<br>
//
pub(crate) use valid_align::ValidAlign;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Takes ownership and "forgets" about the value **without running its destructor**. <br>获取所有权和 "forgets" 值，而不运行其析构函数。<br>
///
/// Any resources the value manages, such as heap memory or a file handle, will linger forever in an unreachable state. <br>该值管理的任何资源 (例如堆内存或文件句柄) 将永远处于无法访问的状态。<br> However, it does not guarantee that pointers to this memory will remain valid. <br>但是，它不能保证指向该内存的指针将保持有效。<br>
///
/// * If you want to leak memory, see [`Box::leak`]. <br>如果要泄漏内存，请参见 [`Box::leak`]。<br>
/// * If you want to obtain a raw pointer to the memory, see [`Box::into_raw`]. <br>如果要获取内存的裸指针，请参见 [`Box::into_raw`]。<br>
/// * If you want to dispose of a value properly, running its destructor, see [`mem::drop`]. <br>如果要正确处理某个值，请运行其析构函数，请参见 [`mem::drop`]。<br>
///
/// # Safety
///
/// `forget` is not marked as `unsafe`, because Rust's safety guarantees do not include a guarantee that destructors will always run. <br>`forget` 没有标记为 `unsafe`，因为 Rust 的安全保证不包括析构函数将始终运行的保证。<br>
/// For example, a program can create a reference cycle using [`Rc`][rc], or call [`process::exit`][exit] to exit without running destructors. <br>例如，程序可以使用 [`Rc`][rc] 创建引用循环，或调用 [`process::exit`][exit] 退出而不运行析构函数。<br>
/// Thus, allowing `mem::forget` from safe code does not fundamentally change Rust's safety guarantees. <br>因此，从安全代码允许 `mem::forget` 不会从根本上改变 Rust 的安全保证。<br>
///
/// That said, leaking resources such as memory or I/O objects is usually undesirable. <br>也就是说，通常不希望泄漏诸如内存或 I/O 对象之类的资源。<br>
/// The need comes up in some specialized use cases for FFI or unsafe code, but even then, [`ManuallyDrop`] is typically preferred. <br>在某些特殊的用例中，对于 FFI 或不安全代码提出了需求，但即使这样，通常还是首选 [`ManuallyDrop`]。<br>
///
/// Because forgetting a value is allowed, any `unsafe` code you write must allow for this possibility. <br>因为允许忘记一个值，所以您编写的任何 `unsafe` 代码都必须允许这种可能性。<br> You cannot return a value and expect that the caller will necessarily run the value's destructor. <br>您不能返回值，并且期望调用者一定会运行该值的析构函数。<br>
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// The canonical safe use of `mem::forget` is to circumvent a value's destructor implemented by the `Drop` trait. <br>`mem::forget` 的规范安全使用是为了避免 `Drop` trait 实现的值的析构函数。<br> For example, this will leak a `File`, i.e. <br>例如，这将泄漏 `File`，即<br>
/// reclaim the space taken by the variable but never close the underlying system resource: <br>回收变量占用的空间，但不要关闭底层系统资源：<br>
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// This is useful when the ownership of the underlying resource was previously transferred to code outside of Rust, for example by transmitting the raw file descriptor to C code. <br>当底层资源的所有权先前已转移到 Rust 之外的代码时 (例如，通过将原始文件描述符传输到 C 代码)，这很有用。<br>
///
/// # Relationship with `ManuallyDrop` <br>与 `ManuallyDrop` 的关系<br>
///
/// While `mem::forget` can also be used to transfer *memory* ownership, doing so is error-prone. <br>虽然 `mem::forget` 也可以用于转移 *内存* 所有权，但是这样做很容易出错。<br>
/// [`ManuallyDrop`] should be used instead. <br>应改用 [`ManuallyDrop`]。<br> Consider, for example, this code: <br>例如，考虑以下代码：<br>
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Build a `String` using the contents of `v` <br>使用 `v` 的内容构建 `String`<br>
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // leak `v` because its memory is now managed by `s` <br>泄漏 `v`，因为它的内存现在由 `s` 管理<br>
/// mem::forget(v);  // ERROR - v is invalid and must not be passed to a function <br>错误 - v 无效，不得将其传递给函数<br>
/// assert_eq!(s, "Az");
/// // `s` is implicitly dropped and its memory deallocated. <br>`s` 被隐式丢弃，并释放其内存。<br>
/// ```
///
/// There are two issues with the above example: <br>上面的示例有两个问题：<br>
///
/// * If more code were added between the construction of `String` and the invocation of `mem::forget()`, a panic within it would cause a double free because the same memory is handled by both `v` and `s`. <br>如果在 `String` 的构造与 `mem::forget()` 的调用之间添加了更多代码，则其中的 panic 将导致双重释放，因为 `v` 和 `s` 均处理同一内存。<br>
/// * After calling `v.as_mut_ptr()` and transmitting the ownership of the data to `s`, the `v` value is invalid. <br>调用 `v.as_mut_ptr()` 并将数据所有权传输到 `s` 之后，`v` 值无效。<br>
/// Even when a value is just moved to `mem::forget` (which won't inspect it), some types have strict requirements on their values that make them invalid when dangling or no longer owned. <br>即使将值仅移动到 `mem::forget` (不会检查它)，某些类型对其值也有严格的要求，以使它们在悬垂或不再拥有时无效。<br>
/// Using invalid values in any way, including passing them to or returning them from functions, constitutes undefined behavior and may break the assumptions made by the compiler. <br>以任何方式使用无效值，包括将它们传递给函数或从函数中返回它们，都构成未定义的行为，并且可能会破坏编译器所做的假设。<br>
///
/// Switching to `ManuallyDrop` avoids both issues: <br>切换到 `ManuallyDrop` 可以避免两个问题：<br>
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Before we disassemble `v` into its raw parts, make sure it does not get dropped! <br>在将 `v` 解开为原始零件之前，请确保它不会丢弃掉！<br>
/////
/// let mut v = ManuallyDrop::new(v);
/// // Now disassemble `v`. <br>现在解开 `v`。<br> These operations cannot panic, so there cannot be a leak. <br>这些操作不能 panic，因此不会有泄漏。<br>
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Finally, build a `String`. <br>最后，构建一个 `String`。<br>
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` is implicitly dropped and its memory deallocated. <br>`s` 被隐式丢弃，并释放其内存。<br>
/// ```
///
/// `ManuallyDrop` robustly prevents double-free because we disable `v`'s destructor before doing anything else. <br>`ManuallyDrop` 强大地防止双重释放，因为我们在做任何其他事情之前禁用了 `v` 的析构函数。<br>
/// `mem::forget()` doesn't allow this because it consumes its argument, forcing us to call it only after extracting anything we need from `v`. <br>`mem::forget()` 不允许这样做，因为它消耗了它的参数，迫使我们只有在从 `v` 中提取我们需要的任何东西后才能调用它。<br>
/// Even if a panic were introduced between construction of `ManuallyDrop` and building the string (which cannot happen in the code as shown), it would result in a leak and not a double free. <br>即使在 `ManuallyDrop` 的构建与字符串的构建之间引入了 panic (这在所示的代码中不能发生)，也将导致泄漏，而不是双重释放。<br>
/// In other words, `ManuallyDrop` errs on the side of leaking instead of erring on the side of (double-)dropping. <br>换句话说，`ManuallyDrop` 在泄漏的一侧发生错误，而不是在 (两次) 丢弃的一侧发生错误。<br>
///
/// Also, `ManuallyDrop` prevents us from having to "touch" `v` after transferring the ownership to `s` — the final step of interacting with `v` to dispose of it without running its destructor is entirely avoided. <br>同样，`ManuallyDrop` 避免了在将所有权转让给 `s` 之后必须使用 "touch" `v` 的情况-完全避免了与 `v` 交互以处置它而不运行其析构函数的最后一步。<br>
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "mem_forget")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Like [`forget`], but also accepts unsized values. <br>与 [`forget`] 一样，但也接受未定义大小的值。<br>
///
/// This function is just a shim intended to be removed when the `unsized_locals` feature gets stabilized. <br>这个函数只是一个垫片，当 `unsized_locals` 特性稳定时，就会被删除。<br>
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Returns the size of a type in bytes. <br>返回类型的大小 (以字节为单位)。<br>
///
/// More specifically, this is the offset in bytes between successive elements in an array with that item type including alignment padding. <br>更具体地说，这是具有该项类型 (包括对齐填充) 的数组中连续元素之间的字节偏移量。<br>
///
/// Thus, for any type `T` and length `n`, `[T; n]` has a size of `n * size_of::<T>()`. <br>因此，对于任何类型的 `T` 和长度 `n`，`[T; n]` 的大小都是 `n * size_of::<T>()`。<br>
///
/// In general, the size of a type is not stable across compilations, but specific types such as primitives are. <br>一般来说，一个类型的大小在不同的编译中是不稳定的，但是特定的类型，比如原语，是稳定的。<br>
///
/// The following table gives the size for primitives. <br>下表提供了原语的大小。<br>
///
/// Type | size_of::\<Type>()
/// ---- | ---------------
/// () | 0 bool | 1 u8 | 1 u16 | 2 u32 | 4 u64 | 8 u128 | 16 i8 | 1 i16 | 2 i32 | 4 i64 | 8 i128 | 16 f32 | 4 f64 | 8 char | 4
///
/// Furthermore, `usize` and `isize` have the same size. <br>此外，`usize` 和 `isize` 具有相同的大小。<br>
///
/// The types `*const T`, `&T`, `Box<T>`, `Option<&T>`, and `Option<Box<T>>` all have the same size. <br>`*const T`，`&T`，`Box<T>`，`Option<&T>` 和 `Option<Box<T>>` 类型均具有相同的大小。<br>
/// If `T` is Sized, all of those types have the same size as `usize`. <br>如果将 `T` 调整为大小，则所有这些类型的大小均与 `usize` 相同。<br>
///
/// The mutability of a pointer does not change its size. <br>指针的可变性不会改变其大小。<br> As such, `&T` and `&mut T` have the same size. <br>这样，`&T` 和 `&mut T` 具有相同的大小。<br>
/// Likewise for `*const T` and `*mut T`. <br>对于 `*const T` 和 `*mut T` 同样。<br>
///
/// # Size of `#[repr(C)]` items <br>`#[repr(C)]` 项的大小<br>
///
/// The `C` representation for items has a defined layout. <br>项的 `C` 表示具有已定义的布局。<br>
/// With this layout, the size of items is also stable as long as all fields have a stable size. <br>使用此布局，只要所有字段的大小都稳定，则项的大小也将保持稳定。<br>
///
/// ## Size of Structs <br>结构体的大小<br>
///
/// For `structs`, the size is determined by the following algorithm. <br>对于 `structs`，大小由以下算法确定。<br>
///
/// For each field in the struct ordered by declaration order: <br>对于结构体中按声明顺序排序的每个字段：<br>
///
/// 1. Add the size of the field. <br>添加字段的大小。<br>
/// 2. Round up the current size to the nearest multiple of the next field's [alignment]. <br>将当前大小四舍五入到下一个字段的 [对齐][alignment] 的最接近倍数。<br>
///
/// Finally, round the size of the struct to the nearest multiple of its [alignment]. <br>最后，将结构体的大小四舍五入到其 [对齐][alignment] 的最接近倍数。<br>
/// The alignment of the struct is usually the largest alignment of all its fields; <br>结构体的排列通常是其所有字段中最大的排列；<br> this can be changed with the use of `repr(align(N))`. <br>这可以通过使用 `repr(align(N))` 进行更改。<br>
///
/// Unlike `C`, zero sized structs are not rounded up to one byte in size. <br>与 `C` 不同，零大小的结构体不会四舍五入为一个字节。<br>
///
/// ## Size of Enums <br>枚举的大小<br>
///
/// Enums that carry no data other than the discriminant have the same size as C enums on the platform they are compiled for. <br>除判别式外不包含任何数据的枚举的大小与为其编译的平台上的 C 枚举的大小相同。<br>
///
/// ## Size of Unions <br>union 的大小<br>
///
/// The size of a union is the size of its largest field. <br>union 的大小是其最大字段的大小。<br>
///
/// Unlike `C`, zero sized unions are not rounded up to one byte in size. <br>与 `C` 不同，零大小的 union 不会被四舍五入到一个字节的大小。<br>
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Some primitives <br>一些原语<br>
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Some arrays <br>一些数组<br>
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pointer size equality <br>指针大小相等<br>
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Using `#[repr(C)]`. <br>使用 `#[repr(C)]`。<br>
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // The size of the first field is 1, so add 1 to the size. <br>第一个字段的大小为 1，因此请在大小上加 1。<br> Size is 1. <br>大小为 1。<br>
/// // The alignment of the second field is 2, so add 1 to the size for padding. <br>第二个字段的对齐方式为 2，因此在填充大小上加 1。<br> Size is 2. <br>大小为 2。<br>
/// // The size of the second field is 2, so add 2 to the size. <br>第二个字段的大小为 2，因此将大小加 2。<br> Size is 4. <br>大小为 4。<br>
/// // The alignment of the third field is 1, so add 0 to the size for padding. <br>第三个字段的对齐方式为 1，因此请在填充大小上加上 0。<br> Size is 4. <br>大小为 4。<br>
/// // The size of the third field is 1, so add 1 to the size. <br>第三个字段的大小为 1，因此请在大小上加 1。<br> Size is 5. <br>大小为 5。<br>
/// // Finally, the alignment of the struct is 2 (because the largest alignment amongst its fields is 2), so add 1 to the size for padding. <br>最后，结构体的对齐方式为 2 (因为其字段之间的最大对齐方式为 2)，所以在填充的大小上加 1。<br>
/// // Size is 6. <br>大小为 6。<br>
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs follow the same rules. <br>元组结构体遵循相同的规则。<br>
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Note that reordering the fields can lower the size. <br>请注意，对字段重新排序可以减小大小。<br>
/// // We can remove both padding bytes by putting `third` before `second`. <br>我们可以通过将 `third` 放在 `second` 之前删除两个填充字节。<br>
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Union size is the size of the largest field. <br>union 的大小是最大字段的大小。<br>
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_mem_size_of", since = "1.24.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "mem_size_of")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Returns the size of the pointed-to value in bytes. <br>返回所指向的值的大小 (以字节为单位)。<br>
///
/// This is usually the same as `size_of::<T>()`. <br>这通常与 `size_of::<T>()` 相同。<br>
/// However, when `T` *has* no statically-known size, e.g., a slice [`[T]`][slice] or a [trait object], then `size_of_val` can be used to get the dynamically-known size. <br>但是，当 `T` 没有静态已知的大小 (例如，切片 [`[T]`][slice] 或 [trait 对象][trait object]) 时，可以使用 `size_of_val` 获得动态已知的大小。<br>
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
#[cfg_attr(not(test), rustc_diagnostic_item = "mem_size_of_val")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: `val` is a reference, so it's a valid raw pointer <br>`val` 是引用，因此它是有效的裸指针<br>
    unsafe { intrinsics::size_of_val(val) }
}

/// Returns the size of the pointed-to value in bytes. <br>返回所指向的值的大小 (以字节为单位)。<br>
///
/// This is usually the same as `size_of::<T>()`. <br>这通常与 `size_of::<T>()` 相同。<br> However, when `T` *has* no statically-known size, e.g., a slice [`[T]`][slice] or a [trait object], then `size_of_val_raw` can be used to get the dynamically-known size. <br>然而，当 `T` 没有静态已知大小时，例如切片 [`[T]`][slice] 或 [trait 对象][trait object]，则可以使用 `size_of_val_raw` 来获取动态已知大小。<br>
///
/// # Safety
///
/// This function is only safe to call if the following conditions hold: <br>仅在满足以下条件时，此函数才可以安全调用：<br>
///
/// - If `T` is `Sized`, this function is always safe to call. <br>如果 `T` 是 `Sized`，则调用该函数始终是安全的。<br>
/// - If the unsized tail of `T` is: <br>如果 `T` 的未定义大小的尾部为：<br>
///     - a [slice], then the length of the slice tail must be an initialized integer, and the size of the *entire value* (dynamic tail length + statically sized prefix) must fit in `isize`. <br>[slice]，则切片尾部的长度必须是初始化的整数，并且 *entire 值*(动态尾部长度 + 静态大小的前缀) 的大小必须适合 `isize`。<br>
///     - a [trait object], then the vtable part of the pointer must point to a valid vtable acquired by an unsizing coercion, and the size of the *entire value* (dynamic tail length + statically sized prefix) must fit in `isize`. <br>[trait 对象][trait object]，则指针的 vtable 部分必须指向通过取消大小调整强制获取的有效 vtable，并且 *entire 值*(动态尾部长度 + 静态大小的前缀) 的大小必须适合 `isize`。<br>
///
///     - an (unstable) [extern type], then this function is always safe to call, but may panic or otherwise return the wrong value, as the extern type's layout is not known. <br>一个不稳定的 [外部类型][extern type]，则此函数始终可以安全调用，但可能会 panic 或以其他方式返回错误的值，因为外部类型的布局未知。<br>
///     This is the same behavior as [`size_of_val`] on a reference to a type with an extern type tail. <br>这与带有外部类型尾部的类型的引用上的 [`size_of_val`] 行为相同。<br>
///     - otherwise, it is conservatively not allowed to call this function. <br>否则，保守地不允许调用此函数。<br>
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[must_use]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: the caller must provide a valid raw pointer <br>调用者必须提供有效的裸指针<br>
    unsafe { intrinsics::size_of_val(val) }
}

/// Returns the [ABI]-required minimum alignment of a type in bytes. <br>返回类型的 [ABI] 要求的最小对齐方式 (以字节为单位)。<br>
///
/// Every reference to a value of the type `T` must be a multiple of this number. <br>`T` 类型的值的每个引用必须是该数字的倍数。<br>
///
/// This is the alignment used for struct fields. <br>这是用于结构字段的对齐方式。<br> It may be smaller than the preferred alignment. <br>它可能小于首选的对齐方式。<br>
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(note = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Returns the [ABI]-required minimum alignment of the type of the value that `val` points to in bytes. <br>返回 `val` 指向的值类型的 [ABI] 要求的最小对齐方式 (以字节为单位)。<br>
///
///
/// Every reference to a value of the type `T` must be a multiple of this number. <br>`T` 类型的值的每个引用必须是该数字的倍数。<br>
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(note = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val is a reference, so it's a valid raw pointer <br>val 是一个引用，因此它是有效的裸指针<br>
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returns the [ABI]-required minimum alignment of a type in bytes. <br>返回类型的 [ABI] 要求的最小对齐方式 (以字节为单位)。<br>
///
/// Every reference to a value of the type `T` must be a multiple of this number. <br>`T` 类型的值的每个引用必须是该数字的倍数。<br>
///
/// This is the alignment used for struct fields. <br>这是用于结构字段的对齐方式。<br> It may be smaller than the preferred alignment. <br>它可能小于首选的对齐方式。<br>
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.24.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Returns the [ABI]-required minimum alignment of the type of the value that `val` points to in bytes. <br>返回 `val` 指向的值类型的 [ABI] 要求的最小对齐方式 (以字节为单位)。<br>
///
///
/// Every reference to a value of the type `T` must be a multiple of this number. <br>`T` 类型的值的每个引用必须是该数字的倍数。<br>
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAFETY: val is a reference, so it's a valid raw pointer <br>val 是一个引用，因此它是有效的裸指针<br>
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returns the [ABI]-required minimum alignment of the type of the value that `val` points to in bytes. <br>返回 `val` 指向的值类型的 [ABI] 要求的最小对齐方式 (以字节为单位)。<br>
///
/// Every reference to a value of the type `T` must be a multiple of this number. <br>`T` 类型的值的每个引用必须是该数字的倍数。<br>
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// This function is only safe to call if the following conditions hold: <br>仅在满足以下条件时，此函数才可以安全调用：<br>
///
/// - If `T` is `Sized`, this function is always safe to call. <br>如果 `T` 是 `Sized`，则调用该函数始终是安全的。<br>
/// - If the unsized tail of `T` is: <br>如果 `T` 的未定义大小的尾部为：<br>
///     - a [slice], then the length of the slice tail must be an initialized integer, and the size of the *entire value* (dynamic tail length + statically sized prefix) must fit in `isize`. <br>[slice]，则切片尾部的长度必须是初始化的整数，并且 *entire 值*(动态尾部长度 + 静态大小的前缀) 的大小必须适合 `isize`。<br>
///     - a [trait object], then the vtable part of the pointer must point to a valid vtable acquired by an unsizing coercion, and the size of the *entire value* (dynamic tail length + statically sized prefix) must fit in `isize`. <br>[trait 对象][trait object]，则指针的 vtable 部分必须指向通过取消大小调整强制获取的有效 vtable，并且 *entire 值*(动态尾部长度 + 静态大小的前缀) 的大小必须适合 `isize`。<br>
///
///     - an (unstable) [extern type], then this function is always safe to call, but may panic or otherwise return the wrong value, as the extern type's layout is not known. <br>一个不稳定的 [外部类型][extern type]，则此函数始终可以安全调用，但可能会 panic 或以其他方式返回错误的值，因为外部类型的布局未知。<br>
///     This is the same behavior as [`align_of_val`] on a reference to a type with an extern type tail. <br>这与带有外部类型尾部的类型的引用上的 [`align_of_val`] 行为相同。<br>
///     - otherwise, it is conservatively not allowed to call this function. <br>否则，保守地不允许调用此函数。<br>
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
///
#[inline]
#[must_use]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAFETY: the caller must provide a valid raw pointer <br>调用者必须提供有效的裸指针<br>
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returns `true` if dropping values of type `T` matters. <br>如果丢弃类型为 `T` 的值很重要，则返回 `true`。<br>
///
/// This is purely an optimization hint, and may be implemented conservatively: <br>这纯粹是一个优化提示，可以保守地实现：<br>
/// it may return `true` for types that don't actually need to be dropped. <br>对于实际上不需要丢弃的类型，它可能返回 `true`。<br>
/// As such always returning `true` would be a valid implementation of this function. <br>因此，始终返回 `true` 将是此函数的有效实现。<br> However if this function actually returns `false`, then you can be certain dropping `T` has no side effect. <br>但是，如果此函数实际返回 `false`，则可以确定丢弃 `T` 没有副作用。<br>
///
/// Low level implementations of things like collections, which need to manually drop their data, should use this function to avoid unnecessarily trying to drop all their contents when they are destroyed. <br>需要手动丢弃其数据的诸如集合之类的底层实现，应使用此函数来避免在销毁它们时不必要地丢弃其所有内容。<br>
///
/// This might not make a difference in release builds (where a loop that has no side-effects is easily detected and eliminated), but is often a big win for debug builds. <br>这可能不会对发行版本产生影响 (可以轻松检测并消除没有副作用的循环)，但是对于调试版本而言，这通常是一个大胜利。<br>
///
/// Note that [`drop_in_place`] already performs this check, so if your workload can be reduced to some small number of [`drop_in_place`] calls, using this is unnecessary. <br>请注意，[`drop_in_place`] 已经执行了此检查，因此，如果您的工作量可以减少到少量的 [`drop_in_place`] 调用，则无需使用此功能。<br>
/// In particular note that you can [`drop_in_place`] a slice, and that will do a single needs_drop check for all the values. <br>特别要注意的是，您可以 [`drop_in_place`] 一个切片，这将对所有值进行一次 needs_drop 检查。<br>
///
/// Types like Vec therefore just `drop_in_place(&mut self[..])` without using `needs_drop` explicitly. <br>因此，像 Vec 这样的类型只是 `drop_in_place(&mut self[..])`，而没有显式使用 `needs_drop`。<br>
/// Types like [`HashMap`], on the other hand, have to drop values one at a time and should use this API. <br>另一方面，像 [`HashMap`] 这样的类型必须一次丢弃一个值，并且应使用此 API。<br>
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Here's an example of how a collection might make use of `needs_drop`: <br>这是一个集合如何利用 `needs_drop` 的示例：<br>
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // drop the data <br>丢弃数据<br>
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[must_use]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_mem_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T: ?Sized>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Returns the value of type `T` represented by the all-zero byte-pattern. <br>返回由全零字节模式表示的 `T` 类型的值。<br>
///
/// This means that, for example, the padding byte in `(u8, u16)` is not necessarily zeroed. <br>这意味着，例如，`(u8, u16)` 中的填充字节不必为零。<br>
///
/// There is no guarantee that an all-zero byte-pattern represents a valid value of some type `T`. <br>不能保证全零字节模式代表某种 `T` 类型的有效值。<br>
/// For example, the all-zero byte-pattern is not a valid value for reference types (`&T`, `&mut T`) and functions pointers. <br>例如，对于引用类型 (`&T`，`&mut T`) 和函数指针，全零字节模式不是有效值。<br>
/// Using `zeroed` on such types causes immediate [undefined behavior][ub] because [the Rust compiler assumes][inv] that there always is a valid value in a variable it considers initialized. <br>在此类类型上使用 `zeroed` 会立即导致 [未定义的行为][ub]，因为 [Rust 编译器][inv] 假设在它认为已初始化的变量中始终存在有效值。<br>
///
///
/// This has the same effect as [`MaybeUninit::zeroed().assume_init()`][zeroed]. <br>与 [`MaybeUninit::zeroed().assume_init()`][zeroed] 具有相同的作用。<br>
/// It is useful for FFI sometimes, but should generally be avoided. <br>有时对 FFI 很有用，但通常应避免使用。<br>
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Correct usage of this function: initializing an integer with zero. <br>此函数的正确用法：用零初始化一个整数。<br>
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Incorrect* usage of this function: initializing a reference with zero. <br>该函数的 *错误* 用法：用零初始化引用。<br>
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Undefined behavior! <br>未定义的行为！<br>
/// let _y: fn() = unsafe { mem::zeroed() }; // And again! <br>然后再一次！<br>
/// ```
///
///
///
#[inline(always)]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
#[track_caller]
pub unsafe fn zeroed<T>() -> T {
    // SAFETY: the caller must guarantee that an all-zero value is valid for `T`. <br>调用者必须保证全零值对 `T` 有效。<br>
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Bypasses Rust's normal memory-initialization checks by pretending to produce a value of type `T`, while doing nothing at all. <br>假装产生 `T` 类型的值，而实际上什么也不做，从而绕过 Rust 的常规内存初始化检查。<br>
///
/// **This function is deprecated.** Use [`MaybeUninit<T>`] instead. <br>**不推荐使用此函数。** 请改用 [`MaybeUninit<T>`]。<br>
///
/// The reason for deprecation is that the function basically cannot be used correctly: it has the same effect as [`MaybeUninit::uninit().assume_init()`][uninit]. <br>弃用的原因是该函数基本上不能正确使用：它具有与 [`MaybeUninit::uninit().assume_init()`][uninit] 相同的作用。<br>
///
/// As the [`assume_init` documentation][assume_init] explains, [the Rust compiler assumes][inv] that values are properly initialized. <br>正如 [`assume_init` 文档][assume_init] 所解释的那样，[Rust 编译器][inv] 假设值已正确初始化。<br>
/// As a consequence, calling e.g. <br>因此，调用例如<br>
/// `mem::uninitialized::<bool>()` causes immediate undefined behavior for returning a `bool` that is not definitely either `true` or `false`. <br>`mem::uninitialized::<bool>()` 会导致 immediate 未定义行为返回 `bool`，而 `bool` 不一定是 `true` 或 `false`。<br>
/// Worse, truly uninitialized memory like what gets returned here is special in that the compiler knows that it does not have a fixed value. <br>更糟糕的是，真正的未初始化内存 (如此处返回的内存) 的特殊之处在于，编译器知道它没有固定的值。<br>
/// This makes it undefined behavior to have uninitialized data in a variable even if that variable has an integer type. <br>这使得在变量中具有未初始化的数据成为不确定的行为，即使该变量具有整数类型也是如此。<br>
/// (Notice that the rules around uninitialized integers are not finalized yet, but until they are, it is advisable to avoid them.) <br>(请注意，关于未初始化整数的规则尚未最终确定，但是除非被确定，否则建议避免使用它们。)<br>
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[must_use]
#[deprecated(since = "1.39.0", note = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
#[track_caller]
pub unsafe fn uninitialized<T>() -> T {
    // SAFETY: the caller must guarantee that an uninitialized value is valid for `T`. <br>调用者必须保证未初始化的值对 `T` 有效。<br>
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Swaps the values at two mutable locations, without deinitializing either one. <br>在两个可变位置交换值，而无需对其中一个进行初始化。<br>
///
/// * If you want to swap with a default or dummy value, see [`take`]. <br>如果要交换默认值或虚拟值，请参见 [`take`]。<br>
/// * If you want to swap with a passed value, returning the old value, see [`replace`]. <br>如果要与传递的值交换，返回旧值，请参见 [`replace`]。<br>
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const fn swap<T>(x: &mut T, y: &mut T) {
    // NOTE(eddyb) SPIR-V's Logical addressing model doesn't allow for arbitrary reinterpretation of values as (chunkable) byte arrays, and the loop in the block optimization in `swap_slice` is hard to rewrite back into the (unoptimized) direct swapping implementation, so we disable it. <br>SPIR-V 的逻辑寻址模型不允许将值任意重新解释为 (chunkable) 字节数组，并且 `swap_slice` 中块优化中的循环很难重写回 (unoptimized) 直接交换实现，因此我们禁用它。<br>
    //
    // FIXME(eddyb) the block optimization also prevents MIR optimizations from understanding `mem::replace`, `Option::take`, etc. <br>块优化还阻止 MIR 优化理解 `mem::replace`、`Option::take` 等。<br>
    // - a better overall solution might be to make `ptr::swap_nonoverlapping` into an intrinsic, which a backend can choose to implement using the block optimization, or not. <br>一个更好的整体解决方案可能是将 `ptr::swap_nonoverlapping` 变成一个内部函数，后端可以选择使用块优化来实现，或者不。<br>
    // NOTE(scottmcm) MIRI is disabled here as reading in smaller units is a pessimization for it. <br>MIRI 在这里被禁用，因为以较小的单位读取对它来说是一种悲观。<br>
    // Also, if the type contains any unaligned pointers, copying those over multiple reads is difficult to support. <br>此外，如果该类型包含任何未对齐的指针，则难以支持在多次读取中复制这些指针。<br>
    //
    //
    //
    //
    //
    #[cfg(not(any(target_arch = "spirv", miri)))]
    {
        // For types that are larger multiples of their alignment, the simple way tends to copy the whole thing to stack rather than doing it one part at a time, so instead treat them as one-element slices and piggy-back the slice optimizations that will split up the swaps. <br>对于对齐的倍数较大的类型，简单的方法倾向于将整个内容复制到栈而不是一次只做一个部分，因此将它们视为单元素切片并搭载将拆分的切片优化调高掉期。<br>
        //
        //
        //
        if size_of::<T>() / align_of::<T>() > 4 {
            // SAFETY: exclusive references always point to one non-overlapping element and are non-null and properly aligned. <br>排他引用总是指向一个不重叠的元素，并且是非空的并且正确对齐。<br>
            //
            return unsafe { ptr::swap_nonoverlapping(x, y, 1) };
        }
    }

    // If a scalar consists of just a small number of alignment units, let the codegen just swap those pieces directly, as it's likely just a few instructions and anything else is probably overcomplicated. <br>如果一个标量只包含少量对齐单元，让 codegen 直接交换这些部分，因为它可能只有几条指令，其他任何东西都可能过于复杂。<br>
    //
    //
    // Most importantly, this covers primitives and simd types that tend to have size=align where doing anything else can be a pessimization. <br>最重要的是，这涵盖了趋向于 size=align 的原语和 simd 类型，而做其他任何事情都可能令人悲观。<br>
    // (This will also be used for ZSTs, though any solution works for them.) <br>(这也将用于 ZST，尽管任何解决方案都适用于它们。)<br>
    //
    //
    swap_simple(x, y);
}

/// Same as [`swap`] semantically, but always uses the simple implementation. <br>语义上与 [`swap`] 相同，但始终使用简单实现。<br>
///
/// Used elsewhere in `mem` and `ptr` at the bottom layer of calls. <br>在调用底层的 `mem` 和 `ptr` 的其他地方使用。<br>
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
#[inline]
pub(crate) const fn swap_simple<T>(x: &mut T, y: &mut T) {
    // We arrange for this to typically be called with small types, so this reads-and-writes approach is actually better than using copy_nonoverlapping as it easily puts things in LLVM registers directly and doesn't end up inlining allocas. <br>我们安排它通常用小类型调用，因此这种读写方法实际上比使用 copy_nonoverlapping 更好，因为它可以轻松地将内容直接放入 LLVM 寄存器中，并且最终不会内联 allocas。<br>
    //
    // And LLVM actually optimizes it to 3×memcpy if called with a type larger than it's willing to keep in a register. <br>如果使用大于它愿意保留在寄存器中的类型调用，LLVM 实际上会将其优化为 3×memcpy。<br>
    // Having typed reads and writes in MIR here is also good as it lets MIRI and CTFE understand them better, including things like enforcing type validity for them. <br>在这里在 MIR 中输入读写操作也很好，因为它可以让 MIRI 和 CTFE 更好地理解它们，包括为它们强制执行类型有效性之类的事情。<br>
    // Importantly, read+copy_nonoverlapping+write introduces confusing asymmetry to the behaviour where one value went through read+write whereas the other was copied over by the intrinsic (see #94371). <br>重要的是，read+copy_nonoverlapping+write 为一个值通过 read+write 而另一个值被内部函数复制 (参见 #94371) 的行为引入了令人困惑的不对称性。<br>
    //
    //
    //
    //
    //
    //
    //

    // SAFETY: exclusive references are always valid to read/write, including being aligned, and nothing here panics so it's drop-safe. <br>排他引用对 read/write 总是有效的，包括对齐，这里没有任何 panic，所以它是丢弃 - 安全的。<br>
    //
    unsafe {
        let a = ptr::read(x);
        let b = ptr::read(y);
        ptr::write(x, b);
        ptr::write(y, a);
    }
}

/// Replaces `dest` with the default value of `T`, returning the previous `dest` value. <br>用默认值 `T` 替换 `dest`，并返回以前的 `dest` 值。<br>
///
/// * If you want to replace the values of two variables, see [`swap`]. <br>如果要替换两个变量的值，请参见 [`swap`]。<br>
/// * If you want to replace with a passed value instead of the default value, see [`replace`]. <br>如果要替换为传递的值而不是默认值，请参见 [`replace`]。<br>
///
/// # Examples
///
/// A simple example: <br>一个简单的例子：<br>
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` allows taking ownership of a struct field by replacing it with an "empty" value. <br>`take` 允许通过将结构体字段替换为 "empty" 值来获取结构体字段的所有权。<br>
/// Without `take` you can run into issues like these: <br>没有 `take`，您可能会遇到以下问题：<br>
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer <br>错误：无法移出 `&mut` 指针的解引用<br>
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Note that `T` does not necessarily implement [`Clone`], so it can't even clone and reset `self.buf`. <br>请注意，`T` 不一定实现 [`Clone`]，因此它甚至无法克隆和重置 `self.buf`。<br>
/// But `take` can be used to disassociate the original value of `self.buf` from `self`, allowing it to be returned: <br>但是 `take` 可以用于取消 `self.buf` 的原始值与 `self` 的关联，从而可以将其返回：<br>
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Moves `src` into the referenced `dest`, returning the previous `dest` value. <br>将 `src` 移至引用的 `dest`，返回先前的 `dest` 值。<br>
///
/// Neither value is dropped. <br>这两个值都不会被丢弃。<br>
///
/// * If you want to replace the values of two variables, see [`swap`]. <br>如果要替换两个变量的值，请参见 [`swap`]。<br>
/// * If you want to replace with a default value, see [`take`]. <br>如果要替换为默认值，请参见 [`take`]。<br>
///
/// # Examples
///
/// A simple example: <br>一个简单的例子：<br>
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` allows consumption of a struct field by replacing it with another value. <br>`replace` 允许通过将结构体字段替换为另一个值来使用它。<br>
/// Without `replace` you can run into issues like these: <br>没有 `replace`，您可能会遇到以下问题：<br>
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer <br>错误：无法移出 `&mut` 指针的解引用<br>
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Note that `T` does not necessarily implement [`Clone`], so we can't even clone `self.buf[i]` to avoid the move. <br>请注意，`T` 不一定实现 [`Clone`]，因此我们甚至无法克隆 `self.buf[i]` 以避免此举。<br>
/// But `replace` can be used to disassociate the original value at that index from `self`, allowing it to be returned: <br>但是 `replace` 可以用于取消该索引处的原始值与 `self` 的关联，从而可以将其返回：<br>
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
#[rustc_const_unstable(feature = "const_replace", issue = "83164")]
#[cfg_attr(not(test), rustc_diagnostic_item = "mem_replace")]
pub const fn replace<T>(dest: &mut T, src: T) -> T {
    // SAFETY: We read from `dest` but directly write `src` into it afterwards, such that the old value is not duplicated. <br>我们从 `dest` 读取，但之后直接将 `src` 写入其中，这样就不会重复旧值。<br>
    // Nothing is dropped and nothing here can panic. <br>什么都不会被丢弃掉，也什么都不会 panic。<br>
    //
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Disposes of a value. <br>处理一个值。<br>
///
/// This does so by calling the argument's implementation of [`Drop`][drop]. <br>通过调用 [`Drop`][drop] 的参数实现来实现。<br>
///
/// This effectively does nothing for types which implement `Copy`, e.g. <br>这对于实现 `Copy` 的类型实际上不起作用，例如<br>
/// integers.
/// Such values are copied and _then_ moved into the function, so the value persists after this function call. <br>这样的值被复制并将 _then_ 移到函数中，因此该值在此函数调用之后仍然存在。<br>
///
///
/// This function is not magic; <br>这个功能并不神奇。<br> it is literally defined as <br>它的字面定义为<br>
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Because `_x` is moved into the function, it is automatically dropped before the function returns. <br>由于 `_x` 已移入函数，因此它会在函数返回之前自动丢弃。<br>
///
/// [drop]: Drop
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // explicitly drop the vector <br>显式丢弃 vector<br>
/// ```
///
/// Since [`RefCell`] enforces the borrow rules at runtime, `drop` can release a [`RefCell`] borrow: <br>由于 [`RefCell`] 在运行时强制执行借用规则，因此 `drop` 可以发布 [`RefCell`] 借用：<br>
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // relinquish the mutable borrow on this slot <br>放弃该插槽上的可变借用<br>
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Integers and other types implementing [`Copy`] are unaffected by `drop`. <br>实现 [`Copy`] 的整数和其他类型不受 `drop` 的影响。<br>
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // a copy of `x` is moved and dropped <br>`x` 的副本已移动并丢弃<br>
/// drop(y); // a copy of `y` is moved and dropped <br>`y` 的副本已移动并丢弃<br>
///
/// println!("x: {}, y: {}", x, y.0); // still available <br>仍然可用<br>
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "mem_drop")]
pub fn drop<T>(_x: T) {}

/// Bitwise-copies a value. <br>按位复制一个值。<br>
///
/// This function is not magic; <br>这个功能并不神奇。<br> it is literally defined as <br>它的字面定义为<br>
/// ```
/// pub fn copy<T: Copy>(x: &T) -> T { *x }
/// ```
///
/// It is useful when you want to pass a function pointer to a combinator, rather than defining a new closure. <br>当您想将函数指针传递给组合器而不是定义新的闭包时，它很有用。<br>
///
/// Example:
/// ```
/// #![feature(mem_copy_fn)]
/// use core::mem::copy;
/// let result_from_ffi_function: Result<(), &i32> = Err(&1);
/// let result_copied: Result<(), i32> = result_from_ffi_function.map_err(copy);
/// ```
#[inline]
#[unstable(feature = "mem_copy_fn", issue = "98262")]
pub fn copy<T: Copy>(x: &T) -> T {
    *x
}

/// Interprets `src` as having type `&U`, and then reads `src` without moving the contained value. <br>将 `src` 解释为具有 `&U` 类型，然后在不移动所包含的值的情况下读取 `src`。<br>
///
/// This function will unsafely assume the pointer `src` is valid for [`size_of::<U>`][size_of] bytes by transmuting `&T` to `&U` and then reading the `&U` (except that this is done in a way that is correct even when `&U` makes stricter alignment requirements than `&T`). <br>通过将 `&T` 转换为 `&U`，然后读取 `&U`，此函数将不安全地假定指针 `src` 对 [`size_of::<U>`][size_of] 字节有效 (除非这样做的正确方式是，即使 `&U` 的对齐要求比 `&T` 严格)。<br>
/// It will also unsafely create a copy of the contained value instead of moving out of `src`. <br>它还将不安全地创建所包含值的副本，而不是移出 `src`。<br>
///
/// It is not a compile-time error if `T` and `U` have different sizes, but it is highly encouraged to only invoke this function where `T` and `U` have the same size. <br>如果 `T` 和 `U` 具有不同的大小，则不是编译时错误，但是强烈建议仅在 `T` 和 `U` 具有相同的大小时调用此函数。<br> This function triggers [undefined behavior][ub] if `U` is larger than `T`. <br>如果 `U` 大于 `T`，则此函数将触发 [未定义的行为][ub]。<br>
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Copy the data from 'foo_array' and treat it as a 'Foo' <br>从 'foo_array' 复制数据并将其视为 'Foo'<br>
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modify the copied data <br>修改复制的数据<br>
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // The contents of 'foo_array' should not have changed <br>'foo_array' 的内容不应更改<br>
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // If U has a higher alignment requirement, src might not be suitably aligned. <br>如果 U 有更高的对齐要求，则 src 可能无法正确对齐。<br>
    if align_of::<U>() > align_of::<T>() {
        // SAFETY: `src` is a reference which is guaranteed to be valid for reads. <br>`src` 是一个引用，它保证对读取有效。<br>
        // The caller must guarantee that the actual transmutation is safe. <br>调用者必须保证实际的转换是安全的。<br>
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SAFETY: `src` is a reference which is guaranteed to be valid for reads. <br>`src` 是一个引用，它保证对读取有效。<br>
        // We just checked that `src as *const U` was properly aligned. <br>我们只是检查 `src as *const U` 是否正确对齐。<br>
        // The caller must guarantee that the actual transmutation is safe. <br>调用者必须保证实际的转换是安全的。<br>
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Opaque type representing the discriminant of an enum. <br>代表枚举的不透明类型。<br>
///
/// See the [`discriminant`] function in this module for more information. <br>有关更多信息，请参见此模块中的 [`discriminant`] 函数。<br>
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. These trait implementations cannot be derived because we don't want any bounds on T. <br>注意，这些 trait 实现无法派生，因为我们不希望 T 有任何界限。<br>

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Returns a value uniquely identifying the enum variant in `v`. <br>返回一个唯一标识 `v` 中的枚举变体的值。<br>
///
/// If `T` is not an enum, calling this function will not result in undefined behavior, but the return value is unspecified. <br>如果 `T` 不是枚举，则调用此函数不会导致未定义的行为，但返回值是未指定的。<br>
///
///
/// # Stability
///
/// The discriminant of an enum variant may change if the enum definition changes. <br>如果枚举定义改变，则枚举变体的判别式可能会改变。<br>
/// A discriminant of some variant will not change between compilations with the same compiler. <br>某些变体的判别式在使用相同编译器的编译之间不会改变。<br>
///
/// # Examples
///
/// This can be used to compare enums that carry data, while disregarding the actual data: <br>这可以用来比较携带数据的枚举，而忽略实际数据：<br>
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
#[cfg_attr(not(test), rustc_diagnostic_item = "mem_discriminant")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Returns the number of variants in the enum type `T`. <br>返回枚举类型 `T` 中的变体数。<br>
///
/// If `T` is not an enum, calling this function will not result in undefined behavior, but the return value is unspecified. <br>如果 `T` 不是枚举，则调用此函数不会导致未定义的行为，但返回值是未指定的。<br>
/// Equally, if `T` is an enum with more variants than `usize::MAX` the return value is unspecified. <br>同样，如果 `T` 是变体数大于 `usize::MAX` 的枚举，则未指定返回值。<br>
/// Uninhabited variants will be counted. <br>无人居住的变体将被计算在内。<br>
///
/// Note that an enum may be expanded with additional variants in the future as a non-breaking change, for example if it is marked `#[non_exhaustive]`, which will change the result of this function. <br>请注意，枚举将来可能会使用额外的变体进行扩展，作为非破坏性更改，例如，如果它标记为 `#[non_exhaustive]`，这将更改此函数的结果。<br>
///
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
///
#[inline(always)]
#[must_use]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
#[rustc_diagnostic_item = "mem_variant_count"]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}
