//! Inplace iterate-and-collect specialization for `Vec` <br>`Vec` 的就地迭代和收集特化<br>
//!
//! Note: This documents Vec internals, some of the following sections explain implementation details and are best read together with the source of this module. <br>本文档记录了 Vec 内部结构，以下部分解释了实现细节，最好与本模块的源代码一起阅读。<br>
//!
//! The specialization in this module applies to iterators in the shape of `source.adapter().adapter().adapter().collect::<Vec<U>>()` <br>本模块的特化适用于 `source.adapter().adapter().adapter().collect::<Vec<U>>()` 形式的迭代器<br>
//! where `source` is an owning iterator obtained from [`Vec<T>`], [`Box<[T]>`][box] (by conversion to `Vec`) or [`BinaryHeap<T>`], the adapters each consume one or more items per step (represented by [`InPlaceIterable`]), provide transitive access to `source` (via [`SourceIter`]) and thus the underlying allocation. <br>其中 `source` 是从 [`Vec<T>`]、[`Box<[T]>`][box] (通过转换为 `Vec`) 或 [`BinaryHeap<T>`] 获得的拥有迭代器，每个适配器每个步骤消耗一个或多个项 (由 [`InPlaceIterable`] 表示)，提供对 `source` 的传递访问 (通过 [`SourceIter`])，从而提供底层分配.<br>
//! And finally the layouts of `T` and `U` must have the same size and alignment, this is currently ensured via const eval instead of trait bounds in the specialized [`SpecFromIter`] implementation. <br>最后，`T` 和 `U` 的布局必须具有相同的大小和对齐方式，目前通过 const eval 而不是专门的 [`SpecFromIter`] 实现中的 trait bounds 来确保的。<br>
//!
//! [`BinaryHeap<T>`]: crate::collections::BinaryHeap
//! [box]: crate::boxed::Box
//!
//! By extension some other collections which use `collect::<Vec<_>>()` internally in their `FromIterator` implementation benefit from this too. <br>通过扩展，在其 `FromIterator` 实现中内部使用 `collect::<Vec<_>>()` 的其他一些集合也从中受益。<br>
//!
//! Access to the underlying source goes through a further layer of indirection via the private trait [`AsVecIntoIter`] to hide the implementation detail that other collections may use `vec::IntoIter` internally. <br>对底层源的访问通过私有 [`AsVecIntoIter`] trait 进行进一步的间接层，以隐藏其他集合可能在内部使用 `vec::IntoIter` 的实现细节。<br>
//!
//! In-place iteration depends on the interaction of several unsafe traits, implementation details of multiple parts in the iterator pipeline and often requires holistic reasoning across multiple structs since iterators are executed cooperatively rather than having a central evaluator/visitor struct executing all iterator components. <br>就地迭代取决于几个不安全的 traits 的交互，迭代器管道中多个部分的实现细节，并且通常需要跨多个结构体进行整体推理，因为迭代器是协作执行的，而不是让中央 evaluator/visitor 结构执行所有迭代器组件。<br>
//!
//!
//! # Reading from and writing to the same allocation <br>读取和写入相同的分配<br>
//!
//! By its nature collecting in place means that the reader and writer side of the iterator use the same allocation. <br>就其本质而言，就地收集意味着迭代器的 reader 和 writer 端使用相同的分配。<br> Since `try_fold()` (used in [`SpecInPlaceCollect`]) takes a reference to the iterator for the duration of the iteration that means we can't interleave the step of reading a value and getting a reference to write to. <br>由于 `try_fold()` (在 [`SpecInPlaceCollect`] 中使用) 在迭代期间需要对迭代器的引用，这意味着我们不能交替读取值和获取要写入的引用。<br>
//! Instead raw pointers must be used on the reader and writer side. <br>相反，必须在 reader 和 writer 端使用裸指针。<br>
//!
//! That writes never clobber a yet-to-be-read item is ensured by the [`InPlaceIterable`] requirements. <br>[`InPlaceIterable`] 要求确保写入操作永远不会破坏尚未读取的项。<br>
//!
//! # Layout constraints <br>布局约束<br>
//!
//! [`Allocator`] requires that `allocate()` and `deallocate()` have matching alignment and size. <br>[`Allocator`] 要求 `allocate()` 和 `deallocate()` 具有匹配的对齐方式和大小。<br>
//! Additionally this specialization doesn't make sense for ZSTs as there is no reallocation to avoid and it would make pointer arithmetic more difficult. <br>此外，这种特化对于 ZST 没有意义，因为不需要避免重新分配，而且它会使指针运算更加困难。<br>
//!
//! [`Allocator`]: core::alloc::Allocator
//!
//! # Drop- and panic-safety <br>Drop- 和 panic 安全<br>
//!
//! Iteration can panic, requiring dropping the already written parts but also the remainder of the source. <br>迭代可能会出现 panic，需要丢弃已写入的部分以及源的其余部分。<br> Iteration can also leave some source items unconsumed which must be dropped. <br>迭代也可以保留一些必须丢弃的未消耗的源项。<br>
//! All those drops in turn can panic which then must either leak the allocation or abort to avoid double-drops. <br>所有这些丢弃进而会导致 panic，然后必须泄漏分配或终止，以避免双重丢弃。<br>
//!
//! This is handled by the [`InPlaceDrop`] guard for sink items (`U`) and by [`vec::IntoIter::forget_allocation_drop_remaining()`] for remaining source items (`T`). <br>这由 sink 项 (`U`) 的 [`InPlaceDrop`] 守卫和剩余源项 (`T`) 的 [`vec::IntoIter::forget_allocation_drop_remaining()`] 处理。<br>
//!
//! [`vec::IntoIter::forget_allocation_drop_remaining()`]: super::IntoIter::forget_allocation_drop_remaining()
//!
//! # O(1) collect <br>O(1) 收集<br>
//!
//! The main iteration itself is further specialized when the iterator implements [`TrustedRandomAccessNoCoerce`] to let the optimizer see that it is a counted loop with a single [induction variable]. <br>当迭代器实现 [`TrustedRandomAccessNoCoerce`] 以让优化器看到它是一个带有单个 [induction variable] 的计数循环时，主迭代本身会进一步特化。<br> This can turn some iterators into a noop, i.e. it reduces them from O(n) to O(1). <br>这可以将一些迭代器变成一个 noop，也就是说，它将迭代器从 O(n) 减少到 O(1)。<br>
//! This particular optimization is quite fickle and doesn't always work, see [#79308] <br>这种特殊的优化非常易变，并不总是有效，请参见 [#79308]<br>
//!
//! [#79308]: https://github.com/rust-lang/rust/issues/79308
//! [induction variable]: https://en.wikipedia.org/wiki/Induction_variable
//!
//! Since unchecked accesses through that trait do not advance the read pointer of `IntoIter` this would interact unsoundly with the requirements about dropping the tail described above. <br>由于通过该 trait 的未经检查的访问不会推进 `IntoIter` 的读取指针，这将与上述关于丢弃尾部的要求进行不合理的交互。<br>
//! But since the normal `Drop` implementation of `IntoIter` would suffer from the same problem it is only correct for `TrustedRandomAccessNoCoerce` to be implemented when the items don't have a destructor. <br>但是由于 `IntoIter` 的正常 `Drop` 实现会遇到同样的问题，因此只有在项没有析构函数时才实现 `TrustedRandomAccessNoCoerce` 是正确的。<br> Thus that implicit requirement also makes the specialization safe to use for in-place collection. <br>因此，该隐式要求也使特化可以安全地用于就地收集。<br>
//! Note that this safety concern is about the correctness of `impl Drop for IntoIter`, not the guarantees of `InPlaceIterable`. <br>请注意，这个安全问题是关于 `impl Drop for IntoIter` 的正确性，而不是 `InPlaceIterable` 的保证。<br>
//!
//! # Adapter implementations <br>适配器实现<br>
//!
//! The invariants for adapters are documented in [`SourceIter`] and [`InPlaceIterable`], but getting them right can be rather subtle for multiple, sometimes non-local reasons. <br>适配器的不变量记录在 [`SourceIter`] 和 [`InPlaceIterable`] 中，但是由于多种原因，有时是非本地原因，使它们正确可能相当微妙。<br>
//! For example `InPlaceIterable` would be valid to implement for [`Peekable`], except that it is stateful, cloneable and `IntoIter`'s clone implementation shortens the underlying allocation which means if the iterator has been peeked and then gets cloned there no longer is enough room, thus breaking an invariant ([#85322]). <br>例如，`InPlaceIterable` 对 [`Peekable`] 实现是有效的，除了它是有状态的、可克隆的并且 `IntoIter` 的克隆实现缩短了底层分配，这意味着如果迭代器已被窥视然后被克隆，则不再有足够的空间，从而破坏了不变量 ([#85322])。<br>
//!
//! [#85322]: https://github.com/rust-lang/rust/issues/85322
//! [`Peekable`]: core::iter::Peekable
//!
//! # Examples
//!
//! Some cases that are optimized by this specialization, more can be found in the `Vec` benchmarks: <br>通过这种特化优化的一些案例，可以在 `Vec` 基准测试中找到更多:<br>
//!
//! ```rust
//! # #[allow(dead_code)]
//! /// Converts a usize vec into an isize one. <br>将 usize vec 转换为 isize one。<br>
//! pub fn cast(vec: Vec<usize>) -> Vec<isize> {
//!   // Does not allocate, free or panic. <br>不分配、释放或 panic。<br> On optlevel>=2 it does not loop. <br>在 optlevel>=2 时，它不会循环。<br>
//!   // Of course this particular case could and should be written with `into_raw_parts` and `from_raw_parts` instead. <br>当然，这种特殊情况可以也应该用 `into_raw_parts` 和 `from_raw_parts` 来代替。<br>
//!   //
//!   vec.into_iter().map(|u| u as isize).collect()
//! }
//! ```
//!
//! ```rust
//! # #[allow(dead_code)]
//! /// Drops remaining items in `src` and if the layouts of `T` and `U` match it returns an empty Vec backed by the original allocation. <br>丢弃 `src` 中的剩余项，如果 `T` 和 `U` 的布局匹配，则返回由原始分配支持的空 Vec。<br>
//! /// Otherwise it returns a new empty vec. <br>否则它返回一个新的空 vec。<br>
//! ///
//! pub fn recycle_allocation<T, U>(src: Vec<T>) -> Vec<U> {
//!   src.into_iter().filter_map(|_| None).collect()
//! }
//! ```
//!
//! ```rust
//! let vec = vec![13usize; 1024];
//! let _ = vec.into_iter()
//!   .enumerate()
//!   .filter_map(|(idx, val)| if idx % 2 == 0 { Some(val+idx) } else {None})
//!   .collect::<Vec<_>>();
//!
//! // is equivalent to the following, but doesn't require bounds checks <br>等效于以下内容，但不需要边界检查<br>
//!
//! let mut vec = vec![13usize; 1024];
//! let mut write_idx = 0;
//! for idx in 0..vec.len() {
//!    if idx % 2 == 0 {
//!       vec[write_idx] = vec[idx] + idx;
//!       write_idx += 1;
//!    }
//! }
//! vec.truncate(write_idx);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
use core::iter::{InPlaceIterable, SourceIter, TrustedRandomAccessNoCoerce};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Specialization marker for collecting an iterator pipeline into a Vec while reusing the source allocation, i.e. <br>专业化标记，用于在重用源分配时将迭代器管道收集到 Vec 中，即<br>
/// executing the pipeline in place. <br>在适当的位置执行管道。<br>
#[rustc_unsafe_specialization_marker]
pub(super) trait InPlaceIterableMarker {}

impl<T> InPlaceIterableMarker for T where T: InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIter<Source: AsVecIntoIter> + InPlaceIterableMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // See "Layout constraints" section in the module documentation. <br>请参见模块文档中的 "布局约束" 部分。<br>
        // We rely on const optimization here since these conditions currently cannot be expressed as trait bounds <br>我们在这里依赖常量优化，因为这些条件目前不能表示为 trait bounds<br>
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsVecIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsVecIntoIter>::Item>()
        {
            // fallback to more generic implementations <br>回退到更通用的实现<br>
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        let len = SpecInPlaceCollect::collect_in_place(&mut iterator, dst_buf, dst_end);

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // check if SourceIter contract was upheld caveat: if they weren't we might not even make it to this point <br>检查 SourceIter 契约是否得到维护警告：如果不是，我们甚至可能无法做到这一点<br>
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // check InPlaceIterable contract. <br>检查 InPlaceIterable 契约。<br> This is only possible if the iterator advanced the source pointer at all. <br>只有迭代器推进了源指针，这才是可能的。<br>
        // If it uses unchecked access via TrustedRandomAccess then the source pointer will stay in its initial position and we can't use it as reference <br>如果它通过 TrustedRandomAccess 使用未经检查的访问，则源指针将停留在其初始位置，我们不能将其用作引用<br>
        //
        if src.ptr != src_ptr {
            debug_assert!(
                unsafe { dst_buf.add(len) as *const _ } <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // Drop any remaining values at the tail of the source but prevent drop of the allocation itself once IntoIter goes out of scope. <br>丢弃源尾部的任何剩余值，但防止在 IntoIter 离开作用域后丢弃分配本身。<br>
        // If the drop panics then we also leak any elements collected into dst_buf. <br>如果丢弃 panic，那么我们还将收集到的任何元素泄漏到 dst_buf 中。<br>
        //
        // Note: This access to the source wouldn't be allowed by the TrustedRandomIteratorNoCoerce contract (used by SpecInPlaceCollect below). <br>TrustedRandomIteratorNoCoerce 契约 (由下面的 SpecInPlaceCollect 使用) 不允许对源的这种访问。<br>
        // But see the "O(1) collect" section in the module documenttation why this is ok anyway. <br>但是请参见模块文档中的 "O(1) 收集" 部分，为什么这仍然可以。<br>
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe { Vec::from_raw_parts(dst_buf, len, cap) };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // the InPlaceIterable contract cannot be verified precisely here since try_fold has an exclusive reference to the source pointer all we can do is check if it's still in range <br>这里的 InPlaceIterable 契约无法精确验证，因为 try_fold 对源指针有一个唯一的引用，我们所能做的就是检查它是否仍在范围内<br>
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            // Since this executes user code which can panic we have to bump the pointer after each step. <br>由于这会执行用户代码，这可能会导致 panic，因此我们必须在每一步之后 bump 指针。<br>
            //
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}

/// Helper trait to hold specialized implementations of the in-place iterate-collect loop <br>一个用于保存就地迭代收集循环的专用实现的 Helper trait<br>
trait SpecInPlaceCollect<T, I>: Iterator<Item = T> {
    /// Collects an iterator (`self`) into the destination buffer (`dst`) and returns the number of items collected. <br>将迭代器 (`self`) 收集到目标缓冲区 (`dst`) 中并返回收集的项数。<br> `end` is the last writable element of the allocation and used for bounds checks. <br>`end` 是分配的最后一个可写元素，用于边界检查。<br>
    ///
    /// This method is specialized and one of its implementations makes use of `Iterator::__iterator_get_unchecked` calls with a `TrustedRandomAccessNoCoerce` bound on `I` which means the caller of this method must take the safety conditions of that trait into consideration. <br>这个方法是专门的，它的一个实现使用 `Iterator::__iterator_get_unchecked` 调用，`TrustedRandomAccessNoCoerce` 绑定在 `I` 上，这意味着这个方法的调用者必须考虑 trait 的安全条件。<br>
    ///
    ///
    ///
    ///
    fn collect_in_place(&mut self, dst: *mut T, end: *const T) -> usize;
}

impl<T, I> SpecInPlaceCollect<T, I> for I
where
    I: Iterator<Item = T>,
{
    #[inline]
    default fn collect_in_place(&mut self, dst_buf: *mut T, end: *const T) -> usize {
        // use try-fold since <br>使用 try-fold，因为<br>
        // - it vectorizes better for some iterator adapters <br>对于某些迭代器适配器，它可以更好地进行矢量化<br>
        // - unlike most internal iteration methods, it only takes a &mut self <br>与大多数内部迭代方法不同，它只需要一个 &mut self<br>
        // - it lets us thread the write pointer through its innards and get it back in the end <br>它让我们把写指针穿进它的内部，最后把它拿回来<br>
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink =
            self.try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(end)).unwrap();
        // iteration succeeded, don't drop head <br>迭代成功，不要丢弃 head<br>
        unsafe { ManuallyDrop::new(sink).dst.sub_ptr(dst_buf) }
    }
}

impl<T, I> SpecInPlaceCollect<T, I> for I
where
    I: Iterator<Item = T> + TrustedRandomAccessNoCoerce,
{
    #[inline]
    fn collect_in_place(&mut self, dst_buf: *mut T, end: *const T) -> usize {
        let len = self.size();
        let mut drop_guard = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        for i in 0..len {
            // Safety: InplaceIterable contract guarantees that for every element we read one slot in the underlying storage will have been freed up and we can immediately write back the result. <br>安全性: InplaceIterable 契约保证，对于我们读取的每个元素，底层存储中的一个插槽将被释放，我们可以立即写回结果。<br>
            //
            //
            unsafe {
                let dst = dst_buf.offset(i as isize);
                debug_assert!(dst as *const _ <= end, "InPlaceIterable contract violation");
                ptr::write(dst, self.__iterator_get_unchecked(i));
                // Since this executes user code which can panic we have to bump the pointer after each step. <br>由于这会执行用户代码，这可能会导致 panic，因此我们必须在每一步之后 bump 指针。<br>
                //
                drop_guard.dst = dst.add(1);
            }
        }
        mem::forget(drop_guard);
        len
    }
}

/// Internal helper trait for in-place iteration specialization. <br>用于就地迭代特化的内部助手 trait。<br>
///
/// Currently this is only implemented by [`vec::IntoIter`] - returning a reference to itself - and [`binary_heap::IntoIter`] which returns a reference to its inner representation. <br>目前这仅由 [`vec::IntoIter`] 实现 - 返回对自身的引用 - 并且 [`binary_heap::IntoIter`] 将返回对其内部表示的引用。<br>
///
/// Since this is an internal trait it hides the implementation detail `binary_heap::IntoIter` uses `vec::IntoIter` internally. <br>由于这是一个内部 trait，它隐藏了 `binary_heap::IntoIter` 在内部使用 `vec::IntoIter` 的实现细节。<br>
///
/// [`vec::IntoIter`]: super::IntoIter
/// [`binary_heap::IntoIter`]: crate::collections::binary_heap::IntoIter
///
/// # Safety
///
/// In-place iteration relies on implementation details of `vec::IntoIter`, most importantly that it does not create references to the whole allocation during iteration, only raw pointers <br>就地迭代依赖于 `vec::IntoIter` 的实现细节，最重要的是它不会在迭代过程中创建对整个分配的引用，只是创建裸指针<br>
///
///
///
#[rustc_specialization_trait]
pub(crate) unsafe trait AsVecIntoIter {
    type Item;
    fn as_into_iter(&mut self) -> &mut super::IntoIter<Self::Item>;
}
