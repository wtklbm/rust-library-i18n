use crate::boxed::Box;

#[rustc_specialization_trait]
pub(super) unsafe trait IsZero {
    /// Whether this value's representation is all zeros <br>该值的表示形式是否全为零<br>
    fn is_zero(&self) -> bool;
}

macro_rules! impl_is_zero {
    ($t:ty, $is_zero:expr) => {
        unsafe impl IsZero for $t {
            #[inline]
            fn is_zero(&self) -> bool {
                $is_zero(*self)
            }
        }
    };
}

impl_is_zero!(i16, |x| x == 0);
impl_is_zero!(i32, |x| x == 0);
impl_is_zero!(i64, |x| x == 0);
impl_is_zero!(i128, |x| x == 0);
impl_is_zero!(isize, |x| x == 0);

impl_is_zero!(u16, |x| x == 0);
impl_is_zero!(u32, |x| x == 0);
impl_is_zero!(u64, |x| x == 0);
impl_is_zero!(u128, |x| x == 0);
impl_is_zero!(usize, |x| x == 0);

impl_is_zero!(bool, |x| x == false);
impl_is_zero!(char, |x| x == '\0');

impl_is_zero!(f32, |x: f32| x.to_bits() == 0);
impl_is_zero!(f64, |x: f64| x.to_bits() == 0);

unsafe impl<T> IsZero for *const T {
    #[inline]
    fn is_zero(&self) -> bool {
        (*self).is_null()
    }
}

unsafe impl<T> IsZero for *mut T {
    #[inline]
    fn is_zero(&self) -> bool {
        (*self).is_null()
    }
}

unsafe impl<T: IsZero, const N: usize> IsZero for [T; N] {
    #[inline]
    fn is_zero(&self) -> bool {
        // Because this is generated as a runtime check, it's not obvious that it's worth doing if the array is really long. <br>因为这是作为运行时检查生成的，所以如果数组很长，就不太值得这么做。<br>
        // The threshold here is largely arbitrary, but was picked because as of 2022-05-01 LLVM can const-fold the check in `vec![[0; 32]; n]` but not in `vec![[0; 64]; n]`: https://godbolt.org/z/WTzjzfs5bFeelfreetotweakifyouhavebetterevidence. <br>这里的阈值在很大程度上是任意的，但之所以选择该阈值是因为从 2022 年 5 月 1 日起，LLVM 可以在 `vec![[0; 32]; n]` 中对检查进行 const-fold，但在 `vec![[0; 64]; n]`: https://godbolt.org/z/WTzjzfs5bFeelfreetotweakifyouhavebetterevidence 中则不能。<br>
        //
        //
        //
        //

        N <= 32 && self.iter().all(IsZero::is_zero)
    }
}

// `Option<&T>` and `Option<Box<T>>` are guaranteed to represent `None` as null. <br>`Option<&T>` 和 `Option<Box<T>>` 保证将 `None` 表示为空。<br>
// For fat pointers, the bytes that would be the pointer metadata in the `Some` variant are padding in the `None` variant, so ignoring them and zero-initializing instead is ok. <br>对于胖指针，将在 `Some` 变体中作为指针元数据的字节填充在 `None` 变体中，因此可以忽略它们，而可以将其初始化为零。<br>
//
// `Option<&mut T>` never implements `Clone`, so there's no need for an impl of `SpecFromElem`. <br>`Option<&mut T>` 从不实现 `Clone`，因此不需要 `SpecFromElem` 的实现。<br>
//
//

unsafe impl<T: ?Sized> IsZero for Option<&T> {
    #[inline]
    fn is_zero(&self) -> bool {
        self.is_none()
    }
}

unsafe impl<T: ?Sized> IsZero for Option<Box<T>> {
    #[inline]
    fn is_zero(&self) -> bool {
        self.is_none()
    }
}

// `Option<num::NonZeroU32>` and similar have a representation guarantee that they're the same size as the corresponding `u32` type, as well as a guarantee that transmuting between `NonZeroU32` and `Option<num::NonZeroU32>` works. <br>`Option<num::NonZeroU32>` 和类似的具有表示保证它们与相应的 `u32` 类型具有相同的大小，并保证 `NonZeroU32` 和 `Option<num::NonZeroU32>` 之间的转换有效。<br>
//
// While the documentation officially makes it UB to transmute from `None`, we're the standard library so we can make extra inferences, and we know that the only niche available to represent `None` is the one that's all zeros. <br>虽然正式的文档将 `None` 转换为 UB，但我们是标准库，因此我们可以进行额外的推断，我们知道唯一可用来表示 `None` 的利基是一个全是零的。<br>
//
//
//

macro_rules! impl_is_zero_option_of_nonzero {
    ($($t:ident,)+) => {$(
        unsafe impl IsZero for Option<core::num::$t> {
            #[inline]
            fn is_zero(&self) -> bool {
                self.is_none()
            }
        }
    )+};
}

impl_is_zero_option_of_nonzero!(
    NonZeroU8,
    NonZeroU16,
    NonZeroU32,
    NonZeroU64,
    NonZeroU128,
    NonZeroI8,
    NonZeroI16,
    NonZeroI32,
    NonZeroI64,
    NonZeroI128,
    NonZeroUsize,
    NonZeroIsize,
);
