//! A priority queue implemented with a binary heap. <br>用二进制堆实现的优先级队列。<br>
//!
//! Insertion and popping the largest element have *O*(log(*n*)) time complexity. <br>插入和弹出最大元素具有 *O*(log(*n*)) 时间复杂度。<br>
//! Checking the largest element is *O*(1). <br>检查最大的元素是 *O*(1)。<br> Converting a vector to a binary heap can be done in-place, and has *O*(*n*) complexity. <br>可以就地将 vector 转换为二进制堆，并且复杂度为 *O*(*n*)。<br>
//! A binary heap can also be converted to a sorted vector in-place, allowing it to be used for an *O*(*n* * log(*n*)) in-place heapsort. <br>二元堆也可以就地转换为已排序的 vector，允许它用于 *O*(*n* * log(*n*)) 就地堆排序。<br>
//!
//! # Examples
//!
//! This is a larger example that implements [Dijkstra's algorithm][dijkstra] to solve the [shortest path problem][sssp] on a [directed graph][dir_graph]. <br>这是一个较大的示例，实现了 [Dijkstra 算法][dijkstra] 来解决 [有向图][dir_graph] 上的 [最短路径问题][sssp]。<br>
//!
//! It shows how to use [`BinaryHeap`] with custom types. <br>它显示了如何将 [`BinaryHeap`] 与自定义类型一起使用。<br>
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // The priority queue depends on `Ord`. <br>优先级队列取决于 `Ord`。<br>
//! // Explicitly implement the trait so the queue becomes a min-heap instead of a max-heap. <br>显式实现 trait，以便队列成为最小堆而不是最大堆。<br>
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Notice that the we flip the ordering on costs. <br>请注意，我们翻转了费用排序。<br>
//!         // In case of a tie we compare positions - this step is necessary to make implementations of `PartialEq` and `Ord` consistent. <br>在平局的情况下，我们比较位置 - 必须执行此步骤才能使 `PartialEq` 和 `Ord` 的实现保持一致。<br>
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` needs to be implemented as well. <br>`PartialOrd` 也需要实现。<br>
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Each node is represented as a `usize`, for a shorter implementation. <br>对于较短的实现，每个节点都表示为 `usize`。<br>
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstra's shortest path algorithm. <br>Dijkstra 的最短路径算法。<br>
//!
//! // Start at `start` and use `dist` to track the current shortest distance to each node. <br>从 `start` 开始，并使用 `dist` 跟踪到每个节点的当前最短距离。<br> This implementation isn't memory-efficient as it may leave duplicate nodes in the queue. <br>此实现的内存效率不高，因为它可能会将重复的节点留在队列中。<br>
//! //
//! // It also uses `usize::MAX` as a sentinel value, for a simpler implementation. <br>它还将 `usize::MAX` 用作标记值，以实现更简单的实现。<br>
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist[node] = current shortest distance from `start` to `node` <br>dist[node] = 当前从 `start` 到 `node` 的最短距离<br>
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // We're at `start`, with a zero cost <br>我们正处于 `start` 阶段，成本为零<br>
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Examine the frontier with lower cost nodes first (min-heap) <br>首先检查成本较低的节点的边界 (min-heap)<br>
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Alternatively we could have continued to find all shortest paths <br>或者，我们可以继续找到所有最短的路径<br>
//!         if position == goal { return Some(cost); }
//!
//!         // Important as we may have already found a better way <br>重要，因为我们可能已经找到了更好的方法<br>
//!         if cost > dist[position] { continue; }
//!
//!         // For each node we can reach, see if we can find a way with a lower cost going through this node <br>对于我们可以到达的每个节点，看看是否可以找到一种成本更低的方法通过该节点<br>
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // If so, add it to the frontier and continue <br>如果是这样，请将其添加到边界并继续<br>
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Relaxation, we have now found a better way <br>放松，我们现在找到了更好的方法<br>
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Goal not reachable <br>无法达成目标<br>
//!     None
//! }
//!
//! fn main() {
//!     // This is the directed graph we're going to use. <br>这是我们将要使用的有向图。<br>
//!     // The node numbers correspond to the different states, and the edge weights symbolize the cost of moving from one node to another. <br>节点编号对应于不同的状态，并且 edge 权重表示从一个节点移动到另一个节点的成本。<br>
//!     //
//!     // Note that the edges are one-way. <br>请注意，edges 是单向的。<br>
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v   1        2    |  2
//!     //          0 -----> 1 -----> 3 ---> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1 +------> 2 -------+      |
//!     //           10      |               |
//!     //                   +---------------+
//!     //
//!     // The graph is represented as an adjacency list where each index, corresponding to a node value, has a list of outgoing edges. <br>该图表示为邻接表，其中每个索引 (对应于节点值) 具有传出 edges 的列表。<br>
//!     // Chosen for its efficiency. <br>选择它的效率。<br>
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Node 0 <br>节点 0<br>
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Node 1 <br>节点 1<br>
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Node 2 <br>节点 2<br>
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Node 3 <br>节点 3<br>
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Node 4 <br>节点 4<br>
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::collections::TryReserveError;
use crate::slice;
use crate::vec::{self, AsVecIntoIter, Vec};

use super::SpecExtend;

#[cfg(test)]
mod tests;

/// A priority queue implemented with a binary heap. <br>用二进制堆实现的优先级队列。<br>
///
/// This will be a max-heap. <br>这将是一个最大的堆。<br>
///
/// It is a logic error for an item to be modified in such a way that the item's ordering relative to any other item, as determined by the [`Ord`] trait, changes while it is in the heap. <br>项的修改方式是一个逻辑错误，即项相对于任何其他项的排序 (由 [`Ord`] trait 确定) 在它在堆中时发生变化。<br> This is normally only possible through [`Cell`], [`RefCell`], global state, I/O, or unsafe code. <br>通常只有通过 [`Cell`]，[`RefCell`]，二进制状态，I/O 或不安全代码才能实现此操作。<br> The behavior resulting from such a logic error is not specified, but will be encapsulated to the `BinaryHeap` that observed the logic error and not result in undefined behavior. <br>由这种逻辑错误导致的行为没有被指定，但会封装到观察到逻辑错误的 `BinaryHeap` 中，并且不会导致未定义的行为。<br>
///
/// This could include panics, incorrect results, aborts, memory leaks, and non-termination. <br>这可能包括 panics，不正确的结果，异常终止，内存泄漏和未终止。<br>
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Type inference lets us omit an explicit type signature (which would be `BinaryHeap<i32>` in this example). <br>通过类型推断，我们可以省略显式类型签名 (在本示例中为 `BinaryHeap<i32>`)。<br>
/////
/// let mut heap = BinaryHeap::new();
///
/// // We can use peek to look at the next item in the heap. <br>我们可以使用 peek 来查看堆中的下一个项。<br>
/// // In this case, there's no items in there yet so we get None. <br>在这种情况下，那里还没有项目，所以我们得到 None。<br>
/// assert_eq!(heap.peek(), None);
///
/// // Let's add some scores... <br>让我们添加一些分数...<br>
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Now peek shows the most important item in the heap. <br>现在，窥视显示了堆中最重要的项。<br>
/// assert_eq!(heap.peek(), Some(&5));
///
/// // We can check the length of a heap. <br>我们可以检查堆的长度。<br>
/// assert_eq!(heap.len(), 3);
///
/// // We can iterate over the items in the heap, although they are returned in a random order. <br>我们可以遍历堆中的项，尽管它们是按随机顺序返回的。<br>
/////
/// for x in &heap {
///     println!("{x}");
/// }
///
/// // If we instead pop these scores, they should come back in order. <br>如果我们改为弹出这些分数，它们应该按顺序返回。<br>
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // We can clear the heap of any remaining items. <br>我们可以清除任何剩余项的堆。<br>
/// heap.clear();
///
/// // The heap should now be empty. <br>堆现在应该为空。<br>
/// assert!(heap.is_empty())
/// ```
///
/// A `BinaryHeap` with a known list of items can be initialized from an array: <br>可以从数组初始化具有已知项列表的 `BinaryHeap`：<br>
///
/// ```
/// use std::collections::BinaryHeap;
///
/// let heap = BinaryHeap::from([1, 5, 2]);
/// ```
///
/// ## Min-heap
///
/// Either [`core::cmp::Reverse`] or a custom [`Ord`] implementation can be used to make `BinaryHeap` a min-heap. <br>[`core::cmp::Reverse`] 或自定义 [`Ord`] 实现可用于使 `BinaryHeap` 成为最小堆。<br> This makes `heap.pop()` return the smallest value instead of the greatest one. <br>这使 `heap.pop()` 返回最小值而不是最大值。<br>
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Wrap values in `Reverse` <br>在 `Reverse` 中包装值<br>
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // If we pop these scores now, they should come back in the reverse order. <br>如果我们现在弹出这些分数，它们应该以相反的顺序返回。<br>
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Time complexity <br>时间复杂度<br>
///
/// | [push]  | [pop]         | [peek]/[peek\_mut] |
/// |---------|---------------|--------------------|
/// | *O*(1)~ | *O*(log(*n*)) | *O*(1)             |
///
/// The value for `push` is an expected cost; <br>`push` 的值是预期成本；<br> the method documentation gives a more detailed analysis. <br>方法文档提供了更详细的分析。<br>
///
/// [`core::cmp::Reverse`]: core::cmp::Reverse
/// [`Ord`]: core::cmp::Ord
/// [`Cell`]: core::cell::Cell
/// [`RefCell`]: core::cell::RefCell
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Structure wrapping a mutable reference to the greatest item on a `BinaryHeap`. <br>将可变引用引至 `BinaryHeap` 上最大部分的结构体。<br>
///
///
/// This `struct` is created by the [`peek_mut`] method on [`BinaryHeap`]. <br>该 `struct` 是通过 [`BinaryHeap`] 上的 [`peek_mut`] 方法创建的。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SAFETY: PeekMut is only instantiated for non-empty heaps. <br>PeekMut 仅针对非空堆实例化。<br>
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut is only instantiated for non-empty heaps <br>仅针对非空堆实例化 PeekMut<br>
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut is only instantiated for non-empty heaps <br>仅针对非空堆实例化 PeekMut<br>
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Removes the peeked value from the heap and returns it. <br>从堆中删除偷看的值并返回它。<br>
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Creates an empty `BinaryHeap<T>`. <br>创建一个空的 `BinaryHeap<T>`。<br>
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Creates an empty `BinaryHeap` as a max-heap. <br>创建一个空的 `BinaryHeap` 作为最大堆。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Creates an empty `BinaryHeap` with at least the specified capacity. <br>创建一个至少具有指定容量的空 `BinaryHeap`。<br>
    ///
    /// The binary heap will be able to hold at least `capacity` elements without reallocating. <br>二进制堆将能够保存至少 `capacity` 个元素而无需重新分配。<br>
    /// This method is allowed to allocate for more elements than `capacity`. <br>此方法允许分配比 `capacity` 更多的元素。<br>
    /// If `capacity` is 0, the binary heap will not allocate. <br>如果 `capacity` 为 0，则不会分配二进制堆。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Returns a mutable reference to the greatest item in the binary heap, or `None` if it is empty. <br>返回二进制堆中最大项的变量引用; 如果为空，则返回 `None`。<br>
    ///
    /// Note: If the `PeekMut` value is leaked, the heap may be in an inconsistent state. <br>如果 `PeekMut` 值泄漏，则堆可能处于不一致状态。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Time complexity <br>时间复杂度<br>
    ///
    /// If the item is modified then the worst case time complexity is *O*(log(*n*)), otherwise it's *O*(1). <br>如果该项被修改，则最坏情况下的时间复杂度为 *O*(log(*n*))，否则为 *O*(1)。<br>
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Removes the greatest item from the binary heap and returns it, or `None` if it is empty. <br>从二进制堆中删除最大的项并返回它; 如果为空，则返回 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from([1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Time complexity <br>时间复杂度<br>
    ///
    /// The worst case cost of `pop` on a heap containing *n* elements is *O*(log(*n*)). <br>`pop` 在包含 *n* 个元素的堆上的最坏情况代价是 *O*(log(*n*))。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SAFETY: !self.is_empty() means that self.len() > 0 <br>`!self.is_empty()` 表示 `self.len() > 0`<br>
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Pushes an item onto the binary heap. <br>将项目推入二进制堆。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Time complexity <br>时间复杂度<br>
    ///
    /// The expected cost of `push`, averaged over every possible ordering of the elements being pushed, and over a sufficiently large number of pushes, is *O*(1). <br>`push` 的预期成本是 *O*(1)，该成本是在被推元素的每个可能排序以及足够大量的推数上平均的。<br>
    ///
    /// This is the most meaningful cost metric when pushing elements that are *not* already in any sorted pattern. <br>当推送尚未处于任何排序模式的元素时，这是最有意义的成本指标。<br>
    ///
    /// The time complexity degrades if elements are pushed in predominantly ascending order. <br>如果元素主要以升序推入，则时间复杂度会降低。<br>
    /// In the worst case, elements are pushed in ascending sorted order and the amortized cost per push is *O*(log(*n*)) against a heap containing *n* elements. <br>在最坏的情况下，元素以升序排序，并且每次推送的摊销成本为 *O*(log(*n*)) 对包含 *n* 个元素的堆。<br>
    ///
    /// The worst case cost of a *single* call to `push` is *O*(*n*). <br>对 `push` 进行 `*` 调用的最坏情况是 *O*(*n*)。<br> The worst case occurs when capacity is exhausted and needs a resize. <br>最坏的情况发生在容量用尽并需要调整大小时。<br>
    /// The resize cost has been amortized in the previous figures. <br>调整大小成本已在之前的数字中摊销。<br>
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SAFETY: Since we pushed a new item it means that old_len = self.len() - 1 < self.len() <br>由于我们推送了一个新项，这意味着 old_len= self.len()-1 <self.len()<br>
        //
        unsafe { self.sift_up(0, old_len) };
    }

    /// Consumes the `BinaryHeap` and returns a vector in sorted (ascending) order. <br>消耗 `BinaryHeap` 并按已排序的 (ascending) 顺序返回 vector。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from([1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SAFETY: `end` goes from `self.len() - 1` to 1 (both included), so it's always a valid index to access. <br>`end` 从 `self.len() - 1` 变为 1 (均包括在内)，因此它始终是可访问的有效索引。<br>
            //
            //  It is safe to access index 0 (i.e. `ptr`), because <br>访问索引 0 (即 `ptr`) 是安全的，因为<br>
            //  1 <= end < self.len(), which means self.len() >= 2. <br>1 <= end < self.len()，表示 self.len() >= 2。<br>
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SAFETY: `end` goes from `self.len() - 1` to 1 (both included) so: <br>`end` 从 `self.len() - 1` 变为 1 (均包括在内)，因此：<br>
            //  0 < 1 <= end <= self.len() - 1 < self.len() Which means 0 < end and end < self.len(). <br>`0 < 1 <= end <= self.len() - 1 < self.len()`，这意味着 `0 < end` 并且 `end < self.len()`。<br>
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // The implementations of sift_up and sift_down use unsafe blocks in order to move an element out of the vector (leaving behind a hole), shift along the others and move the removed element back into the vector at the final location of the hole. <br>sift_up 和 sift_down 的实现使用不安全的块，以将元素从 vector 中移出 (留在 hole 后面)，沿其他元素移动，然后将移除的元素在 hole 的最终位置移回 vector 中。<br>
    //
    // The `Hole` type is used to represent this, and make sure the hole is filled back at the end of its scope, even on panic. <br>`Hole` 类型用于表示这一点，并确保 hole 在其作用域的末尾 (即使在 panic 上) 也被填充回去。<br>
    // Using a hole reduces the constant factor compared to using swaps, which involves twice as many moves. <br>与使用掉期相比，使用 hole 减少了常量因子，掉期涉及两倍的移动次数。<br>
    //
    //
    //
    //

    /// # Safety
    ///
    /// The caller must guarantee that `pos < self.len()`. <br>调用者必须保证 `pos < self.len()`。<br>
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Take out the value at `pos` and create a hole. <br>取出 `pos` 处的值，并创建一个 hole。<br>
        // SAFETY: The caller guarantees that pos < self.len() <br>调用者保证 pos <self.len()<br>
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SAFETY: hole.pos() > start >= 0, which means hole.pos() > 0 and so hole.pos() - 1 can't underflow. <br>hole.pos() > start >= 0，这意味着 hole.pos() > 0，因此  hole.pos() - 1 不能下溢。<br>
            //
            //  This guarantees that parent < hole.pos() so it's a valid index and also != hole.pos(). <br>这样可以保证 `parent < hole.pos()`，因此它是一个有效的索引，而且 `!= hole.pos()`。<br>
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SAFETY: Same as above <br>同上<br>
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Take an element at `pos` and move it down the heap, while its children are larger. <br>在 `pos` 处取一个元素，然后将其向下移动到堆中，而其子元素较大。<br>
    ///
    ///
    /// # Safety
    ///
    /// The caller must guarantee that `pos < end <= self.len()`. <br>调用者必须保证 `pos < end <= self.len()`。<br>
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SAFETY: The caller guarantees that pos < end <= self.len(). <br>调用者保证 pos <end <= self.len()。<br>
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: child == 2 * hole.pos() + 1. <br>循环不变量: child == 2 * hole.pos() + 1。<br>
        while child <= end.saturating_sub(2) {
            // compare with the greater of the two children <br>比较两个子节点中较大的一个<br>
            // SAFETY: child < end - 1 < self.len() and child + 1 < end <= self.len(), so they're valid indexes. <br>child <end-1 <self.len() 和 child + 1 <end <= self.len()，因此它们是有效索引。<br>
            //
            //  child == 2 * hole.pos() + 1 != hole.pos() and child + 1 == 2 * hole.pos() + 2 != hole.pos(). <br>`child == 2 * hole.pos() + 1 != hole.pos()` 和 `child + 1 == 2 * hole.pos() + 2 != hole.pos().`。<br>
            // FIXME: 2 * hole.pos() + 1 or 2 * hole.pos() + 2 could overflow if T is a ZST <br>如果 T 是 ZST，则 `2 * hole.pos() + 1` 或 `2 * hole.pos() + 2` 可能溢出<br>
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // if we are already in order, stop. <br>如果我们已经整齐了，那就停下来。<br>
            // SAFETY: child is now either the old child or the old child+1 We already proven that both are < self.len() and != hole.pos() <br>child 要么是老节点要么是老节点 + 1，我们已经证明它们都是 `< self.len()` 和 `!= hole.pos()`<br>
            //
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SAFETY: same as above. <br>与上述相同。<br>
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SAFETY: && short circuit, which means that in the second condition it's already true that child == end - 1 < self.len(). <br>短路，这意味着在第二种情况下 `child == end - 1 < self.len()` 已经是正确的。<br>
        //
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SAFETY: child is already proven to be a valid index and child == 2 * hole.pos() + 1 != hole.pos(). <br>child 已被证明是有效的索引，`child == 2 * hole.pos() + 1 != hole.pos()`。<br>
            //
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// The caller must guarantee that `pos < self.len()`. <br>调用者必须保证 `pos < self.len()`。<br>
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SAFETY: pos < len is guaranteed by the caller and obviously len = self.len() <= self.len(). <br>`pos < len` 是由调用者保证的，并且显然 `len = self.len() <= self.len()`。<br>
        //
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Take an element at `pos` and move it all the way down the heap, then sift it up to its position. <br>在 `pos` 处获取一个元素，并将其一直向下移动到堆中，然后将其筛选到其位置。<br>
    ///
    ///
    /// Note: This is faster when the element is known to be large / should be closer to the bottom. <br>当已知元素很大 / 应该更靠近底部时，这就更快了。<br>
    ///
    /// # Safety
    ///
    /// The caller must guarantee that `pos < self.len()`. <br>调用者必须保证 `pos < self.len()`。<br>
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SAFETY: The caller guarantees that pos < self.len(). <br>调用者保证 `pos < self.len()`。<br>
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: child == 2 * hole.pos() + 1. <br>循环不变量: child == 2 * hole.pos() + 1。<br>
        while child <= end.saturating_sub(2) {
            // SAFETY: child < end - 1 < self.len() and child + 1 < end <= self.len(), so they're valid indexes. <br>child <end-1 <self.len() 和 child + 1 <end <= self.len()，因此它们是有效索引。<br>
            //
            //  child == 2 * hole.pos() + 1 != hole.pos() and child + 1 == 2 * hole.pos() + 2 != hole.pos(). <br>`child == 2 * hole.pos() + 1 != hole.pos()` 和 `child + 1 == 2 * hole.pos() + 2 != hole.pos().`。<br>
            // FIXME: 2 * hole.pos() + 1 or 2 * hole.pos() + 2 could overflow if T is a ZST <br>如果 T 是 ZST，则 `2 * hole.pos() + 1` 或 `2 * hole.pos() + 2` 可能溢出<br>
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SAFETY: Same as above <br>同上<br>
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SAFETY: child == end - 1 < self.len(), so it's a valid index and child == 2 * hole.pos() + 1 != hole.pos(). <br>`child == end - 1 < self.len()`，所以它是一个有效的索引，`child == 2 * hole.pos() + 1 != hole.pos()`。<br>
            //
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SAFETY: pos is the position in the hole and was already proven to be a valid index. <br>pos 是 hole 中的位置，并且已经被证明是有效的索引。<br>
        //
        unsafe { self.sift_up(start, pos) };
    }

    /// Rebuild assuming data[0..start] is still a proper heap. <br>重建假设 data[0..start] 仍然是一个合适的堆。<br>
    fn rebuild_tail(&mut self, start: usize) {
        if start == self.len() {
            return;
        }

        let tail_len = self.len() - start;

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` takes O(self.len()) operations and about 2 * self.len() comparisons in the worst case while repeating `sift_up` takes O(tail_len * log(start)) operations and about 1 * tail_len * log_2(start) comparisons in the worst case, assuming start >= tail_len. <br>`rebuild` 在最坏情况下需要 O(self.len()) 次操作和大约 2 * self.len() 次比较，而重复 `sift_up` 在最坏情况下需要 O(tail_len * log(start)) 次操作和大约 1 * tail_len * log_2(start) 次比较，假设 start >= tail_len。<br>
        // For larger heaps, the crossover point no longer follows this reasoning and was determined empirically. <br>对于较大的堆，交叉点不再遵循此推理，而是根据经验确定的。<br>
        //
        //
        //
        //
        let better_to_rebuild = if start < tail_len {
            true
        } else if self.len() <= 2048 {
            2 * self.len() < tail_len * log2_fast(start)
        } else {
            2 * self.len() < tail_len * 11
        };

        if better_to_rebuild {
            self.rebuild();
        } else {
            for i in start..self.len() {
                // SAFETY: The index `i` is always less than self.len(). <br>索引 `i` 始终小于 self.len()。<br>
                unsafe { self.sift_up(0, i) };
            }
        }
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SAFETY: n starts from self.len() / 2 and goes down to 0. <br>n 从 self.len() / 2 开始，下降到 0。<br>
            //  The only case when !(n < self.len()) is if self.len() == 0, but it's ruled out by the loop condition. <br>`!(n < self.len())` 是 `self.len() == 0` 的唯一情况，但是循环条件将其排除在外。<br>
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Moves all the elements of `other` into `self`, leaving `other` empty. <br>将 `other` 的所有元素移到 `self`，将 `other` 留空。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut a = BinaryHeap::from([-10, 1, 2, 3, 3]);
    /// let mut b = BinaryHeap::from([-20, 5, 43]);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        let start = self.data.len();

        self.data.append(&mut other.data);

        self.rebuild_tail(start);
    }

    /// Clears the binary heap, returning an iterator over the removed elements in heap order. <br>清除二进制堆，按堆顺序返回已删除元素的迭代器。<br>
    /// If the iterator is dropped before being fully consumed, it drops the remaining elements in heap order. <br>如果迭代器在被完全消耗之前被丢弃，它会按照堆顺序丢弃剩余的元素。<br>
    ///
    ///
    /// The returned iterator keeps a mutable borrow on the heap to optimize its implementation. <br>返回的迭代器在堆上保留一个可变借用以优化其实现。<br>
    ///
    /// Note:
    /// * `.drain_sorted()` is *O*(*n* \* log(*n*)); <br>`.drain_sorted()` 是 *O*(*n*\* log(*n*))；<br> much slower than `.drain()`. <br>比 `.drain()` 慢得多。<br>
    ///   You should use the latter for most cases. <br>在大多数情况下，应使用后者。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from([1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // removes all elements in heap order <br>删除堆顺序中的所有元素<br>
    /// assert_eq!(heap.len(), 0);
    /// ```
    ///
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Retains only the elements specified by the predicate. <br>仅保留谓词指定的元素。<br>
    ///
    /// In other words, remove all elements `e` for which `f(&e)` returns `false`. <br>换句话说，删除所有 `f(&e)` 返回 `false` 的 `e` 元素。<br>
    /// The elements are visited in unsorted (and unspecified) order. <br>元素以未排序 (和未指定) 的顺序访问。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from([-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // only keep even numbers <br>只保留偶数<br>
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let mut first_removed = self.len();
        let mut i = 0;
        self.data.retain(|e| {
            let keep = f(e);
            if !keep && i < first_removed {
                first_removed = i;
            }
            i += 1;
            keep
        });
        // data[0..first_removed] is untouched, so we only need to rebuild the tail: <br>data[0..first_removed] 没有改变，所以我们只需要重建尾部：<br>
        self.rebuild_tail(first_removed);
    }
}

impl<T> BinaryHeap<T> {
    /// Returns an iterator visiting all values in the underlying vector, in arbitrary order. <br>返回一个迭代器，以任意顺序访问底层 vector 中的所有值。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from([1, 2, 3, 4]);
    ///
    /// // Print 1, 2, 3, 4 in arbitrary order <br>以任意顺序打印 1，2，3，4<br>
    /// for x in heap.iter() {
    ///     println!("{x}");
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Returns an iterator which retrieves elements in heap order. <br>返回一个迭代器，该迭代器以堆顺序检索元素。<br>
    /// This method consumes the original heap. <br>此方法消耗原始堆。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from([1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), [5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Returns the greatest item in the binary heap, or `None` if it is empty. <br>返回二进制堆中最大的项，如果为空，则返回 `None`。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Time complexity <br>时间复杂度<br>
    ///
    /// Cost is *O*(1) in the worst case. <br>在最坏的情况下，成本为 *O*(1)。<br>
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Returns the number of elements the binary heap can hold without reallocating. <br>返回二进制堆在不重新分配的情况下可以容纳的元素数。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Reserves the minimum capacity for at least `additional` elements more than the current length. <br>为超过当前长度的至少 `additional` 个元素保留最小容量。<br>
    /// Unlike [`reserve`], this will not deliberately over-allocate to speculatively avoid frequent allocations. <br>与 [`reserve`] 不同，这不会故意过度分配以推测性地避免频繁分配。<br>
    ///
    /// After calling `reserve_exact`, capacity will be greater than or equal to `self.len() + additional`. <br>调用 `reserve_exact` 后，容量将大于或等于 `self.len() + additional`。<br>
    /// Does nothing if the capacity is already sufficient. <br>如果容量已经足够，则不执行任何操作。<br>
    ///
    /// [`reserve`]: BinaryHeap::reserve
    ///
    /// # Panics
    ///
    /// Panics if the new capacity overflows [`usize`]. <br>如果新容量溢出 [`usize`]，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Reserves capacity for at least `additional` elements more than the current length. <br>为超过当前长度的至少 `additional` 个元素保留容量。<br> The allocator may reserve more space to speculatively avoid frequent allocations. <br>分配器可以保留更多空间来推测性地避免频繁分配。<br>
    ///
    /// After calling `reserve`, capacity will be greater than or equal to `self.len() + additional`. <br>调用 `reserve` 后，容量将大于或等于 `self.len() + additional`。<br>
    /// Does nothing if capacity is already sufficient. <br>如果容量已经足够，则不执行任何操作。<br>
    ///
    /// # Panics
    ///
    /// Panics if the new capacity overflows [`usize`]. <br>如果新容量溢出 [`usize`]，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Tries to reserve the minimum capacity for at least `additional` elements more than the current length. <br>尝试为超过当前长度的至少 `additional` 个元素保留最小容量。<br>
    /// Unlike [`try_reserve`], this will not deliberately over-allocate to speculatively avoid frequent allocations. <br>与 [`try_reserve`] 不同，这不会故意过度分配以推测性地避免频繁分配。<br>
    /// After calling `try_reserve_exact`, capacity will be greater than or equal to `self.len() + additional` if it returns `Ok(())`. <br>调用 `try_reserve_exact` 后，如果返回 `Ok(())`，则容量将大于或等于 `self.len() + additional`。<br>
    ///
    /// Does nothing if the capacity is already sufficient. <br>如果容量已经足够，则不执行任何操作。<br>
    ///
    /// Note that the allocator may give the collection more space than it requests. <br>请注意，分配器可能会给集合提供比其请求更多的空间。<br>
    /// Therefore, capacity can not be relied upon to be precisely minimal. <br>因此，不能依靠容量来精确地最小化。<br>
    /// Prefer [`try_reserve`] if future insertions are expected. <br>如果希望将来插入，则首选 [`try_reserve`]。<br>
    ///
    /// [`try_reserve`]: BinaryHeap::try_reserve
    ///
    /// # Errors
    ///
    /// If the capacity overflows, or the allocator reports a failure, then an error is returned. <br>如果容量溢出，或者分配器报告失败，则返回错误。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// use std::collections::TryReserveError;
    ///
    /// fn find_max_slow(data: &[u32]) -> Result<Option<u32>, TryReserveError> {
    ///     let mut heap = BinaryHeap::new();
    ///
    ///     // Pre-reserve the memory, exiting if we can't <br>预先保留内存，如果不能，则退出<br>
    ///     heap.try_reserve_exact(data.len())?;
    ///
    ///     // Now we know this can't OOM in the middle of our complex work <br>现在我们知道在我们复杂的工作中这不能 OOM<br>
    ///     heap.extend(data.iter());
    ///
    ///     Ok(heap.pop())
    /// }
    /// # find_max_slow(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[stable(feature = "try_reserve_2", since = "1.63.0")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.data.try_reserve_exact(additional)
    }

    /// Tries to reserve capacity for at least `additional` elements more than the current length. <br>尝试为超过当前长度的至少 `additional` 个元素保留容量。<br>
    /// The allocator may reserve more space to speculatively avoid frequent allocations. <br>分配器可以保留更多空间来推测性地避免频繁分配。<br>
    /// After calling `try_reserve`, capacity will be greater than or equal to `self.len() + additional` if it returns `Ok(())`. <br>调用 `try_reserve` 后，如果返回 `Ok(())`，容量将大于等于 `self.len() + additional`。<br>
    ///
    /// Does nothing if capacity is already sufficient. <br>如果容量已经足够，则不执行任何操作。<br>
    ///
    /// # Errors
    ///
    /// If the capacity overflows, or the allocator reports a failure, then an error is returned. <br>如果容量溢出，或者分配器报告失败，则返回错误。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// use std::collections::TryReserveError;
    ///
    /// fn find_max_slow(data: &[u32]) -> Result<Option<u32>, TryReserveError> {
    ///     let mut heap = BinaryHeap::new();
    ///
    ///     // Pre-reserve the memory, exiting if we can't <br>预先保留内存，如果不能，则退出<br>
    ///     heap.try_reserve(data.len())?;
    ///
    ///     // Now we know this can't OOM in the middle of our complex work <br>现在我们知道在我们复杂的工作中这不能 OOM<br>
    ///     heap.extend(data.iter());
    ///
    ///     Ok(heap.pop())
    /// }
    /// # find_max_slow(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[stable(feature = "try_reserve_2", since = "1.63.0")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.data.try_reserve(additional)
    }

    /// Discards as much additional capacity as possible. <br>丢弃尽可能多的附加容量。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Discards capacity with a lower bound. <br>丢弃容量下限。<br>
    ///
    /// The capacity will remain at least as large as both the length and the supplied value. <br>容量将至少保持与长度和提供的值一样大。<br>
    ///
    ///
    /// If the current capacity is less than the lower limit, this is a no-op. <br>如果当前容量小于下限，则为无操作。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "shrink_to", since = "1.56.0")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Returns a slice of all values in the underlying vector, in arbitrary order. <br>以任意顺序返回底层 vector 中所有值的切片。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// #![feature(binary_heap_as_slice)]
    /// use std::collections::BinaryHeap;
    /// use std::io::{self, Write};
    ///
    /// let heap = BinaryHeap::from([1, 2, 3, 4, 5, 6, 7]);
    ///
    /// io::sink().write(heap.as_slice()).unwrap();
    /// ```
    #[must_use]
    #[unstable(feature = "binary_heap_as_slice", issue = "83659")]
    pub fn as_slice(&self) -> &[T] {
        self.data.as_slice()
    }

    /// Consumes the `BinaryHeap` and returns the underlying vector in arbitrary order. <br>消耗 `BinaryHeap` 并以任意顺序返回底层 vector。<br>
    ///
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from([1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Will print in some order <br>将以一定顺序打印<br>
    /// for x in vec {
    ///     println!("{x}");
    /// }
    /// ```
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Returns the length of the binary heap. <br>返回二进制堆的长度。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from([1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Checks if the binary heap is empty. <br>检查二进制堆是否为空。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Clears the binary heap, returning an iterator over the removed elements in arbitrary order. <br>清除二进制堆，以任意顺序返回已删除元素的迭代器。<br>
    /// If the iterator is dropped before being fully consumed, it drops the remaining elements in arbitrary order. <br>如果迭代器在被完全消耗之前被丢弃，它会以任意顺序丢弃剩余的元素。<br>
    ///
    ///
    /// The returned iterator keeps a mutable borrow on the heap to optimize its implementation. <br>返回的迭代器在堆上保留一个可变借用以优化其实现。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from([1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{x}");
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Drops all items from the binary heap. <br>从二进制堆中丢弃所有项。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from([1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Hole represents a hole in a slice i.e., an index without valid value (because it was moved from or duplicated). <br>Hole 表示切片中的 hole，即没有有效值的索引 (因为它是从中移出或复制的)。<br>
///
/// In drop, `Hole` will restore the slice by filling the hole position with the value that was originally removed. <br>在丢弃时，`Hole` 将通过使用最初删除的值填充 hole 位置来恢复切片。<br>
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Create a new `Hole` at index `pos`. <br>在索引 `pos` 处创建一个新的 `Hole`。<br>
    ///
    /// Unsafe because pos must be within the data slice. <br>不安全，因为 pos 必须在数据切片内。<br>
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos should be inside the slice <br>pos 应该在切片内<br>
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Returns a reference to the element removed. <br>返回对已删除元素的引用。<br>
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Returns a reference to the element at `index`. <br>返回 `index` 处元素的引用。<br>
    ///
    /// Unsafe because index must be within the data slice and not equal to pos. <br>不安全，因为索引必须在数据切片内且不等于 pos。<br>
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Move hole to new location <br>将 hole 移到新位置<br>
    ///
    /// Unsafe because index must be within the data slice and not equal to pos. <br>不安全，因为索引必须在数据切片内且不等于 pos。<br>
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // fill the hole again <br>再次填充 hole<br>
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// An iterator over the elements of a `BinaryHeap`. <br>`BinaryHeap` 元素上的迭代器。<br>
///
/// This `struct` is created by [`BinaryHeap::iter()`]. <br>该 `struct` 由 [`BinaryHeap::iter()`] 创建。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
///
/// [`iter`]: BinaryHeap::iter
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Remove in favor of `#[derive(Clone)]` <br>删除以支持 `#[derive(Clone)]`<br>
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// An owning iterator over the elements of a `BinaryHeap`. <br>`BinaryHeap` 元素上的拥有的迭代器。<br>
///
/// This `struct` is created by [`BinaryHeap::into_iter()`] (provided by the [`IntoIterator`] trait). <br>这个 `struct` 由 [`BinaryHeap::into_iter()`] 创建 (由 [`IntoIterator`] trait 提供)。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
///
/// [`into_iter`]: BinaryHeap::into_iter
/// [`IntoIterator`]: core::iter::IntoIterator
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

// In addition to the SAFETY invariants of the following three unsafe traits also refer to the vec::in_place_collect module documentation to get an overview <br>除了以下三个不安全的 traits 的 SAFETY 不变量之外，还可以参考 vec::in_place_collect 模块文档以获得概述<br>
//
#[unstable(issue = "none", feature = "inplace_iteration")]
#[doc(hidden)]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
#[doc(hidden)]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

unsafe impl<I> AsVecIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[must_use = "iterators are lazy and do nothing unless consumed"]
#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// A draining iterator over the elements of a `BinaryHeap`. <br>`BinaryHeap` 的元素上的 draining 迭代器。<br>
///
/// This `struct` is created by [`BinaryHeap::drain()`]. <br>该 `struct` 由 [`BinaryHeap::drain()`] 创建。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// A draining iterator over the elements of a `BinaryHeap`. <br>`BinaryHeap` 的元素上的 draining 迭代器。<br>
///
/// This `struct` is created by [`BinaryHeap::drain_sorted()`]. <br>该 `struct` 由 [`BinaryHeap::drain_sorted()`] 创建。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Removes heap elements in heap order. <br>按堆顺序删除堆元素。<br>
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Converts a `Vec<T>` into a `BinaryHeap<T>`. <br>将 `Vec<T>` 转换为 `BinaryHeap<T>`。<br>
    ///
    /// This conversion happens in-place, and has *O*(*n*) time complexity. <br>此转换发生在原地，并且具有 *O*(*n*) 时间复杂度。<br>
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "std_collections_from_array", since = "1.56.0")]
impl<T: Ord, const N: usize> From<[T; N]> for BinaryHeap<T> {
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut h1 = BinaryHeap::from([1, 4, 2, 3]);
    /// let mut h2: BinaryHeap<_> = [1, 4, 2, 3].into();
    /// while let Some((a, b)) = h1.pop().zip(h2.pop()) {
    ///     assert_eq!(a, b);
    /// }
    /// ```
    fn from(arr: [T; N]) -> Self {
        Self::from_iter(arr)
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Converts a `BinaryHeap<T>` into a `Vec<T>`. <br>将 `BinaryHeap<T>` 转换为 `Vec<T>`。<br>
    ///
    /// This conversion requires no data movement or allocation, and has constant time complexity. <br>这种转换不需要数据移动或分配，并且具有恒定的时间复杂度。<br>
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Creates a consuming iterator, that is, one that moves each value out of the binary heap in arbitrary order. <br>创建一个消耗迭代器，即一个将任意值以任意顺序移出二进制堆的迭代器。<br>
    /// The binary heap cannot be used after calling this. <br>调用此后不能使用二进制堆。<br>
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from([1, 2, 3, 4]);
    ///
    /// // Print 1, 2, 3, 4 in arbitrary order <br>以任意顺序打印 1，2，3，4<br>
    /// for x in heap.into_iter() {
    ///     // x has type i32, not &i32 <br>x 的类型为 i32，不是 &i32<br>
    ///     println!("{x}");
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<Vec<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: Vec<T>) {
        let start = self.data.len();
        self.data.append(other);
        self.rebuild_tail(start);
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}
