use crate::ascii;
use crate::cmp::Ordering;
use crate::ffi::c_char;
use crate::fmt::{self, Write};
use crate::ops;
use crate::slice;
use crate::slice::memchr;
use crate::str;

/// 借用的 C 字符串的表示形式。
///
/// 此类型表示对以 n 结尾的字节数组的引用。
/// 它可以从一个 <code>&[[u8]]</code> 切片安全地构建，或者从原始 `*const c_char` 不安全地构建。
/// 然后可以通过执行 UTF-8 验证将其转换为 Rust <code>&[str]</code>，或转换为拥有所有权的 `CString`。
///
/// `&CStr` 对 `CString` 就像 <code>&[str]</code> 对 `String` 一样: 每对中的前者都是借用的引用; 后者是拥有的字符串。
///
/// 请注意，此结构体不是 `repr(C)`，不建议放置在 FFI 函数的签名中。
/// 而是，FFI 函数的安全包装程序可以利用不安全的 [`CStr::from_ptr`] 构造函数为其他使用者提供安全的接口。
///
///
/// # Examples
///
/// 检查外部 C 字符串：
///
/// ```ignore (extern-declaration)
/// use std::ffi::CStr;
/// use std::os::raw::c_char;
///
/// extern "C" { fn my_string() -> *const c_char; }
///
/// unsafe {
///     let slice = CStr::from_ptr(my_string());
///     println!("string buffer size without nul terminator: {}", slice.to_bytes().len());
/// }
/// ```
///
/// 传递源自 Rust 的 C 字符串：
///
/// ```ignore (extern-declaration)
/// use std::ffi::{CString, CStr};
/// use std::os::raw::c_char;
///
/// fn work(data: &CStr) {
///     extern "C" { fn work_with(data: *const c_char); }
///
///     unsafe { work_with(data.as_ptr()) }
/// }
///
/// let s = CString::new("data data data data").expect("CString::new failed");
/// work(&s);
/// ```
///
/// 将外部 C 字符串转换为 Rust `String`:
///
/// ```ignore (extern-declaration)
/// use std::ffi::CStr;
/// use std::os::raw::c_char;
///
/// extern "C" { fn my_string() -> *const c_char; }
///
/// fn my_string_safe() -> String {
///     unsafe {
///         CStr::from_ptr(my_string()).to_string_lossy().into_owned()
///     }
/// }
///
/// println!("string: {}", my_string_safe());
/// ```
///
/// [str]: prim@str "str"
///
///
///
///
///
#[derive(Hash)]
#[cfg_attr(not(test), rustc_diagnostic_item = "CStr")]
#[unstable(feature = "core_c_str", issue = "94079")]
#[rustc_has_incoherent_inherent_impls]
// FIXME:
// `impl From<&CStr> for Box<CStr>` 当前实现中的 `fn from` 依赖于 `CStr` 与 `[u8]` 布局兼容。
// 实现属性隐私时，应将 `CStr` 注解为 `#[repr(transparent)]`。
// 无论如何，`CStr` 表示形式和布局被视为实现细节，没有文档记录，因此不能依赖。
//
//
pub struct CStr {
    // FIXME: 这不应该用 DST 切片来表示，而只能用原始 `c_char` 以及某种形式的标记将其表示为未定义大小的类型。
    // 本质上，`sizeof(&CStr)` 应该与 `sizeof(&c_char)` 相同，但是 `CStr` 应该是未定义大小的类型。
    //
    //
    inner: [c_char],
}

/// 指示 nul 字节不在预期位置中的错误。
///
/// 用于创建 [`CStr`] 的切片必须位于末尾且只有一个 nul 字节。
///
///
/// 此错误是由 [`CStr::from_bytes_with_nul`] 方法创建的。
/// 有关更多信息，请参见其文档。
///
/// # Examples
///
/// ```
/// use std::ffi::{CStr, FromBytesWithNulError};
///
/// let _: FromBytesWithNulError = CStr::from_bytes_with_nul(b"f\0oo").unwrap_err();
/// ```
#[derive(Clone, PartialEq, Eq, Debug)]
#[unstable(feature = "core_c_str", issue = "94079")]
pub struct FromBytesWithNulError {
    kind: FromBytesWithNulErrorKind,
}

#[derive(Clone, PartialEq, Eq, Debug)]
enum FromBytesWithNulErrorKind {
    InteriorNul(usize),
    NotNulTerminated,
}

impl FromBytesWithNulError {
    fn interior_nul(pos: usize) -> FromBytesWithNulError {
        FromBytesWithNulError { kind: FromBytesWithNulErrorKind::InteriorNul(pos) }
    }
    fn not_nul_terminated() -> FromBytesWithNulError {
        FromBytesWithNulError { kind: FromBytesWithNulErrorKind::NotNulTerminated }
    }

    #[doc(hidden)]
    #[unstable(feature = "cstr_internals", issue = "none")]
    pub fn __description(&self) -> &str {
        match self.kind {
            FromBytesWithNulErrorKind::InteriorNul(..) => {
                "data provided contains an interior nul byte"
            }
            FromBytesWithNulErrorKind::NotNulTerminated => "data provided is not nul terminated",
        }
    }
}

/// 指示不存在空字节的错误。
///
/// 用于创建 [`CStr`] 的切片必须在切片内的某处包含一个空字节。
///
///
/// 此错误是由 [`CStr::from_bytes_until_nul`] 方法创建的。
///
#[derive(Clone, PartialEq, Eq, Debug)]
#[unstable(feature = "cstr_from_bytes_until_nul", issue = "95027")]
pub struct FromBytesUntilNulError(());

#[unstable(feature = "cstr_from_bytes_until_nul", issue = "95027")]
impl fmt::Display for FromBytesUntilNulError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "data provided does not contain a nul")
    }
}

#[stable(feature = "cstr_debug", since = "1.3.0")]
impl fmt::Debug for CStr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "\"")?;
        for byte in self.to_bytes().iter().flat_map(|&b| ascii::escape_default(b)) {
            f.write_char(byte as char)?;
        }
        write!(f, "\"")
    }
}

#[stable(feature = "cstr_default", since = "1.10.0")]
impl Default for &CStr {
    fn default() -> Self {
        const SLICE: &[c_char] = &[0];
        // SAFETY: `SLICE` 确实指向一个有效的以 nul 结尾的字符串。
        unsafe { CStr::from_ptr(SLICE.as_ptr()) }
    }
}

#[stable(feature = "frombyteswithnulerror_impls", since = "1.17.0")]
impl fmt::Display for FromBytesWithNulError {
    #[allow(deprecated, deprecated_in_future)]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.__description())?;
        if let FromBytesWithNulErrorKind::InteriorNul(pos) = self.kind {
            write!(f, " at byte pos {pos}")?;
        }
        Ok(())
    }
}

impl CStr {
    /// 用安全的 C 字符串包装器包装原始 C 字符串。
    ///
    /// 此函数将使用 `CStr` 包装器包装提供的 `ptr`，从而允许检查和互操作非所有的 C 字符串。
    /// 由于调用了 `slice::from_raw_parts` 函数，原始 C 字符串的总大小必须小于 `isize::MAX` 字节` 在内存中。
    ///
    /// # Safety
    ///
    /// * `ptr` 指向的内存必须在字符串末尾包含一个有效的 nul 终止符。
    ///
    /// * `ptr` 必须是 [valid] 以读取最多包括空终止符的字节。
    ///   这尤其意味着：
    ///
    ///     * 这个 `CStr` 的整个内存范围必须包含在一个分配的对象中!
    ///     * 即使对于零长度的 cstr，`ptr` 也必须为非空值。
    ///
    /// * 返回的 `CStr` 引用的内存在生命周期 `'a` 的持续时间内不能发生可变的。
    ///
    /// > **Note**: 该操作原定为零成本投放，但
    /// > 目前已通过预先计算长度来实现
    /// > 字符串。不能保证总是这样。
    ///
    /// # Caveat
    ///
    /// 从使用中可以推断出返回切片的生命周期。
    /// 为防止意外滥用，建议将生命周期与生命周期中任何安全的来源联系起来，例如通过提供一个辅助函数，获取切片的宿主值的生命周期，或通过明确的注解法。
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::ffi::CStr;
    /// use std::os::raw::c_char;
    ///
    /// extern "C" {
    ///     fn my_string() -> *const c_char;
    /// }
    ///
    /// unsafe {
    ///     let slice = CStr::from_ptr(my_string());
    ///     println!("string returned: {}", slice.to_str().unwrap());
    /// }
    /// # }
    /// ```
    ///
    /// [valid]: core::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_ptr<'a>(ptr: *const c_char) -> &'a CStr {
        // SAFETY: 调用者提供了一个指针，该指针指向大小小于 `isize::MAX` 的 NUL 终止符的有效 C 字符串，其内容保持有效，并且对于返回的 `CStr` 的生命周期不会更改。
        //
        //
        // 这样计算长度就可以了 (存在一个 NUL 字节)，对 from_raw_parts 的调用是安全的，因为我们知道长度最多为 `isize::MAX`，这意味着对 `from_bytes_with_nul_unchecked` 的调用是正确的。
        //
        // 从 c_char 到 u8 的转换是可以的，因为 c_char 始终是一个字节。
        //
        //
        //
        //
        unsafe {
            extern "C" {
                /// 由 libc 或 compiler_builtins 提供。
                fn strlen(s: *const c_char) -> usize;
            }
            let len = strlen(ptr);
            let ptr = ptr as *const u8;
            CStr::from_bytes_with_nul_unchecked(slice::from_raw_parts(ptr, len as usize + 1))
        }
    }

    /// 从字节切片创建 C 字符串包装器。
    ///
    /// 此方法将从包含至少一个 nul 字节的任何字节切片创建 `CStr`。
    /// 调用者不需要知道或指定 nul 字节的位置。
    ///
    /// 如果第一个字节是一个空字符，这个方法将返回一个空的 `CStr`。
    /// 如果存在多个 nul 字符，则 `CStr` 将在第一个字符处结束。
    ///
    /// 如果切片末尾只有一个 nul 字节，则此方法等效于 [`CStr::from_bytes_with_nul`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cstr_from_bytes_until_nul)]
    ///
    /// use std::ffi::CStr;
    ///
    /// let mut buffer = [0u8; 16];
    /// unsafe {
    ///     // 在这里，我们可能会调用一个不安全的 C 函数，它将字符串写入缓冲区。
    /////
    ///     let buf_ptr = buffer.as_mut_ptr();
    ///     buf_ptr.write_bytes(b'A', 8);
    /// }
    /// // 尝试从缓冲区中提取 C 以 nul 结尾的字符串。
    /// let c_str = CStr::from_bytes_until_nul(&buffer[..]).unwrap();
    /// assert_eq!(c_str.to_str().unwrap(), "AAAAAAAA");
    /// ```
    ///
    ///
    #[unstable(feature = "cstr_from_bytes_until_nul", issue = "95027")]
    pub fn from_bytes_until_nul(bytes: &[u8]) -> Result<&CStr, FromBytesUntilNulError> {
        let nul_pos = memchr::memchr(0, bytes);
        match nul_pos {
            Some(nul_pos) => {
                let subslice = &bytes[..nul_pos + 1];
                // SAFETY: 我们知道在 nul_pos 处有一个 nul 字节，所以这个切片 (以 nul 字节结束) 是一个格式良好的 C 字符串。
                //
                Ok(unsafe { CStr::from_bytes_with_nul_unchecked(subslice) })
            }
            None => Err(FromBytesUntilNulError(())),
        }
    }

    /// 从字节切片创建 C 字符串包装器。
    ///
    /// 在确保字节切片以 nul 终止并且不包含任何内部 nul 字节之后，此函数会将提供的 `bytes` 强制转换为 `CStr` 包装器。
    ///
    ///
    /// 如果 nul 字节可能不在末尾，则可以使用 [`CStr::from_bytes_until_nul`] 代替。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ffi::CStr;
    ///
    /// let cstr = CStr::from_bytes_with_nul(b"hello\0");
    /// assert!(cstr.is_ok());
    /// ```
    ///
    /// 创建没有尾随 nul 终止符的 `CStr` 是错误的：
    ///
    /// ```
    /// use std::ffi::CStr;
    ///
    /// let cstr = CStr::from_bytes_with_nul(b"hello");
    /// assert!(cstr.is_err());
    /// ```
    ///
    /// 使用内部 nul 字节创建 `CStr` 是错误的：
    ///
    /// ```
    /// use std::ffi::CStr;
    ///
    /// let cstr = CStr::from_bytes_with_nul(b"he\0llo\0");
    /// assert!(cstr.is_err());
    /// ```
    ///
    ///
    #[stable(feature = "cstr_from_bytes", since = "1.10.0")]
    pub fn from_bytes_with_nul(bytes: &[u8]) -> Result<&Self, FromBytesWithNulError> {
        let nul_pos = memchr::memchr(0, bytes);
        match nul_pos {
            Some(nul_pos) if nul_pos + 1 == bytes.len() => {
                // SAFETY: 我们知道在字节切片的末尾只有一个 nul 字节。
                //
                Ok(unsafe { Self::from_bytes_with_nul_unchecked(bytes) })
            }
            Some(nul_pos) => Err(FromBytesWithNulError::interior_nul(nul_pos)),
            None => Err(FromBytesWithNulError::not_nul_terminated()),
        }
    }

    /// 从字节切片不安全地创建 C 字符串包装器。
    ///
    /// 此函数会将提供的 `bytes` 强制转换为 `CStr` 包装器，而无需执行任何健全性检查。
    ///
    ///
    /// # Safety
    /// 所提供的切片必须以 nul 结尾，并且不包含任何内部 nul 字节。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ffi::{CStr, CString};
    ///
    /// unsafe {
    ///     let cstring = CString::new("hello").expect("CString::new failed");
    ///     let cstr = CStr::from_bytes_with_nul_unchecked(cstring.to_bytes_with_nul());
    ///     assert_eq!(cstr, &*cstring);
    /// }
    /// ```
    ///
    #[inline]
    #[must_use]
    #[stable(feature = "cstr_from_bytes", since = "1.10.0")]
    #[rustc_const_stable(feature = "const_cstr_unchecked", since = "1.59.0")]
    pub const unsafe fn from_bytes_with_nul_unchecked(bytes: &[u8]) -> &CStr {
        // 我们在一个 const fn 中，所以这是我们能做的最好的
        debug_assert!(!bytes.is_empty() && bytes[bytes.len() - 1] == 0);
        // SAFETY: 调用具有相同先决条件的内部函数。
        unsafe { Self::_from_bytes_with_nul_unchecked(bytes) }
    }

    #[inline]
    const unsafe fn _from_bytes_with_nul_unchecked(bytes: &[u8]) -> &CStr {
        // SAFETY: 强制转换为 CStr 是安全的，因为其内部表示形式也是 [u8] (仅在 std 内部安全)。
        //
        // 解引用获得的指针是安全的，因为它来自引用。
        // 这样，进行引用是安全的，因为其生命周期受给定 `bytes` 的生命周期的约束。
        //
        unsafe { &*(bytes as *const [u8] as *const CStr) }
    }

    /// 返回此 C 字符串的内部指针。
    ///
    /// 返回的指针在 `self` 内一直有效，并且指向以 0 字节结尾的连续区域，以表示字符串的结尾。
    ///
    /// **WARNING**
    ///
    /// 返回的指针是只读的； 对其进行写入 (包括将其传递给进行写入的 C 代码) 会导致未定义的行为。
    ///
    /// 您有责任确保底层内存不会过早释放。例如，当在 `unsafe` 块中使用 `ptr` 时，以下代码将导致未定义的行为：
    ///
    /// ```no_run
    /// # #![allow(unused_must_use)] #![allow(temporary_cstring_as_ptr)]
    /// use std::ffi::CString;
    ///
    /// let ptr = CString::new("Hello").expect("CString::new failed").as_ptr();
    /// unsafe {
    ///     // `ptr` 是悬垂的
    ///     *ptr;
    /// }
    /// ```
    ///
    /// 发生这种情况是因为 `as_ptr` 返回的指针不携带任何生命周期信息，并且 `CString` 在 `CString::new("Hello").expect("CString::new failed").as_ptr()` 表达式计算后立即被释放。
    ///
    /// 要解决此问题，请将 `CString` 绑定到本地变量：
    ///
    /// ```no_run
    /// # #![allow(unused_must_use)]
    /// use std::ffi::CString;
    ///
    /// let hello = CString::new("Hello").expect("CString::new failed");
    /// let ptr = hello.as_ptr();
    /// unsafe {
    ///     // `ptr` 有效，因为 `hello` 在作用域内
    ///     *ptr;
    /// }
    /// ```
    ///
    /// 这样，`hello` 中 `CString` 的生命周期就包含了 `ptr` 和 `unsafe` 区块的生命周期。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *const c_char {
        self.inner.as_ptr()
    }

    /// 将此 C 字符串转换为字节片。
    ///
    /// 返回的切片将不包含此 C 字符串具有的尾随 nul 终止符。
    ///
    ///
    /// > **Note**: 该方法当前被实现为恒定时间
    /// > 强制转换，但计划将其在 future 中的定义更改为
    /// > 每当调用此方法时，都要执行长度计算。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ffi::CStr;
    ///
    /// let cstr = CStr::from_bytes_with_nul(b"foo\0").expect("CStr::from_bytes_with_nul failed");
    /// assert_eq!(cstr.to_bytes(), b"foo");
    /// ```
    #[inline]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn to_bytes(&self) -> &[u8] {
        let bytes = self.to_bytes_with_nul();
        // SAFETY: to_bytes_with_nul 返回长度至少为 1 的字节
        unsafe { bytes.get_unchecked(..bytes.len() - 1) }
    }

    /// 将此 C 字符串转换为包含尾随 0 字节的字节切片。
    ///
    /// 此函数与 [`CStr::to_bytes`] 等效，除了保留尾随的 nul 终止符而不是将其截断之外。
    ///
    ///
    /// > **Note**: 目前，此方法已实现为零费用强制转换，但是
    /// > 计划在 future 中更改其定义以执行
    /// > 每次调用此方法时的长度计算。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ffi::CStr;
    ///
    /// let cstr = CStr::from_bytes_with_nul(b"foo\0").expect("CStr::from_bytes_with_nul failed");
    /// assert_eq!(cstr.to_bytes_with_nul(), b"foo\0");
    /// ```
    #[inline]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn to_bytes_with_nul(&self) -> &[u8] {
        // SAFETY: 在所有受支持的目标上，将 `c_char`s 切片转换为 `u8`s 切片是安全的。
        //
        unsafe { &*(&self.inner as *const [c_char] as *const [u8]) }
    }

    /// 如果 `CStr` 包含有效的 UTF-8，则产生 <code>&[str]</code> 切片。
    ///
    /// 如果 `CStr` 的内容是有效的 UTF-8 数据，该函数将返回相应的 <code>&[str]</code> 切片。
    ///
    /// 否则，它将返回错误，并详细说明 UTF-8 验证失败的位置。
    ///
    /// [str]: prim@str "str"
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ffi::CStr;
    ///
    /// let cstr = CStr::from_bytes_with_nul(b"foo\0").expect("CStr::from_bytes_with_nul failed");
    /// assert_eq!(cstr.to_str(), Ok("foo"));
    /// ```
    #[stable(feature = "cstr_to_str", since = "1.4.0")]
    pub fn to_str(&self) -> Result<&str, str::Utf8Error> {
        // 注意，将 `CStr` 更改为在 `.to_bytes()` 中而不是 `from_ptr()` 中执行长度检查时，可能值得考虑是否应该重写此代码，以便在进行长度计算时内联 UTF-8 检查，而不是随后进行。
        //
        //
        //
        str::from_utf8(self.to_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for CStr {
    fn eq(&self, other: &CStr) -> bool {
        self.to_bytes().eq(other.to_bytes())
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for CStr {}
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for CStr {
    fn partial_cmp(&self, other: &CStr) -> Option<Ordering> {
        self.to_bytes().partial_cmp(&other.to_bytes())
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for CStr {
    fn cmp(&self, other: &CStr) -> Ordering {
        self.to_bytes().cmp(&other.to_bytes())
    }
}

#[stable(feature = "cstr_range_from", since = "1.47.0")]
impl ops::Index<ops::RangeFrom<usize>> for CStr {
    type Output = CStr;

    fn index(&self, index: ops::RangeFrom<usize>) -> &CStr {
        let bytes = self.to_bytes_with_nul();
        // 我们需要手动检查起始索引来说明空字节，因为否则我们会得到一个不以空结尾的空字符串。
        //
        //
        if index.start < bytes.len() {
            // SAFETY: 有效 `CStr` 的非空尾仍然是有效 `CStr`。
            unsafe { CStr::from_bytes_with_nul_unchecked(&bytes[index.start..]) }
        } else {
            panic!(
                "index out of bounds: the len is {} but the index is {}",
                bytes.len(),
                index.start
            );
        }
    }
}

#[stable(feature = "cstring_asref", since = "1.7.0")]
impl AsRef<CStr> for CStr {
    #[inline]
    fn as_ref(&self) -> &CStr {
        self
    }
}
