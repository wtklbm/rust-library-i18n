//! 通过裸指针手动管理内存。
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! 该模块中的许多函数都将裸指针作为参数，并对其进行读取或写入。为了安全起见，这些指针必须是 *valid*。
//! 指针是否有效取决于指针用于 (读或写) 的操作以及所访问的内存范围 (即 read/written 多少个字节)。
//! 大多数函数使用 `*mut T` 和 `*const T` 来访问单个值，在这种情况下，文档将忽略该大小，并隐式地假定其为 `size_of::<T>()` 字节。
//!
//! 有效性的确切规则尚未确定。此时提供的保证非常小：
//!
//! * [null] 指针从来都是无效的，甚至对于 [大小为零][zst] 的访问也是无效的。
//! * 为了使指针有效，有必要 (但并不总是足够) 使指针 *可引用*: 从指针开始的给定大小的内存范围必须全部在单个已分配对象的范围内。
//!
//! 请注意，在 Rust 中，每个 (stack-allocated) 变量都被视为一个单独的分配对象。
//! * 即使对于 [大小为零][zst] 的操作，指针也不得指向已释放的内存，即，即使对于大小为零的操作，释放也会使指针无效。
//! 但是，将任何非零整数 *字面量* 强制转换为指针对于零大小的访问都是有效的，即使该地址恰好存在一些内存并被释放了。
//! 这相当于编写自己的分配器：分配零大小的对象不是很困难。
//! 获得对零大小访问有效的指针的规范方法是 [`NonNull::dangling`]。
//!
//!
//!
//!
//!
//!
//!
//!
// FIXME: 上面提到 `ptr::invalid`，一旦它稳定了。
//! * 在用于在线程之间同步的 [原子操作][atomic operations] 的意义上，此模块中的函数执行的所有访问都是非原子的。这意味着从两个不同的线程对同一位置执行两次并发访问是一种未定义的行为，除非两个访问均仅从内存中读取。
//! 请注意，这明确包含 [`read_volatile`] 和 [`write_volatile`]: 易失性访问不能用于线程间同步。
//! * 只要底层对象处于活动状态，并且不使用引用 (仅仅是裸指针) 来访问同一内存，则转换对指针的引用的结果就是有效的。
//!
//! 这些公理，以及仔细地使用 [`offset`] 进行指针运算，足以在不安全的代码中正确实现许多有用的东西。随着 [aliasing] 规则的确定，最终将提供更强有力的保证。有关更多信息，请参见 [书籍][book] 以及专门针对 [未定义的行为][ub] 的引用中的部分。
//!
//! ## Alignment
//!
//! 上面定义的有效裸指针不一定正确对齐 (其中 "proper" 对齐由 pointee 类型定义，即 `*const T` 必须与 `mem::align_of::<T>()` 对齐)。但是，大多数函数要求其参数正确对齐，并将在其文档中明确说明此要求。
//! [`read_unaligned`] 和 [`write_unaligned`] 除外。
//!
//! 当一个函数需要适当的对齐时，即使访问的大小为 0，即实际上没有触摸到内存，它也需要进行适当的对齐。在这种情况下，请考虑使用 [`NonNull::dangling`]。
//!
//! ## 分配对象
//!
//! 对于一些操作，例如 [`offset`] 或 projection (`expr.field`)，"allocated object" 的概念变得相关。分配的对象是一个连续的内存区域。
//! 分配对象的常见示例包括栈分配变量 (每个变量都是一个单独的分配对象)、堆分配 (每个分配器创建的分配都是一个单独的分配对象) 和 `static` 变量。
//!
//! # Strict Provenance
//!
//! **以下文本是非规范性的，不够正式，并且是对 Provenance 的极其严格的解释。如果您的代码没有严格遵循它，那也没关系。**
//!
//! [Strict Provenance][] 是一组实验性 API，可帮助工具尝试验证程序执行的内存安全性。值得注意的是，这包括 [Miri][] 和 [CHERI][]，它们可以检测您何时访问越界内存或以其他方式违反 Rust 的内存模型。
//!
//! 任何为现代计算机架构编译的编程语言都必须以某种形式存在 Provenance，但是以对编译器和程序员都有用的方式指定 Provenance 模型是一个持续的挑战。
//! [Strict Provenance][] 实验旨在探索这个问题: 如果我们只是说您不能做所有使 provenance 如此混乱的讨厌的操作，那会怎么样?
//!
//! 必须删除哪些 API? 必须添加哪些 API? 代码需要改变多少，现在是更糟还是更好? 任何模式都会变得真正无法表达吗?
//! 我们可以为这些模式开辟特殊的例外吗? 我们应该吗?
//!
//! 这个项目的第二个目标是看看我们是否可以消除指针 <-> 整数转换的许多函数的歧义，以便放宽 `usize` 的定义，使其不是 *pointer* 大小而是 address-space/offset/allocation-sized (我们可能会继续混淆这些概念)。
//! 这可能使更有效地定位指针大于偏移量的平台成为可能，例如 CHERI 和一些分段架构。
//!
//! ## Provenance
//!
//! **这部分是非规范性的，是 [Strict Provenance][] 实验的一部分。**
//!
//! 指针并不是简单的 "integer" 或 "address"。例如，可以毫无争议地说，释放后使用显然是未定义的行为，即使你运气好，并且释放的内存在读或写之前得到了重新分配 (事实上，这是最坏的情况，如果不发生这种情况，UAFs 也不会太担心!)。
//! 为了使这种说法合理化，指针需要以某种方式不仅仅是它们的地址:
//! 他们必须有 provenance。
//!
//! 创建分配时，该分配具有唯一的原始指针。对于 alloc API，这实际上是调用返回的指针，对于本地变量和静态变量，这是变量或静态的名称。为了简洁明了起见，这稍微过多地使用了 "pointer" 这个术语。
//!
//! 保证分配的原始指针对整个分配具有唯一的访问权限，并且只对该分配具有唯一的访问权。从这个意义上说，分配可以被认为是一个不能被打破的 "sandbox"。*Provenance* 是访问分配沙箱的权限，并具有 *spatial* 和 *temporal* 组件:
//!
//! * Spatial: 允许指针访问的字节范围。
//! * Temporal: 访问这些字节相关的 (分配的) 生命周期。
//!
//! Spatial provenance 确保您不会超出沙盒，而时间 provenance 确保您在访问某些内存的权限被撤销 (通过释放或借用到期) 后不能侥幸成功。
//!
//! 通过 [`offset`]、借用和指针转换等操作从原始指针传递派生的所有指针隐式共享 provenance。
//! 一些操作可能会收缩派生的 provenance，从而限制它可以访问多少内存或它的有效期有多长 (即借用一个子字段和子切片)。
//!
//! 收缩的 provenance 无法撤消: 即使您知道有一个更大的分配，你也不能派生一个具有更大起源的指针。同样，您不能 "recombine" 将两个连续的 provenances 重新合二为一 (即使用 `fn merge(&[T], &[T]) -> &[T]`).
//!
//! 对某个值的引用始终具有该字段占用的内存的确切来源。
//! 对切片的引用总是在切片描述的范围内 provenances。
//!
//! 如果一个分配被释放，所有指向该分配的指针都会失效，并且实际上失去了它们的出处。
//!
//! strict provenance 实验主要只对探索更严格的 *空间* provenance 感兴趣。从这个意义上说，它可以被认为是更雄心勃勃和正式的 [Stacked Borrows][] 研究项目的一个子集，这是 [Miri][] 等工具的基础。
//! 特别是，堆叠借用对于正确描述允许借用做什么以及何时失效是必要的。这必然涉及比简单地识别分配更复杂的*时间*推理。为 strict provenance 实验调整 API 和代码也将极大地帮助 Stacked 借用。
//!
//! ## 指针与地址
//!
//! **这部分是非规范性的，是 [Strict Provenance][] 实验的一部分。**
//!
//! 试图定义 provenance 的最大历史问题之一是程序员在指针和整数之间自由转换。一旦您允许这一点，通常就不可能准确地跟踪和保存 provenance 信息，您需要求助于非常复杂和不可靠的启发式方法。
//! 但是当然，指针和整数之间的转换是非常有用的，那么我们能做什么呢?
//!
//! 您还知道 WASM 实际上是 "Harvard Architecture" 吗? 正如函数指针与数据指针的处理方式完全不同? 而且我们只是在 WASM 上发布了 Rust 并没有真正解决我们让您在函数指针和数据指针之间自由转换的事实，因为它主要是 Just Works? 让我们把它放在 "指针强制转换是可疑的" 堆上。
//!
//!
//! Strict Provenance 试图通过解耦 Rust 的指针和 `usize` (和 `isize`) 的传统合并，并定义一个指向语义上包含以下信息的指针来解决这些问题:
//!
//! * **address-space** 它是它的一部分 (例如 "data" 与 WASM 中的 "code")。
//! * 它指向的 **地址**，可以用 `usize` 表示。
//! * 它拥有所有权的 **出处**，定义了它有权访问的内存。
//!
//! 在 Strict Provenance 下，usize *不能* 准确地表示指针，从指针转换为 usize 通常是 *only* 提取地址的操作。因此*不可能*从一个 usize 创建一个有效的指针，因为没有办法恢复地址空间和 provenance。
//! 换句话说，指针 - 整数 - 指针往返是不可能的 (从某种意义上说，生成的指针不可解引用)。
//!
//! 使这个模型 *完全* 可行的关键见解是 [`with_addr`][] 方法:
//!
//! ```text
//!     /// 使用给定地址创建一个新指针。
//!     ///
//!     /// 这执行与 `addr as ptr` 强制转换相同的操作，但将 `self` 的 *address-space* 和 *provenance* 复制到新指针。
//!     /// 这使我们能够动态地保存和传播这些重要信息，而这在其他情况下使用一元强制转换是不可能的。
//!     ///
//!     /// 这相当于使用 `wrapping_offset` 将 `self` 偏移到给定地址，因此具有所有相同的功能和限制。
//!     ///
//!     ///
//!     ///
//!     pub fn with_addr(self, addr: usize) -> Self;
//! ```
//!
//! 所以您仍然可以丢弃一个地址表示并做任何您想要的聪明的技巧 *只要* 您能够将指针保持在您关心的分配中，可以 "reconstitute" 指针的其他部分.
//! 通常这很容易，因为您只需要一个指针，弄乱地址，然后立即转换回指针。
//! 为了使这个用例更符合人体工程学，我们提供了 [`map_addr`][] 方法。
//!
//! 为了清楚地表明代码是 "following" Strict Provenance 语义，我们还提供了一个 [`addr`][] 方法，该方法 promises 返回的地址不是指针使用指针往返的一部分。在 future 中，我们可以为指针 <-> 整数转换提供 lint，以帮助您审核您的代码是否符合严格的 provenance。
//!
//! ## 使用 Strict Provenance
//!
//! 大多数代码不需要更改以符合 strict provenance，因为 *不是* 显然已经存在未定义行为的唯一真正相关的操作是从 usize 强制转换为指针。对于 *does* 将 usize 转换为指针的代码，更改的作用域取决于您正在做什么。
//!
//! 通常，您只需要确保如果要将使用地址转换为指针，然后使用该指针指向 read/write 内存，则需要保留一个具有足够来源来执行 read/write 本身的指针。这样，从地址到指针的所有强制转换基本上都只是应用 offsets/indexing。
//!
//! 对于像标记指针 *as 这样的简单情况，只要将标记指针表示为实际指针而不是 usize*，这通常是微不足道的。例如:
//!
//! ```
//! #![feature(strict_provenance)]
//!
//! unsafe {
//!     // 我们要打包到指针中的标志
//!     static HAS_DATA: usize = 0x1;
//!     static FLAG_MASK: usize = !HAS_DATA;
//!
//!     // 我们的值，它必须有足够的对齐，以便有备用的最低有效位。
//!     let my_precious_data: u32 = 17;
//!     assert!(core::mem::align_of::<u32>() > 1);
//!
//!     // 创建一个标记指针
//!     let ptr = &my_precious_data as *const u32;
//!     let tagged = ptr.map_addr(|addr| addr | HAS_DATA);
//!
//!     // 检查标志:
//!     if tagged.addr() & HAS_DATA != 0 {
//!         // 取消标记并读取指针
//!         let data = *tagged.map_addr(|addr| addr & FLAG_MASK);
//!         assert_eq!(data, 17);
//!     } else {
//!         unreachable!()
//!     }
//! }
//! ```
//!
//! (是的，如果您一直使用 AtomicUsize 作为同步数据结构中的指针，则应该改用 AtomicPtr。
//! 如果这弄乱了您以原子方式操作指针的方式，我们想知道原因，以及需要做些什么来修复它。)
//!
//! 像 XOR 列表这样更复杂且通常 *evil* 的东西需要更重大的更改，例如在预分配的 Vec 或 Arena 中分配所有节点，并使用指向整个分配的指针来重构 XORed 地址。
//!
//! 必须从一个地址创建有效指针的情况，例如访问固定地址的内存映射接口的裸机代码，是一个关于如何支持的悬而未决的问题。
//! 这些情况仍然是允许的，但我们可能需要某种 "I know what I'm doing" 注解来向编译器解释这种情况。也有可能它们根本不需要特别注意，因为它们通常在 "the abstract machine" 的作用域之外访问内存，或者已经像 "volatile" 一样使用 "I know what I'm doing" 注解。
//!
//! 在 [Strict Provenance] 下，未定义行为:
//!
//! * 通过与该内存没有 provenance 的指针访问内存。
//!
//! * [`offset`] 指向或来自没有 provenance 的地址的指针。
//!   这意味着它总是 UB 来偏移一个指针，这个指针是从一个被释放的对象中派生出来的，即使这个偏移量是 0。请注意，其 provenance 的指针 "one past the end" 实际上并不在其 provenance 之外，它只有 0 个字节可以 load/store。
//!
//! 但它仍然听起来像是:
//!
//! * 仅从地址创建无效指针 (请参见 [`ptr::invalid`][])。这可用于 `null` 或之类的标记值，以表示永远不会被解引用的标记指针。通常，只要您不对整数使用要求它有效的操作 (偏移、读取、写入等)，将整数伪装成指针 "for fun" 总是合理的。
//!
//! * 在任何充分对齐的非空地址处伪造大小为零的分配。
//!   即通常的 "ST 是假的，做你想做的事" 规则适用 *但是* 这仅适用于实际伪造 (整数转换为指针)。如果您借用一些结构体的字段，它 *碰巧* 是零大小，则结果指针将与该分配相关联，如果分配被释放，它仍然会失效。
//!   在 future 中，我们可能会引入一个 API 来明确这种伪造的分配。
//!
//! * [`wrapping_offset`][] 指向其 provenance 之外的指针。这包括具有 "no"  provenance 的无效指针。不幸的是，对于特定平台，这可能存在实际限制，如何指定它 (如果有的话) 是一个悬而未决的问题。
//!   值得注意的是，[CHERI][] 依赖于一种压缩方案，该方案无法处理使偏移量 "too far" 越界的指针。如果发生这种情况，`addr` 返回的地址将是您期望的值，但 provenance 将失效，并且将其用于 read/write 会出错。
//!   这方面的细节是特定于架构的并且基于对齐，但是指针范围两侧的缓冲区非常大 (想想千字节，而不是字节)。
//!
//! * 按地址比较任意指针。地址是只是整数，因此总是有一个连贯的答案，即使指针无效或来自不同的 address-spaces/provenances。当然，比较来自不同地址空间的地址通常 *毫无意义*，但是将千克与米进行比较也是如此，并且 Rust 也不会阻止这种情况。
//! 类似地，如果您得到 "lucky"，并且注意到一个指针过去是 "same" 地址作为不相关分配的开始，那么您对这个事实所做的任何事情都是 *可能* 会是莫名其妙的。
//! 由于两个指针仍然不允许访问另一个指针的分配 (bytes)，因为它们仍然有不同的 provenance，所以这种莫名其妙的范围受到控制。
//!
//! * 执行指针标记技巧。这不属于 [`wrapping_offset`]，但由于 [CHERI][] 的局限性，值得更详细地提及。低位标记非常健壮，并且通常甚至不会越界，因为类型确保大小 >= 对齐 (并且过度对齐实际上给了 CHERI 更大的灵活性)。
//! 任何比这更复杂的东西都会迅速进入 "extremely platform-specific" 领域，因为根据特定支持的操作可能会或可能不会允许某些事情。
//!   例如，ARM 明确支持高位标记，因此 ARM 上的 CHERI 继承了它并且应该支持它。
//!
//! ## 指针使用大小指针往返和 'exposed' 出处
//!
//! **本节*非规范*，是 [Strict Provenance] 实验的一部分。**
//!
//! 如上所述，在 [Strict Provenance] 下，指针 - 使用 - 指针往返是不可能的。
//! 但是，存在充满此类往返的遗留 Rust 代码，并且遗留平台 API 通常假设 `usize` 可以捕获构成指针的所有信息。也可能存在无法移植到 Strict Provenance 的代码 (我们会使用 [like to hear about][Strict Provenance])。
//!
//! 对于这种情况，有一个后备计划，一种 `选择退出` 严格来源的方法。
//! 但是，请注意，这会使您的代码更难指定，并且代码在 (well) 中无法与 [Miri] 和 [CHERI] 等工具一起使用。
//!
//! 此回退计划由 [`expose_addr`] 和 [`from_exposed_addr`] 方法 (相当于指针和整数之间的 `as` 转换) 提供。[`expose_addr`] 与 [`addr`] 很相似，但还添加了指向 'exposed' 的证明列表的指针。
//! (此列表纯粹是概念性的，它的存在是为了指定 Rust，但在实际执行中并未具体化，除非在 [Miri] 之类的工具中。) [`from_exposed_addr`] 可用于构造具有这些先前 'exposed' 出处之一的指针。
//! [`from_exposed_addr`] 仅将 `addr: usize` 作为参数，因此与 [`with_addr`] 不同，没有指示返回指针的正确出处是什么 -- 这正是指针 - 使用 - 指针往返如此难以严格指定的原因! 没有算法可以决定使用哪个出处。
//! 您可以将其视为 "guessing" 正确的出处，并且猜测将是 "maximally in your favor"，从某种意义上说，如果有任何方法可以避免未定义的行为，那么这就是将要进行的猜测。
//! 但是，如果 *no* 以前的 'exposed' 出处证明返回的指针的使用方式是正确的，则程序具有未定义的行为。
//!
//! 使用 [`expose_addr`] 或 [`from_exposed_addr`] (或等效的 `as` 强制转换) 意味着代码*不*遵循严格的出处规则。Strict Provenance 实验的目标是确定是否可以在没有 [`expose_addr`] 和 [`from_exposed_addr`] 的情况下使用 Rust。
//! 如果这成功了，这将是避免规范复杂性和促进采用 [CHERI] 和 [Miri] 等工具的重大胜利，这对于提高对 (unsafe) Rust 代码的信心有很大帮助。
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//! [`wrapping_offset`]: pointer::wrapping_offset
//! [`with_addr`]: pointer::with_addr
//! [`map_addr`]: pointer::map_addr
//! [`addr`]: pointer::addr
//! [`ptr::invalid`]: core::ptr::invalid
//! [`expose_addr`]: pointer::expose_addr
//! [`from_exposed_addr`]: from_exposed_addr
//! [Miri]: https://github.com/rust-lang/miri
//! [CHERI]: https://www.cl.cam.ac.uk/research/security/ctsrd/cheri/
//! [Strict Provenance]: https://github.com/rust-lang/rust/issues/95228
//! [Stacked Borrows]: https://plv.mpi-sws.org/rustbelt/stacked-borrows/
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{
    self, assert_unsafe_precondition, is_aligned_and_not_null, is_nonoverlapping,
};

use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

mod metadata;
pub(crate) use metadata::PtrRepr;
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// 执行指向值的析构函数 (如果有)。
///
/// 从语义上讲，这等效于调用 [`ptr::read`] 并丢弃结果，但是具有以下优点：
///
/// * 强制要求使用 `drop_in_place` 丢弃未定义大小的类型 (例如 trait 对象)，因为它们无法被读取到栈上并且无法正常丢弃。
///
/// * 当丢弃手动分配的内存时 (例如，在 `Box`/`Rc`/`Vec` 的实现中)，通过 [`ptr::read`] 进行此操作对优化器来说更友好，因为编译器不需要证明丢弃副本是合理的。
///
///
/// * 当 `T` 不是 `repr(packed)` 时，可用于丢弃 [固定][pinned] 数据 (在丢弃固定的数据之前，不得移动固定的数据)。
///
/// 未对齐的值不能被直接丢弃，必须先使用 [`ptr::read_unaligned`] 将它们复制到对齐的位置。对于包装的结构体，此移动由编译器自动完成。
/// 这意味着已打包结构的字段不会被原地丢弃。
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的：
///
/// * 对于读取和写入，`to_drop` 必须是 [有效][valid]。
///
/// * `to_drop` 必须正确对齐。
///
/// * `to_drop` 指向的值必须对丢弃有效，这可能意味着它必须支持其他不变量 - 这与类型有关。
///
/// 此外，如果 `T` 不是 [`Copy`]，则在调用 `drop_in_place` 之后使用指向的值可能会导致未定义的行为。请注意，`*to_drop = foo` 被视为使用，因为它将导致该值再次被丢弃。
/// [`write()`] 可用于覆盖数据，而不会导致数据被丢弃。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
///
/// # Examples
///
/// 从 vector 手动删除最后一个项：
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // 获取指向 `v` 中最后一个元素的裸指针。
///     let ptr = &mut v[1] as *mut _;
///     // 缩短 `v`，以防止丢弃最后一个项。
///     // 我们首先这样做是为了防止 `drop_in_place` 低于 panics。
///     v.set_len(1);
///     // 如果没有调用 `drop_in_place`，则最后一个项将永远不会被删除，并且它管理的内存也会泄漏。
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // 确保丢弃了最后一项。
/// assert!(weak.upgrade().is_none());
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // 这里的代码并不重要 - 编译器会将其替换为真正的 drop glue。
    //

    // SAFETY: 请看上面的注释
    unsafe { drop_in_place(to_drop) }
}

/// 创建一个空的裸指针。
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.24.0")]
#[rustc_diagnostic_item = "ptr_null"]
#[cfg(bootstrap)]
pub const fn null<T>() -> *const T {
    invalid(0)
}

/// 创建一个空的裸指针。
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.24.0")]
#[rustc_allow_const_fn_unstable(ptr_metadata)]
#[rustc_diagnostic_item = "ptr_null"]
#[cfg(not(bootstrap))]
pub const fn null<T: ?Sized + Thin>() -> *const T {
    from_raw_parts(invalid(0), ())
}

/// 创建一个空的可变裸露指针。
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.24.0")]
#[rustc_diagnostic_item = "ptr_null_mut"]
#[cfg(bootstrap)]
pub const fn null_mut<T>() -> *mut T {
    invalid_mut(0)
}

/// 创建具有给定地址的无效指针。
///
/// 这与 `addr as *const T` 不同，`addr as *const T` 创建一个指针来获取先前公开的出处。有关该操作的更多详细信息，请参见 [`from_exposed_addr`]。
///
/// 该模块的顶层文档讨论了 "invalid" 指针的确切含义，但本质上这表示该指针与任何实际分配无关，只不过是一个伪装的 usize 地址。
///
///
/// 该指针将没有与之关联的 provenance，因此 read/write/offset 是 UB 的。这主要是为了促进像 `ptr::null` 和 `NonNull::dangling` 这样的东西，它们会产生无效的指针。
///
/// (标准 "Zero-Sized-Types get to cheat and lie" 的警告是适用的，尽管可能需要为它们提供自己的 API，以便 100% 清楚地说明这一点。)
///
/// 此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。
///
///
///
///
///
///
#[inline(always)]
#[must_use]
#[rustc_const_stable(feature = "stable_things_using_strict_provenance", since = "1.61.0")]
#[unstable(feature = "strict_provenance", issue = "95228")]
pub const fn invalid<T>(addr: usize) -> *const T {
    // FIXME(strict_provenance_magic): 我是魔法，应该是编译器内部函数。
    // 我们使用 transmute 而不是 cast，所以像 Miri 这样的工具可以判断这与 from_exposed_addr*不*相同。
    //
    // SAFETY: 每个有效的整数也是一个有效的指针 (只要您不解引用那个指针)。
    //
    unsafe { mem::transmute(addr) }
}

/// 用给定的地址创建一个无效的可变指针。
///
/// 这与 `addr as *mut T` 不同，`addr as *mut T` 创建一个指针来获取先前公开的出处。有关该操作的更多详细信息，请参见 [`from_exposed_addr_mut`]。
///
/// 该模块的顶层文档讨论了 "invalid" 指针的确切含义，但本质上这表示该指针与任何实际分配无关，只不过是一个伪装的 usize 地址。
///
///
/// 该指针将没有与之关联的 provenance，因此 read/write/offset 是 UB 的。这主要是为了促进像 `ptr::null` 和 `NonNull::dangling` 这样的东西，它们会产生无效的指针。
///
/// (标准 "Zero-Sized-Types get to cheat and lie" 的警告是适用的，尽管可能需要为它们提供自己的 API，以便 100% 清楚地说明这一点。)
///
/// 此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。
///
///
///
///
///
///
#[inline(always)]
#[must_use]
#[rustc_const_stable(feature = "stable_things_using_strict_provenance", since = "1.61.0")]
#[unstable(feature = "strict_provenance", issue = "95228")]
pub const fn invalid_mut<T>(addr: usize) -> *mut T {
    // FIXME(strict_provenance_magic): 我是魔法，应该是编译器内部函数。
    // 我们使用 transmute 而不是 cast，所以像 Miri 这样的工具可以判断这与 from_exposed_addr*不*相同。
    //
    // SAFETY: 每个有效的整数也是一个有效的指针 (只要您不解引用那个指针)。
    //
    unsafe { mem::transmute(addr) }
}

/// 将地址转换回指针，获取以前的 'exposed' 出处。
///
/// 这相当于 `addr as *const T`。返回指针的出处是先前传递给 [`expose_addr`][pointer::expose_addr] 或 `ptr as usize` 强制转换的 *any* 指针的出处。
/// 如果没有以前的 'exposed' 出处证明该指针的使用方式是正确的，则程序具有未定义的行为。
/// 请注意，没有算法可以决定使用哪个出处。
/// 您可以将其视为 "guessing" 正确的出处，并且猜测将是 "maximally in your favor"，从某种意义上说，如果有任何方法可以避免未定义的行为，那么这就是将要进行的猜测。
///
/// 在具有多个地址空间的平台上，您有责任确保该地址在该指针将使用的地址空间中有意义。
///
/// 使用这种方法意味着代码没有遵循严格的出处规则。
/// "Guessing" 合适的出处使规范和推理复杂化，并且可能不受帮助您与 Rust 内存模型保持一致的工具的支持，因此建议尽可能使用 [`with_addr`][pointer::with_addr]。
///
///
/// 在大多数平台上，这将产生一个与地址具有相同字节的值。
/// 需要在指针中存储附加信息的平台可能不支持此操作，因为通常不可能实际*计算*返回的指针必须拾取哪个出处。
///
/// 此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。
///
///
///
///
///
///
///
///
#[must_use]
#[inline]
#[unstable(feature = "strict_provenance", issue = "95228")]
pub fn from_exposed_addr<T>(addr: usize) -> *const T
where
    T: Sized,
{
    // FIXME(strict_provenance_magic): 我是魔法，应该是编译器内部函数。
    addr as *const T
}

/// 将地址转换回错误指针，获取以前的 'exposed' 出处。
///
/// 这相当于 `addr as *mut T`。返回指针的出处是先前传递给 [`expose_addr`][pointer::expose_addr] 或 `ptr as usize` 强制转换的 *any* 指针的出处。
/// 如果没有以前的 'exposed' 出处证明该指针的使用方式是正确的，则程序具有未定义的行为。
/// 请注意，没有算法可以决定使用哪个出处。
/// 您可以将其视为 "guessing" 正确的出处，并且猜测将是 "maximally in your favor"，从某种意义上说，如果有任何方法可以避免未定义的行为，那么这就是将要进行的猜测。
///
/// 在具有多个地址空间的平台上，您有责任确保该地址在该指针将使用的地址空间中有意义。
///
/// 使用这种方法意味着代码没有遵循严格的出处规则。
/// "Guessing" 合适的出处使规范和推理复杂化，并且可能不受帮助您与 Rust 内存模型保持一致的工具的支持，因此建议尽可能使用 [`with_addr`][pointer::with_addr]。
///
///
/// 在大多数平台上，这将产生一个与地址具有相同字节的值。
/// 需要在指针中存储附加信息的平台可能不支持此操作，因为通常不可能实际*计算*返回的指针必须拾取哪个出处。
///
/// 此 API 及其声明的语义是 Strict Provenance 实验的一部分，有关详细信息，请参见 [模块文档][crate::ptr]。
///
///
///
///
///
///
///
///
#[must_use]
#[inline]
#[unstable(feature = "strict_provenance", issue = "95228")]
pub fn from_exposed_addr_mut<T>(addr: usize) -> *mut T
where
    T: Sized,
{
    // FIXME(strict_provenance_magic): 我是魔法，应该是编译器内部函数。
    addr as *mut T
}

/// 创建一个空的可变裸露指针。
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.24.0")]
#[rustc_allow_const_fn_unstable(ptr_metadata)]
#[rustc_diagnostic_item = "ptr_null_mut"]
#[cfg(not(bootstrap))]
pub const fn null_mut<T: ?Sized + Thin>() -> *mut T {
    from_raw_parts_mut(invalid_mut(0), ())
}

/// 根据指针和长度形成原始切片。
///
/// `len` 参数是 **元素** 的数量，而不是字节数。
///
/// 此函数是安全的，但实际上使用返回值是不安全的。
/// 有关切片的安全要求，请参见 [`slice::from_raw_parts`] 的文档。
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // 从指向第一个元素的指针开始创建切片指针
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    from_raw_parts(data.cast(), len)
}

/// 执行与 [`slice_from_raw_parts`] 相同的功能，但返回的是原始可变切片，而不是原始的不可变切片。
///
///
/// 有关更多详细信息，请参见 [`slice_from_raw_parts`] 的文档。
///
/// 此函数是安全的，但实际上使用返回值是不安全的。
/// 有关切片的安全要求，请参见 [`slice::from_raw_parts_mut`] 的文档。
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // 在切片中的索引处分配值
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    from_raw_parts_mut(data.cast(), len)
}

/// 在相同类型的两个可变位置交换值，而无需取消初始化任何一个。
///
/// 但是对于以下两个例外，此函数在语义上等效于 [`mem::swap`]：
///
///
/// * 它对裸指针而不是引用进行操作。
/// 如果引用可用，则应首选 [`mem::swap`]。
///
/// * 两个指向的值可能会重叠。
/// 如果值确实重叠，则将使用 `x` 的内存重叠区域。
/// 在下面的第二个示例中对此进行了演示。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的：
///
/// * 对于读取和写入，`x` 和 `y` 都必须为 [有效][valid] 的。
///
/// * `x` 和 `y` 必须正确对齐。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
///
/// # Examples
///
/// 交换两个不重叠的区域：
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let (x, y) = array.split_at_mut(2);
/// let x = x.as_mut_ptr().cast::<[u32; 2]>(); // 这是 `array[0..2]`
/// let y = y.as_mut_ptr().cast::<[u32; 2]>(); // 这是 `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// 交换两个重叠的区域：
///
/// ```
/// use std::ptr;
///
/// let mut array: [i32; 4] = [0, 1, 2, 3];
///
/// let array_ptr: *mut i32 = array.as_mut_ptr();
///
/// let x = array_ptr as *mut [i32; 3]; // 这是 `array[0..3]`
/// let y = unsafe { array_ptr.add(1) } as *mut [i32; 3]; // 这是 `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // 切片的索引 `1..3` 在 `x` 和 `y` 之间重叠。
///     // 合理的结果将是 `[2, 3]`，因此索引 `0..3` 为 `[1, 2, 3]` (与 `swap` 匹配的 `y`) ； 或将它们设为 `[0, 1]`，以使索引 `1..4` 为 `[0, 1, 2]` (与 `swap` 之前的 `x` 匹配)。
/////
///     // 定义此实现是为了做出后一种选择。
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // 给自己一些工作的空间。
    // 我们不必担心丢弃: `MaybeUninit` 在丢弃时什么也不做。
    let mut tmp = MaybeUninit::<T>::uninit();

    // 执行交换
    // SAFETY: 调用者必须保证 `x` 和 `y` 对写入有效并且正确对齐。
    // `tmp` 不能与 `x` 或 `y` 重叠，因为 `tmp` 只是作为单独的分配对象在栈上分配。
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` 和 `y` 可能重叠
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// 从 `x` 和 `y` 开始在两个内存区域之间交换 `count * size_of::<T>()` 字节。
/// 这两个区域必须 *不能* 重叠。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的：
///
/// * `x` 和 `y` 都必须 [有效][valid] 才能读取和写入 `count *
///   size_of::<T>()` 个字节。
///
/// * `x` 和 `y` 必须正确对齐。
///
/// * 从 `x` 开始的内存区域，大小为 `count *
///   size_of::<T>()` 字节不得与以 `y` 开始且大小相同的内存区域重叠。
///
/// 请注意，即使有效复制的大小 (`count * size_of::<T>()`) 是 `0`，指针也必须非空的并且正确对齐。
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    #[allow(unused)]
    macro_rules! attempt_swap_as_chunks {
        ($ChunkTy:ty) => {
            if mem::align_of::<T>() >= mem::align_of::<$ChunkTy>()
                && mem::size_of::<T>() % mem::size_of::<$ChunkTy>() == 0
            {
                let x: *mut MaybeUninit<$ChunkTy> = x.cast();
                let y: *mut MaybeUninit<$ChunkTy> = y.cast();
                let count = count * (mem::size_of::<T>() / mem::size_of::<$ChunkTy>());
                // SAFETY: 这些是调用者承诺的相同字节，只是输入为 `MaybeUninit<ChunkTy>`s 而不是 `T`s。
                // 上面的 `if` 条件确保我们没有违反对齐要求，并且划分是准确的，这样我们就不会丢失任何最后的字节。
                //
                //
                //
                return unsafe { swap_nonoverlapping_simple(x, y, count) };
            }
        };
    }

    // SAFETY: 调用者必须保证 `x` 和 `y` 对写入有效并且正确对齐。
    //
    unsafe {
        assert_unsafe_precondition!(
            is_aligned_and_not_null(x)
                && is_aligned_and_not_null(y)
                && is_nonoverlapping(x, y, count)
        );
    }

    // NOTE(scottmcm) Miri 在这里被禁用，因为以较小的单位读取对它来说是一种悲观。
    // 此外，如果该类型包含任何未对齐的指针，则难以支持在多次读取中复制这些指针。
    //
    #[cfg(not(miri))]
    {
        // 将切片拆分为 LLVM 能够向量化的 2 次幂大小的小块 (除非它是具有多于指针对齐的特殊类型，因为我们不想悲观 SIMD vectors 的切片之类的东西。)
        //
        //
        if mem::align_of::<T>() <= mem::size_of::<usize>()
            && (!mem::size_of::<T>().is_power_of_two()
                || mem::size_of::<T>() > mem::size_of::<usize>() * 2)
        {
            attempt_swap_as_chunks!(usize);
            attempt_swap_as_chunks!(u8);
        }
    }

    // SAFETY: 与此函数相同的前提条件
    unsafe { swap_nonoverlapping_simple(x, y, count) }
}

/// 与 [`swap_nonoverlapping`] 相同的行为和安全条件
///
/// LLVM 可以对其进行矢量化 (至少它可以用于 `swap_nonoverlapping` 尝试使用的两倍大小的类型)，因此无需手动对其进行 SIMD。
///
#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_simple<T>(x: *mut T, y: *mut T, count: usize) {
    let mut i = 0;
    while i < count {
        let x: &mut T =
            // SAFETY: 根据前提条件，`i` 是在界内，因为它低于 `n`
            unsafe { &mut *x.add(i) };
        let y: &mut T =
            // SAFETY: 根据前提条件，`i` 是在界内，因为它低于 `n`，并且它不同于 `x`，因为范围不重叠
            //
            unsafe { &mut *y.add(i) };
        mem::swap_simple(x, y);

        i += 1;
    }
}

/// 将 `src` 移至指定的 `dst`，返回先前的 `dst` 值。
///
/// 这两个值都不会被丢弃。
///
/// 该函数在语义上等效于 [`mem::replace`]，除了它在裸指针上而不是在引用上运行。
/// 如果引用可用，则应首选 [`mem::replace`]。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的：
///
/// * 对于读取和写入，`dst` 必须是 [有效的][valid]。
///
/// * `dst` 必须正确对齐。
///
/// * `dst` 必须指向 `T` 类型的正确初始化值。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` 将具有相同的效果，而无需 unsafe 块。
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_replace", issue = "83164")]
pub const unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SAFETY: 调用者必须保证 `dst` 有效，可以强制转换为变量引用 (对写入，对齐，初始化有效)，并且不能与 `src` 重叠，因为 `dst` 必须指向不同的分配对象。
    //
    //
    //
    unsafe {
        assert_unsafe_precondition!(is_aligned_and_not_null(dst));
        mem::swap(&mut *dst, &mut src); // 不能重叠
    }
    src
}

/// 从 `src` 读取值而不移动它。这将使 `src` 中的内存保持不变。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的：
///
/// * `src` 必须是 [有效的][valid] 才能读取。
///
/// * `src` 必须正确对齐。如果不是这种情况，请使用 [`read_unaligned`]。
///
/// * `src` 必须指向 `T` 类型的正确初始化值。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// 手动实现 [`mem::swap`]：
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // 在 `tmp` 中的 `a` 处创建值的按位副本。
///         let tmp = ptr::read(a);
///
///         // 此时退出 (通过显式返回或调用 panics 的函数) 将导致 `tmp` 中的值被丢弃，而 `a` 仍引用相同的值。
///         // 如果 `T` 不是 `Copy`，则可能触发未定义的行为。
/////
/////
///
///         // 在 `a` 中的 `b` 处创建值的按位副本。
///         // 这是安全的，因为可变引用不能使用别名。
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // 如上所述，退出此处可能会触发未定义的行为，因为 `a` 和 `b` 引用了相同的值。
/////
///
///         // 将 `tmp` 移至 `b`。
///         ptr::write(b, tmp);
///
///         // `tmp` 已移动 (`write` 对其第二个参数的所有权)，因此这里没有隐含地丢弃任何东西。
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## 归还值的所有权
///
/// `read` 创建 `T` 的按位副本，无论 `T` 是否为 [`Copy`]。
/// 如果 `T` 不是 [`Copy`]，则同时使用返回的值和 `*src` 的值可能会违反内存安全性。
/// 请注意，将分配给 `*src` 视为一种用途，因为它将尝试丢弃 `*src` 处的值。
///
/// [`write()`] 可用于覆盖数据，而不会导致数据被丢弃。
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` 现在指向与 `s` 相同的底层内存。
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // 分配给 `s2` 会导致其原始值被丢弃。
///     // 除此之外，由于已释放底层内存，因此不能再使用 `s`。
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // 分配给 `s` 将导致旧值再次被丢弃，从而导致未定义的行为。
/////
///     // s = String::from("bar");  // 错误
///
///     // `ptr::write` 可用于覆盖一个值而无需丢弃它。
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    // 我们直接调用内部函数是为了避免在生成的代码中调用函数，因为 `intrinsics::copy_nonoverlapping` 是一个包装函数。
    //
    extern "rust-intrinsic" {
        #[rustc_const_stable(feature = "const_intrinsic_copy", since = "1.63.0")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: 调用者必须保证 `src` 对于读取有效。
    // `src` 不能与 `tmp` 重叠，因为 `tmp` 只是作为单独的分配对象在栈上分配的。
    //
    //
    // 另外，由于我们只是将有效值写入 `tmp`，因此可以确保正确初始化它。
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// 从 `src` 读取值而不移动它。这将使 `src` 中的内存保持不变。
///
/// 与 [`read`] 不同，`read_unaligned` 使用未对齐的指针。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的：
///
/// * `src` 必须是 [有效的][valid] 才能读取。
///
/// * `src` 必须指向 `T` 类型的正确初始化值。
///
/// 与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`read_unaligned` 都会创建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，则同时使用返回值和 `*src` 处的值都可以 [违反内存安全][read-ownership]。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空。
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## 在 `packed` 结构体上
///
/// 尝试使用诸如 `&packed.unaligned as *const FieldType` 的表达式创建指向 `unaligned` 结构体字段的裸指针，然后再将其转换为裸指针，这会产生一个中间未对齐的引用。
///
/// 引用是临时的并且立即强制转换是无关紧要的，因为编译器始终希望引用正确对齐。
/// 结果，使用 `&packed.unaligned as *const FieldType` 会在程序中立即导致* undefined 行为 *。
///
/// 相反，您必须使用 [`ptr::addr_of!`](addr_of) 宏来创建指针。您可以将返回的指针与此函数一起使用。
///
/// 一个不执行的操作以及它与 `read_unaligned` 的关系的示例是：
///
/// ```
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// // 取一个未对齐的 32 位整数的地址。
/// // 与 `&packed.unaligned as *const _` 相比，它没有未定义的行为。
/// let unaligned = std::ptr::addr_of!(packed.unaligned);
///
/// let v = unsafe { std::ptr::read_unaligned(unaligned) };
/// assert_eq!(v, 0x01020304);
/// ```
///
/// 但是，例如使用 `packed.unaligned` 直接访问未对齐的字段是安全的。
///
/// # Examples
///
/// 从字节缓冲区读取 usize 值：
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: 调用者必须保证 `src` 对于读取有效。
    // `src` 不能与 `tmp` 重叠，因为 `tmp` 只是作为单独的分配对象在栈上分配的。
    //
    //
    // 另外，由于我们只是将有效值写入 `tmp`，因此可以确保正确初始化它。
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// 用给定值覆盖存储位置，而无需读取或丢弃旧值。
///
/// `write` 不会丢弃 `dst` 的内容。
/// 这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。
///
///
/// 此外，它不会丢弃 `src`。在语义上，`src` 被移到 `dst` 指向的位置。
///
/// 这适用于初始化未初始化的内存，或覆盖以前是 [`read`] 的内存。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的：
///
/// * `dst` 必须是 [有效的][valid] 才能写入。
///
/// * `dst` 必须正确对齐。如果不是这种情况，请使用 [`write_unaligned`]。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// 手动实现 [`mem::swap`]：
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // 在 `tmp` 中的 `a` 处创建值的按位副本。
///         let tmp = ptr::read(a);
///
///         // 此时退出 (通过显式返回或调用 panics 的函数) 将导致 `tmp` 中的值被丢弃，而 `a` 仍引用相同的值。
///         // 如果 `T` 不是 `Copy`，则可能触发未定义的行为。
/////
/////
///
///         // 在 `a` 中的 `b` 处创建值的按位副本。
///         // 这是安全的，因为可变引用不能使用别名。
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // 如上所述，退出此处可能会触发未定义的行为，因为 `a` 和 `b` 引用了相同的值。
/////
///
///         // 将 `tmp` 移至 `b`。
///         ptr::write(b, tmp);
///
///         // `tmp` 已移动 (`write` 对其第二个参数的所有权)，因此这里没有隐含地丢弃任何东西。
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "86302")]
pub const unsafe fn write<T>(dst: *mut T, src: T) {
    // 我们直接调用内部函数是为了避免在生成的代码中调用函数，因为 `intrinsics::copy_nonoverlapping` 是一个包装函数。
    //
    extern "rust-intrinsic" {
        #[rustc_const_stable(feature = "const_intrinsic_copy", since = "1.63.0")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SAFETY: 调用者必须保证 `dst` 对写入有效。
    // `dst` 不能与 `dst` 重叠，因为调用者拥有 `dst` 的权限，而 `src` 是这个函数拥有所有权的。
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// 用给定值覆盖存储位置，而无需读取或丢弃旧值。
///
/// 与 [`write()`] 不同，指针可能未对齐。
///
/// `write_unaligned` 不会丢弃 `dst` 的内容。这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。
///
/// 此外，它不会丢弃 `src`。在语义上，`src` 被移到 `dst` 指向的位置。
///
/// 这适用于初始化未初始化的内存，或覆盖以前用 [`read_unaligned`] 读取的内存。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的：
///
/// * `dst` 必须是 [有效的][valid] 才能写入。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空。
///
/// [valid]: self#safety
///
/// ## 在 `packed` 结构体上
///
/// 尝试使用诸如 `&packed.unaligned as *const FieldType` 的表达式创建指向 `unaligned` 结构体字段的裸指针，然后再将其转换为裸指针，这会产生一个中间未对齐的引用。
///
/// 引用是临时的并且立即强制转换是无关紧要的，因为编译器始终希望引用正确对齐。
/// 结果，使用 `&packed.unaligned as *const FieldType` 会在程序中立即导致* undefined 行为 *。
///
/// 相反，您必须使用 [`ptr::addr_of_mut!`](addr_of_mut) 宏来创建指针。您可以将返回的指针与此函数一起使用。
///
/// 如何做到这一点以及这与 `write_unaligned` 的关系的一个例子是：
///
/// ```
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// // 取一个未对齐的 32 位整数的地址。
/// // 与 `&packed.unaligned as *mut _` 相比，它没有未定义的行为。
/// let unaligned = std::ptr::addr_of_mut!(packed.unaligned);
///
/// unsafe { std::ptr::write_unaligned(unaligned, 42) };
///
/// assert_eq!({packed.unaligned}, 42); // `{...}` 强制复制字段而不是创建引用。
/// ```
///
/// 然而，直接使用例如 `packed.unaligned` 访问未对齐的字段是安全的 (如上面的 `assert_eq!` 所示)。
///
/// # Examples
///
/// 将 usize 值写入字节缓冲区：
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "86302")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SAFETY: 调用者必须保证 `dst` 对写入有效。
    // `dst` 不能与 `dst` 重叠，因为调用者拥有 `dst` 的权限，而 `src` 是这个函数拥有所有权的。
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // 我们直接调用内部函数以避免在生成的代码中进行函数调用。
        intrinsics::forget(src);
    }
}

/// 对 `src` 的值进行易失性读取，而无需移动它。这将使 `src` 中的内存保持不变。
///
/// 易失性操作旨在作用于 I/O 存储器，并保证编译器不会在其他易失性操作中对易失性操作进行清除或重新排序。
///
/// # Notes
///
/// Rust 当前没有严格和正式定义的内存模型，因此 "volatile" 此处所指的确切语义会随时间而变化。
/// 话虽如此，其语义几乎总是以与 [C11 对 volatile 的定义][c11] 相似的方式结束。
///
/// 编译器不应更改易失性存储器操作的相对顺序或数量。
/// 但是，零大小类型 (例如，如果将零大小类型传递给 `read_volatile`) 上的易失性存储器操作为无操作，可以忽略。
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的：
///
/// * `src` 必须是 [有效的][valid] 才能读取。
///
/// * `src` 必须正确对齐。
///
/// * `src` 必须指向 `T` 类型的正确初始化值。
///
/// 与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`read_volatile` 都会创建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，则同时使用返回值和 `*src` 处的值都可以 [违反内存安全][read-ownership]。
/// 但是，几乎可以肯定地将非 [`Copy`] 类型存储在易失性存储器中。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// 就像在 C 语言中一样，操作是否易失性与涉及从多个线程进行并发访问的问题无关。在这方面，易失性访问的行为与非原子访问完全相同。
///
/// 特别是，`read_volatile` 与任何对同一位置的写操作之间的争夺是未定义的行为。
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    // SAFETY: 调用者必须遵守 `volatile_load` 的安全保证。
    unsafe {
        assert_unsafe_precondition!(is_aligned_and_not_null(src));
        intrinsics::volatile_load(src)
    }
}

/// 使用给定值对存储单元执行易失性写操作，而无需读取或丢弃旧值。
///
/// 易失性操作旨在作用于 I/O 存储器，并保证编译器不会在其他易失性操作中对易失性操作进行清除或重新排序。
///
/// `write_volatile` 不会丢弃 `dst` 的内容。这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。
///
/// 此外，它不会丢弃 `src`。在语义上，`src` 被移到 `dst` 指向的位置。
///
/// # Notes
///
/// Rust 当前没有严格和正式定义的内存模型，因此 "volatile" 此处所指的确切语义会随时间而变化。
/// 话虽如此，其语义几乎总是以与 [C11 对 volatile 的定义][c11] 相似的方式结束。
///
/// 编译器不应更改易失性存储器操作的相对顺序或数量。
/// 但是，零大小类型 (例如，如果将零大小类型传递给 `write_volatile`) 上的易失性存储器操作为无操作，可以忽略。
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的：
///
/// * `dst` 必须是 [有效的][valid] 才能写入。
///
/// * `dst` 必须正确对齐。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
///
/// 就像在 C 语言中一样，操作是否易失性与涉及从多个线程进行并发访问的问题无关。在这方面，易失性访问的行为与非原子访问完全相同。
///
/// 特别是，`write_volatile` 与同一位置上的任何其他操作 (读取或写入) 之间的争夺是未定义的行为。
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    // SAFETY: 调用者必须遵守 `volatile_store` 的安全保证。
    unsafe {
        assert_unsafe_precondition!(is_aligned_and_not_null(dst));
        intrinsics::volatile_store(dst, src);
    }
}

/// 对齐指针 `p`。
///
/// 计算必须应用于指针 `p` 的偏移量 (根据 `stride` 步幅)，以便指针 `p` 与 `a` 对齐。
///
/// Note: 此实现已针对非 panic 进行了精心设计。到 panic 是 UB。
/// 此处唯一可以进行的更改是 `INV_TABLE_MOD_16` 及其关联常量的更改。
///
/// 如果我们决定可以使用不是二次幂的 `a` 来调用内部函数，那么可能更谨慎的做法是只更改为一个简单的实现，而不是尝试调整它以适应这种更改。
///
///
/// 如有任何疑问，请发送至 @nagisa。
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): 直接使用这些内部函数可以显着提高 codegen 在 opt-level <=
    // 1，其中未内联这些操作的方法版本。
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    let addr = p.addr();

    /// 计算 `x` 模 `m` 的乘法模逆。
    ///
    /// 此实现是针对 `align_offset` 量身定制的，并具有以下先决条件：
    ///
    /// * `m` 是二的幂；
    /// * `x < m`; (如果使用 `x ≥ m`，请改为传入 `x % m`)
    ///
    /// 此函数的实现不得为 panic。Ever.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// 乘模逆矩阵模 2⁴=16。
        ///
        /// 注意，该表不包含不存在反值的值 (例如，对于 `0⁻¹ mod 16`，`2⁻¹ mod 16` 等)。
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// `INV_TABLE_MOD_16` 的模数。
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SAFETY: `m` 必须为 2 的幂，因此不能为零。
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // 我们使用以下公式迭代 "up"：
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2 - xy) ≡ 1 (mod 2²ⁿ)  $$
            //
            // 直到 2²ⁿ ≥ m。然后，我们可以通过取结果 `mod m` 减少到所需的 `m`。
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y = y * (2 - xy) mod n
                //
                // 注意，这里我们有意使用包装操作 - 原始公式使用减法 `mod n`。
                // 改用 `mod usize::MAX` 完全可以，因为无论如何我们将结果 `mod n` 放在最后。
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: `a` 为 2 的幂，因此非零。
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case 可以通过 `-p (mod a)` 更简单地计算，但这样做会抑制 LLVM 选择像 `lea` 这样的指令的能力。相反，我们计算
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // 它围绕承重来分配操作，但是对 `and` 进行了充分的模拟，以使 LLVM 能够利用它所了解的各种优化。
        //
        //
        return wrapping_sub(wrapping_add(addr, a_minus_one) & wrapping_sub(0, a), addr);
    }

    let pmoda = addr & a_minus_one;
    if pmoda == 0 {
        // 已经对齐。Yay!
        return 0;
    } else if stride == 0 {
        // 如果指针未对齐，并且元素大小为零，则将没有任何元素可以对齐指针。
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SAFETY: a 是 2 的幂，因此非零。stride == 0 情况已在上面处理。
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAFETY: gcdpow 有一个上限，最多是 usize 中的位数。
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAFETY: gcd 始终大于或等于 1。
    if addr & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // 该分支求解以下线性同余方程：
        //
        // ` p + so = 0 mod a `
        //
        // 这里的 `p` 是指针值，`s`-`T` 的步幅，`T` 中的 `o` 偏移量，以及 `a` - 请求的对齐方式。
        //
        // 使用 `g = gcd(a, s)`，并且上面的条件断言 `p` 也可以被 `g` 整除，我们可以表示 `a' = a/g`，`s' = s/g`，`p' = p/g`，那么它等效于：
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // 第一项是 "the relative alignment of `p` to `a`" (除以 `g`)，第二项是 "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (再次除以 `g`)。
        //
        // 如果 `a` 和 `s` 不是互质的，则 `g` 的除法对于使逆结构良好是必要的。
        //
        // 此外，此解决方案产生的结果不是 "minimal"，因此必须获得结果 `o mod lcm(s, a)`。我们可以只用 `a'` 代替 `lcm(s, a)`。
        //
        //
        //
        //
        //

        // SAFETY: `gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SAFETY: `a2` 不为零。
        // 将 `a` 移位 `gcdpow` 不能移出 `a` 中的任何设置位 (其中只有一位)。
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SAFETY: `gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAFETY: `gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。
        // 此外，减法不会溢出，因为 `a2 = a >> gcdpow` 将始终严格大于 `(p % a) >> gcdpow`。
        //
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAFETY: 如上所述，`a2` 是 2 的幂。
        // `s2` 严格小于 `a2`，因为 `(s % a) >> gcdpow` 严格小于 `a >> gcdpow`。
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // 根本无法对齐。
    usize::MAX
}

/// 比较裸指针是否相等。
///
/// 这与使用 `==` 运算符相同，但泛型较少：
/// 参数必须是 `*const T` 裸指针，而不是任何实现 `PartialEq` 的东西。
///
/// 这可用于按地址比较 `&T` 引用 (隐式强制为 `*const T`)，而不是比较它们指向的值 (`PartialEq for &T` 实现的作用)。
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// 切片还通过它们的长度 (胖指针) 进行比较：
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// 还可以通过 traits 的实现进行比较：
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // 指针具有相等的地址。
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // 对象具有相等的地址，但是 `Trait` 具有不同的实现。
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // 将引用转换为 `*const u8` 时，将按地址进行比较。
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// 散列一个裸指针。
///
/// 这可用于通过其地址而不是其指向的值 (`Hash for &T` 实现的作用) 对 `&T` 引用 (隐式强制为 `*const T`) 进行哈希处理。
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// FIXME(strict_provenance_magic): 函数指针有错误的代码生成，这需要强制转换为 usize 才能让后端做正确的事情。
//
// 现在我将打破 AVR，以使 *10 亿* lints 安静下来。
// 我们可能应该有一个合适的 "不透明函数指针类型" 来处理这种事情。

// 函数指针的 Impls
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::pointer_fmt_inner(*self as usize, f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::pointer_fmt_inner(*self as usize, f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // 没有参数为 0 的可变参数函数
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// 创建一个 `const` 裸指针到一个位置，而无需创建中间引用。
///
/// 仅当指针正确对齐并指向初始化数据时，才允许使用 `&`/`&mut` 创建引用。
/// 对于那些不满足要求的情况，应改用裸指针。
/// 但是，`&expr as *const _` 在将其强制转换为裸指针之前会创建一个引用，并且该引用与所有其他引用都遵循相同的规则。
///
/// 该宏可以创建一个裸指针，而无需先创建一个引用。
///
/// 但是请注意，`addr_of!(expr)` 中的 `expr` 仍受所有常规规则的约束。
/// 特别是，`addr_of!(*ptr::null())` 是未定义行为，因为它解引用空指针。
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` 会创建一个未对齐的引用，因此是未定义的行为！
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
/// 有关如何创建指向未初始化数据的指针，请参见 [`addr_of_mut`]。
/// 用 `addr_of` 这样做没有多大意义，因为人们只能读取数据，这将是未定义行为。
///
///
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// 创建一个 `mut` 裸指针到一个位置，而无需创建中间引用。
///
/// 仅当指针正确对齐并指向初始化数据时，才允许使用 `&`/`&mut` 创建引用。
/// 对于那些不满足要求的情况，应改用裸指针。
/// 但是，`&mut expr as *mut _` 在将其强制转换为裸指针之前会创建一个引用，并且该引用与所有其他引用都遵循相同的规则。
///
/// 该宏可以创建一个裸指针，而无需先创建一个引用。
///
/// 但请注意，`addr_of_mut!(expr)` 中的 `expr` 仍受所有常规规则的约束。
/// 特别是，`addr_of_mut!(*ptr::null_mut())` 是未定义行为，因为它解引用空指针。
///
/// # Examples
///
/// **创建指向未对齐数据的指针：**
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` 会创建一个未对齐的引用，因此是未定义的行为！
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` 强制复制字段而不是创建引用。
/// ```
///
/// **创建指向未初始化数据的指针：**
///
/// ```rust
/// use std::{ptr, mem::MaybeUninit};
///
/// struct Demo {
///     field: bool,
/// }
///
/// let mut uninit = MaybeUninit::<Demo>::uninit();
/// // `&uninit.as_mut().field` 会创建一个对未初始化的 `bool` 的引用，因此是未定义的行为！
/////
/// let f1_ptr = unsafe { ptr::addr_of_mut!((*uninit.as_mut_ptr()).field) };
/// unsafe { f1_ptr.write(true); }
/// let init = unsafe { uninit.assume_init() };
/// ```
///
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}
