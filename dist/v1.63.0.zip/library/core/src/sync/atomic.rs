//! 原子类型
//!
//! 原子类型提供线程之间的原始共享内存通信，并且是其他并发类型的构建块。
//!
//! Rust atomics 目前遵循与 [C++20 atomics][cpp] 相同的规则，特别是 `atomic_ref`。
//! 基本上，为 Rust 原子类型之一创建一个共享引用对应于在 C++ 中创建一个 `atomic_ref`; `atomic_ref` 是在视频生命周期结束时共享的。
//! (一个 Rust 原子类型，它是独占的或在一个惰性引用之后*不*对应于 C++ 中的 "atomic object"，因为它可以通过非原子操作访问。)
//!
//! 该模块定义了一些原始类型的原子版本，包括 [`AtomicBool`]，[`AtomicIsize`]，[`AtomicUsize`]，[`AtomicI8`]，[`AtomicU16`] 等。
//! 原子类型表示可正确使用的操作，这些操作可在线程之间同步更新。
//!
//! 每种方法都使用一个 [`Ordering`] 来表示该操作的内存屏障的强度。这些顺序与 [C++20 原子排序][1] 相同。有关更多信息，请参见 [nomicon][2]。
//!
//! [cpp]: https://en.cppreference.com/w/cpp/atomic
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! 原子变量可以安全地在线程之间共享 (它们实现 [`Sync`])，但是它们本身并不提供共享机制并遵循 Rust 的 [线程模型](../../../std/thread/index.html#the-threading-model)。
//!
//! 共享原子变量的最常见方法是将其放入 [`Arc`][arc] (原子引用计数的共享指针)。
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! 原子类型可以存储在静态变量中，可以使用常量初始化程序 (如 [`AtomicBool::new`]) 进行初始化。原子静态常用于懒惰的初始化。
//!
//! # Portability
//!
//! 如果可用，则保证该模块中的所有原子类型均为 [无锁][lock-free]。这意味着他们没有在内部获得一个整体互斥锁。不能保证原子类型和操作无需等待。
//! 这意味着可以使用比较和交换循环来实现类似 `fetch_or` 的操作。
//!
//! 原子操作可以在指令层用更大的原子来实现。例如，某些平台使用 4 字节原子指令来实现 `AtomicI8`。
//! 请注意，此仿真不应影响代码的正确性，这只是需要注意的事情。
//!
//! 此模块中的原子类型可能并非在所有平台上都可用。但是，这里的原子类型都是广泛可用的，并且通常可以依赖现有原子类型。一些值得注意的例外是：
//!
//! * 具有 32 位指针的 PowerPC 和 MIPS 平台没有 `AtomicU64` 或 `AtomicI64` 类型。
//! * 不支持 Linux 的 `armv5te` 等 ARM 平台只提供 `load` 和 `store` 操作，不支持 Compare 和 Swap (CAS) 操作，如 `swap`、`fetch_add` 等。
//! 此外，在 Linux 上，这些 CAS 操作是通过 [操作系统支持][operating system support] 实现的，这可能会降低性能。
//! * 带有 `thumbv6m` 的 ARM 目标仅提供 `load` 和 `store` 操作，不支持 (CAS) 比较和交换操作，如 `swap`、`fetch_add` 等。
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! 请注意，可能会添加 future 平台，这些平台也不支持某些原子操作。最大程度地讲，可移植代码将要注意所使用的原子类型。
//! `AtomicUsize` 和 `AtomicIsize` 通常是最便携的，但即便如此，它们也并非随处可用。
//! 作为参考，`std` 库需要 `AtomicBool`s 和 pointer-sized atomics，尽管 `core` 不需要。
//!
//! `#[cfg(target_has_atomic)]` 属性可用于根据目标支持的位宽进行有条件的编译。
//! 它是为每个支持的大小设置的键值选项，其值 "8"、"16"、"32"、"64"、"128" 和 "ptr" 用于指针大小的原子。
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! 一个简单的自旋锁：
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::{hint, thread};
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // 等待另一个线程释放锁
//!     while spinlock.load(Ordering::SeqCst) != 0 {
//!         hint::spin_loop();
//!     }
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {panic:?}");
//!     }
//! }
//! ```
//!
//! 保持活动线程的数量：
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]
#![rustc_diagnostic_item = "atomic_mod"]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// 可以在线程之间安全共享的布尔类型。
///
/// 此类型与 [`bool`] 具有相同的内存表示形式。
///
/// **Note**: 此类型仅在支持 `u8` 的原子加载和存储的平台上可用。
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "AtomicBool"]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_default_impls", issue = "87864")]
impl const Default for AtomicBool {
    /// 创建一个初始化为 `false` 的 `AtomicBool`。
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send 是为 AtomicBool 隐式实现的。
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// 可以在线程之间安全共享的裸指针类型。
///
/// 此类型与 `*mut T` 具有相同的内存表示形式。
///
/// **Note**: 此类型仅在支持原子加载和指针存储的平台上可用。
/// 它的大小取决于目标指针的大小。
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "AtomicPtr")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_default_impls", issue = "87864")]
impl<T> const Default for AtomicPtr<T> {
    /// 创建一个空 `AtomicPtr<T>`。
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// 原子内存排序
///
/// 内存排序指定了原子操作同步内存的方式。
/// 在最弱的 [`Ordering::Relaxed`] 中，仅同步操作直接触摸的内存。
/// 另一方面，[`Ordering::SeqCst`] 操作的存储 - 加载对同步了其他内存，同时还保留了所有线程中此类操作的总顺序。
///
///
/// Rust 的内存排序和 [C++ 20 相同](https://en.cppreference.com/w/cpp/atomic/memory_order)。
///
/// 有关更多信息，请参见 [nomicon]。
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
#[rustc_diagnostic_item = "Ordering"]
pub enum Ordering {
    /// 没有排序约束，只有原子操作。
    ///
    /// 对应于 C++ 20 中的 [`memory_order_relaxed`]。
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// 当与存储耦合时，所有先前的操作都将在使用 [`Acquire`] (或更高级) 排序加载此值之前进行排序。
    ///
    /// 特别是，所有以前的写入操作对执行此值 [`Acquire`] (或更强) 的所有线程均可见。
    ///
    /// 请注意，对组合加载和存储的操作使用此顺序将导致 [`Relaxed`] 加载操作！
    ///
    /// 此排序仅适用于可以执行存储的操作。
    ///
    /// 对应于 C++ 20 中的 [`memory_order_release`]。
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// 与加载耦合时，如果加载的值是由具有 [`Release`] (或更高级) 排序的存储操作写入的，则所有后续操作在该存储之后都将被排序。
    /// 特别是，所有后续加载将看到在存储之前写入的数据。
    ///
    /// 请注意，对组合加载和存储的操作使用此顺序将导致 [`Relaxed`] 存储操作！
    ///
    /// 此排序仅适用于可以执行加载的操作。
    ///
    /// 对应于 C++ 20 中的 [`memory_order_acquire`]。
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// 同时具有 [`Acquire`] 和 [`Release`] 的效果：
    /// 对于负载，它使用 [`Acquire`] 排序。对于商店，它使用 [`Release`] 排序。
    ///
    /// 请注意，在 `compare_and_swap` 的情况下，该操作可能最终不执行任何存储而因此仅具有 [`Acquire`] 排序。
    ///
    /// 但是，`AcqRel` 将永远不会执行 [`Relaxed`] 访问。
    ///
    /// 此排序仅适用于将加载和存储结合在一起的操作。
    ///
    /// 对应于 C++ 20 中的 [`memory_order_acq_rel`]。
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// 像 [`Acquire`]/[`Release`]/[`AcqRel`] (分别用于加载，存储和随存储加载操作) 一样，另外保证所有线程都可以按相同的顺序看到所有顺序一致的操作。
    ///
    ///
    /// 对应于 C++ 20 中的 [`memory_order_seq_cst`]。
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] 初始化为 `false`。
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(
    since = "1.34.0",
    note = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// 创建一个新的 `AtomicBool`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.24.0")]
    #[must_use]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// 返回底层 [`bool`] 的可变引用。
    ///
    /// 这是安全的，因为可变引用保证没有其他线程同时访问原子数据。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SAFETY: 可变引用保证唯一的所有权。
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// 获得对 `&mut bool` 的原子访问。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &mut Self {
        // SAFETY: 可变引用保证唯一的所有权，并且 `bool` 和 `Self` 的对齐方式均为 1。
        //
        unsafe { &mut *(v as *mut bool as *mut Self) }
    }

    /// 获得对 `&mut [AtomicBool]` 切片的非原子访问。
    ///
    /// 这是安全的，因为可变引用保证没有其他线程同时访问原子数据。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut, inline_const)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bools = [const { AtomicBool::new(false) }; 10];
    ///
    /// let view: &mut [bool] = AtomicBool::get_mut_slice(&mut some_bools);
    /// assert_eq!(view, [false; 10]);
    /// view[..5].copy_from_slice(&[true; 5]);
    ///
    /// std::thread::scope(|s| {
    ///     for t in &some_bools[..5] {
    ///         s.spawn(move || assert_eq!(t.load(Ordering::Relaxed), true));
    ///     }
    ///
    ///     for f in &some_bools[5..] {
    ///         s.spawn(move || assert_eq!(f.load(Ordering::Relaxed), false));
    ///     }
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn get_mut_slice(this: &mut [Self]) -> &mut [bool] {
        // SAFETY: 可变引用保证唯一的所有权。
        unsafe { &mut *(this as *mut [Self] as *mut [bool]) }
    }

    /// 获得对 `&mut [bool]` 切片的原子访问。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bools = [false; 10];
    /// let a = &*AtomicBool::from_mut_slice(&mut some_bools);
    /// std::thread::scope(|s| {
    ///     for i in 0..a.len() {
    ///         s.spawn(move || a[i].store(true, Ordering::Relaxed));
    ///     }
    /// });
    /// assert_eq!(some_bools, [true; 10]);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut_slice(v: &mut [bool]) -> &mut [Self] {
        // SAFETY: 可变引用保证唯一的所有权，并且 `bool` 和 `Self` 的对齐方式均为 1。
        //
        unsafe { &mut *(v as *mut [bool] as *mut [Self]) }
    }

    /// 消耗原子并返回包含的值。
    ///
    /// 这是安全的，因为按值传递 `self` 可以确保没有其他线程同时访问原子数据。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// 从 bool 加载一个值。
    ///
    /// `load` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。
    /// 可能的值为 [`SeqCst`]，[`Acquire`] 和 [`Relaxed`]。
    ///
    /// # Panics
    ///
    /// 如果 `order` 是 [`Release`] 或 [`AcqRel`]，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SAFETY: 原子内部函数可以防止任何数据竞争，并且传入的裸指针是有效的，因为我们是从引用中获得的。
        //
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// 将值存储到 bool 中。
    ///
    /// `store` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。
    /// 可能的值为 [`SeqCst`]，[`Release`] 和 [`Relaxed`]。
    ///
    /// # Panics
    ///
    /// 如果 `order` 是 [`Acquire`] 或 [`AcqRel`]，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SAFETY: 原子内部函数可以防止任何数据竞争，并且传入的裸指针是有效的，因为我们是从引用中获得的。
        //
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// 将值存储到 bool 中，返回前一个值。
    ///
    /// `swap` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
    /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法仅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: 原子内部函数可以防止数据竞争。
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// 如果当前值与 `current` 值相同，则将值存储到 [`bool`] 中。
    ///
    /// 返回值始终是前一个值。如果等于 `current`，则该值已更新。
    ///
    /// `compare_and_swap` 还带有一个 [`Ordering`] 参数，它描述了此操作的内存顺序。
    /// 请注意，即使使用 [`AcqRel`]，该操作也可能失败，因此仅执行 `Acquire` 加载，但没有 `Release` 语义。
    /// 如果发生此操作，则使用 [`Acquire`] 使其成为该操作 [`Relaxed`] 的存储部分，而使用 [`Release`] 使该操作成为存储部分 [`Relaxed`]。
    ///
    /// **Note:** 此方法仅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # 迁移到 `compare_exchange` 和 `compare_exchange_weak`
    ///
    /// `compare_and_swap` 等效于 `compare_exchange`，具有以下内存排序映射：
    ///
    /// Original | Success | Failure
    /// -------- | ------- | -------
    /// Relaxed  | Relaxed | Relaxed Acquire  | Acquire | Acquire Release  | Release | Relaxed AcqRel   | AcqRel  | Acquire SeqCst   | SeqCst  | SeqCst
    ///
    /// 即使比较成功，`compare_exchange_weak` 也允许虚假失败，这允许编译器在循环中使用比较和交换时生成更好的汇编代码。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[deprecated(
        since = "1.50.0",
        note = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// 如果当前值与 `current` 值相同，则将值存储到 [`bool`] 中。
    ///
    /// 返回值是指示是否写入了新值并包含先前值的结果。
    /// 成功后，此值保证等于 `current`。
    ///
    /// `compare_exchange` 需要两个 [`Ordering`] 参数来描述这个操作的内存顺序。
    /// `success` 描述了在与 `current` 的比较成功时发生的读取 - 修改 - 写入操作所需的顺序。
    /// `failure` 描述了比较失败时发生的加载操作所需的排序。
    /// 使用 [`Acquire`] 作为成功排序，使存储成为操作 [`Relaxed`] 的一部分，而使用 [`Release`]，则使装载成功 [`Relaxed`]。
    ///
    /// 失败排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，并且必须等于或弱于成功排序。
    ///
    /// **Note:** 此方法仅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SAFETY: 原子内部函数可以防止数据竞争。
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// 如果当前值与 `current` 值相同，则将值存储到 [`bool`] 中。
    ///
    /// 与 [`AtomicBool::compare_exchange`] 不同，即使比较成功，也允许该函数错误地失败，这可能导致某些平台上的代码效率更高。
    ///
    /// 返回值是指示是否写入了新值并包含先前值的结果。
    ///
    /// `compare_exchange_weak` 需要两个 [`Ordering`] 参数来描述这个操作的内存顺序。
    /// `success` 描述了在与 `current` 的比较成功时发生的读取 - 修改 - 写入操作所需的顺序。
    /// `failure` 描述了比较失败时发生的加载操作所需的排序。
    /// 使用 [`Acquire`] 作为成功排序，使存储成为操作 [`Relaxed`] 的一部分，而使用 [`Release`]，则使装载成功 [`Relaxed`]。
    /// 失败排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，并且必须等于或弱于成功排序。
    ///
    /// **Note:** 此方法仅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SAFETY: 原子内部函数可以防止数据竞争。
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// 具有布尔值的逻辑 "and"。
    ///
    /// 对当前值和参数 `val` 执行逻辑 "and" 运算，并将新值设置为结果。
    ///
    /// 返回前一个值。
    ///
    /// `fetch_and` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
    /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法仅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: 原子内部函数可以防止数据竞争。
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// 具有布尔值的逻辑 "nand"。
    ///
    /// 对当前值和参数 `val` 执行逻辑 "nand" 运算，并将新值设置为结果。
    ///
    /// 返回前一个值。
    ///
    /// `fetch_nand` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
    /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法仅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // 我们在这里不能使用 atomic_nand，因为它可能导致 bool 的值无效。
        // 发生这种情况的原因是，原子操作内部使用 8 位整数完成，这将设置高 7 位。
        //
        // 因此，我们只使用 fetch_xor 或 swap 即可。
        if val {
            // !(x & true) == !x 我们必须反转 bool。
            //
            self.fetch_xor(true, order)
        } else {
            // !(x & false) == true 我们必须将 bool 设置为 true。
            //
            self.swap(true, order)
        }
    }

    /// 具有布尔值的逻辑 "or"。
    ///
    /// 对当前值和参数 `val` 执行逻辑 "or" 运算，并将新值设置为结果。
    ///
    /// 返回前一个值。
    ///
    /// `fetch_or` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
    /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法仅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: 原子内部函数可以防止数据竞争。
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// 具有布尔值的逻辑 "xor"。
    ///
    /// 对当前值和参数 `val` 执行逻辑 "xor" 运算，并将新值设置为结果。
    ///
    /// 返回前一个值。
    ///
    /// `fetch_xor` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
    /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法仅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SAFETY: 原子内部函数可以防止数据竞争。
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// 返回指向底层 [`bool`] 的可变指针。
    ///
    /// 在结果整数上进行非原子读取和写入可以是数据竞争。
    /// 此方法对 FFI 最为有用，在 FFI 中，函数签名可以使用 `*mut bool` 而不是 `&AtomicBool`。
    ///
    /// 从共享引用返回 `*mut` 指针到此原子是安全的，因为原子类型可与内部可变性一起使用。
    /// 原子的所有修改都通过共享的 quot 更改值，并且只要它们使用原子操作就可以安全地进行更改。
    /// 对返回的裸指针的任何使用都需要一个 `unsafe` 块，并且仍然必须遵守相同的限制：对其进行的操作必须是原子的。
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// 获取该值，并对其应用一个函数，该函数返回一个可选的新值。如果函数返回 `Some(_)`，则返回 `Ok(previous_value)` 的 `Result`，否则返回 `Err(previous_value)`。
    ///
    /// Note: 如果与此同时从其他线程更改了值，则只要函数返回 `Some(_)`，这可能会多次调用该函数，但是该函数仅对存储的值应用一次。
    ///
    ///
    /// `fetch_update` 需要两个 [`Ordering`] 参数来描述这个操作的内存顺序。
    /// 第一个描述了操作最终成功时所需的顺序，第二个描述了负载所需的顺序。
    /// 这些分别对应于 [`AtomicBool::compare_exchange`] 的成功和失败顺序。
    ///
    /// 使用 [`Acquire`] 作为成功排序，使存储成为该操作 [`Relaxed`] 的一部分，而使用 [`Release`]，则使最终成功加载 [`Relaxed`]。
    /// (failed) 负载排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，并且必须等于或小于成功排序。
    ///
    /// **Note:** 此方法仅在支持 `u8` 上原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "atomic_fetch_update", since = "1.53.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// 创建一个新的 `AtomicPtr`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.24.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// 返回底层指针的可变引用。
    ///
    /// 这是安全的，因为可变引用保证没有其他线程同时访问原子数据。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut data = 10;
    /// let mut atomic_ptr = AtomicPtr::new(&mut data);
    /// let mut other_data = 5;
    /// *atomic_ptr.get_mut() = &mut other_data;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// 获得对指针的原子访问。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut data = 123;
    /// let mut some_ptr = &mut data as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// let mut other_data = 456;
    /// a.store(&mut other_data, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &mut Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - 可变引用保证唯一的所有权。
        //  - 如上所述，在 rust 支持的所有平台上，`*mut T` 和 `Self` 的对齐方式均相同。
        //
        unsafe { &mut *(v as *mut *mut T as *mut Self) }
    }

    /// 获得对 `&mut [AtomicPtr]` 切片的非原子访问。
    ///
    /// 这是安全的，因为可变引用保证没有其他线程同时访问原子数据。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut, inline_const)]
    /// use std::ptr::null_mut;
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptrs = [const { AtomicPtr::new(null_mut::<String>()) }; 10];
    ///
    /// let view: &mut [*mut String] = AtomicPtr::get_mut_slice(&mut some_ptrs);
    /// assert_eq!(view, [null_mut::<String>(); 10]);
    /// view
    ///     .iter_mut()
    ///     .enumerate()
    ///     .for_each(|(i, ptr)| *ptr = Box::into_raw(Box::new(format!("iteration#{i}"))));
    ///
    /// std::thread::scope(|s| {
    ///     for ptr in &some_ptrs {
    ///         s.spawn(move || {
    ///             let ptr = ptr.load(Ordering::Relaxed);
    ///             assert!(!ptr.is_null());
    ///
    ///             let name = unsafe { Box::from_raw(ptr) };
    ///             println!("Hello, {name}!");
    ///         });
    ///     }
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn get_mut_slice(this: &mut [Self]) -> &mut [*mut T] {
        // SAFETY: 可变引用保证唯一的所有权。
        unsafe { &mut *(this as *mut [Self] as *mut [*mut T]) }
    }

    /// 获得对指针切片的原子访问。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::ptr::null_mut;
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptrs = [null_mut::<String>(); 10];
    /// let a = &*AtomicPtr::from_mut_slice(&mut some_ptrs);
    /// std::thread::scope(|s| {
    ///     for i in 0..a.len() {
    ///         s.spawn(move || {
    ///             let name = Box::new(format!("thread{i}"));
    ///             a[i].store(Box::into_raw(name), Ordering::Relaxed);
    ///         });
    ///     }
    /// });
    /// for p in some_ptrs {
    ///     assert!(!p.is_null());
    ///     let name = unsafe { Box::from_raw(p) };
    ///     println!("Hello, {name}!");
    /// }
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut_slice(v: &mut [*mut T]) -> &mut [Self] {
        // SAFETY:
        //  - 可变引用保证唯一的所有权。
        //  - 如上所述，在 rust 支持的所有平台上，`*mut T` 和 `Self` 的对齐方式均相同。
        //
        unsafe { &mut *(v as *mut [*mut T] as *mut [Self]) }
    }

    /// 消耗原子并返回包含的值。
    ///
    /// 这是安全的，因为按值传递 `self` 可以确保没有其他线程同时访问原子数据。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let mut data = 5;
    /// let atomic_ptr = AtomicPtr::new(&mut data);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// 从指针加载一个值。
    ///
    /// `load` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。
    /// 可能的值为 [`SeqCst`]，[`Acquire`] 和 [`Relaxed`]。
    ///
    /// # Panics
    ///
    /// 如果 `order` 是 [`Release`] 或 [`AcqRel`]，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SAFETY: 原子内部函数可以防止数据竞争。
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// 将值存储到指针中。
    ///
    /// `store` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。
    /// 可能的值为 [`SeqCst`]，[`Release`] 和 [`Relaxed`]。
    ///
    /// # Panics
    ///
    /// 如果 `order` 是 [`Acquire`] 或 [`AcqRel`]，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SAFETY: 原子内部函数可以防止数据竞争。
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// 将一个值存储到指针中，返回前一个值。
    ///
    /// `swap` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
    /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
    ///
    ///
    /// **Note:** 此方法仅在支持对指针进行原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SAFETY: 原子内部函数可以防止数据竞争。
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// 如果当前值与 `current` 值相同，则将一个值存储到指针中。
    ///
    /// 返回值始终是前一个值。如果等于 `current`，则该值已更新。
    ///
    /// `compare_and_swap` 还带有一个 [`Ordering`] 参数，它描述了此操作的内存顺序。
    /// 请注意，即使使用 [`AcqRel`]，该操作也可能失败，因此仅执行 `Acquire` 加载，但没有 `Release` 语义。
    /// 如果发生此操作，则使用 [`Acquire`] 使其成为该操作 [`Relaxed`] 的存储部分，而使用 [`Release`] 使该操作成为存储部分 [`Relaxed`]。
    ///
    /// **Note:** 此方法仅在支持对指针进行原子操作的平台上可用。
    ///
    /// # 迁移到 `compare_exchange` 和 `compare_exchange_weak`
    ///
    /// `compare_and_swap` 等效于 `compare_exchange`，具有以下内存排序映射：
    ///
    /// Original | Success | Failure
    /// -------- | ------- | -------
    /// Relaxed  | Relaxed | Relaxed Acquire  | Acquire | Acquire Release  | Release | Relaxed AcqRel   | AcqRel  | Acquire SeqCst   | SeqCst  | SeqCst
    ///
    /// 即使比较成功，`compare_exchange_weak` 也允许虚假失败，这允许编译器在循环中使用比较和交换时生成更好的汇编代码。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[deprecated(
        since = "1.50.0",
        note = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// 如果当前值与 `current` 值相同，则将一个值存储到指针中。
    ///
    /// 返回值是指示是否写入了新值并包含先前值的结果。
    /// 成功后，此值保证等于 `current`。
    ///
    /// `compare_exchange` 需要两个 [`Ordering`] 参数来描述这个操作的内存顺序。
    /// `success` 描述了在与 `current` 的比较成功时发生的读取 - 修改 - 写入操作所需的顺序。
    /// `failure` 描述了比较失败时发生的加载操作所需的排序。
    /// 使用 [`Acquire`] 作为成功排序，使存储成为操作 [`Relaxed`] 的一部分，而使用 [`Release`]，则使装载成功 [`Relaxed`]。
    ///
    /// 失败排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，并且必须等于或弱于成功排序。
    ///
    /// **Note:** 此方法仅在支持对指针进行原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SAFETY: 原子内部函数可以防止数据竞争。
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// 如果当前值与 `current` 值相同，则将一个值存储到指针中。
    ///
    /// 与 [`AtomicPtr::compare_exchange`] 不同，即使比较成功，也允许该函数错误地失败，这可能导致某些平台上的代码效率更高。
    ///
    /// 返回值是指示是否写入了新值并包含先前值的结果。
    ///
    /// `compare_exchange_weak` 需要两个 [`Ordering`] 参数来描述这个操作的内存顺序。
    /// `success` 描述了在与 `current` 的比较成功时发生的读取 - 修改 - 写入操作所需的顺序。
    /// `failure` 描述了比较失败时发生的加载操作所需的排序。
    /// 使用 [`Acquire`] 作为成功排序，使存储成为操作 [`Relaxed`] 的一部分，而使用 [`Release`]，则使装载成功 [`Relaxed`]。
    /// 失败排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，并且必须等于或弱于成功排序。
    ///
    /// **Note:** 此方法仅在支持对指针进行原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SAFETY: 这个内部函数是不安全的，因为它在裸指针上操作，但是我们可以肯定该指针是有效的 (我们只是从引用中获得了 `UnsafeCell` 来获取它)，而原子操作本身允许我们安全地对 `UnsafeCell` 的内容进行可变。
        //
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// 获取该值，并对其应用一个函数，该函数返回一个可选的新值。如果函数返回 `Some(_)`，则返回 `Ok(previous_value)` 的 `Result`，否则返回 `Err(previous_value)`。
    ///
    /// Note: 如果与此同时从其他线程更改了值，则只要函数返回 `Some(_)`，这可能会多次调用该函数，但是该函数仅对存储的值应用一次。
    ///
    ///
    /// `fetch_update` 需要两个 [`Ordering`] 参数来描述这个操作的内存顺序。
    /// 第一个描述了操作最终成功时所需的顺序，第二个描述了负载所需的顺序。
    /// 这些分别对应于 [`AtomicPtr::compare_exchange`] 的成功和失败顺序。
    ///
    /// 使用 [`Acquire`] 作为成功排序，使存储成为该操作 [`Relaxed`] 的一部分，而使用 [`Release`]，则使最终成功加载 [`Relaxed`]。
    /// (failed) 负载排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，并且必须等于或小于成功排序。
    ///
    /// **Note:** 此方法仅在支持对指针进行原子操作的平台上可用。
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "atomic_fetch_update", since = "1.53.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl const From<bool> for AtomicBool {
    /// 将 `bool` 转换为 `AtomicBool`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{atomic_bool:?}"), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
#[rustc_const_unstable(feature = "const_convert", issue = "88674")]
impl<T> const From<*mut T> for AtomicPtr<T> {
    /// 将 `*mut T` 转换为 `AtomicPtr<T>`。
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // 该宏最终在某些体系结构上未使用。
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $diagnostic_item:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// 可以在线程之间安全共享的整数类型。
        ///
        /// 此类型与基本整数类型 [` 具有相同的内存表示形式
        ///
        #[doc = $s_int_type]
        /// `].
        /// 有关原子类型和非原子类型之间的区别以及有关此类型的可移植性的更多信息，请参见 [模块级文档][module-level documentation]。
        ///
        ///
        /// **Note:** 此类型仅在支持原子负载和 [` 的存储的平台上可用
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[$diagnostic_item]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// 初始化为 `0` 的原子整数。
        #[$stable_init_const]
        #[deprecated(
            since = "1.34.0",
            note = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        #[rustc_const_unstable(feature = "const_default_impls", issue = "87864")]
        impl const Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        #[rustc_const_unstable(feature = "const_num_from_num", issue = "87852")]
        impl const From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::Relaxed), f)
            }
        }

        // 发送是隐式实现的。
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// 创建一个新的原子整数。
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            ///
            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            #[must_use]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// 返回底层整数的可变引用。
            ///
            /// 这是安全的，因为可变引用保证没有其他线程同时访问原子数据。
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() = 5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]
            ///
            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            ///
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            /// let mut some_int = 123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            /// assert_eq!(some_int, 100);
            /// ```
            ///
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &mut Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - 可变引用保证唯一的所有权。
                //  - `$int_type` 和 `Self` 的对齐方式相同，如 $cfg_align 所承诺并已在上面进行了验证。
                //
                unsafe { &mut *(v as *mut $int_type as *mut Self) }
            }

            #[doc = concat!("Get non-atomic access to a `&mut [", stringify!($atomic_type), "]` slice")]
            /// 这是安全的，因为可变引用保证没有其他线程同时访问原子数据。
            ///
            ///
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut, inline_const)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let mut some_ints = [const { ", stringify!($atomic_type), "::new(0) }; 10];")]
            ///
            #[doc = concat!("let view: &mut [", stringify!($int_type), "] = ", stringify!($atomic_type), "::get_mut_slice(&mut some_ints);")]
            /// assert_eq!(view, [0; 10]);
            /// view
            ///     .iter_mut()
            ///     .enumerate()
            ///     .for_each(|(idx, int)| *int = idx as _);
            ///
            /// std::thread::scope(|s| {
            ///     some_ints
            ///         .iter()
            ///         .enumerate()
            ///         .for_each(|(idx, int)| {
            ///             s.spawn(move || assert_eq!(int.load(Ordering::Relaxed), idx as _));
            ///         })
            /// });
            /// ```
            ///
            #[inline]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn get_mut_slice(this: &mut [Self]) -> &mut [$int_type] {
                // SAFETY: 可变引用保证唯一的所有权。
                unsafe { &mut *(this as *mut [Self] as *mut [$int_type]) }
            }

            #[doc = concat!("Get atomic access to a `&mut [", stringify!($int_type), "]` slice.")]
            ///
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            /// let mut some_ints = [0; 10];
            #[doc = concat!("let a = &*", stringify!($atomic_type), "::from_mut_slice(&mut some_ints);")]
            /// std::thread::scope(|s| {
            ///     for i in 0..a.len() {
            ///         s.spawn(move || a[i].store(i as _, Ordering::Relaxed));
            ///     }
            /// });
            /// for (i, n) in some_ints.into_iter().enumerate() {
            ///     assert_eq!(i, n as usize);
            /// }
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut_slice(v: &mut [$int_type]) -> &mut [Self] {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - 可变引用保证唯一的所有权。
                //  - `$int_type` 和 `Self` 的对齐方式相同，如 $cfg_align 所承诺并已在上面进行了验证。
                //
                unsafe { &mut *(v as *mut [$int_type] as *mut [Self]) }
            }

            /// 消耗原子并返回包含的值。
            ///
            /// 这是安全的，因为按值传递 `self` 可以确保没有其他线程同时访问原子数据。
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            ///
            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// 从原子整数加载值。
            ///
            /// `load` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。
            /// 可能的值为 [`SeqCst`]，[`Acquire`] 和 [`Relaxed`]。
            ///
            /// # Panics
            ///
            /// 如果 `order` 是 [`Release`] 或 [`AcqRel`]，就会出现 panics。
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            ///
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// 将值存储到原子整数中。
            ///
            /// `store` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。
            ///  可能的值为 [`SeqCst`]，[`Release`] 和 [`Relaxed`]。
            ///
            /// # Panics
            ///
            /// 如果 `order` 是 [`Acquire`] 或 [`AcqRel`]，就会出现 panics。
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            ///
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// 将值存储到原子整数中，返回前一个值。
            ///
            /// `swap` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
            /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
            ///
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            ///
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// 如果当前值与 `current` 值相同，则将值存储到原子整数中。
            ///
            /// 返回值始终是前一个值。如果等于 `current`，则该值已更新。
            ///
            /// `compare_and_swap` 还带有一个 [`Ordering`] 参数，它描述了此操作的内存顺序。
            /// 请注意，即使使用 [`AcqRel`]，该操作也可能失败，因此仅执行 `Acquire` 加载，但没有 `Release` 语义。
            ///
            /// 如果发生此操作，则使用 [`Acquire`] 使其成为该操作 [`Relaxed`] 的存储部分，而使用 [`Release`] 使该操作成为存储部分 [`Relaxed`]。
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # 迁移到 `compare_exchange` 和 `compare_exchange_weak`
            ///
            /// `compare_and_swap` 等效于 `compare_exchange`，具有以下内存排序映射：
            ///
            /// Original | Success | Failure
            /// -------- | ------- | -------
            /// Relaxed  | Relaxed | Relaxed Acquire  | Acquire | Acquire Release  | Release | Relaxed AcqRel   | AcqRel  | Acquire SeqCst   | SeqCst  | SeqCst
            ///
            /// 即使比较成功，`compare_exchange_weak` 也允许虚假失败，这允许编译器在循环中使用比较和交换时生成更好的汇编代码。
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            ///
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable]
            #[deprecated(
                since = "1.50.0",
                note = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// 如果当前值与 `current` 值相同，则将值存储到原子整数中。
            ///
            /// 返回值是指示是否写入了新值并包含先前值的结果。
            /// 成功后，此值保证等于 `current`。
            ///
            /// `compare_exchange` 需要两个 [`Ordering`] 参数来描述这个操作的内存顺序。
            /// `success` 描述了在与 `current` 的比较成功时发生的读取 - 修改 - 写入操作所需的顺序。
            /// `failure` 描述了比较失败时发生的加载操作所需的排序。
            /// 使用 [`Acquire`] 作为成功排序，使存储成为操作 [`Relaxed`] 的一部分，而使用 [`Release`]，则使装载成功 [`Relaxed`]。
            ///
            /// 失败排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，并且必须等于或弱于成功排序。
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            ///
            /// assert_eq!(some_var.compare_exchange(5, 10,
            ///                                      Ordering::Acquire,
            ///                                      Ordering::Relaxed),
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,
            ///                                      Ordering::SeqCst,
            ///                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// 如果当前值与 `current` 值相同，则将值存储到原子整数中。
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// 即使比较成功，此函数也可能会虚假地失败，这可能导致某些平台上的代码效率更高。
            /// 返回值是指示是否写入了新值并包含先前值的结果。
            ///
            /// `compare_exchange_weak` 需要两个 [`Ordering`] 参数来描述这个操作的内存顺序。
            /// `success` 描述了在与 `current` 的比较成功时发生的读取 - 修改 - 写入操作所需的顺序。
            /// `failure` 描述了比较失败时发生的加载操作所需的排序。
            /// 使用 [`Acquire`] 作为成功排序，使存储成为操作 [`Relaxed`] 的一部分，而使用 [`Release`]，则使装载成功 [`Relaxed`]。
            ///
            /// 失败排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，并且必须等于或弱于成功排序。
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            ///
            /// let mut old = val.load(Ordering::Relaxed);
            /// loop {
            ///     let new = old * 2;
            ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
            ///         Ok(_) => break,
            ///         Err(x) => old = x,
            ///     }
            /// }
            /// ```
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// 加到当前值，返回前一个值。
            ///
            /// 此操作在溢出时回绕。
            ///
            /// `fetch_add` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
            /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
            ///
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// 从当前值中减去，返回前一个值。
            ///
            /// 此操作在溢出时回绕。
            ///
            /// `fetch_sub` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
            /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
            ///
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// "and" 按位与当前值。
            ///
            /// 对当前值和参数 `val` 执行按位 "and" 运算，并将新值设置为结果。
            ///
            /// 返回前一个值。
            ///
            /// `fetch_and` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
            /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
            ///
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// "nand" 按位与当前值。
            ///
            /// 对当前值和参数 `val` 执行按位 "nand" 运算，并将新值设置为结果。
            ///
            /// 返回前一个值。
            ///
            /// `fetch_nand` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
            /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
            ///
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), !(0x13 & 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// "or" 按位与当前值。
            ///
            /// 对当前值和参数 `val` 执行按位 "or" 运算，并将新值设置为结果。
            ///
            /// 返回前一个值。
            ///
            /// `fetch_or` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
            /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
            ///
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// "xor" 按位与当前值。
            ///
            /// 对当前值和参数 `val` 执行按位 "xor" 运算，并将新值设置为结果。
            ///
            /// 返回前一个值。
            ///
            /// `fetch_xor` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
            /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
            ///
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// 获取该值，并对其应用一个函数，该函数返回一个可选的新值。如果函数返回 `Some(_)`，则返回 `Ok(previous_value)` 的 `Result`，否则返回 `Err(previous_value)`。
            ///
            /// Note: 如果与此同时从其他线程更改了值，则只要函数返回 `Some(_)`，这可能会多次调用该函数，但是该函数仅对存储的值应用一次。
            ///
            ///
            /// `fetch_update` 需要两个 [`Ordering`] 参数来描述这个操作的内存顺序。
            /// 第一个描述了操作最终成功时所需的顺序，第二个描述了负载所需的顺序。这些对应于成功和失败的顺序
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// 使用 [`Acquire`] 作为成功排序，使存储成为该操作 [`Relaxed`] 的一部分，而使用 [`Release`]，则使最终成功加载 [`Relaxed`]。
            /// (failed) 负载排序只能是 [`SeqCst`]，[`Acquire`] 或 [`Relaxed`]，并且必须等于或小于成功排序。
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(x + 1)), Ok(7));
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// 当前值的最大值。
            ///
            /// 查找当前值和参数 `val` 的最大值，并将新值设置为结果。
            ///
            /// 返回前一个值。
            ///
            /// `fetch_max` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
            /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
            ///
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// 如果要一步获得最大值，可以使用以下方法：
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar = 42;
            /// let max_foo = foo.fetch_max(bar, Ordering::SeqCst).max(bar);
            /// assert!(max_foo == 42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// 当前值的最小值。
            ///
            /// 查找当前值和参数 `val` 的最小值，并将新值设置为结果。
            ///
            /// 返回前一个值。
            ///
            /// `fetch_min` 需要一个 [`Ordering`] 参数，它描述了这个操作的内存顺序。所有排序模式都是可能的。
            /// 请注意，使用 [`Acquire`] 会使该操作成为存储部分 [`Relaxed`]，而使用 [`Release`] 会使装入部分成为 [`Relaxed`]。
            ///
            ///
            /// **Note**: 此方法仅在支持原子操作的平台上可用
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// 如果要一步获得最小值，则可以使用以下方法：
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            ///
            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar = 12;
            /// let min_foo = foo.fetch_min(bar, Ordering::SeqCst).min(bar);
            /// assert_eq!(min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAFETY: 原子内部函数可以防止数据竞争。
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// 返回指向底层整数的可变指针。
            ///
            /// 在结果整数上进行非原子读取和写入可以是数据竞争。
            /// 此方法对于 FFI 最为有用，在 FFI 中可能使用函数签名
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// 从共享引用返回 `*mut` 指针到此原子是安全的，因为原子类型可与内部可变性一起使用。
            /// 原子的所有修改都通过共享的 quot 更改值，并且只要它们使用原子操作就可以安全地进行更改。
            /// 对返回的裸指针的任何使用都需要一个 `unsafe` 块，并且仍然必须遵守相同的限制：对其进行的操作必须是原子的。
            ///
            ///
            /// # Examples
            ///
            /// ```ignore (extern-declaration)
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            ///
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]
            ///
            // SAFETY: 只要 `my_atomic_op` 是原子的就安全。
            /// unsafe {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            ///
            ///
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    cfg_attr(not(test), rustc_diagnostic_item = "AtomicI8"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    cfg_attr(not(test), rustc_diagnostic_item = "AtomicU8"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    cfg_attr(not(test), rustc_diagnostic_item = "AtomicI16"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    cfg_attr(not(test), rustc_diagnostic_item = "AtomicU16"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    cfg_attr(not(test), rustc_diagnostic_item = "AtomicI32"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    cfg_attr(not(test), rustc_diagnostic_item = "AtomicU32"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    cfg_attr(not(test), rustc_diagnostic_item = "AtomicI64"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    cfg_attr(not(test), rustc_diagnostic_item = "AtomicU64"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    cfg_attr(not(test), rustc_diagnostic_item = "AtomicI128"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    cfg_attr(not(test), rustc_diagnostic_item = "AtomicU128"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_ptr_sized_atomics", since = "1.24.0"),
            stable(feature = "rust1", since = "1.0.0"),
            cfg_attr(not(test), rustc_diagnostic_item = "AtomicIsize"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_ptr_sized_atomics", since = "1.24.0"),
            stable(feature = "rust1", since = "1.0.0"),
            cfg_attr(not(test), rustc_diagnostic_item = "AtomicUsize"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SAFETY: 调用者必须遵守 `atomic_store` 的安全保证。
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_load` 的安全保证。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_swap` 的安全保证。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// 返回前一个值 (如 __sync_fetch_and_add)。
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_add` 的安全保证。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// 返回前一个值 (如 __sync_fetch_and_sub)。
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_sub` 的安全保证。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAFETY: 调用者必须遵守 `atomic_compare_exchange` 的安全保证。
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAFETY: 调用者必须遵守 `atomic_compare_exchange_weak` 的安全保证。
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_and` 的安全保证
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_nand` 的安全保证
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_or` 的安全保证
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_xor` 的安全保证
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// 返回最大值 (有符号比较)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_max` 的安全保证
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// 返回最小值 (带符号的比较)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_min` 的安全保证
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// 返回最大值 (无符号比较)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_umax` 的安全保证
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// 返回最小值 (无符号比较)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: 调用者必须遵守 `atomic_umin` 的安全保证
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// 原子栅栏。
///
/// 根据指定的顺序，栅栏可防止编译器和 CPU 对其周围的某些类型的内存操作重新排序。
/// 这会在它与其他线程中的原子操作或栅栏之间创建同步关系。
///
/// 具有 (至少) [`Release`] 排序语义的栅栏 `A` 与具有 (至少) [`Acquire`] 语义的栅栏 `B` 同步，当且仅当存在操作 X 和 Y 时，这两个操作都在某个原子对象 `M` 上操作，使得 A 在 X 之前排序，Y 在 B 之前排序，并且 Y 观察到 M 的变化
/// 这提供了 A 和 B 之间的依存关系。
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// 具有 [`Release`] 或 [`Acquire`] 语义的原子操作也可以与栅栏同步。
///
/// 除了具有 [`Acquire`] 和 [`Release`] 语义外，具有 [`SeqCst`] 顺序的栅栏还参与其他 [`SeqCst`] 操作和/或栅栏的全局程序顺序。
///
/// 接受 [`Acquire`]，[`Release`]，[`AcqRel`] 和 [`SeqCst`] 排序。
///
/// # Panics
///
/// 如果 `order` 为 [`Relaxed`]，就会出现 panics。
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // 基于自旋锁的互斥原语。
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // 等待直到旧值为 `false`。
///         while self
///             .flag
///             .compare_exchange_weak(false, true, Ordering::Relaxed, Ordering::Relaxed)
///             .is_err()
///         {}
///         // 此栅栏与 `unlock` 中的存储同步。
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "fence"]
pub fn fence(order: Ordering) {
    // SAFETY: 使用原子栅栏是安全的。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// 编译器内存栅栏。
///
/// `compiler_fence` 不发出任何机器代码，但限制了允许编译器重新排序的内存种类。具体来说，根据给定的 [`Ordering`] 语义，可能不允许编译器将调用之前或之后的读取或写入移动到 `compiler_fence` 的另一侧。请注意，它确实不会阻止 *硬件* 进行此类重新排序。
///
/// 在单线程执行上下文中这不是问题，但是当其他线程可以同时修改内存时，则需要更强大的同步原语，例如 [`fence`]。
///
/// 通过不同的排序语义防止的重新排序是：
///
///  - 对于 [`SeqCst`]，不允许在这一点上对读取和写入进行重新排序。
///  - 对于 [`Release`]，不能将先前的读取和写入移至后续的写入之后。
///  - 如果使用 [`Acquire`]，则后续的读取和写入操作不能移至先前的读取操作之前。
///  - 对于 [`AcqRel`]，将同时执行以上两个规则。
///
/// `compiler_fence` 通常仅用于防止线程与自身发生冲突时有用。也就是说，如果给定线程正在执行一段代码，然后被中断，并开始在其他位置执行代码 (虽然仍在同一线程中，并且从概念上讲仍在同一内核上)。在传统程序中，只有在注册信号处理程序时才会发生这种情况。
/// 在更多灵活的代码中，当处理中断，以抢占方式实现绿色线程等时，也会出现这种情况。
/// 鼓励好奇的读者阅读 Linux 内核对 [内存屏障][memory barriers] 的讨论。
///
/// # Panics
///
/// 如果 `order` 为 [`Relaxed`]，就会出现 panics。
///
/// # Examples
///
/// 如果没有 `compiler_fence`，则尽管所有内容都在单个线程中发生，但不能保证以下代码中的 `assert_eq!` 成功。
/// 要了解原因，请记住编译器可以自由地将存储交换为 `IMPORTANT_VARIABLE` 和 `IS_READY`，因为它们都是 `Ordering::Relaxed`。如果是这样，并且在更新 `IS_READY` 之后立即调用信号处理程序，则信号处理程序将看到 `IS_READY=1`，但是看到 `IMPORTANT_VARIABLE=0`。
/// 使用 `compiler_fence` 可以解决这种情况。
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // 防止将较早的写入移至此点之外
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
#[rustc_diagnostic_item = "compiler_fence"]
pub fn compiler_fence(order: Ordering) {
    // SAFETY: 使用原子栅栏是安全的。
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::Relaxed), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::Relaxed), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// 向处理器发出信号，通知它处于忙于等待的自旋循环 (自旋锁) 中。
///
/// 不推荐使用此函数，而推荐使用 [`hint::spin_loop`]。
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[deprecated(since = "1.51.0", note = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}
