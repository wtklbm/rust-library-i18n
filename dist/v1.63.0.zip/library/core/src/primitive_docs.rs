// `library/{std,core}/src/primitive_docs.rs` 应该具有相同的内容。
// 这些是不同的文件，因此相关链接无需设置 `CARGO_PKG_NAME` 即可正常工作，但从概念上讲，它们应该始终相同。
//
#[doc(primitive = "bool")]
#[doc(alias = "true")]
#[doc(alias = "false")]
/// 布尔类型。
///
/// `bool` 代表一个值，它只能是 [`true`] 或 [`false`]。
/// 如果将 `bool` 转换为整数，则 [`true`] 表示为 1，[`false`] 表示为 0。
///
/// # 基本用法
///
/// `bool` 实现了各种 traits，例如 [`BitAnd`]、[`BitOr`]、[`Not`] 等，允许我们使用 `&`、`|` 和 `!` 执行布尔运算。
///
///
/// [`if`] 需要一个 `bool` 值作为它的条件。
/// [`assert!`] 是测试中的一个重要宏，检查表达式是否为 [`true`]，如果不是则为 panics。
///
/// ```
/// let bool_val = true & false | false;
/// assert!(!bool_val);
/// ```
///
/// [`true`]: ../std/keyword.true.html
/// [`false`]: ../std/keyword.false.html
/// [`BitAnd`]: ops::BitAnd
/// [`BitOr`]: ops::BitOr
/// [`Not`]: ops::Not
/// [`if`]: ../std/keyword.if.html
///
/// # Examples
///
/// `bool` 用法的一个简单示例：
///
/// ```
/// let praise_the_borrow_checker = true;
///
/// // 使用 `if` 有条件
/// if praise_the_borrow_checker {
///     println!("oh, yeah!");
/// } else {
///     println!("what?!!");
/// }
///
/// // ... 或者，匹配模式
/// match praise_the_borrow_checker {
///     true => println!("keep praising!"),
///     false => println!("you should praise!"),
/// }
/// ```
///
/// 另外，由于 `bool` 实现了 [`Copy`] trait，因此我们不必担心移动语义 (就像整数和浮点图元一样)。
///
/// 现在将 `bool` 强制转换为整数类型的示例：
///
/// ```
/// assert_eq!(true as i32, 1);
/// assert_eq!(false as i32, 0);
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_bool {}

#[doc(primitive = "never")]
#[doc(alias = "!")]
//
/// `!` 类型，也称为 "never"。
///
/// `!` 表示永远不会解析为任何值的计算类型。
/// 例如，[`exit`] 函数 `fn exit(code: i32) -> !` 退出该进程而不返回，因此返回 `!`。
///
/// `break`、`continue` 和 `return` 表达式也具有 `!` 类型。例如，我们可以写：
///
/// ```
/// #![feature(never_type)]
/// # fn foo() -> u32 {
/// let x: ! = {
///     return 123
/// };
/// # }
/// ```
///
/// 尽管 `let` 在这里毫无意义，但它说明了 `!` 的含义。
/// 由于从未给 `x` 赋值 (因为 `return` 从整个函数返回)，因此可以给 `x` 指定 `!` 类型。
/// 我们也可以将 `return 123` 替换为 `panic!` 或永无休止的 `loop`，并且此代码仍然有效。
///
/// 以下代码更实际地使用 `!`：
///
/// ```
/// # fn get_a_number() -> Option<u32> { None }
/// # loop {
/// let num: u32 = match get_a_number() {
///     Some(num) => num,
///     None => break,
/// };
/// # }
/// ```
///
/// 两个匹配分支都必须产生 [`u32`] 类型的值，但是由于 `break` 根本不会产生值，我们知道它永远不会产生不是 [`u32`] 的值。
///
/// 这说明了 `!` 类型的另一种行为 - 类型为 `!` 的表达式将强制转换为任何其他类型。
///
/// [`u32`]: prim@u32
///
///
///
#[doc = concat!("[`exit`]: ", include_str!("../primitive_docs/process_exit.md"))]
/// # `!` 和泛型
///
/// ## 绝对的错误
///
/// 您将看到显式使用的 `!` 的主要位置是泛型代码。考虑 [`FromStr`] trait：
///
/// ```
/// trait FromStr: Sized {
///     type Err;
///     fn from_str(s: &str) -> Result<Self, Self::Err>;
/// }
/// ```
///
/// 当为 [`String`] 实现此 trait 时，我们需要为 [`Err`] 选择一个类型。并且由于将字符串转换为字符串永远不会导致错误，因此适当的类型是 `!`。
/// (目前实际使用的类型是一个没有变体的枚举，尽管这只是因为 `!` 以后才会被添加到 Rust 中，并且将来可能会发生变化。) 对于 [`Err`] 类型的 `!`，如果我们由于某种原因不得不调用 [`String::from_str`]，那么结果将是 [`Result<String, !>`]，我们可以像这样解包：
///
///
/// ```
/// #![feature(exhaustive_patterns)]
/// use std::str::FromStr;
/// let Ok(s) = String::from_str("hello");
/// ```
///
/// 由于 [`Err`] 变体包含 `!`，因此永远不会发生。如果存在 `exhaustive_patterns` 特性，则意味着我们只需采用 [`Ok`] 变体就可以在 [`Result<T, !>`] 上进行穷尽的匹配。
/// 这说明了 `!` 的另一种行为 - 它可以用于 "delete" 泛型 (如 `Result`) 中的某些枚举变体。
///
/// ## 无限循环
///
/// 尽管 [`Result<T, !>`] 对于消除错误非常有用，但 `!` 也可以用于消除成功。如果我们将 [`Result<T, !>`] 视为 "if this function returns, it has not errored,"，那么我们也会非常直观地想到 [`Result<!, E>`]: 如果函数返回，则 *有* 错误。
///
/// 例如，考虑一个简单的 Web 服务器的情况，它可以简化为：
///
/// ```ignore (hypothetical-example)
/// loop {
///     let (client, request) = get_request().expect("disconnected");
///     let response = request.process();
///     response.send(client);
/// }
/// ```
///
/// 目前，这并不理想，因为只要无法建立新的连接，我们就简单地使用 panic。
/// 相反，我们想跟踪此错误，如下所示：
///
/// ```ignore (hypothetical-example)
/// loop {
///     match get_request() {
///         Err(err) => break err,
///         Ok((client, request)) => {
///             let response = request.process();
///             response.send(client);
///         },
///     }
/// }
/// ```
///
/// 现在，当服务器断开连接时，我们以错误退出循环而不是 panic。虽然简单地返回错误可能很直观，但我们可能希望将其包装在 [`Result<!, E>`] 中：
///
/// ```ignore (hypothetical-example)
/// fn server_loop() -> Result<!, ConnectionError> {
///     loop {
///         let (client, request) = get_request()?;
///         let response = request.process();
///         response.send(client);
///     }
/// }
/// ```
///
/// 现在，我们可以使用 `?` 代替 `match`，并且返回类型更有意义：如果循环停止，则意味着发生了错误。我们甚至不必将循环包装在 `Ok` 中，因为 `!` 会自动强制转换为 `Result<!, ConnectionError>`。
///
/// [`String::from_str`]: str::FromStr::from_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[doc = concat!("[`String`]: ", include_str!("../primitive_docs/string_string.md"))]
/// [`FromStr`]: str::FromStr
///
/// # `!` 和 traits
///
/// 编写自己的 traits 时，只要有明显的 `impl` 而不是 `panic!`，`!` 就应该有一个 `impl`。
/// 原因是返回 `impl Trait` 且 `!` 没有 `impl` 的函数不能作为它的唯一可能的代码路径发散。
/// 换句话说，它们不能从每个代码路径返回 `!`。
/// 例如，此代码不会编译：
///
/// ```compile_fail
/// use std::ops::Add;
///
/// fn foo() -> impl Add<u32> {
///     unimplemented!()
/// }
/// ```
///
/// 但是这段代码可以做到：
///
/// ```
/// use std::ops::Add;
///
/// fn foo() -> impl Add<u32> {
///     if true {
///         unimplemented!()
///     } else {
///         0
///     }
/// }
/// ```
///
/// 原因是，在第一个示例中，`!` 可以强制转换为许多可能的类型，因为许多类型实现了 `Add<u32>`。
/// 但是，在第二个示例中，`else` 分支返回 `0`，编译器从返回类型推断出它为 `u32` 类型。
/// 由于 `u32` 是具体类型，因此 `!` 可以并且将被强制使用。
/// 有关此 `!` 的更多信息，请参见问题 [#36375]。
///
/// [#36375]: https://github.com/rust-lang/rust/issues/36375
///
/// 但是，事实证明，大多数 traits 都可以将 `impl` 用作 `!`。以 [`Debug`] 为例：
///
/// ```
/// #![feature(never_type)]
/// # use std::fmt;
/// # trait Debug {
/// #     fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result;
/// # }
/// impl Debug for ! {
///     fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
///         *self
///     }
/// }
/// ```
///
/// 我们再次使用 `! ` 的功能来强制转换为任何其他类型，在本例中为 [`fmt::Result`]。
/// 由于此方法将 `&!` 作为参数，因此我们知道它永远不能被调用 (因为没有 `!` 类型的值可以调用它)。
/// 编写 `*self` 实质上就是告诉编译器 "我们知道这段代码永远无法运行，所以只需将整个函数体视为具有类型 [`fmt::Result`]"。
/// 当为 `!` 实现 traits 时，可以使用这种模式。
/// 通常，任何仅具有采用 `self` 参数的方法的 trait 都应具有这样的含义。
///
/// 另一方面，不适合实现的一个 trait 是 [`Default`]：
///
/// ```
/// trait Default {
///     fn default() -> Self;
/// }
/// ```
///
/// 由于 `!` 没有值，因此也没有默认值。
/// 的确，我们可以为此编写一个 `impl`，它只是 panics，但是对于任何类型都一样 (我们可以通过仅将 [`default()`] panic 制作为 (eg.) [`File`] 来使用 `impl Default`)。
///
///
///
///
///
///
#[doc = concat!("[`File`]: ", include_str!("../primitive_docs/fs_file.md"))]
/// [`Debug`]: fmt::Debug
/// [`default()`]: Default::default
///
#[unstable(feature = "never_type", issue = "35121")]
mod prim_never {}

#[doc(primitive = "char")]
#[allow(rustdoc::invalid_rust_codeblocks)]
/// 一个字符类型。
///
/// `char` 类型代表一个字符。更具体地说，由于 'character' 在 Unicode 中不是一个明确定义的概念，因此 `char` 是一个 [Unicode 标量值][Unicode scalar value]。
///
/// 本文档描述了 `char` 类型上的许多方法和 trait 实现。由于技术原因，[the `std::char` module](char/index.html) 中还有其他单独的文档。
///
/// # Validity
///
/// `char` 是一个 [Unicode 标量值][Unicode scalar value]，它是除 [代理代码点][surrogate code point] 之外的任何 [Unicode 代码点][Unicode code point]。这有一个固定的数字定义:
/// 代码点在 0 到 0x10FFFF 的范围内，包括 0 到 0x10FFFF。
/// UTF-16 使用的代理代码点在 0xD800 到 0xDFFF 范围内。
///
/// 无论是作为字面量还是在运行时，都不能构造不是 Unicode 标量值的 `char`:
///
/// ```compile_fail
/// // 这些都是编译器错误
/// ['\u{D800}', '\u{DFFF}', '\u{110000}'];
/// ```
///
/// ```should_panic
/// // Panics; from_u32 返回 None。
/// char::from_u32(0xDE01).unwrap();
/// ```
///
/// ```no_run
/// // 未定义的行为
/// unsafe { char::from_u32_unchecked(0x110000) };
/// ```
///
/// USV 也是可以在 UTF-8 中编码的精确值集。
/// 因为 `char` 值是 USV 而 `str` 值是有效的 UTF-8，所以将任何 `char` 存储在 `str` 中或从 `str` 读取任何字符作为 `char` 是安全的。
///
/// 编译器可以理解有效 `char` 值的差距，因此在下面的示例中，这两个范围被理解为涵盖了可能的 `char` 值的整个范围，并且 [非穷举匹配][non-exhaustive match] 没有错误。
///
///
/// ```
/// let c: char = 'a';
/// match c {
///     '\0' ..= '\u{D7FF}' => false,
///     '\u{E000}' ..= '\u{10FFFF}' => true,
/// };
/// ```
///
/// 所有的 USV 都是有效的 `char` 值，但并不是所有的都代表一个真实的字符。
/// 许多 USV 目前没有分配给一个字符，但将来可能会被分配 ("保留"); 有些永远不会是字符 ("非字符"); 并且有些可能被不同的用户赋予不同的含义 ("私有使用")。
///
/// [Unicode code point]: https://www.unicode.org/glossary/#code_point
/// [Unicode scalar value]: https://www.unicode.org/glossary/#unicode_scalar_value
/// [non-exhaustive match]: ../book/ch06-02-match.html#matches-are-exhaustive
/// [surrogate code point]: https://www.unicode.org/glossary/#surrogate_code_point
///
/// # Representation
///
/// `char` 的大小始终为四个字节。这与给定字符作为 [`String`] 的一部分的表示形式不同。例如：
///
/// ```
/// let v = vec!['h', 'e', 'l', 'l', 'o'];
///
/// // 五个元素乘以每个元素四个字节
/// assert_eq!(20, v.len() * std::mem::size_of::<char>());
///
/// let s = String::from("hello");
///
/// // 5 个元素乘以每个元素一个字节
/// assert_eq!(5, s.len() * std::mem::size_of::<u8>());
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
#[doc = concat!("[`String`]: ", include_str!("../primitive_docs/string_string.md"))]
/// 与往常一样，请记住，人类对 'character' 的直觉可能不是 map 到 Unicode 的定义。
/// 例如，尽管看起来相似，但 'é' 字符是一个 Unicode 代码点，而 'é' 是两个 Unicode 代码点：
///
/// ```
/// let mut chars = "é".chars();
/// // U+00e9: '带锐音符的拉丁小写字母 e'
/// assert_eq!(Some('\u{00e9}'), chars.next());
/// assert_eq!(None, chars.next());
///
/// let mut chars = "é".chars();
/// // U+0065: ' 拉丁小写字母 e'
/// assert_eq!(Some('\u{0065}'), chars.next());
/// // U+0301: '结合重音'
/// assert_eq!(Some('\u{0301}'), chars.next());
/// assert_eq!(None, chars.next());
/// ```
///
/// 这意味着 _will_ 上方的第一个字符串的内容适合 `char`，而第二个字符串 _will_ 的内容则不会。
///
/// 尝试使用第二个字符串的内容创建 `char` 字面量会产生错误：
///
/// ```text
/// error: character literal may only contain one codepoint: 'é'
/// let c = 'é';
///         ^^^
/// ```
///
/// `char` 的 4 字节固定大小的另一个含义是，每个字符处理可能最终会使用更多的内存：
///
/// ```
/// let s = String::from("love: ❤️");
/// let v: Vec<char> = s.chars().collect();
///
/// assert_eq!(12, std::mem::size_of_val(&s[..]));
/// assert_eq!(32, std::mem::size_of_val(&v[..]));
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_char {}

#[doc(primitive = "unit")]
#[doc(alias = "(")]
#[doc(alias = ")")]
#[doc(alias = "()")]
//
/// `()` 类型，也称为 "unit"。
///
/// `()` 类型只有一个值 `()`，在没有其他有意义的值可以返回时使用。
/// `()` 最常见的是隐式的：没有 `-> ...` 的函数隐式具有返回类型 `()`，也就是说，它们是等价的：
///
/// ```rust
/// fn long() -> () {}
///
/// fn short() {}
/// ```
///
/// 分号 `;` 可用于在块末尾丢弃表达式的结果，从而使表达式 (从而使该块) 的值为 `()`。
///
/// 例如，
///
/// ```rust
/// fn returns_i64() -> i64 {
///     1i64
/// }
/// fn returns_unit() {
///     1i64;
/// }
///
/// let is_i64 = {
///     returns_i64()
/// };
/// let is_unit = {
///     returns_i64();
/// };
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_unit {}

// 需要进行自动 trait impls 渲染。
// 请参见 src/librustdoc/passes/collect_trait_impls.rs:collect_trait_impls
#[doc(hidden)]
impl () {}

// 仅真正用于文档的假 impl。
#[cfg(doc)]
#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for () {
    fn clone(&self) -> Self {
        loop {}
    }
}

// 仅真正用于文档的假 impl。
#[cfg(doc)]
#[stable(feature = "rust1", since = "1.0.0")]
impl Copy for () {
    // empty
}

#[doc(primitive = "pointer")]
#[doc(alias = "ptr")]
#[doc(alias = "*")]
#[doc(alias = "*const")]
#[doc(alias = "*mut")]
//
/// 原始的、不安全的指针 `*const T` 和 `*mut T`。
///
/// *[See also the `std::ptr` module](ptr).*
///
/// 在 Rust 中使用裸指针并不常见，通常仅限于几种模式。
/// 裸指针可以是未对齐的或 [`null`]。但是，当解引用裸指针 (使用 `*` 运算符) 时，它必须为非 null 并对齐。
///
/// 使用 `*ptr = data` 通过裸指针存储会在旧值上调用 `drop`，因此，如果该类型具有 drop glue 并且尚未初始化内存，则必须使用 [`write`]; 否则，将在未初始化的内存上调用 `drop`。
///
///
/// 使用 [`null`] 和 [`null_mut`] 函数创建空指针，并使用 `*const T` 和 `*mut T` 类型的 [`is_null`] 方法检查空值。
/// `*const T` 和 `*mut T` 类型还定义了用于指针数学的 [`offset`] 方法。
///
/// # 创建裸指针的常用方法
///
/// ## 1. 强制引用 (`&T`) 或可变引用 (`&mut T`)。
///
/// ```
/// let my_num: i32 = 10;
/// let my_num_ptr: *const i32 = &my_num;
/// let mut my_speed: i32 = 88;
/// let my_speed_ptr: *mut i32 = &mut my_speed;
/// ```
///
/// 要获得指向 boxed 值的指针，请解引用 box：
///
/// ```
/// let my_num: Box<i32> = Box::new(10);
/// let my_num_ptr: *const i32 = &*my_num;
/// let mut my_speed: Box<i32> = Box::new(88);
/// let my_speed_ptr: *mut i32 = &mut *my_speed;
/// ```
///
/// 这不会获得原始分配的所有权，并且以后不需要任何资源管理，但是您一定不能在其生命周期之后使用该指针。
///
/// ## 2. 消费 box (`Box<T>`)。
///
/// [`into_raw`] 函数消费 box 并返回裸指针。它不会销毁 `T` 或释放任何内存。
///
/// ```
/// let my_speed: Box<i32> = Box::new(88);
/// let my_speed: *mut i32 = Box::into_raw(my_speed);
///
/// // 通过拥有原始 `Box<T>` 的所有权，我们有义务稍后将其放在一起销毁。
/////
/// unsafe {
///     drop(Box::from_raw(my_speed));
/// }
/// ```
///
/// 请注意，此处对 [`drop`] 的调用是为了清楚起见 - 表示我们已经完成了给定值的操作，应将其销毁。
///
/// ## 3. 使用 `ptr::addr_of!` 创建它
///
/// 您可以使用宏 [`ptr::addr_of!`] (对于 `*const T`) 和 [`ptr::addr_of_mut!`] (对于 `*mut T`)，而不是强制引用裸指针。
/// 这些宏允许您创建裸指针指向您无法创建引用的字段 (不会导致未定义的行为)，例如未对齐的字段。
/// 如果涉及包装的结构或未初始化的内存，这可能是必要的。
///
/// ```
/// #[derive(Debug, Default, Copy, Clone)]
/// #[repr(C, packed)]
/// struct S {
///     aligned: u8,
///     unaligned: u32,
/// }
/// let s = S::default();
/// let p = std::ptr::addr_of!(s.unaligned); // 不允许强制转换
/// ```
///
/// ## 4. 从 C 获取它。
///
/// ```
/// # #![feature(rustc_private)]
/// extern crate libc;
///
/// use std::mem;
///
/// unsafe {
///     let my_num: *mut i32 = libc::malloc(mem::size_of::<i32>()) as *mut i32;
///     if my_num.is_null() {
///         panic!("failed to allocate memory");
///     }
///     libc::free(my_num as *mut libc::c_void);
/// }
/// ```
///
/// 通常，您实际上不会使用 Rust 中的 `malloc` 和 `free`，但是 C API 通常会发出很多指针，因此 Rust 中的裸指针常见来源。
///
/// [`null`]: ptr::null
/// [`null_mut`]: ptr::null_mut
/// [`is_null`]: pointer::is_null
/// [`offset`]: pointer::offset
///
///
///
///
///
///
///
///
///
///
///
///
///
#[doc = concat!("[`into_raw`]: ", include_str!("../primitive_docs/box_into_raw.md"))]
/// [`drop`]: mem::drop
/// [`write`]: ptr::write
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_pointer {}

#[doc(primitive = "array")]
#[doc(alias = "[]")]
#[doc(alias = "[T;N]")] // 不幸的是，rustdoc 没有对别名的模糊搜索
#[doc(alias = "[T; N]")]
/// 一个固定大小的数组，表示为 `[T; N]`，用于元素类型 `T` 和非负编译时常量大小 `N`。
///
/// 创建数组有两种语法形式：
///
/// * 包含每个元素的列表，即 `[x, y, z]`。
/// * 重复表达式 `[x; N]`，该数组生成包含 `x` 的 `N` 副本的数组。
///   `x` 的类型必须为 [`Copy`]。
///
/// 请注意，`[expr; 0]` 是允许的，并产生一个空数组。
/// 然而，这仍然会计算 `expr`，并立即丢弃结果值，因此请注意副作用。
///
/// 如果元素类型允许，则任何大小的数组都将实现以下 traits：
///
/// - [`Copy`]
/// - [`Clone`]
/// - [`Debug`]
/// - [`IntoIterator`] (为 `[T; N]`、`&[T; N]` 和 `&mut [T; N]` 实现)
/// - [`PartialEq`], [`PartialOrd`], [`Eq`], [`Ord`]
/// - [`Hash`]
/// - [`AsRef`], [`AsMut`]
/// - [`Borrow`], [`BorrowMut`]
///
/// 如果元素类型允许，则大小为 0 到 32 (inclusive) 的数组将实现 [`Default`] trait。
/// 作为权宜之计，trait 实现是静态生成的，最大大小为 32。
///
/// 数组强制转换为 [slices (`[T]`) ][slice]，因此可以在数组上调用 slice 方法。实际上，这提供了用于处理数组的大多数 API。
/// 切片具有动态大小，并且不强制转换为数组。
///
/// 您可以使用 [切片模式][slice pattern] 将元素移出数组。如果需要一个元素，请参见 [`mem::replace`]。
///
/// # Examples
///
/// ```
/// let mut array: [i32; 3] = [0; 3];
///
/// array[1] = 1;
/// array[2] = 2;
///
/// assert_eq!([1, 2], &array[1..]);
///
/// // 该循环打印: 0 1 2
/// for x in array {
///     print!("{x} ");
/// }
/// ```
///
/// 您还可以迭代数组元素的引用：
///
/// ```
/// let array: [i32; 3] = [0; 3];
///
/// for x in &array { }
/// ```
///
/// 您可以使用 [切片模式][slice pattern] 将元素移出数组：
///
/// ```
/// fn move_away(_: String) { /* Do interesting things. */ }
///
/// let [john, roa] = ["John".to_string(), "Roa".to_string()];
/// move_away(john);
/// move_away(roa);
/// ```
///
/// # Editions
///
/// 在 Rust 1.53 之前，数组没有按值实现 [`IntoIterator`]，因此调用 `array.into_iter()` 方法自动引用到 [slice 迭代器](slice::iter)。
/// 目前，为了兼容性，Rust 的 2015 和 2018 版本中保留了旧行为，忽略了 [`IntoIterator`] 的值。
/// 将来，2015 年和 2018 年版本的行为可能会与以后版本的行为一致。
///
/// ```rust,edition2018
/// // Rust 2015 和 2018：
///
/// # #![allow(array_into_iter)] // 覆盖我们的 `deny(warnings)`
/// let array: [i32; 3] = [0; 3];
///
/// // 这将创建一个切片迭代器，产生对每个值的引用。
/// for item in array.into_iter().enumerate() {
///     let (i, x): (usize, &i32) = item;
///     println!("array[{i}] = {x}");
/// }
///
/// // `array_into_iter` lint 建议进行此更改以实现未来兼容性：
/// for item in array.iter().enumerate() {
///     let (i, x): (usize, &i32) = item;
///     println!("array[{i}] = {x}");
/// }
///
/// // 您可以使用 `IntoIterator::into_iter` 按值显式迭代数组
/// for item in IntoIterator::into_iter(array).enumerate() {
///     let (i, x): (usize, i32) = item;
///     println!("array[{i}] = {x}");
/// }
/// ```
///
/// 从 2021 版开始，`array.into_iter()` 通常使用 `IntoIterator` 进行值迭代，而应该像以前的版本一样使用 `iter()` 进行引用迭代。
///
///
/// ```rust,edition2021
/// // Rust 2021:
///
/// let array: [i32; 3] = [0; 3];
///
/// // 这通过引用进行迭代：
/// for item in array.iter().enumerate() {
///     let (i, x): (usize, &i32) = item;
///     println!("array[{i}] = {x}");
/// }
///
/// // 这是按值迭代的：
/// for item in array.into_iter().enumerate() {
///     let (i, x): (usize, i32) = item;
///     println!("array[{i}] = {x}");
/// }
/// ```
///
/// 未来的语言版本可能会开始将 2015 和 2018 版的 `array.into_iter()` 语法与 2021 版相同。
/// 因此，在编写使用这些旧版本的代码时仍应牢记这一更改，以防止将来出现破坏。
/// 实现这一点最安全的方法是避免这些版本中的 `into_iter` 语法。
/// 如果版本更新不是不可行/不受欢迎的，则有多种选择：
/// * 使用 `iter`，相当于旧行为，创建引用
/// * 使用 [`IntoIterator::into_iter`]，相当于 2021 年后的行为 (Rust 1.53+)
/// * 替换 `for ....
/// in array.into_iter() {` 和 `for ...
/// in array {`，相当于 2021 年后的行为 (Rust 1.53+)
///
/// ```rust,edition2018
/// // Rust 2015 和 2018：
///
/// let array: [i32; 3] = [0; 3];
///
/// // 这通过引用进行迭代：
/// for item in array.iter() {
///     let x: &i32 = item;
///     println!("{x}");
/// }
///
/// // 这是按值迭代的：
/// for item in IntoIterator::into_iter(array) {
///     let x: i32 = item;
///     println!("{x}");
/// }
///
/// // 这是按值迭代的：
/// for item in array {
///     let x: i32 = item;
///     println!("{x}");
/// }
///
/// // IntoIter 也可以启动一个链。
/// // 这是按值迭代的：
/// for item in IntoIterator::into_iter(array).enumerate() {
///     let (i, x): (usize, i32) = item;
///     println!("array[{i}] = {x}");
/// }
/// ```
///
/// [slice]: prim@slice
/// [`Debug`]: fmt::Debug
/// [`Hash`]: hash::Hash
/// [`Borrow`]: borrow::Borrow
/// [`BorrowMut`]: borrow::BorrowMut
/// [slice pattern]: ../reference/patterns.html#slice-patterns
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_array {}

#[doc(primitive = "slice")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
/// 一个动态大小的视图到一个连续的序列，`[T]`。
/// 这里的连续意味着元素的布局应使每个元素与其相邻元素之间的距离相同。
///
/// *[See also the `std::slice` module](crate::slice).*
///
/// 切片是一个内存块的视图，表示为一个指针和一个长度。
///
/// ```
/// // 切片 Vec
/// let vec = vec![1, 2, 3];
/// let int_slice = &vec[..];
/// // 将数组强制转换为切片
/// let str_slice: &[&str] = &["one", "two", "three"];
/// ```
///
/// 切片是可变的或共享的。
/// 共享切片类型为 `&[T]`，而可变切片类型为 `&mut [T]`，其中 `T` 表示元素类型。
/// 例如，您可以更改可变切片所指向的内存块：
///
/// ```
/// let mut x = [1, 2, 3];
/// let x = &mut x[..]; // 取 `x` 的完整切片。
/// x[1] = 7;
/// assert_eq!(x, &[1, 7, 3]);
/// ```
///
/// 当切片存储所引用序列的长度时，它们的指针大小是 [`Sized`](marker/trait.Sized.html) 类型的两倍。
///
/// 另请参见 [动态大小的类型](../reference/dynamically-sized-types.html) 上的引用。
///
/// ```
/// # use std::rc::Rc;
/// let pointer_size = std::mem::size_of::<&u8>();
/// assert_eq!(2 * pointer_size, std::mem::size_of::<&[u8]>());
/// assert_eq!(2 * pointer_size, std::mem::size_of::<*const [u8]>());
/// assert_eq!(2 * pointer_size, std::mem::size_of::<Box<[u8]>>());
/// assert_eq!(2 * pointer_size, std::mem::size_of::<Rc<[u8]>>());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_slice {}

#[doc(primitive = "str")]
//
/// 字符串切片。
///
/// *[See also the `std::str` module](crate::str).*
///
/// `str` 类型，也称为字符串切片，是最原始的字符串类型。
/// 它通常以其借用形式 `&str` 出现。
/// 也是字符串字面量的类型，`&'static str`。
///
/// 字符串切片始终是有效的 UTF-8。
///
/// # Examples
///
/// 字符串字面量是字符串切片：
///
/// ```
/// let hello = "Hello, world!";
///
/// // 带有明确的类型注解
/// let hello: &'static str = "Hello, world!";
/// ```
///
/// 它们是 `'static`，因为它们直接存储在最终二进制文件中，因此在 `'static` 持续时间内有效。
///
///
/// # Representation
///
/// `&str` 由两个部分组成：一个指向某些字节的指针和一个长度。
/// 您可以使用 [`as_ptr`] 和 [`len`] 方法查看它们：
///
/// ```
/// use std::slice;
/// use std::str;
///
/// let story = "Once upon a time...";
///
/// let ptr = story.as_ptr();
/// let len = story.len();
///
/// // story 有十九个字节
/// assert_eq!(19, len);
///
/// // 我们可以根据 ptr 和 len 重新构建一个 str。
/// // 这都是不安全的，因为我们有责任确保两个组件均有效：
/// let s = unsafe {
///     // 首先，我们建立一个 &[u8] ...
///     let slice = slice::from_raw_parts(ptr, len);
///
///     // ... 然后将该切片转换为字符串
///     str::from_utf8(slice)
/// };
///
/// assert_eq!(s, Ok(story));
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: str::len
///
/// Note: 本示例显示了 `&str` 的内部结构。
/// 在正常情况下，不应使用 `unsafe` 来获取字符串切片。
/// 请改用 `as_str`。
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_str {}

#[doc(primitive = "tuple")]
#[doc(alias = "(")]
#[doc(alias = ")")]
#[doc(alias = "()")]
//
/// 一个有限异构序列，`(T, U, ..)`。
///
/// 让我们依次介绍其中的每一个：
///
/// 元组是有限的。换句话说，元组具有长度。这是长度为 `3` 的元组：
///
/// ```
/// ("hello", 5, 'c');
/// ```
///
/// 'Length' 有时也称为 'arity'； 每个不同长度的元组都是不同的，不同的类型。
///
/// 元组是异构的。这意味着元组的每个元素可以具有不同的类型。
/// 在上面的元组中，其类型为：
///
/// ```
/// # let _:
/// (&'static str, i32, char)
/// # = ("hello", 5, 'c');
/// ```
///
/// 元组是一个序列。这意味着可以按位置访问它们；
/// 这称为元组索引，它看起来像这样：
///
/// ```rust
/// let tuple = ("hello", 5, 'c');
///
/// assert_eq!(tuple.0, "hello");
/// assert_eq!(tuple.1, 5);
/// assert_eq!(tuple.2, 'c');
/// ```
///
/// 元组的顺序性质适用于各种 traits 的实现。
/// 例如，在 [`PartialOrd`] 和 [`Ord`] 中，元素按顺序进行比较，直到找到第一个不相等的集合。
///
///
/// 有关元组的更多信息，请参见 [这本书](../book/ch03-02-data-types.html#the-tuple-type)。
///
///
///
// src/librustdoc/html/format.rs 中的硬编码锚链接到 `#trait-implementations-1`
//
/// # trait 实现
///
/// 在本文档中，简写 `(T₁, T₂,…, Tₙ)` 用于表示不同长度的元组。
/// 当使用它时，在 `T` 上表达的任何 trait bound 都独立地应用于元组的每个元素。
/// 请注意，这是一种方便的符号，以避免重复文档，不是有效的 Rust 语法。
///
/// 由于 Rust 的类型系统的临时限制，以下 traits 仅在 arity 12 或更少的元组上实现。
/// 在未来，这可能会改变:
///
/// * [`PartialEq`]
/// * [`Eq`]
/// * [`PartialOrd`]
/// * [`Ord`]
/// * [`Debug`]
/// * [`Default`]
/// * [`Hash`]
///
/// [`Debug`]: fmt::Debug
/// [`Hash`]: hash::Hash
///
/// 以下 traits 用于任意长度的元组。
/// 这些 traits 具有由编译器自动生成的实现，因此不受缺少语言，特性，的限制。
///
///
/// * [`Clone`]
/// * [`Copy`]
/// * [`Send`]
/// * [`Sync`]
/// * [`Unpin`]
/// * [`UnwindSafe`]
/// * [`RefUnwindSafe`]
///
/// [`Unpin`]: marker::Unpin
/// [`UnwindSafe`]: panic::UnwindSafe
/// [`RefUnwindSafe`]: panic::RefUnwindSafe
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// let tuple = ("hello", 5, 'c');
///
/// assert_eq!(tuple.0, "hello");
/// ```
///
/// 当您要返回多个值时，通常将元组用作返回类型：
///
/// ```
/// fn calculate_point() -> (i32, i32) {
///     // 不要进行计算，这不是示例的重点
///     (4, 5)
/// }
///
/// let point = calculate_point();
///
/// assert_eq!(point.0, 4);
/// assert_eq!(point.1, 5);
///
/// // 将此与模式结合起来会更好。
///
/// let (x, y) = calculate_point();
///
/// assert_eq!(x, 4);
/// assert_eq!(y, 5);
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_tuple {}

// 需要进行自动 trait impls 渲染。
// 请参见 src/librustdoc/passes/collect_trait_impls.rs:collect_trait_impls
#[doc(hidden)]
impl<T> (T,) {}

// 仅真正用于文档的假 impl。
#[cfg(doc)]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(bootstrap), doc(tuple_variadic))]
/// 这个 trait 在任意长度的元组上实现。
impl<T: Clone> Clone for (T,) {
    fn clone(&self) -> Self {
        loop {}
    }
}

// 仅真正用于文档的假 impl。
#[cfg(doc)]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(bootstrap), doc(tuple_variadic))]
/// 这个 trait 在任意长度的元组上实现。
impl<T: Copy> Copy for (T,) {
    // empty
}

#[doc(primitive = "f32")]
/// 32 位浮点类型 (特别是 IEEE 754-2008 中定义的 "binary32" 类型)。
///
/// 此类型可以表示各种十进制数字，例如 `3.5`，`27`，`-113.75`，`0.0078125`，`34359738368`，`0`，`-1`。因此，与整数类型 (例如 `i32`) 不同，浮点类型也可以表示非整数。
///
/// 但是，能够表示这么广泛的数字是以牺牲精度为代价的：浮点数只能表示某些实数，并且计算时会将浮点数舍入到附近的可表示数字。
/// 例如，`5.0` 和 `1.0` 可以精确地表示为 `f32`，但是 `1.0 / 5.0` 会导致 `0.20000000298023223876953125`，因为 `0.2` 不能精确地表示为 `f32`。但是请注意，带有 `println` 的浮动彩信和朋友经常会丢弃无关紧要的数字: `println!("{}", 1.0f32 / 5.0f32)` 会打印 `0.2`。
///
/// 此外，`f32` 可以表示一些特殊值：
///
/// - -0.0: IEEE 754 浮点数有一个表示它们的符号的位，所以 `-0.0` 是一个可能的值。对于比较 `-0.0 = +0.0`，但浮点运算可以通过算术运算携带符号位。
/// 这意味着 `-0.0 × +0.0` 产生 `-0.0`，四舍五入到小于浮点值的负数也产生 `-0.0`。
/// - [∞](#associatedconstant.INFINITY) 和 [−∞](#associatedconstant.NEG_INFINITY): 这些是由 `1.0 / 0.0` 等计算得出的。
/// - [NaN (不是一个数字)](#associatedconstant.NAN): 此值由 `(-1.0).sqrt()` 等计算得出。NaN 有一些潜在的意外行为:
///   - 它不等于任何浮点数，包括它自己! 这就是 `f32` 没有实现 `Eq` trait 的原因。
///   - 它既不小于也不大于任何浮点数，因此无法通过默认比较操作进行排序，这就是 `f32` 没有实现 `Ord` trait 的原因。
///   - 它也被认为是*传染的*，因为几乎所有操作数之一为 NaN 的计算也会导致 NaN。如果此默认值偏离，此页面上的说明仅明确记录 NaN 操作数的行为。
///   - 最后，有多个位模式被认为是 NaN。
///     Rust 目前不保证 NaN 的位模式在算术运算中得到保留，也不保证它们是可移植的，甚至是完全确定的! 这意味着在检查位模式时可能会有一些令人惊讶的结果，因为相同的计算可能会产生具有不同位模式的 NaN。
///
///
/// 当此类型的原始操作 (加法、减法、乘法或除法) 产生的数字不能完全表示为 `f32` 时，它会根据 IEEE 754-2008 中定义的 roundTiesToEven 方向进行四舍五入。这意味着:
///
/// - 如果存在唯一的最接近的可表示值，则结果是最接近真实值的可表示值。
/// - 如果真值恰好在两个可表示值的中间，则结果是具有偶数最低有效二进制数字的结果。
/// - 如果真值的大小 ≥ `f32::MAX` + 2 <sup>(`f32::MAX_EXP`-`f32::MANTISSA_DIGITS`-1)</sup>，则结果为 ∞ 或 -∞ (保留真值的符号)。
///
/// 有关浮点数的更多信息，请参见 [维基百科][wikipedia]。
///
/// *[See also the `std::f32::consts` module](crate::f32::consts).*
///
/// [wikipedia]: https://en.wikipedia.org/wiki/Single-precision_floating-point_format
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_f32 {}

#[doc(primitive = "f64")]
/// 64 位浮点类型 (特别是 IEEE 754-2008 中定义的 "binary64" 类型)。
///
/// 此类型与 [`f32`] 非常相似，但是通过使用两倍的位来提高精度。
/// 请参见 [`f32`] 的文档或关于双精度值的 [维基百科][wikipedia] 了解更多信息。
///
///
/// *[See also the `std::f64::consts` module](crate::f64::consts).*
///
/// [`f32`]: prim@f32
/// [wikipedia]: https://en.wikipedia.org/wiki/Double-precision_floating-point_format
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_f64 {}

#[doc(primitive = "i8")]
//
/// 8 位带符号整数类型。
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_i8 {}

#[doc(primitive = "i16")]
//
/// 16 位带符号整数类型。
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_i16 {}

#[doc(primitive = "i32")]
//
/// 32 位带符号整数类型。
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_i32 {}

#[doc(primitive = "i64")]
//
/// 64 位带符号整数类型。
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_i64 {}

#[doc(primitive = "i128")]
//
/// 128 位带符号整数类型。
#[stable(feature = "i128", since = "1.26.0")]
mod prim_i128 {}

#[doc(primitive = "u8")]
//
/// 8 位无符号整数类型。
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_u8 {}

#[doc(primitive = "u16")]
//
/// 16 位无符号整数类型。
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_u16 {}

#[doc(primitive = "u32")]
//
/// 32 位无符号整数类型。
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_u32 {}

#[doc(primitive = "u64")]
//
/// 64 位无符号整数类型。
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_u64 {}

#[doc(primitive = "u128")]
//
/// 128 位无符号整数类型。
#[stable(feature = "i128", since = "1.26.0")]
mod prim_u128 {}

#[doc(primitive = "isize")]
//
/// 指针大小的有符号整数类型。
///
/// 该原语的大小是引用内存中任何位置所需要的字节数。
/// 例如，在 32 位目标上，这是 4 个字节，而在 64 位目标上，这是 8 个字节。
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_isize {}

#[doc(primitive = "usize")]
//
/// 指针大小的无符号整数类型。
///
/// 该原语的大小是引用内存中任何位置所需要的字节数。
/// 例如，在 32 位目标上，这是 4 个字节，而在 64 位目标上，这是 8 个字节。
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_usize {}

#[doc(primitive = "reference")]
#[doc(alias = "&")]
#[doc(alias = "&mut")]
//
/// 引用，包括共享引用和可变引用。
///
/// 引用代表某种拥有值的借用。您可以通过在值上使用 `&` 或 `&mut` 运算符，或者使用 [`ref`](../std/keyword.ref.html) 或 <code>[ref](../std/keyword.ref.html) [mut](../std/keyword.mut.html)</code> 模式。
///
/// 对于那些熟悉指针的人来说，引用只是一个被认为是对齐的指针，而不是空的，并且指向包含有效值 `T` 的内存 -- 例如， <code>&[bool]</code> 只能指向包含整数值 `1` ([`true`](../std/keyword.true.html)) 或 `0` ([`false`](../std/keyword.false.html)) 的分配，但创建一个 <code>&[bool]</code> 指向包含值 `3` 的分配会导致未定义的行为。
///
/// 事实上，<code>[Option]\<&T></code> 与可为空但已对齐的指针具有相同的内存表示，并且可以像这样跨 FFI 边界传递。
///
/// 在大多数情况下，引用可以像原始值一样使用。字段访问，方法调用和索引工作相同 (当然，要保留可变性规则)。另外，比较运算符透明地遵从引用对象的实现，从而允许将引用与拥有的值进行比较。
///
/// 引用具有附加的生命周期，代表借用有效的作用域。如果一个生命周期的代表作用域与另一个生命周期一样长或更长，则将其称为 "outlive"。`'static` 生命周期是最长的生命周期，它代表程序的总生命周期。
/// 例如，字符串字面量具有 `'static` 生命周期，因为文本数据嵌入到程序的二进制文件中，而不是嵌入在需要动态管理的分配中。
///
/// `&mut T` 引用可以自由强制转换为 `&T` 引用类型相同的引用，生命周期较长的引用可以自由强制转换为较短的引用。
///
/// 通过地址引用相等，而不是比较所指向的值，是通过 [`ptr::eq`] 通过隐式引用指针强制和裸指针相等来实现的，而 [`PartialEq`] 则是对值进行比较。
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(five_ref == other_five_ref);
///
/// assert!(ptr::eq(five_ref, same_five_ref));
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// 有关如何使用引用的更多信息，请参见 [本书的 "References and Borrowing" 章节][book-refs]。
///
/// [book-refs]: ../book/ch04-02-references-and-borrowing.html
///
/// # trait 实现
///
/// 对于所有 `&T` 都实现了以下 traits，无论其引用的类型是什么：
///
/// * [`Copy`]
/// * [`Clone`] \(请注意，如果存在的话，这不会遵循 `T` 的 `Clone` 实现！)
/// * [`Deref`]
/// * [`Borrow`]
/// * [`fmt::Pointer`]
///
/// [`Deref`]: ops::Deref
/// [`Borrow`]: borrow::Borrow
///
/// `&mut T` 引用除了 `Copy` 和 `Clone` (防止创建多个同时借用) 之外的所有内容，加上以下内容，无论其所指对象的类型如何：
///
/// * [`DerefMut`]
/// * [`BorrowMut`]
///
/// [`DerefMut`]: ops::DerefMut
/// [`BorrowMut`]: borrow::BorrowMut
/// [bool]: prim@bool
///
/// 如果底层 `T` 也实现了该 trait，则在 `&T` 引用上实现以下 traits：
///
/// * [`std::fmt`] 中的所有 traits，除了 [`fmt::Pointer`] (无论其引用对象的类型是什么，它都被实现) 和 [`fmt::Write`]
/// * [`PartialOrd`]
/// * [`Ord`]
/// * [`PartialEq`]
/// * [`Eq`]
/// * [`AsRef`]
/// * [`Fn`] \(另外，`&T` 引用 [`FnMut`] 和 [`FnOnce`] 如果 `T: Fn`)
/// * [`Hash`]
/// * [`ToSocketAddrs`]
/// * [`Send`] \(`&T` 引用也需要 <code>T: [Sync]</code>)
///
/// [`std::fmt`]: fmt
/// [`Hash`]: hash::Hash
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[doc = concat!("[`ToSocketAddrs`]: ", include_str!("../primitive_docs/net_tosocketaddrs.md"))]
/// `&mut T` 引用获得除 `ToSocketAddrs` 之外的所有上述内容，加上以下内容，如果 `T` 实现了 trait：
///
///
/// * [`AsMut`]
/// * [`FnMut`] \(另外，如果 `T: FnMut`，`&mut T` 引用得到 [`FnOnce`])
/// * [`fmt::Write`]
/// * [`Iterator`]
/// * [`DoubleEndedIterator`]
/// * [`ExactSizeIterator`]
/// * [`FusedIterator`]
/// * [`TrustedLen`]
/// * [`io::Write`]
/// * [`Read`]
/// * [`Seek`]
/// * [`BufRead`]
///
/// [`FusedIterator`]: iter::FusedIterator
/// [`TrustedLen`]: iter::TrustedLen
///
#[doc = concat!("[`Seek`]: ", include_str!("../primitive_docs/io_seek.md"))]
#[doc = concat!("[`BufRead`]: ", include_str!("../primitive_docs/io_bufread.md"))]
#[doc = concat!("[`Read`]: ", include_str!("../primitive_docs/io_read.md"))]
#[doc = concat!("[`io::Write`]: ", include_str!("../primitive_docs/io_write.md"))]
/// 请注意，由于采用了调用解引用强制多态方法，只需调用 trait 方法就可以像处理引用一样，也可以使用其拥有的值！ 这里描述的实现是针对泛型上下文的，其中最终类型 `T` 是类型参数或本地未知。
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_ref {}

#[doc(primitive = "fn")]
//
/// 函数指针，例如 `fn(usize) -> bool`。
///
/// *另请参见 traits [`Fn`]，[`FnMut`] 和 [`FnOnce`]。*
///
/// [`Fn`]: ops::Fn
/// [`FnMut`]: ops::FnMut
/// [`FnOnce`]: ops::FnOnce
///
/// 函数指针是指向 *code* 的指针，而不是数据。它们可以像函数一样被调用。
/// 像引用一样，函数指针被假定为不为空，所以如果您想通过 FFI 传递函数指针并能够容纳空指针，请使用所需的签名来创建类型 [`Option<fn()>`](core::option#options-and-pointers-nullable-pointers)。
///
///
/// ### Safety
///
/// 普通函数指针是通过强制转换不能捕获环境的普通函数或闭包而获得的：
///
/// ```
/// fn add_one(x: usize) -> usize {
///     x + 1
/// }
///
/// let ptr: fn(usize) -> usize = add_one;
/// assert_eq!(ptr(5), 6);
///
/// let clos: fn(usize) -> usize = |x| x + 5;
/// assert_eq!(clos(5), 10);
/// ```
///
/// 除了根据其签名而有所不同外，函数指针还具有两种形式：安全和不安全。
/// 普通 `fn()` 函数指针只能指向安全函数，而 `unsafe fn()` 函数指针可以指向安全或不安全函数。
///
/// ```
/// fn add_one(x: usize) -> usize {
///     x + 1
/// }
///
/// unsafe fn add_one_unsafely(x: usize) -> usize {
///     x + 1
/// }
///
/// let safe_ptr: fn(usize) -> usize = add_one;
///
/// // ERROR: 不匹配的类型：预期正常 fn，发现不安全 fn let bad_ptr: fn(usize) -> usize=add_one_unsafely；
/////
///
/// let unsafe_ptr: unsafe fn(usize) -> usize = add_one_unsafely;
/// let really_safe_ptr: unsafe fn(usize) -> usize = add_one;
/// ```
///
/// ### ABI
///
/// 最重要的是，函数指针可以根据它们使用的 ABI 有所不同。这是通过在类型之前添加 `extern` 关键字，然后是所涉及的 ABI 来实现的。默认的 ABI 是 "Rust"，即 `fn()` 是与 `extern "Rust" fn()` 完全相同的类型。
/// 指向带有 C ABI 的函数的指针的类型为 `extern "C" fn()`。
///
/// `extern "ABI" { ... }` 块用 ABI "ABI" 声明函数。此处的默认值为 "C"，即，在 `extern {...}` 块中声明的函数具有 "C" ABI。
///
/// 有关更多信息和受支持的 ABI 列表，请参见 [nomicon 中关于外部调用约定的部分][nomicon-abi]。
///
/// [nomicon-abi]: ../nomicon/ffi.html#foreign-calling-conventions
///
/// ### 可变函数
///
/// "C" 或 "cdecl" ABI 的 Extern 函数声明也可以 *variadic*，允许使用可变数量的参数来调用它们。普通的 Rust 函数，即使是 `extern "ABI"` 的函数，也不能可变。
/// 有关更多信息，请参见 [关于可变参数函数的 nomicon 部分][nomicon-variadic]。
///
/// [nomicon-variadic]: ../nomicon/ffi.html#variadic-functions
///
/// ### 创建函数指针
///
/// 如果 `bar` 是函数的名称，则表达式 `bar`*不是* 函数指针。相反，它表示唯一标识函数 `bar` 的无法命名类型的值。该值的大小为零，因为该类型已经标识了该函数。
/// 这样做的好处是 "calling" 值 (实现 `Fn*` traits) 不需要动态分配。
///
/// 零大小的类型 *强制* 到常规函数指针。例如：
///
/// ```rust
/// use std::mem;
///
/// fn bar(x: i32) {}
///
/// let not_bar_ptr = bar; // `not_bar_ptr` 是零大小的，唯一标识是 `bar`
/// assert_eq!(mem::size_of_val(&not_bar_ptr), 0);
///
/// let bar_ptr: fn(i32) = not_bar_ptr; // 强制转换为函数指针
/// assert_eq!(mem::size_of_val(&bar_ptr), mem::size_of::<usize>());
///
/// let footgun = &bar; // 这是对标识 `bar` 的零大小类型的共享引用
/// ```
///
/// 最后一行显示 `&bar` 也不是函数指针。相反，它是特定于函数的 ZST 的引用。当 `bar` 是一个函数时，`&bar` 基本上不是您想要的。
///
/// ### 转换为整数和从整数转换
///
/// 您将函数指针直接转换为整数:
///
/// ```rust
/// let fnptr: fn(i32) -> i32 = |x| x+2;
/// let fnptr_addr = fnptr as usize;
/// ```
///
/// 但是，直接回退是不可能的。您需要使用 `transmute`:
///
/// ```rust
/// # let fnptr: fn(i32) -> i32 = |x| x+2;
/// # let fnptr_addr = fnptr as usize;
/// let fnptr = fnptr_addr as *const ();
/// let fnptr: fn(i32) -> i32 = unsafe { std::mem::transmute(fnptr) };
/// assert_eq!(fnptr(40), 42);
/// ```
///
/// 至关重要的是，我们在转换为函数指针之前 `as`-cast 为一个裸指针。
/// 这避免了整数到指针 `transmute`，这可能是有问题的。
/// 在裸指针 (即两个指针类型) 之间转换是可以的。
///
/// 请注意，所有这些都不能移植到函数指针和数据指针具有不同大小的平台。
///
/// ### Traits
///
/// 函数指针实现以下 traits：
///
/// * [`Clone`]
/// * [`PartialEq`]
/// * [`Eq`]
/// * [`PartialOrd`]
/// * [`Ord`]
/// * [`Hash`]
/// * [`Pointer`]
/// * [`Debug`]
///
/// [`Hash`]: hash::Hash
/// [`Pointer`]: fmt::Pointer
///
/// 由于 Rust 的类型系统中的临时限制，这些 traits 仅在 `"Rust"` 和 `"C"` ABI 上使用不超过 12 个参数的函数上实现。未来，这可能会改变。
///
/// 另外，具有 *any* 签名，ABI 或 safety 的函数指针是 [`Copy`]，并且所有 *safe* 函数指针都实现 [`Fn`]，[`FnMut`] 和 [`FnOnce`]。之所以可行，是因为这些 traits 是编译器特有的。
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
mod prim_fn {}
