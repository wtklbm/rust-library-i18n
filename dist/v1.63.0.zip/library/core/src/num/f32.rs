//! `f32` 单精度浮点类型专用的常量。
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! `consts` 子模块中提供了数学上有效的数字。
//!
//! 对于直接在此模块中定义的常量 (不同于 `consts` 子模块中定义的常量)，新代码应改为使用直接在 `f32` 类型上定义的关联常量。
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f32` 内部表示形式的基数或基数。
/// 请改用 [`f32::RADIX`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // 预期的方式
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// 以 2 为底的有效位数。
/// 请改用 [`f32::MANTISSA_DIGITS`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // 预期的方式
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(
    since = "TBD",
    note = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// 以 10 为基数的有效位数的大概数字。
/// 请改用 [`f32::DIGITS`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // 预期的方式
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// `f32` 的 [机器精度][Machine epsilon] 值。
/// 请改用 [`f32::EPSILON`]。
///
/// 这是 `1.0` 与下一个较大的可表示数字之间的差异。
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // 预期的方式
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `EPSILON` associated constant on `f32`")]
pub const EPSILON: f32 = f32::EPSILON;

/// 最小的 `f32` 有限值。
/// 请改用 [`f32::MIN`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // 预期的方式
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// 最小正 `f32` 正值。
/// 请改用 [`f32::MIN_POSITIVE`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // 预期的方式
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MIN_POSITIVE` associated constant on `f32`")]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// 最大的有限 `f32` 值。
/// 请改用 [`f32::MAX`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // 预期的方式
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// 比 2 的最小可能标准幂大一。
/// 请改用 [`f32::MIN_EXP`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // 预期的方式
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MIN_EXP` associated constant on `f32`")]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// 2 指数的最大可能乘方。
/// 请改用 [`f32::MAX_EXP`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // 预期的方式
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MAX_EXP` associated constant on `f32`")]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// 最小可能的标准幂为 10 指数。
/// 请改用 [`f32::MIN_10_EXP`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // 预期的方式
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MIN_10_EXP` associated constant on `f32`")]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// 最大可能功效为 10 指数。
/// 请改用 [`f32::MAX_10_EXP`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // 预期的方式
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `MAX_10_EXP` associated constant on `f32`")]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// 不是数字 (NaN)。
/// 请改用 [`f32::NAN`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // 预期的方式
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// 无限 (∞)。
/// 请改用 [`f32::INFINITY`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // 预期的方式
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `INFINITY` associated constant on `f32`")]
pub const INFINITY: f32 = f32::INFINITY;

/// 负无穷大 (−∞)。
/// 请改用 [`f32::NEG_INFINITY`]。
///
/// # Examples
///
/// ```rust
/// // 弃用的方式
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // 预期的方式
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[deprecated(since = "TBD", note = "replaced by the `NEG_INFINITY` associated constant on `f32`")]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// 基本数学常量。
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: 用 cmath 中的数学常量替换。

    /// 阿基米德的恒定 (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// 整圈常量 (τ)
    ///
    /// 等于 2π。
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// 欧拉数 (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[cfg(not(test))]
impl f32 {
    /// `f32` 内部表示形式的基数或基数。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// 以 2 为底的有效位数。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// 以 10 为基数的有效位数的大概数字。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// `f32` 的 [机器精度][Machine epsilon] 值。
    ///
    /// 这是 `1.0` 与下一个较大的可表示数字之间的差异。
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// 最小的 `f32` 有限值。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// 最小正 `f32` 正值。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// 最大的有限 `f32` 值。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// 比 2 的最小可能标准幂大一。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// 2 指数的最大可能乘方。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// 最小可能的标准幂为 10 指数。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// 最大可能功效为 10 指数。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// 不是数字 (NaN)。
    ///
    /// 请注意，IEEE-745 不只定义一个 NaN 值;
    /// 过多的位模式被认为是 NaN。
    /// 此外，该标准区分了 "signaling" 和 "quiet" NaN，并允许检查其 "payload" (位模式中未指定的位)。
    /// 不保证此特性等于任何特定的 NaN 位模式，并且不保证其表示在 Rust 版本和目标平台上的稳定性。
    ///
    ///
    ///
    ///
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// 无限 (∞)。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// 负无穷大 (−∞)。
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// 如果此值为 NaN，则返回 `true`。
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): 由于担心可移植性，`abs` 在 libcore 中公开不可用，所以这个实现是内部私有的。
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub(crate) const fn abs_private(self) -> f32 {
        // SAFETY: 这个转变很好。大概吧。可能因为 std 使用它的原因。
        unsafe { mem::transmute::<u32, f32>(mem::transmute::<f32, u32>(self) & 0x7fff_ffff) }
    }

    /// 如果此值是正无穷大或负无穷大，则返回 `true`，否则返回 `false`。
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        // 使用转变可能会导致某些 FPU 的错误答复
        // FIXME: 改变 Rust <-> Rust 调用约定来防止这个问题。
        // See https://github.com/rust-lang/rust/issues/72327
        (self == f32::INFINITY) | (self == f32::NEG_INFINITY)
    }

    /// 如果此数字既不是无穷大也不是 NaN，则返回 `true`。
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // 无需单独处理 NaN: 如果 self 是 NaN，则比较不完全正确。
        //
        self.abs_private() < Self::INFINITY
    }

    /// 如果数字为 [subnormal]，则返回 `true`。
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // `0` 和 `min` 之间的值是次标准的。
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[must_use]
    #[stable(feature = "is_subnormal", since = "1.53.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// 如果数字既不是零、无穷大、[subnormal] 或 NaN，则返回 `true`。
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // `0` 和 `min` 之间的值是次标准的。
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// 返回数字的浮点类别。
    /// 如果仅要测试一个属性，则通常使用特定谓词会更快。
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        // 以前的实现尝试仅使用基于位掩码的检查，使用 f32::to_bits 将浮点数转换为它的位 repr 并在其上进行匹配。
        // 不幸的是，浮点数可能比这更糟糕。
        // 这也不需要导致对 f64::to_bits 的递归计算。
        //
        // 在某些处理器上，在某些情况下，LLVM 将有益地降低浮点运算，尽管要求它们使用 f32 和 f64，但对 x87 运算之类的操作。
        //
        // 它们有一个 f64 的尾数，但可以具有比正常指数更大的指数。
        // FIXME(jubilee): 为了在 x86 处理器上进行 Rust 到 Rust 的调用，永远不需要使用 x87 操作，所以不应该发生这个问题。
        // 应调整代码生成以使用非 C 调用约定，从而避免这种情况。
        //
        //
        //
        if self.is_infinite() {
            // 因此，一个值可能比较不等于无穷大，尽管具有 "full" 指数掩码。
            FpCategory::Infinite
        } else if self.is_nan() {
            // 它可能不是 NaN，因为它可以简单地是一个 "overextended" 有限值。
            FpCategory::Nan
        } else {
            // 但是，std 也不能简单地与零比较来检查是否为零，因为正确性需要避免可能是 Subnormal == -0.0 的相等测试，因为它在 "denormals are zero" 和 "flush to zero" 模式下可能是错误的。
            //
            // 大多数 std 的目标不使用这些，但它们用于 thumbv7neon。
            // 因此，这确实使用了其余部分的位模式匹配。
            //

            // SAFETY: f32 到 u32 是可以的。Usually.
            // 如果分类已经走到这一步，那么值肯定属于这些类别之一。
            unsafe { f32::partial_classify(self) }
        }
    }

    // 这实际上并没有故意返回 NaN 的正确答案，因为它无法正确区分浮点 NaN 和从 x87 FPU 截断的一些正常浮点数。
    //
    // FIXME(jubilee): 这可能至少可以正确回答 Infinity 的问题，就像 f64 版本一样，但我需要对 x86 上的情况进行更多检查。
    // 我担心丢失尾数数据，否则答案会有所不同。
    //
    // # Safety
    // 这需要确保您调用此函数以获得正确回答的值，否则它会返回错误答案。
    // 这对于内存安全本身并不重要，但是正确的浮点数对于不意外泄漏 const eval 运行时偏差逻辑很重要，这可能是可接受的，也可能是不可接受的。
    //
    //
    //
    //
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const unsafe fn partial_classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        // SAFETY: 调用者不会问这样会说谎的问题。
        let b = unsafe { mem::transmute::<f32, u32>(self) };
        match (b & MAN_MASK, b & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            _ => FpCategory::Normal,
        }
    }

    // 它对位进行操作，并且仅对位进行操作，因此它可以忽略对奇怪 FPU 的担忧。
    // FIXME(jubilee): 在一个公正的世界里，这将是分类的整个 impl，加上一个 transmute。
    // 我们并不生活在一个公正的世界里，但我们可以让它变得更加公正。
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn classify_bits(b: u32) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        match (b & MAN_MASK, b & EXP_MASK) {
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            _ => FpCategory::Normal,
        }
    }

    /// 如果 `self` 有正号，则返回 `true`，包括 `+0.0`、带正号位的 NaN 和正无穷大。
    /// 请注意，在 NaN 的情况下，IEEE-745 不会为符号位分配任何含义，并且由于 Rust 不保证 NaN 的位模式在算术运算中保持不变，因此 `is_sign_positive` 对 NaN 的结果可能会产生在某些情况下会出现意想不到的结果。
    ///
    /// 有关详细信息，请参见 [将 NaN 解释为特殊值](f32)。
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    ///
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// 如果 `self` 具有 negative 符号，则返回 `true`，包括 `-0.0`、具有 negative 符号位的 NaN 和 negative 无穷大。
    /// 请注意，在 NaN 的情况下，IEEE-745 不会为符号位分配任何含义，并且由于 Rust 不保证 NaN 的位模式在算术运算中保持不变，因此 `is_sign_negative` 对 NaN 的结果可能会产生在某些情况下会出现意想不到的结果。
    ///
    /// 有关详细信息，请参见 [将 NaN 解释为特殊值](f32)。
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    ///
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 说：当且仅当 x 具有负号时，isSignMinus(x) 才为 true。
        // isSignMinus 也适用于零和 NaN。
        // SAFETY: 这只是为了得到符号位而转换，没关系。
        unsafe { mem::transmute::<f32, u32>(self) & 0x8000_0000 != 0 }
    }

    /// 取一个数 `1/x` 的倒数 (inverse)。
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[must_use = "this returns the result of the operation, without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// 将弧度转换为度数。
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // 使用常量可获得更好的精度。
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// 将度数转换为弧度。
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// 返回两个数字中的最大值，忽略 NaN。
    ///
    /// 如果参数之一是 NaN，则返回另一个参数。
    /// 这遵循 maxNum 的 IEEE-754 2008 语义，除了处理信令 NaN;
    /// 这个函数以相同的方式处理所有的 NaN，并避免了 maxNum 的关联性问题。
    /// 这也符合 libm 的 fmax 的行为。
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    #[must_use = "this returns the result of the comparison, without modifying either input"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// 返回两个数字中的最小值，忽略 NaN。
    ///
    /// 如果参数之一是 NaN，则返回另一个参数。
    /// 这遵循 IEEE-754 2008 对 minNum 的语义，除了对信令 NaN 的处理;
    /// 这个函数以相同的方式处理所有的 NaN，并避免了 minNum 的关联性问题。
    /// 这也符合 libm 的 fmin 的行为。
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    #[must_use = "this returns the result of the comparison, without modifying either input"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// 返回两个数字中的最大值，传播 NaN。
    ///
    /// 这在任一参数为 NaN 时，这将返回 NaN，而 [`f32::max`] 仅当两个参数都为 NaN 时才返回 NaN。
    ///
    /// ```
    /// #![feature(float_minimum_maximum)]
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.maximum(y), y);
    /// assert!(x.maximum(f32::NAN).is_nan());
    /// ```
    ///
    /// 如果参数之一是 NaN，则返回 NaN。否则，这将返回两个数字中较大的一个。对于此操作，`-0.0` 被认为小于 `+0.0`。
    /// 请注意，这遵循 IEEE 754-2019 中指定的语义。
    ///
    /// 另请注意，此处 NaN 的 "propagation" 并不一定意味着 NaN 操作数的位模式是守恒的; 有关详细信息，请参见 [将 NaN 解释为特殊值](f32)。
    ///
    ///
    ///
    #[must_use = "this returns the result of the comparison, without modifying either input"]
    #[unstable(feature = "float_minimum_maximum", issue = "91079")]
    #[inline]
    pub fn maximum(self, other: f32) -> f32 {
        if self > other {
            self
        } else if other > self {
            other
        } else if self == other {
            if self.is_sign_positive() && other.is_sign_negative() { self } else { other }
        } else {
            self + other
        }
    }

    /// 返回两个数字中的最小值，传播 NaN。
    ///
    /// 当任一参数是 NaN 时，这将返回 NaN，而 [`f32::min`] 只有当两个参数都是 NaN 时才返回 NaN。
    ///
    /// ```
    /// #![feature(float_minimum_maximum)]
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.minimum(y), x);
    /// assert!(x.minimum(f32::NAN).is_nan());
    /// ```
    ///
    /// 如果参数之一是 NaN，则返回 NaN。否则，这将返回两个数字中的较小者。对于此操作，`-0.0` 被认为小于 `+0.0`。
    /// 请注意，这遵循 IEEE 754-2019 中指定的语义。
    ///
    /// 另请注意，此处 NaN 的 "propagation" 并不一定意味着 NaN 操作数的位模式是守恒的; 有关详细信息，请参见 [将 NaN 解释为特殊值](f32)。
    ///
    ///
    ///
    #[must_use = "this returns the result of the comparison, without modifying either input"]
    #[unstable(feature = "float_minimum_maximum", issue = "91079")]
    #[inline]
    pub fn minimum(self, other: f32) -> f32 {
        if self < other {
            self
        } else if other < self {
            other
        } else if self == other {
            if self.is_sign_negative() && other.is_sign_positive() { self } else { other }
        } else {
            self + other
        }
    }

    /// 舍入为零并转换为任何原始整数类型，前提是该值是有限的并且适合该类型。
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// 该值必须：
    ///
    /// * 不是 `NaN`
    /// * 不是无限的
    /// * 截断小数部分后，可以在返回类型 `Int` 中表示
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SAFETY: 调用者必须遵守 `FloatToInt::to_int_unchecked` 的安全保证。
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// 原始 trans 变为 `u32`。
    ///
    /// 当前，这与所有平台上的 `transmute::<f32, u32>(self)` 相同。
    ///
    /// 有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。
    ///
    /// 请注意，此函数与 `as` 强制转换不同，后者试图保留 *数字* 值，而不是按位值。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() 不是 casting!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // SAFETY: `u32` 是一个普通的旧数据类型，所以我们总是可以转换成它。
        // ...sorta.
        //
        // 事实证明，在运行时，浮点数可能会受到浮点模式的影响，该模式在读取和写入时将非零 subnormal 数更改为零，即 "denormals are zero" 和 "flush to zero"。
        //
        // 这本身不是问题，但至少有一个用于 Rust 的 tier2 平台实际上默认表现出这种行为。
        //
        // 此外，在禁用 SSE 或 SSE2 并启用 x87 FPU 的 x86 目标上，即
        // 不是软浮点，Rust 进行参数传递的方式实际上可以以稍微不可预测的方式将 "not infinity" 的数字更改为具有与无穷大相同的指数。
        //
        // 而且，当然评估到 NaN 值是相当不确定的。
        // 更准确地说: 什么时候应该返回 NaN 是可知的，但是哪个 NaN 呢?
        // 到目前为止，这是由 LLVM 和 CPU 的组合定义的，而不是 Rust。
        // 然而，这个函数允许观察 NaN 的位串，从而对 CTFE 进行内省。
        //
        // 为了至少暂时保持 const 到运行时的等价性，我们拒绝任何这些可能的情况发生。
        //
        //
        //
        //
        //
        //
        #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
        const fn ct_f32_to_u32(ct: f32) -> u32 {
            match ct.classify() {
                FpCategory::Nan => {
                    panic!("const-eval error: cannot use f32::to_bits on a NaN")
                }
                FpCategory::Subnormal => {
                    panic!("const-eval error: cannot use f32::to_bits on a subnormal number")
                }
                FpCategory::Infinite | FpCategory::Normal | FpCategory::Zero => {
                    // SAFETY: 我们有一个普通的浮点数。现在我们进行转换，即进行位复制。
                    unsafe { mem::transmute::<f32, u32>(ct) }
                }
            }
        }
        // SAFETY: `u32` 是一个普通的旧数据类型，所以我们总是可以... uh...
        // ... 看，就假装您忘记了您刚刚读到的东西。
        // 稳定性问题。
        let rt_f32_to_u32 = |rt| unsafe { mem::transmute::<f32, u32>(rt) };
        // SAFETY: 我们使用在编译时要么总是工作要么失败的内部实现。
        unsafe { intrinsics::const_eval_select((self,), ct_f32_to_u32, rt_f32_to_u32) }
    }

    /// 来自 `u32` 的原始 mut 变。
    ///
    /// 当前，这与所有平台上的 `transmute::<u32, f32>(v)` 相同。
    /// 事实证明，此方法具有很高的可移植性，其原因有两个：
    ///
    /// * 浮点数和整数在所有受支持的平台上具有相同的字节序。
    /// * IEEE-754 非常精确地指定了 float 的位布局。
    ///
    /// 但是，有一个警告：在 2008 年版本的 IEEE-754 之前，实际上并未指定如何解释 NaN 信令位。
    /// 大多数平台 (特别是 x86 和 ARM) 采用了最终在 2008 年标准化的解释，但有些则没有 (特别是 MIPS)。
    /// 结果，MIPS 上的所有信令 NaN 都是 x86 上的安静 NaN，反之亦然。
    ///
    /// 该实现方式不是尝试保留跨信令的信令，而是倾向于保留确切的位。
    /// 这意味着，即使此方法的结果通过网络从 x86 机器发送到 MIPS 机器，任何以 NaN 编码的有效载荷也将被保留。
    ///
    ///
    /// 如果这个方法的结果只由产生它们的同一个架构操纵，那么就没有可移植性的问题。
    ///
    /// 如果输入的不是 NaN，则不存在可移植性问题。
    ///
    /// 如果您不太在意信号传递 (非常可能)，那么就不必担心可移植性。
    ///
    /// 请注意，此函数与 `as` 强制转换不同，后者试图保留 *数字* 值，而不是按位值。
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[must_use]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // 事实证明，sNaN 的安全问题被夸大了! Hooray!
        // SAFETY: `u32` 是一个普通的旧数据类型，所以我们总是可以从它变形...... 排序。
        //
        // 事实证明，在运行时，浮点数可能会受到浮点模式的影响，这些模式在读取和写入时将非零 subnormal 数更改为零，即 "denormals are zero" 和 "flush to zero"。
        //
        // 这通常不是问题，但至少有一个 Rust 的 tier2 平台实际上默认表现出这种行为: thumbv7neon aka "the Neon FPU in AArch32 state"
        //
        // 此外，在禁用 SSE 或 SSE2 并启用 x87 FPU 的 x86 目标上，即
        // 不是软浮点，Rust 进行参数传递的方式实际上可以以稍微不可预测的方式将 "not infinity" 的数字更改为具有与无穷大相同的指数。
        //
        // 而且，当然评估到 NaN 值是相当不确定的。
        // 更准确地说: 什么时候应该返回 NaN 是可知的，但是哪个 NaN 呢?
        // 到目前为止，这是由 LLVM 和 CPU 的组合定义的，而不是 Rust。
        // 然而，这个函数允许观察 NaN 的位串，从而对 CTFE 进行内省。
        //
        // 为了至少暂时保持 const 到运行时的等价性，拒绝任何这些可能的情况发生。
        //
        //
        //
        //
        //
        //
        //
        //
        #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
        const fn ct_u32_to_f32(ct: u32) -> f32 {
            match f32::classify_bits(ct) {
                FpCategory::Subnormal => {
                    panic!("const-eval error: cannot use f32::from_bits on a subnormal number")
                }
                FpCategory::Nan => {
                    panic!("const-eval error: cannot use f32::from_bits on NaN")
                }
                FpCategory::Infinite | FpCategory::Normal | FpCategory::Zero => {
                    // SAFETY: 这不是一个有趣的数字
                    unsafe { mem::transmute::<u32, f32>(ct) }
                }
            }
        }
        // SAFETY: `u32` 是一个普通的旧数据类型，所以我们总是可以... uh...
        // ... 看，就假装您忘记了您刚刚读到的东西。
        // 稳定性问题。
        let rt_u32_to_f32 = |rt| unsafe { mem::transmute::<u32, f32>(rt) };
        // SAFETY: 我们使用在编译时要么总是工作要么失败的内部实现。
        unsafe { intrinsics::const_eval_select((v,), ct_u32_to_f32, rt_u32_to_f32) }
    }

    /// 以大端 (网络) 字节顺序的字节数组形式返回此浮点数的内存表示形式。
    ///
    /// 有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    ///
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// 以小字节序字节顺序将浮点数的内存表示形式返回为字节数组。
    ///
    /// 有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    ///
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// 返回此浮点数的内存表示形式，以原生字节顺序的字节数组形式。
    ///
    /// 由于使用了目标平台的原生字节序，因此，可移植代码应酌情使用 [`to_be_bytes`] 或 [`to_le_bytes`]。
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// 有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    ///
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// 从其表示形式以 big endian 的字节数组创建一个浮点值。
    ///
    /// 有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[must_use]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// 从它的表示形式以 Little Endian 的字节数组创建一个浮点值。
    ///
    /// 有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[must_use]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// 从其表示形式 (以原生字节序形式的字节数组形式) 创建浮点值。
    ///
    /// 由于使用了目标平台的原生字节序，因此可移植代码可能希望酌情使用 [`from_be_bytes`] 或 [`from_le_bytes`]。
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// 有关此操作的可移植性的一些讨论，请参见 [`from_bits`](Self::from_bits) (几乎没有问题)。
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[must_use]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// 返回 `self` 和 `other` 之间的顺序。
    ///
    /// 与浮点数之间的标准部分比较不同，此比较始终根据 IEEE 754 (2008 修订版) 浮点标准中定义的 `totalOrder` 谓词生成排序。
    /// 这些值按以下顺序排序:
    ///
    /// - negative quiet NaN
    /// - negative signaling NaN
    /// - negative infinity
    /// - negative numbers
    /// - negative subnormal numbers
    /// - negative zero
    /// - positive zero
    /// - positive subnormal numbers
    /// - positive numbers
    /// - positive infinity
    /// - positive signaling NaN
    /// - positive quiet NaN.
    ///
    /// 这个函数建立的顺序并不总是与 `f32` 的 [`PartialOrd`] 和 [`PartialEq`] 实现一致。
    /// 例如，他们认为负零和正零相等，而 `total_cmp`
    /// doesn't.
    ///
    /// 信令 NaN 位的解释遵循 IEEE 754 标准中的定义，这可能与一些旧的、不符合标准的 (例如 MIPS) 硬件实现的解释不匹配。
    ///
    /// # Example
    ///
    /// ```
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "total_cmp", since = "1.62.0")]
    #[must_use]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // 如果是负数，将除符号外的所有位翻转以实现与二进制补码整数相似的布局
        //
        // 为什么这样做？ IEEE 754 浮点数包含三个字段：
        // 符号位，指数和尾数。整个指数和尾数字段具有以下属性：它们的按位顺序等于定义大小的数字大小。
        // 幅度通常不是在 NaN 值上定义的，但是 IEEE 754 totalOrder 将 NaN 值也定义为遵循位顺序。这导致了文档注释中解释的顺序。
        // 但是，对于负数和正数，幅值的表示是相同的 - 仅符号位不同。
        // 为了轻松地将浮点数与带符号整数进行比较，在负数的情况下，我们需要翻转指数位和尾数位。
        // 我们将数字有效地转换为 "二进制补码" 的形式。
        //
        // 为了进行翻转，我们构造了一个掩码并对它进行 XOR。
        // 我们从负号值无分支地计算 "除符号位之外的全 1" 掩码: 右移符号以扩展整数，因此我们用符号位 "fill" 掩码，然后转换为无符号以压入另一个零位。
        //
        // 如果为正值，则掩码全为零，因此是空操作。
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// 除非是 NaN，否则将值限制为一定的时间间隔。
    ///
    /// 如果 `self` 大于 `max`，则返回 `max`; 如果 `self` 小于 `min`，则返回 `min`。
    /// 否则，将返回 `self`。
    ///
    /// 请注意，如果初始值也为 NaN，则此函数将返回 NaN。
    ///
    /// # Panics
    ///
    /// 如果 `min > max`，`min` 为 NaN 或 `max` 为 NaN，就会出现 panics。
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}
