//! 指针大小的有符号整数类型的常量。
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! 新代码应直接在原始类型上使用关联的常量。

#![stable(feature = "rust1", since = "1.0.0")]
#![deprecated(
    since = "TBD",
    note = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }
