uint_module!(u8);
