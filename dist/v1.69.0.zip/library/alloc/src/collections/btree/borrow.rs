use core::marker::PhantomData;
use core::ptr::NonNull;

/// 当您知道重借项及其所有后代 (即从中衍生的所有指针和引用) 在某个时候将不再使用时，对某个重借项的重借进行建模。
///
///
/// 借用检查器通常为您处理借用的这种堆叠，但是完成该堆叠的某些控制流对于编译器而言太复杂了。
/// `DormantMutRef` 允许您自己检查借用，同时仍然表示其堆叠性质，并且封装执行此操作所需的裸指针代码而没有未定义的行为。
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// 捕获一个独特的借用，然后立即重新借用。
    /// 对于编译器，新引用的生命周期与原始引用的生命周期相同，但您 promise 可以将其使用更短的时间。
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SAFETY: 我们通过 `_marker` 在整个 'a 中持有借用，并且仅公开此引用，因此它是唯一的。
        //
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// 恢复为最初捕获的唯一借用。
    ///
    /// # Safety
    ///
    /// 重新借用必须已经结束，即不再使用 `new` 返回的引用以及从该指针派生的所有指针和引用。
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SAFETY: 我们自己的的安全条件意味着该引用仍然是独一无二的。
        unsafe { &mut *self.ptr.as_ptr() }
    }

    /// 从最初捕获的独特借用中借用一个新的可变引用。
    ///
    /// # Safety
    ///
    /// 重新借用必须已经结束，即不再使用 `new` 返回的引用以及从该指针派生的所有指针和引用。
    ///
    pub unsafe fn reborrow(&mut self) -> &'a mut T {
        // SAFETY: 我们自己的的安全条件意味着该引用仍然是独一无二的。
        unsafe { &mut *self.ptr.as_ptr() }
    }

    /// 从最初捕获的唯一借用中借用一个新的共享引用。
    ///
    /// # Safety
    ///
    /// 重新借用必须已经结束，即不再使用 `new` 返回的引用以及从该指针派生的所有指针和引用。
    ///
    pub unsafe fn reborrow_shared(&self) -> &'a T {
        // SAFETY: 我们自己的的安全条件意味着该引用仍然是独一无二的。
        unsafe { &*self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;
