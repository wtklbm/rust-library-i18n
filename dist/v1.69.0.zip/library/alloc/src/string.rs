//! 一个 UTF-8 编码的可增长字符串。
//!
//! 该模块包含 [`String`] 类型，用于转换为字符串的 [`ToString`] trait 以及使用 [`String`] 可能导致的几种错误类型。
//!
//!
//! # Examples
//!
//! 有多种方法可从字符串字面量创建新的 [`String`]：
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! 您可以通过与现有的 [`String`] 串联来创建一个新的 [`String`]。
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! 如果您有一个有效的 UTF-8 字节 vector，则可以用它制作一个 [`String`]。您也可以做相反的事情。
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // 我们知道这些字节是有效的，因此我们将使用 `unwrap()`。
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::error::Error;
use core::fmt;
use core::hash;
use core::iter::FusedIterator;
#[cfg(not(no_global_oom_handling))]
use core::iter::{from_fn, FromIterator};
#[cfg(not(no_global_oom_handling))]
use core::ops::Add;
#[cfg(not(no_global_oom_handling))]
use core::ops::AddAssign;
#[cfg(not(no_global_oom_handling))]
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::pattern::Pattern;
#[cfg(not(no_global_oom_handling))]
use core::str::Utf8Chunks;

#[cfg(not(no_global_oom_handling))]
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_utf8_unchecked_mut, Chars, Utf8Error};
#[cfg(not(no_global_oom_handling))]
use crate::str::{from_boxed_utf8_unchecked, FromStr};
use crate::vec::Vec;

/// 一个 UTF-8 编码的可增长字符串。
///
/// `String` 类型是最常见的字符串类型，拥有对该字符串内容的所有权。它与其借用的对应物，原始的 [`str`] 有着密切的关系。
///
/// # Examples
///
/// 您可以使用 [`String::from`] 从一个 [字符串字面量][`&str`] 创建一个 `String`：
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// 您可以使用 [`push`] 方法将 [`char`] 追加到 `String` 上，并使用 [`push_str`] 方法追加 [`&str`]：
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// 如果具有 UTF-8 字节的 vector，则可以使用 [`from_utf8`] 方法从中创建一个 `String`：
///
/// ```
/// // vector 中的一些字节
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // 我们知道这些字节是有效的，因此我们将使用 `unwrap()`。
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s 始终是有效的 UTF-8。如果您需要非 UTF-8 字符串，请考虑 [`OsString`]。它是相似的，但是没有 UTF-8 约束。因为 UTF-8 是可变宽度的编码，`String`s 通常小于相同 `chars` 的数组:
///
/// ```
/// use std::mem;
///
/// // `s` 是 ASCII 码，它表示每个 `char` 为一个字节
/// let s = "hello";
/// assert_eq!(s.len(), 5);
///
/// // 具有相同内容的 `char` 数组会更长，因为每个 `char` 都是四个字节
/////
/// let s = ['h', 'e', 'l', 'l', 'o'];
/// let size: usize = s.into_iter().map(|c| mem::size_of_val(&c)).sum();
/// assert_eq!(size, 20);
///
/// // 但是，对于非 ASCII 字符串，差异会更小，有时它们是相同的
/////
/// let s = "💖💖💖💖💖";
/// assert_eq!(s.len(), 20);
///
/// let s = ['💖', '💖', '💖', '💖', '💖'];
/// let size: usize = s.into_iter().map(|c| mem::size_of_val(&c)).sum();
/// assert_eq!(size, 20);
/// ```
///
/// 这就提出了一些有趣的问题，比如 `s[i]` 应该如何工作。
/// `i` 在这里应该是什么? 几个选项包括字节索引和 `char` 索引，但由于 UTF-8 编码，只有字节索引会提供时间特性索引。例如，可以使用 [`chars`] 获取第 i 个 `char`:
///
/// ```
/// let s = "hello";
/// let third_character = s.chars().nth(2);
/// assert_eq!(third_character, Some('l'));
///
/// let s = "💖💖💖💖💖";
/// let third_character = s.chars().nth(2);
/// assert_eq!(third_character, Some('💖'));
/// ```
///
/// 接下来，`s[i]` 应该返回什么? 因为索引会返回对，底层，数据的引用，所以它可能是 `&u8`、`&[u8]` 或其他类似的东西。
/// 由于我们只提供一个索引，`&u8` 是最有意义的，但这可能不是用户所期望的，并且可以通过
/// [`as_bytes()`]:
///
/// ```
/// // 第一个字节是 104-`'h'` 的字节值
/// let s = "hello";
/// assert_eq!(s.as_bytes()[0], 104);
/// // or
/// assert_eq!(s.as_bytes()[0], b'h');
///
/// // 第一个字节是 240 这显然没有用
/// let s = "💖💖💖💖💖";
/// assert_eq!(s.as_bytes()[0], 240);
/// ```
///
/// 由于这些歧义或限制，简单地禁止使用 `usize` 进行索引:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// // 以下内容将不会编译!
/// println!("The first letter of s is {}", s[0]);
/// ```
///
/// 然而，更清楚的是 `&s[i..j]` 应该如何工作 (即，使用范围进行索引)。它应该接受字节索引 (作为特征时间) 并返回一个 `&str`，它是 UTF-8 编码的。这也称为 "字符串切片"。
/// 请注意，如果提供的字节索引不是字符边界，这将导致 panic - 有关更多详细信息，请参见 [`is_char_boundary`]。有关字符串切片的更多详细信息，请参见 [`SliceIndex<str>`] 的实现。有关字符串切片的非 panic 版本，请参见 [`get`]。
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html "ffi::OsString"
/// [`SliceIndex<str>`]: core::slice::SliceIndex
/// [`as_bytes()`]: str::as_bytes
/// [`get`]: str::get
/// [`is_char_boundary`]: str::is_char_boundary
///
/// [`bytes`] 和 [`chars`] 方法分别返回字符串的字节和代码点的迭代器。要迭代代码点和字节索引，请使用 [`char_indices`]。
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
/// [`char_indices`]: str::char_indices
///
/// # Deref
///
/// `String` 实现了 <code>[Deref]<Target = [str]></code>，因此继承了 [`str`] 的所有方法。另外，这意味着您可以使用与号 (`&`) 将 `String` 传递给采用 [`&str`] 的函数：
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// 这将从 `String` 创建一个 [`&str`]，并将其传入。这种转换非常便宜，因此通常，函数会接受 [`&str`] 作为参数，除非出于某些特定原因它们需要 `String`。
///
/// 在某些情况下，Rust 没有足够的信息来进行此转换，称为 [`Deref`] 强制多态。在以下示例中，字符串切片 [`&'a str`][`&str`] 实现 `TraitExample` trait，函数 `example_func` 接受实现 trait 的所有内容。
/// 在这种情况下，Rust 将需要进行两次隐式转换，而 Rust 没有办法进行转换。
/// 因此，以下示例将无法编译。
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// 有两种选择可以代替。第一种是使用方法 [`as_str()`] 显式提取包含该字符串的字符串切片，从而将 `example_func(&example_string);` 行更改为 `example_func(example_string.as_str());`。
/// 第二种方法将 `example_func(&example_string);` 更改为 `example_func(&*example_string);`。
/// 在这种情况下，我们将 `String` 解引用到 [`str`]，然后将 [`str`] 引用回 [`&str`]。
/// 第二种方法更惯用，但是两种方法都可以显式地进行转换，而不是依赖于隐式转换。
///
/// # Representation
///
/// `String` 由三个部分组成：指向某些字节的指针，长度和容量。指针指向 `String` 用于存储其数据的内部缓冲区。长度是当前存储在缓冲区中的字节数，容量是缓冲区的大小 (以字节为单位)。
///
/// 这样，长度将始终小于或等于容量。
///
/// 此缓冲区始终存储在堆中。
///
/// 您可以使用 [`as_ptr`]，[`len`] 和 [`capacity`] 方法查看它们：
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
// FIXME 在 vec_into_raw_parts 稳定后更新它
/// // 防止自动丢弃字符串的数据
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // story 有十九个字节
/// assert_eq!(19, len);
///
/// // 我们可以用 ptr，len 和 capacity 重新构建一个 String。
/// // 这都是不安全的，因为我们有责任确保组件有效：
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// 如果 `String` 具有足够的容量，则向其添加元素将不会重新分配。例如，考虑以下程序：
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// 这将输出以下内容：
///
/// ```text
/// 0
/// 8
/// 16
/// 16
/// 32
/// 32
/// ```
///
/// 最初，我们根本没有分配任何内存，但是当我们追加到字符串后，它会适当地增加其容量。如果我们改为使用 [`with_capacity`] 方法来初始分配正确的容量，请执行以下操作：
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// 我们最终得到了不同的输出：
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// 在这里，不需要在循环内分配更多的内存。
///
/// [str]: prim@str "str"
/// [`str`]: prim@str "str"
/// [`&str`]: prim@str "&str"
/// [Deref]: core::ops::Deref "ops::Deref"
/// [`Deref`]: core::ops::Deref "ops::Deref"
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), lang = "String")]
pub struct String {
    vec: Vec<u8>,
}

/// 从 UTF-8 字节 vector 转换 `String` 时可能的错误值。
///
/// 该类型是 [`String`] 上 [`from_utf8`] 方法的错误类型。
/// 它的设计方式旨在避免重新分配: [`into_bytes`] 方法将返回转换尝试中使用的字节 vector。
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] 提供的 [`Utf8Error`] 类型表示将 [`u8`] 的切片转换为 [`&str`] 时可能发生的错误。
/// 从这个意义上讲，它是 `FromUtf8Error` 的类似物，您可以通过 [`utf8_error`] 方法从 `FromUtf8Error` 中获得一个。
///
/// [`Utf8Error`]: str::Utf8Error "std::str::Utf8Error"
/// [`std::str`]: core::str "std::str"
/// [`&str`]: prim@str "&str"
/// [`utf8_error`]: FromUtf8Error::utf8_error
///
/// # Examples
///
/// 基本用法：
///
/// ```
/// // vector 中的一些无效字节
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(no_global_oom_handling), derive(Clone))]
#[derive(Debug, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// 从 UTF-16 字节切片转换 `String` 时可能的错误值。
///
/// 该类型是 [`String`] 上 [`from_utf16`] 方法的错误类型。
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// 基本用法：
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// 创建一个新的空 `String`。
    ///
    /// 由于 `String` 为空，因此不会分配任何初始缓冲区。虽然这意味着该初始操作非常便宜，但在以后添加数据时可能会导致过多的分配。
    ///
    /// 如果您对 `String` 可以容纳多少数据有所了解，请考虑使用 [`with_capacity`] 方法来防止过多的重新分配。
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// 创建一个至少具有指定容量的新空 `String`。
    ///
    /// `String` 有一个内部缓冲区来保存其数据。
    /// 容量是该缓冲区的长度，可以使用 [`capacity`] 方法进行查询。
    /// 此方法创建一个空的 `String`，但它的初始缓冲区至少可容纳 `capacity` 字节。
    /// 当您可能将一堆数据追加到 `String` 时，这很有用，从而减少了它需要进行的重新分配的次数。
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// 如果给定的容量为 `0`，则不会进行分配，并且此方法与 [`new`] 方法相同。
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // 字符串不包含任何字符，即使它可以容纳更多字符
    /// assert_eq!(s.len(), 0);
    ///
    /// // 这些都是在不重新分配的情况下完成的...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ...但这可能会使字符串重新分配
    /// s.push('a');
    /// ```
    ///
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): 对于 cfg(test)，此方法定义所需的固有 `[T]::to_vec` 方法不可用。
    // 由于我们不需要出于测试目的使用此方法，因此我将其存根。
    // NB 有关更多信息，请参见 slice.rs 中的 slice::hack 模块
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// 将字节的 vector 转换为 `String`。
    ///
    /// 字符串 ([`String`]) 由字节 ([`u8`]) 组成，字节 ([`Vec<u8>`]) 的 vector 由字节组成，因此此函数在两者之间进行转换。
    /// 并非所有的字节片都是有效的 `String`，但是: `String` 要求它是有效的 UTF-8。
    /// `from_utf8()` 检查以确保字节是有效的 UTF-8，然后进行转换。
    ///
    /// 如果您确定字节切片是有效的 UTF-8，并且不想增加有效性检查的开销，则此函数有一个不安全的版本 [`from_utf8_unchecked`]，它具有相同的行为，但是会跳过检查。
    ///
    ///
    /// 为了提高效率，此方法将注意不要复制 vector。
    ///
    /// 如果需要 [`&str`] 而不是 `String`，请考虑使用 [`str::from_utf8`]。
    ///
    /// 与此方法的相反的是 [`into_bytes`]。
    ///
    /// # Errors
    ///
    /// 如果切片不是 UTF-8，则返回 [`Err`]，并说明为什么提供的字节不是 UTF-8。还包括您移入的 vector。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// // vector 中的一些字节
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // 我们知道这些字节是有效的，因此我们将使用 `unwrap()`。
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// 字节不正确：
    ///
    /// ```
    /// // vector 中的一些无效字节
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// 请参见 [`FromUtf8Error`] 文档，以获取有关此错误的更多详细信息。
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec "Vec"
    /// [`&str`]: prim@str "&str"
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// 将字节切片转换为字符串，包括无效字符。
    ///
    /// 字符串由字节 ([`u8`]) 组成，而字节 ([`&[u8]`][byteslice]) 的切片由字节组成，因此此函数在两者之间进行转换。然而，并非所有的字节片都是有效的字符串，字符串必须是有效的 UTF-8。
    /// 在此转换过程中，`from_utf8_lossy()` 会将所有无效的 UTF-8 序列替换为 [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]，如下所示：
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// 如果您确定字节切片是有效的 UTF-8，并且不想增加转换的开销，则此函数有一个不安全的版本 [`from_utf8_unchecked`]，它具有相同的行为，但是会跳过检查。
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// 此函数返回 [`Cow<'a, str>`]。如果字节切片的 UTF-8 无效，则需要插入替换字符，这将更改字符串的大小，因此需要 `String`。
    /// 但是，如果它已经是有效的 UTF-8，则不需要新的分配。
    /// 这种返回类型使我们能够处理两种情况。
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow "borrow::Cow"
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// // vector 中的一些字节
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// 字节不正确：
    ///
    /// ```
    /// // 一些无效的字节
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[must_use]
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = Utf8Chunks::new(v);

        let first_valid = if let Some(chunk) = iter.next() {
            let valid = chunk.valid();
            if chunk.invalid().is_empty() {
                debug_assert_eq!(valid.len(), v.len());
                return Cow::Borrowed(valid);
            }
            valid
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        res.push_str(REPLACEMENT);

        for chunk in iter {
            res.push_str(chunk.valid());
            if !chunk.invalid().is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// 将 UTF-16 编码的 vector `v` 解码为 `String`，如果 `v` 包含任何无效数据，则返回 [`Err`]。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // 这不是通过 collect:: 完成的: <Result<_, _>> () 出于性能原因。
        // FIXME: 关闭 #48994 时，可以再次简化函数。
        let mut ret = String::with_capacity(v.len());
        for c in char::decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// 将 UTF-16 编码的切片 `v` 解码为 `String`，将无效数据替换为 [替换字符 (`U+FFFD`)][U+FFFD]。
    ///
    /// 与 [`from_utf8_lossy`] 返回 [`Cow<'a, str>`] 不同，`from_utf16_lossy` 返回 `String`，因为 UTF-16 到 UTF-8 的转换需要分配内存。
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow "borrow::Cow"
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[cfg(not(no_global_oom_handling))]
    #[must_use]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        char::decode_utf16(v.iter().cloned())
            .map(|r| r.unwrap_or(char::REPLACEMENT_CHARACTER))
            .collect()
    }

    /// 将 `String` 分解为其原始组件。
    ///
    /// 返回指向底层数据的裸指针，字符串的长度 (以字节为单位) 和数据的已分配容量 (以字节为单位)。
    /// 这些参数与 [`from_raw_parts`] 的参数顺序相同。
    ///
    /// 调用此函数后，调用者将负责先前由 `String` 管理的内存。
    /// 唯一的方法是使用 [`from_raw_parts`] 函数将裸指针，长度和容量转换回 `String`，从而允许析构函数执行清除操作。
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[must_use = "`self` will be dropped if the result is not used"]
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// 根据长度，容量和指针创建一个新的 `String`。
    ///
    /// # Safety
    ///
    /// 这是非常不安全的，因为没有检查的不变量的数量：
    ///
    /// * `buf` 处的内存需要由标准库使用的同一分配器预先分配，并且需要精确对齐 1.
    /// * `length` 需要小于或等于 `capacity`。
    /// * `capacity` 需要是正确的值。
    /// * `buf` 的前 `length` 字节必须为有效的 UTF-8。
    ///
    /// 违反这些可能会导致一些问题，比如破坏分配器的内部数据结构。
    /// 例如，从指向包含 UTF-8 的 C `char` 数组的指针构建 `String` 通常**不**安全，除非您确定该数组最初是由 Rust 标准库的分配器分配的。
    ///
    ///
    /// `buf` 的所有权有效地转移到 `String`，然后 `String` 可以随意释放，重新分配或更改指针所指向的内存的内容。
    /// 调用此函数后，请确保没有其他任何东西使用该指针。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    // FIXME 在 vec_into_raw_parts 稳定后更新它
    ///     // 防止自动丢弃字符串的数据
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// 将字节的 vector 转换为 `String`，而无需检查字符串是否包含有效的 UTF-8。
    ///
    /// 有关更多详细信息，请参见安全版本 [`from_utf8`]。
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// 此函数不安全，因为它不检查传递给它的字节是否为有效的 UTF-8。
    /// 如果违反了此约束，则 `String` 的未来用户可能会导致内存不安全问题，因为标准库的其余部分都假定 `String` 是有效的 UTF-8。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// // vector 中的一些字节
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// 将 `String` 转换为字节 vector。
    ///
    /// 这会消耗 `String`，因此我们不需要复制其内容。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// 提取包含整个 `String` 的字符串切片。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// 将 `String` 转换为可变字符串切片。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// 将给定的字符串切片追加到这个 `String` 的末尾。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// 将 `src` 范围内的元素复制到字符串的末尾。
    ///
    /// # Panics
    ///
    /// 如果起始点或结束点不在 [`char`] 边界上，或超出边界，就会出现 panic。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_extend_from_within)]
    /// let mut string = String::from("abcde");
    ///
    /// string.extend_from_within(2..);
    /// assert_eq!(string, "abcdecde");
    ///
    /// string.extend_from_within(..2);
    /// assert_eq!(string, "abcdecdeab");
    ///
    /// string.extend_from_within(4..8);
    /// assert_eq!(string, "abcdecdeabecde");
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "string_extend_from_within", issue = "103806")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let src @ Range { start, end } = slice::range(src, ..self.len());

        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        self.vec.extend_from_within(src);
    }

    /// 返回此字符串的容量 (以字节为单位)。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// 保留至少比当前长度多 `additional` 字节的容量。分配器可以保留更多空间来推测性地避免频繁分配。
    ///
    /// 调用 `reserve` 后，容量将大于或等于 `self.len() + additional`。
    /// 如果容量已经足够，则不执行任何操作。
    ///
    /// # Panics
    ///
    /// 如果新容量溢出 [`usize`]，就会出现 panics。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// 这实际上可能不会增加容量：
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s 现在的长度为 2，容量至少为 10
    /// let capacity = s.capacity();
    /// assert_eq!(2, s.len());
    /// assert!(capacity >= 10);
    ///
    /// // 因为我们已经至少有额外的 8 个容量，所以称这个...
    /// s.reserve(8);
    ///
    /// // ... 实际上并没有增加。
    /// assert_eq!(capacity, s.capacity());
    /// ```
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// 保留至少比当前长度多 `additional` 字节的最小容量。
    /// 与 [`reserve`] 不同，这不会故意过度分配以推测性地避免频繁分配。
    ///
    /// 调用 `reserve_exact` 后，容量将大于或等于 `self.len() + additional`。
    /// 如果容量已经足够，则不执行任何操作。
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// 如果新容量溢出 [`usize`]，就会出现 panics。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// 这实际上可能不会增加容量：
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s 现在的长度为 2，容量至少为 10
    /// let capacity = s.capacity();
    /// assert_eq!(2, s.len());
    /// assert!(capacity >= 10);
    ///
    /// // 因为我们已经至少有额外的 8 个容量，所以称这个...
    /// s.reserve_exact(8);
    ///
    /// // ... 实际上并没有增加。
    /// assert_eq!(capacity, s.capacity());
    /// ```
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// 尝试为至少比当前长度多 `additional` 字节的容量保留容量。
    /// 分配器可以保留更多空间来推测性地避免频繁分配。
    /// 调用 `try_reserve` 后，如果返回 `Ok(())`，容量将大于等于 `self.len() + additional`。
    ///
    /// 如果容量已经足够，则不执行任何操作。
    /// 即使发生错误，此方法也会保留内容。
    ///
    /// # Errors
    ///
    /// 如果容量溢出，或者分配器报告失败，则返回错误。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // 预先保留内存，如果不能，则退出
    ///     output.try_reserve(data.len())?;
    ///
    ///     // 现在我们知道在我们复杂的工作中这不能 OOM
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[stable(feature = "try_reserve", since = "1.57.0")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// 尝试为至少比当前长度多 `additional` 字节的最小容量保留。
    /// 与 [`try_reserve`] 不同，这不会故意过度分配以推测性地避免频繁分配。
    /// 调用 `try_reserve_exact` 后，如果返回 `Ok(())`，则容量将大于或等于 `self.len() + additional`。
    ///
    /// 如果容量已经足够，则不执行任何操作。
    ///
    /// 请注意，分配器可能会给集合提供比其请求更多的空间。
    /// 因此，不能依靠容量来精确地最小化。
    /// 如果希望将来插入，则首选 [`try_reserve`]。
    ///
    /// [`try_reserve`]: String::try_reserve
    ///
    /// # Errors
    ///
    /// 如果容量溢出，或者分配器报告失败，则返回错误。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // 预先保留内存，如果不能，则退出
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // 现在我们知道在我们复杂的工作中这不能 OOM
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[stable(feature = "try_reserve", since = "1.57.0")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// 缩小此 `String` 的容量以使其长度匹配。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// 降低 `String` 的容量。
    ///
    /// 容量将至少保持与长度和提供的值一样大。
    ///
    ///
    /// 如果当前容量小于下限，则为无操作。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "shrink_to", since = "1.56.0")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// 将给定的 [`char`] 追加到该 `String` 的末尾。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// 返回此 String 内容的字节切片。
    ///
    /// 与此方法的相反的是 [`from_utf8`]。
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// 将此 `String` 缩短为指定的长度。
    ///
    /// 如果 `new_len` 大于字符串的当前长度，则无效。
    ///
    ///
    /// 请注意，此方法对字符串的分配容量没有影响
    ///
    /// # Panics
    ///
    /// 如果 `new_len` 不位于 [`char`] 边界上，就会出现 panics。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// 从字符串缓冲区中删除最后一个字符并返回它。
    ///
    /// 如果 `String` 为空，则返回 [`None`]。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// 从该 `String` 的字节位置删除 [`char`] 并将其返回。
    ///
    /// 这是 *O*(*n*) 操作，因为它需要复制缓冲区中的每个元素。
    ///
    /// # Panics
    ///
    /// 如果 `idx` 大于或等于 String 的长度，或者它不位于 [`char`] 边界上，就会出现 panics。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// 删除 `String` 中所有模式 `pat` 的匹配项。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// 匹配项将被检测并迭代删除，因此在样式重叠的情况下，仅第一个样式将被删除：
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let rejections = {
            let mut searcher = pat.into_searcher(self);
            // Per Searcher::next:
            //
            // Match 结果需要包含整个匹配的模式，而 Reject 结果可以被分割成任意多个相邻的片段。两个范围的长度都可以为零。
            //
            // 在实践中，Searcher::next_match 的实现往往更高效，所以我们在这里使用它并做一些工作将匹配转化为拒绝，因为这就是我们想要在下面复制的内容。
            //
            //
            //
            //
            let mut front = 0;
            let rejections: Vec<_> = from_fn(|| {
                let (start, end) = searcher.next_match()?;
                let prev_front = front;
                front = end;
                Some((prev_front, start))
            })
            .collect();
            rejections.into_iter().chain(core::iter::once((front, self.len())))
        };

        let mut len = 0;
        let ptr = self.vec.as_mut_ptr();

        for (start, end) in rejections {
            let count = end - start;
            if start != len {
                // SAFETY: per Searcher::next:
                //
                // 直到 Done 的 Match 和 Reject 值流将包含相邻、不重叠、覆盖整个 haystack 并位于 utf8 边界上的索引范围。
                //
                //
                //
                unsafe {
                    ptr::copy(ptr.add(start), ptr.add(len), count);
                }
            }
            len += count;
        }

        unsafe {
            self.vec.set_len(len);
        }
    }

    /// 仅保留谓词指定的字符。
    ///
    /// 换句话说，删除所有字符 `c`，以使 `f(c)` 返回 `false`。
    /// 此方法在原地运行，以原始顺序恰好一次访问每个字符，并保留保留字符的顺序。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// 由于按原始顺序仅对元素进行过一次访问，因此可以使用外部状态来确定要保留哪些元素。
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// s.retain(|_| *iter.next().unwrap());
    /// assert_eq!(s, "bce");
    /// ```
    ///
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        struct SetLenOnDrop<'a> {
            s: &'a mut String,
            idx: usize,
            del_bytes: usize,
        }

        impl<'a> Drop for SetLenOnDrop<'a> {
            fn drop(&mut self) {
                let new_len = self.idx - self.del_bytes;
                debug_assert!(new_len <= self.s.len());
                unsafe { self.s.vec.set_len(new_len) };
            }
        }

        let len = self.len();
        let mut guard = SetLenOnDrop { s: self, idx: 0, del_bytes: 0 };

        while guard.idx < len {
            let ch =
                // SAFETY: `guard.idx` 为正数或零，且小于 len，因此 `get_unchecked` 是有边界的。
                // `self` 是像字符串一样的有效 UTF-8，返回的切片从 unicode 代码点开始，因此 `Chars` 始终返回一个字符。
                //
                unsafe { guard.s.get_unchecked(guard.idx..len).chars().next().unwrap_unchecked() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                guard.del_bytes += ch_len;
            } else if guard.del_bytes > 0 {
                // SAFETY: `guard.idx` 已绑定，`guard.del_bytes` 表示字符串中 erased 的字节数，因此生成的 `guard.idx - guard.del_bytes` 始终表示有效的 unicode 代码点。
                //
                //
                // `guard.del_bytes` >= `ch.len_utf8()`，所以用 `ch.len_utf8()` len 切片是安全的。
                //
                //
                ch.encode_utf8(unsafe {
                    crate::slice::from_raw_parts_mut(
                        guard.s.as_mut_ptr().add(guard.idx - guard.del_bytes),
                        ch.len_utf8(),
                    )
                });
            }

            // 将 idx 指向下一个字符
            guard.idx += ch_len;
        }

        drop(guard);
    }

    /// 在此 `String` 的字节位置插入一个字符。
    ///
    /// 这是一个 *O*(*n*) 操作，因为它需要复制缓冲区中的每个元素。
    ///
    /// # Panics
    ///
    /// 如果 `idx` 大于 `String` 的长度，或者它不在 [`char`] 边界上，就会出现 panics。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    #[cfg(not(no_global_oom_handling))]
    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy_nonoverlapping(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// 在此 `String` 的字节位置处插入字符串切片。
    ///
    /// 这是一个 *O*(*n*) 操作，因为它需要复制缓冲区中的每个元素。
    ///
    /// # Panics
    ///
    /// 如果 `idx` 大于 `String` 的长度，或者它不在 [`char`] 边界上，就会出现 panics。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// 返回此 `String` 的内容的可变引用。
    ///
    /// # Safety
    ///
    /// 这个函数是不安全的，因为返回的 `&mut Vec` 允许写入无效的 UTF-8 字节。
    /// 如果违反此约束，则在丢弃 `&mut Vec` 之后使用原始 `String` 可能会违反内存安全，因为标准库的其余部分假定 `String` 是有效的 UTF-8。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// 返回此 `String` 的长度，以字节为单位，而不是 [`char`] 或字素。
    /// 换句话说，它可能不是人类认为的字符串长度。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// 如果此 `String` 的长度为零，则返回 `true`，否则返回 `false`。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// 在给定的字节索引处将字符串拆分为两个。
    ///
    /// 返回新分配的 `String`。
    /// `self` 包含字节 `[0, at)`，返回的 `String` 包含字节 `[at, len)`。
    /// `at` 必须位于 UTF-8 代码点的边界上。
    ///
    /// 请注意，`self` 的容量不会改变。
    ///
    /// # Panics
    ///
    /// 如果 `at` 不在 `UTF-8` 代码点边界上，或者它超出字符串的最后一个代码点，就会出现 panics。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// 截断此 `String`，删除所有内容。
    ///
    /// 虽然这意味着 `String` 的长度为零，但它并未触及其容量。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// 从字符串中批量删除指定范围，并以迭代器的形式返回所有删除的字符。
    ///
    /// 返回的迭代器在字符串上保留一个可变借用以优化其实现。
    ///
    /// # Panics
    ///
    /// 如果起始点或结束点不在 [`char`] 边界上，或超出边界，就会出现 panic。
    ///
    /// # Leaking
    ///
    /// 如果返回的迭代器离开作用域而没有被丢弃 (例如，由于 [`core::mem::forget`])，则字符串可能仍包含任何耗尽字符的副本，或者可能任意丢失字符，包括范围外的字符。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // 删除范围直到字符串中的 β
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // 全范围清除字符串，就像 `clear()` 一样
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // 内存安全
        //
        // Drain 的字符串版本没有 vector 版本的内存安全问题。
        // 数据只是纯字节。
        // 因为范围移除发生在 Drop 中，所以如果 Drain 迭代器泄漏，则移除不会发生。
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // 同时取出两个借用。
        // 在 Drop 中，直到迭代结束，才可以访问 &mut 字符串。
        let self_ptr = self as *mut _;
        // SAFETY: `slice::range` 和 `is_char_boundary` 进行适当的边界检查。
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// 删除字符串中的指定范围，并将其替换为给定的字符串。
    /// 给定的字符串不必与范围相同。
    ///
    /// # Panics
    ///
    /// 如果起始点或结束点不在 [`char`] 边界上，或超出边界，就会出现 panic。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // 替换范围直到字符串中的 β
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // 内存安全
        //
        // Replace_range 没有 vector Splice 的内存安全问题。
        // vector 版本的版本。数据只是纯字节。

        // WARNING: 内联此变量将是不正确的 (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // WARNING: 内联此变量将是不正确的 (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // 再次使用 `range` 是不正确的 (#81138) 我们假设 `range` 所报告的界限保持不变，但是在两次通话之间可能会发生对抗性实现
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// 将此 `String` 转换为 <code>[Box]<[str]></code>。
    ///
    /// 这将丢弃任何多余的容量。
    ///
    /// [str]: prim@str "str"
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "box_str", since = "1.4.0")]
    #[must_use = "`self` will be dropped if the result is not used"]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }

    /// 消耗并泄漏 `String`，向内容返回一个错误引用 `&'static mut str`。
    ///
    /// 这主要适用于在程序剩余生命周期中存在的数据。
    /// 丢弃返回的引用将导致内存泄漏。
    ///
    /// 它不会重新分配或收缩 `String`，因此泄漏的分配可能包括不属于返回片的未使用容量。
    ///
    ///
    /// # Examples
    ///
    /// 简单用法：
    ///
    /// ```
    /// #![feature(string_leak)]
    ///
    /// let x = String::from("bucket");
    /// let static_ref: &'static mut str = x.leak();
    /// assert_eq!(static_ref, "bucket");
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "string_leak", issue = "102929")]
    #[inline]
    pub fn leak(self) -> &'static mut str {
        let slice = self.vec.leak();
        unsafe { from_utf8_unchecked_mut(slice) }
    }
}

impl FromUtf8Error {
    /// 返回试图转换为 `String` 的 [u8] 个字节切片。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// // vector 中的一些无效字节
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[must_use]
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// 返回尝试转换为 `String` 的字节。
    ///
    /// 精心构造此方法以避免分配。
    /// 它将消耗错误，将字节移出，因此不需要制作字节的副本。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// // vector 中的一些无效字节
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[must_use = "`self` will be dropped if the result is not used"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// 提取 `Utf8Error` 以获取有关转换失败的更多详细信息。
    ///
    /// [`std::str`] 提供的 [`Utf8Error`] 类型表示将 [`u8`] 的切片转换为 [`&str`] 时可能发生的错误。
    /// 从这个意义上讲，它类似于 `FromUtf8Error`。
    /// 有关使用它的更多详细信息，请参见其文档。
    ///
    /// [`std::str`]: core::str "std::str"
    /// [`&str`]: prim@str "&str"
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// // vector 中的一些无效字节
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // 第一个字节在这里无效
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Error for FromUtf8Error {
    #[allow(deprecated)]
    fn description(&self) -> &str {
        "invalid utf-8"
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Error for FromUtf16Error {
    #[allow(deprecated)]
    fn description(&self) -> &str {
        "invalid utf-16"
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // 因为我们要在 `String` 上进行迭代，所以可以通过从迭代器获取第一个字符串，并将所有后续字符串追加到该字符串来避免至少一次分配。
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // 因为我们要遍历 CoW，所以我们可以 (潜在地) 通过获取第一个项，并向它追加所有后续的项来避免至少一次分配。
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// 一个方便的 impl，委派给 `&str` 的 impl。
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
#[cfg(not(no_global_oom_handling))]
impl_eq! { Cow<'a, str>, str }
#[cfg(not(no_global_oom_handling))]
impl_eq! { Cow<'a, str>, &'b str }
#[cfg(not(no_global_oom_handling))]
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_default_impls", issue = "87864")]
impl const Default for String {
    /// 创建一个空的 `String`。
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// 实现 `+` 运算符以连接两个字符串。
///
/// 这会消费左侧的 `String`，并重新使用其缓冲区 (如有必要，请增加缓冲区)。
/// 这样做是为了避免分配新的 `String` 并在每个操作上复制整个内容，当通过重复连接构建 *n* 字节的字符串时，这将导致 *O*(*n*^ 2) 运行时间。
///
///
/// 右侧的字符串仅是借用的。它的内容被复制到返回的 `String` 中。
///
/// # Examples
///
/// 将两个 `String` 连接起来，第一个按值取值，第二个借用：
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` 已移动，不能再在此处使用。
/// ```
///
/// 如果要继续使用第一个 `String`，则可以对其进行克隆并追加到克隆中：
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` 在这里仍然有效。
/// ```
///
/// 可以通过将第一个切片转换为 `String` 来完成 `&str` 切片的连接：
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// 实现用于追加到 `String` 的 `+=` 运算符。
///
/// 这与 [`push_str`][String::push_str] 方法具有相同的行为。
#[cfg(not(no_global_oom_handling))]
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`] 的类型别名。
///
/// 存在此别名是为了向后兼容，并且最终可能会弃用该别名。
///
/// [`Infallible`]: core::convert::Infallible "convert::Infallible"
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// 一个用于将值转换为 `String` 的 trait。
///
/// 对于任何实现 [`Display`] trait 的类型，都会自动实现 trait。
/// 因此，不应直接实现 `ToString`：
/// 应该实现 [`Display`]，您可以免费获得 `ToString` 实现。
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// 将给定值转换为 `String`。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// 在此实现中，如果 `Display` 实现返回错误，则 `to_string` 方法 panics。
/// 这表示 `Display` 实现不正确，因为 `fmt::Write for String` 本身从不返回错误。
///
///
#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // 常见的准则是不要内联泛型函数。
    // 但是，从此方法中删除 `#[inline]` 会导致不可忽略的回归。
    // 请参见 <https://github.com/rust-lang/rust/pull/74852>，这是尝试将其删除的最后一次尝试。
    //
    #[inline]
    default fn to_string(&self) -> String {
        let mut buf = String::new();
        let mut formatter = core::fmt::Formatter::new(&mut buf);
        // 绕过 format_args!() 以避免使用零长度字符串 write_str
        fmt::Display::fmt(self, &mut formatter)
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "bool_to_string_specialization", since = "1.68.0")]
impl ToString for bool {
    #[inline]
    fn to_string(&self) -> String {
        String::from(if *self { "true" } else { "false" })
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "u8_to_string_specialization", since = "1.54.0")]
impl ToString for u8 {
    #[inline]
    fn to_string(&self) -> String {
        let mut buf = String::with_capacity(3);
        let mut n = *self;
        if n >= 10 {
            if n >= 100 {
                buf.push((b'0' + n / 100) as char);
                n %= 100;
            }
            buf.push((b'0' + n / 10) as char);
            n %= 10;
        }
        buf.push((b'0' + n) as char);
        buf
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "i8_to_string_specialization", since = "1.54.0")]
impl ToString for i8 {
    #[inline]
    fn to_string(&self) -> String {
        let mut buf = String::with_capacity(4);
        if self.is_negative() {
            buf.push('-');
        }
        let mut n = self.unsigned_abs();
        if n >= 10 {
            if n >= 100 {
                buf.push('1');
                n -= 100;
            }
            buf.push((b'0' + n / 10) as char);
            n %= 10;
        }
        buf.push((b'0' + n) as char);
        buf
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    /// 将 `&str` 转换为 [`String`]。
    ///
    /// 结果分配在堆上。
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// 将 `&mut str` 转换为 [`String`]。
    ///
    /// 结果分配在堆上。
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    /// 将 `&String` 转换为 [`String`]。
    ///
    /// 这将克隆 `s` 并返回该克隆。
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test 拉入 std，导致此处出错
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// 将给定的 boxed `str` 切片转换为 [`String`]。
    /// 值得注意的是，`str` 切片是拥有的。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// 将给定的 [`String`] 转换为拥有所有权的 boxed `str` 切片。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    /// 将写时克隆字符串转换为 [`String`] 的拥有实例。
    ///
    /// 这将提取拥有所有权的字符串，如果尚未拥有，则克隆该字符串。
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// // 如果字符串不被拥有...
    /// let cow: Cow<str> = Cow::Borrowed("eggplant");
    /// // 它将在堆上分配并复制字符串。
    /// let owned: String = String::from(cow);
    /// assert_eq!(&owned[..], "eggplant");
    /// ```
    ///
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// 将字符串切片转换为 [`Borrowed`] 变体。
    /// 不执行堆分配，并且不复制字符串。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    ///
    /// [`Borrowed`]: crate::borrow::Cow::Borrowed "borrow::Cow::Borrowed"
    ///
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// 将 [`String`] 转换为 [`Owned`] 变体。
    /// 不执行堆分配，并且不复制字符串。
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    ///
    /// [`Owned`]: crate::borrow::Cow::Owned "borrow::Cow::Owned"
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// 将 [`String`] 引用转换为 [`Borrowed`] 变体。
    /// 不执行堆分配，并且不复制字符串。
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    ///
    /// [`Borrowed`]: crate::borrow::Cow::Borrowed "borrow::Cow::Borrowed"
    ///
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// 将给定的 [`String`] 转换为包含 [`u8`] 类型值的 vector [`Vec`]。
    ///
    /// # Examples
    ///
    /// 基本用法：
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{b}");
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` 的 draining 迭代器。
///
/// 该结构体是通过 [`String`] 上的 [`drain`] 方法创建的。
/// 有关更多信息，请参见其文档。
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// 将在析构函数中用作 &'a mut String
    string: *mut String,
    /// 要移除的部分的开始
    start: usize,
    /// 要移除的部分的结束
    end: usize,
    /// 当前剩余范围要删除
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // 使用 Vec::drain。
            // "Reaffirm" 边界检查以避免再次插入 panic 代码。
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// 返回此迭代器的其余 (子) 字符串作为切片。
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[must_use]
    #[stable(feature = "string_drain_as_str", since = "1.55.0")]
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

#[stable(feature = "string_drain_as_str", since = "1.55.0")]
impl<'a> AsRef<str> for Drain<'a> {
    fn as_ref(&self) -> &str {
        self.as_str()
    }
}

#[stable(feature = "string_drain_as_str", since = "1.55.0")]
impl<'a> AsRef<[u8]> for Drain<'a> {
    fn as_ref(&self) -> &[u8] {
        self.as_str().as_bytes()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    /// 从单个字符分配一个拥有所有权的 [`String`]。
    ///
    /// # Example
    /// ```rust
    /// let c: char = 'a';
    /// let s: String = String::from(c);
    /// assert_eq!("a", &s[..]);
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}
