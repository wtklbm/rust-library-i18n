use core::ptr::{self};
use core::slice::{self};

// 用于就地迭代的辅助结构体，该结构体将迭代的目标切片 (即头部) 丢弃。
// 源切片 (尾部) 由 IntoIter 丢弃。
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.sub_ptr(self.inner) }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}

// 用于丢弃目标分配和元素的就地集合的帮助器结构体，以避免在其他一些析构函数 panic 时泄漏它们。
//
pub(super) struct InPlaceDstBufDrop<T> {
    pub(super) ptr: *mut T,
    pub(super) len: usize,
    pub(super) cap: usize,
}

impl<T> Drop for InPlaceDstBufDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe { super::Vec::from_raw_parts(self.ptr, self.len, self.cap) };
    }
}
