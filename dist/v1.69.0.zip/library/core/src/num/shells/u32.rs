//! [`u32` primitive type][u32] 的冗余常量模块。
//!
//! 新代码应直接在原始类型上使用关联的常量。

#![stable(feature = "rust1", since = "1.0.0")]
#![deprecated(
    since = "TBD",
    note = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }
