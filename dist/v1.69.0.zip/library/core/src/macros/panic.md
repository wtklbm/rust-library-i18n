让当前线程 panics。

这允许程序立即终止并向程序的调用者提供反馈。

此宏是在示例代码和测试中声明条件的理想方法。`panic!` 与 [`Option`][ounwrap] 和 [`Result`][runwrap] 枚举的 `unwrap` 方法密切相关。当它们被设置为 [`None`] 或 [`Err`] 变体时，这两个实现都调用了 `panic!`。

使用 `panic!()` 时，你可以指定一个字符串有效载荷，它是使用 [`format!`] 语法构建的。当将 panic 注入到调用的 Rust 线程中时，将使用这个有效载荷，从而导致该线程完全变为 panic。

默认 `std` 钩子的行为，即在调用 panic 后直接运行的代码，是将消息，载荷，连同 `panic!()` 调用的 file/line/column 信息一起打印到 `stderr`。您可以使用 [`std::panic::set_hook()`] 覆盖 panic 钩子。
在钩子内部，可以通过 `&dyn Any + Send` 访问 panic，其中包含用于常规 `panic!()` 调用的 `&str` 或 `String`。
对于具有其他类型值的 panic，可以使用 [`panic_any`]。

另请参见宏 [`compile_error!`]，以获取编译期间的错误。

# 何时使用 `panic!` 与 `Result`

Rust 语言提供了两个互补的系统来构建、表示、报告、传播、响应和丢弃错误。
这些职责统称为 "error handling." `panic!` 和 `Result` 的相似之处在于它们都是各自错误处理系统的主要接口; 但是，这些接口附加到它们的错误的含义以及它们在各自的错误处理系统中履行的职责是不同的。


`panic!` 宏用于构建代表程序中已检测到的错误的错误。使用 `panic!`，您可以提供描述错误的消息，然后语言会使用该消息构造错误、报告错误并为您传播错误。

另一方面，`Result` 用于包装其他类型，这些类型代表某些计算的成功结果 `Ok(T)` 或代表该计算的预期运行时失败模式 `Err(E)` 的错误类型。
`Result` 与代表相关计算可能遇到的各种预期运行时故障模式的用户定义类型一起使用。`Result` 必须手动传播，通常在 `?` 运算符和 `Try` trait 的帮助下，并且必须手动报告，通常在 `Error` trait 的帮助下。

有关错误处理的更多详细信息，请切换到 [book] 或 [`std::result`] 模块文档。

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html
[`std::result`]: ../std/result/index.html

# 当前实现

如果主线程为 panics，它将终止您的所有线程并以代码 `101` 结束您的程序。

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```
