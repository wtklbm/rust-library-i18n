use crate::intrinsics::{assert_unsafe_precondition, unchecked_add, unchecked_sub};
use crate::iter::{FusedIterator, TrustedLen};

/// 类似于 `Range<usize>`，但具有 `start <= end` 的安全不变体。
///
/// 这意味着 `end - start` 不能溢出，允许一些 μ 优化。
///
/// (普通的 `Range` 代码需要处理像 `10..0` 这样的退化范围，与只处理规范形式相比，这需要额外的检查。)
///
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct IndexRange {
    start: usize,
    end: usize,
}

impl IndexRange {
    /// # Safety
    /// - `start <= end`
    #[inline]
    pub const unsafe fn new_unchecked(start: usize, end: usize) -> Self {
        // SAFETY: 使用大小的比较是纯粹的
        unsafe {
            assert_unsafe_precondition!(
               "IndexRange::new_unchecked requires `start <= end`",
                (start: usize, end: usize) => start <= end
            )
        };
        IndexRange { start, end }
    }

    #[inline]
    pub const fn zero_to(end: usize) -> Self {
        IndexRange { start: 0, end }
    }

    #[inline]
    pub const fn start(&self) -> usize {
        self.start
    }

    #[inline]
    pub const fn end(&self) -> usize {
        self.end
    }

    #[inline]
    pub const fn len(&self) -> usize {
        // SAFETY: 根据不变量，这不能换行
        unsafe { unchecked_sub(self.end, self.start) }
    }

    /// # Safety
    /// - 只能在 `start < end` 时调用，也就是在 `len > 0` 时调用。
    #[inline]
    unsafe fn next_unchecked(&mut self) -> usize {
        debug_assert!(self.start < self.end);

        let value = self.start;
        // SAFETY: 范围不为空，因此不能溢出
        self.start = unsafe { unchecked_add(value, 1) };
        value
    }

    /// # Safety
    /// - 只能在 `start < end` 时调用，也就是在 `len > 0` 时调用。
    #[inline]
    unsafe fn next_back_unchecked(&mut self) -> usize {
        debug_assert!(self.start < self.end);

        // SAFETY: 范围不为空，因此不能溢出
        let value = unsafe { unchecked_sub(self.end, 1) };
        self.end = value;
        value
    }

    /// 从此范围中删除第一个 `n` 项，将它们作为 `IndexRange` 返回。
    /// 如果少于 `n`，则返回整个范围并将 `self` 留空。
    ///
    ///
    /// 这旨在帮助实现 `Iterator::advance_by`。
    #[inline]
    pub fn take_prefix(&mut self, n: usize) -> Self {
        let mid = if n <= self.len() {
            // SAFETY: 我们刚刚检查了这将在开始和结束之间，因此加法不会溢出。
            //
            unsafe { unchecked_add(self.start, n) }
        } else {
            self.end
        };
        let prefix = Self { start: self.start, end: mid };
        self.start = mid;
        prefix
    }

    /// 从此范围中删除最后一个 `n` 项，将它们作为 `IndexRange` 返回。
    /// 如果少于 `n`，则返回整个范围并将 `self` 留空。
    ///
    ///
    /// 这旨在帮助实现 `Iterator::advance_back_by`。
    #[inline]
    pub fn take_suffix(&mut self, n: usize) -> Self {
        let mid = if n <= self.len() {
            // SAFETY: 我们刚刚检查了这将在开始和结束之间，因此加法不会溢出。
            //
            unsafe { unchecked_sub(self.end, n) }
        } else {
            self.start
        };
        let suffix = Self { start: mid, end: self.end };
        self.end = mid;
        suffix
    }
}

impl Iterator for IndexRange {
    type Item = usize;

    #[inline]
    fn next(&mut self) -> Option<usize> {
        if self.len() > 0 {
            // SAFETY: 我们刚刚检查了范围是非空的
            unsafe { Some(self.next_unchecked()) }
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    #[inline]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        let original_len = self.len();
        self.take_prefix(n);
        if n > original_len { Err(original_len) } else { Ok(()) }
    }
}

impl DoubleEndedIterator for IndexRange {
    #[inline]
    fn next_back(&mut self) -> Option<usize> {
        if self.len() > 0 {
            // SAFETY: 我们刚刚检查了范围是非空的
            unsafe { Some(self.next_back_unchecked()) }
        } else {
            None
        }
    }

    #[inline]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        let original_len = self.len();
        self.take_suffix(n);
        if n > original_len { Err(original_len) } else { Ok(()) }
    }
}

impl ExactSizeIterator for IndexRange {
    #[inline]
    fn len(&self) -> usize {
        self.len()
    }
}

// SAFETY: 因为我们只做 `usize`，所以我们的 `len` 总是完美的。
unsafe impl TrustedLen for IndexRange {}

impl FusedIterator for IndexRange {}
