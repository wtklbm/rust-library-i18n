#![doc = include_str!("../../stdarch/crates/core_arch/src/core_arch_docs.md")]

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use crate::core_arch::arch::*;

/// 内联汇编。
///
/// 有关使用指南，请参见 [rust by example]，有关语法和可用选项的详细信息，请参见 [reference]。
///
///
/// [rust by example]: https://doc.rust-lang.org/nightly/rust-by-example/unsafe/asm.html
/// [reference]: https://doc.rust-lang.org/nightly/reference/inline-assembly.html
#[stable(feature = "asm", since = "1.59.0")]
#[rustc_builtin_macro]
pub macro asm("assembly template", $(operands,)* $(options($(option),*))?) {
    /* compiler built-in */
}

/// 模块级内联汇编。
///
/// 有关使用指南，请参见 [rust by example]，有关语法和可用选项的详细信息，请参见 [reference]。
///
///
/// [rust by example]: https://doc.rust-lang.org/nightly/rust-by-example/unsafe/asm.html
/// [reference]: https://doc.rust-lang.org/nightly/reference/inline-assembly.html
#[stable(feature = "global_asm", since = "1.59.0")]
#[rustc_builtin_macro]
pub macro global_asm("assembly template", $(operands,)* $(options($(option),*))?) {
    /* compiler built-in */
}
