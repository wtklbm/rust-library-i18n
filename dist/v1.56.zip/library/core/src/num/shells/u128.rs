//! 128 位无符号整数类型的常量。
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! 新代码应直接在原始类型上使用关联的常量。

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }