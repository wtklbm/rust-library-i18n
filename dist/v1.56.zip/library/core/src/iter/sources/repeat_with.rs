use crate::iter::{FusedIterator, TrustedLen};

/// 创建一个新的迭代器，方法是应用提供的闭包，转发器，无限地重复 `A` 类型的元素， `F: FnMut() -> A`.
///
/// `repeat_with()` 函数一遍又一遍地调用中继器。
///
/// 无限迭代器 (如 `repeat_with()`) 通常与适配器 (如 [`Iterator::take()`]) 一起使用，以使其具有有限性。
///
/// 如果您需要的迭代器的元素类型实现 [`Clone`]，并且可以将源元素保留在内存中，则应改用 [`repeat()`] 函数。
///
///
/// `repeat_with()` 产生的迭代器不是 [`DoubleEndedIterator`]。
/// 如果您需要 `repeat_with()` 来返回 [`DoubleEndedIterator`]，请打开 GitHub 问题，说明您的用例。
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::iter;
///
/// // 让我们假设我们有一些不是 `Clone` 的值，或者因为它很昂贵而现在还不想在内存中:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // 永远具有特定的值:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// 使用可变和有限化:
///
/// ```rust
/// use std::iter;
///
/// // 从两个的零次幂到三次幂:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... 现在我们完成了
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// 一个迭代器，通过应用提供的闭包 `F: FnMut() -> A`，无限地重复 `A` 类型的元素。
///
///
/// 该 `struct` 由 [`repeat_with()`] 函数创建。
/// 有关更多信息，请参见其文档。
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}