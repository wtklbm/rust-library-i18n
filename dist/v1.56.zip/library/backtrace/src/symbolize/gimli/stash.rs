// 目前仅在 Linux 上使用，因此允许在其他地方使用无效代码
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use super::Mmap;
use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// 一个简单的舞台分配器，用于字节缓冲区。
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
    mmap_aux: UnsafeCell<Option<Mmap>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
            mmap_aux: UnsafeCell::new(None),
        }
    }

    /// 分配指定大小的缓冲区，并向其返回可变引用。
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: 这是创建 `self.buffers` 的可变引用的唯一函数。
        //
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SAFETY: 我们从不从 `self.buffers` 中删除元素，因此只要 `self` 起作用，对任何缓冲区中的数据的引用都将有效。
        //
        &mut buffers[i]
    }

    /// 为这个 `Stash` 的生命周期存储一个 `Mmap`，返回一个指针，该指针的范围仅限于这个生命周期。
    ///
    pub fn set_mmap_aux(&self, map: Mmap) -> &[u8] {
        // SAFETY: 这是唯一的位置，并且指向 `mmap_aux` 的指针，这个结构体也不是线程安全的，不能跨线程共享。
        // 这也很小心，最多存储一个 `mmap_aux`，因为覆盖前一个会使前一个指针无效。
        // 鉴于我们可以安全地返回一个指向我们内部拥有所有权的内容的指针。
        //
        //
        //
        unsafe {
            let mmap_aux = &mut *self.mmap_aux.get();
            assert!(mmap_aux.is_none());
            *mmap_aux = Some(map);
            mmap_aux.as_ref().unwrap()
        }
    }
}