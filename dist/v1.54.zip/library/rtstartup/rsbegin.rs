// rsbegin.o 和 rsend.o 是所谓的编译器运行时启动对象。
// 它们包含正确初始化编译器运行时所需的代码。
//
// 链接可执行文件或 dylib 映像时，这两个目标文件之间的所有用户代码和库都是 "sandwiched"，因此，来自 rsbegin.o 的代码或数据在映像的各个部分中排在第一位，而来自 rsend.o 的代码和数据则成为最后一个。
// 此效果可用于将符号放置在节的开头或结尾，以及插入任何所需的页眉或页脚。
//
// 请注意，实际的模块入口点位于 C 运行时启动对象 (通常称为 `crtX.o`) 中，然后该对象调用其他运行时组件的初始化回调 (通过另一个特殊的映像部分注册)。
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // 标记栈帧展开信息部分的开头
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // 为 unwinder 的内部的 book-keeping 留出空间。
    // 在 $GCC/unwind-dw2-fde.h 中被定义为 `struct object`。
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // 展开信息注册/注销例程。
    // 请参见 libpanic_unwind 的文档。
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // 在模块启动时注册展开信息
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // 关闭时注销
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW 特定的 init/uninit 例行注册
    pub mod mingw_init {
        // MinGW 的启动对象 (crt0.o/dllcrt0.o) 将在启动和退出时在 .ctors 和 .dtors 部分中调用构造函数。
        // 对于 DLL，这是在加载和卸载 DLL 时完成的。
        //
        // 链接器将对这些部分进行排序，以确保我们的回调位于列表的末尾。
        // 由于构造函数以相反的顺序运行，因此可以确保我们的回调是执行的第一个和最后一个。
        //
        //

        #[link_section = ".ctors.65535"] // .ctors.* : C 初始化回调
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors.* : C 终止回调
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}