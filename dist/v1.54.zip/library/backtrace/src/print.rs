#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// 回溯的格式化程序。
///
/// 不管回溯本身来自何处，都可以使用此类型来打印回溯。
/// 如果您使用的是 `Backtrace` 类型，则其 `Debug` 实现已使用此打印格式。
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// 我们可以打印的打印样式
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// 打印一个简短的回溯，理想情况下仅包含相关信息
    Short,
    /// 打印包含所有可能信息的回溯
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// 创建一个新的 `BacktraceFmt`，它将输出写入到提供的 `fmt` 中。
    ///
    /// `format` 参数将控制打印回溯记录的样式，而 `print_path` 参数将用于打印文件名的 `BytesOrWideString` 实例。
    /// 此类型本身不执行任何文件名打印，但是需要执行此回调。
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// 打印将要打印的回溯的前导。
    ///
    /// 在某些平台上，这是必需的，以便在以后完全符号化回溯，否则，这应该只是在创建 `BacktraceFmt` 之后调用的第一个方法。
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// 将框架添加到回溯输出。
    ///
    /// 该提交返回 `BacktraceFrameFmt` 的 RAII 实例，该实例可用于实际打印帧，并且在销毁时它将增加帧计数器。
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// 完成回溯输出。
    ///
    /// 目前这是一个空操作，但为实现 future 与 backtrace 格式的兼容性而添加。
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // 当前不操作 - 包括此 hook 以允许添加 future。
        Ok(())
    }
}

/// 仅用于回溯的一帧的格式化程序。
///
/// 此类型由 `BacktraceFmt::frame` 函数创建。
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// 使用此帧格式化程序打印 `BacktraceFrame`。
    ///
    /// 这将递归打印 `BacktraceFrame` 中的所有 `BacktraceSymbol` 实例。
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// 在 `BacktraceFrame` 中打印 `BacktraceSymbol`。
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: 这不是很好，因为我们最终不会输出任何非 utf8 文件名的文件。
            // 幸运的是，几乎所有东西都是 utf8，所以这应该不太糟。
            //
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// 通常从此 crate 的原始回调中打印原始跟踪的 `Frame` 和 `Symbol`。
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// 将原始帧添加到回溯输出中。
    ///
    /// 与以前的方法不同，此方法采用原始参数，以防它们来自不同位置。
    /// 注意，对于一帧可以多次调用。
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// 将原始帧添加到 backtrace 输出中，包括列信息。
    ///
    /// 与前面的方法一样，此方法采用原始参数，以防它们来自不同位置。
    /// 注意，对于一帧可以多次调用。
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia 无法在流程中进行符号化，因此它具有可用于稍后符号化的特殊格式。
        // 在此处打印，而不用我们自己的格式打印地址。
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // 无需打印 "null" 帧，这基本上意味着系统回溯有点渴望超远地回溯。
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // 为了减小 Sgx 飞地中的 TCB 大小，我们不想实现符号解析功能。
        // 相反，我们可以在此处打印地址的偏移量，以后可以将其映射为正确的函数。
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // 打印框架的索引以及框架的可选指令指针。
        // 如果我们超出该帧的第一个符号，尽管我们只打印适当的空格。
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // 接下来，写出符号名称，如果我们有完整的回溯，请使用其他格式来获取更多信息。
        // 在这里，我们还处理没有名称的符号，
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // 最后，打印出 filename/line 编号 (如果有)。
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line 是在符号名称下的行上打印的，因此请打印一些适当的空格以使自己右对齐。
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // 委托给我们的内部回调以打印文件名，然后打印出行号。
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // 添加列号 (如果有)。
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // 我们只关心框架的第一个符号
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}