fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");
}
