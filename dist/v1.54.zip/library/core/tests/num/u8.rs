uint_module!(u8, u8);
