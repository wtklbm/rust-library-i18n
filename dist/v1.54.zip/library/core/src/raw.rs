#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]
#![rustc_deprecated(
    since = "1.53.0",
    reason = "use pointer metadata APIs instead https://github.com/rust-lang/rust/issues/81513"
)]

//! 包含用于编译器内置类型的布局的结构体定义。
//!
//! 它们可以用作不安全代码中的变形目标，以直接操作原始表示。
//!
//!
//! 它们的定义应始终与 `rustc_middle::ty::layout` 中定义的 ABI 相匹配。
//!

/// trait 对象 (如 `&dyn SomeTrait`) 的表示形式。
///
/// 该结构体的布局与 `&dyn SomeTrait` 和 `Box<dyn AnotherTrait>` 等类型的布局相同。
///
/// `TraitObject` 保证匹配布局，但这不是 trait 对象的类型 (例如，不能在 `&dyn SomeTrait` 上直接访问字段)，也不是控制布局 (更改定义不会更改 `&dyn SomeTrait` 的布局)。
///
/// 它仅设计用于需要操纵脆弱细节的不安全代码。
///
/// 无法通用地引用所有 trait 对象，因此创建此类型的值的唯一方法是使用 [`std::mem::transmute`][transmute] 之类的函数。
/// 同样，从 `TraitObject` 值创建真正的 trait 对象的唯一方法是使用 `transmute`。
///
/// [transmute]: crate::intrinsics::transmute
///
/// 使用不匹配的类型 (一个 vtable 不对应于数据指针所指向的值的类型) 合成 trait 对象的可能性极高，这会导致不确定的行为。
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // 示例 trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // 让编译器制作一个 trait 对象
/// let object: &dyn Foo = &value;
///
/// // 看原始表示
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // 数据指针是 `value` 的地址
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // 创建一个指向另一个 `i32` 的新对象，请小心使用 `object` 的 `i32` vtable
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // 它应该就像我们直接从 `other_value` 构造了一个 trait 对象一样工作
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}