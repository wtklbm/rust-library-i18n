//! 通过裸指针手动管理内存。
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! 该模块中的许多函数都将裸指针作为参数，并对其进行读取或写入。为了安全起见，这些指针必须是 *valid*。
//! 指针是否有效取决于指针用于 (读或写) 的操作以及所访问的内存范围 (即 read/written 多少个字节)。
//! 大多数函数使用 `*mut T` 和 `* const T` 来访问单个值，在这种情况下，文档将忽略该大小，并隐式地假定其为 `size_of::<T>()` 字节。
//!
//! 有效性的确切规则尚未确定。此时提供的保证非常小:
//!
//! * [null] 指针从来都是无效的，甚至对于 [大小为零][zst] 的访问也是无效的。
//! * 为了使指针有效，有必要 (但并不总是足够) 使指针 *可引用*: 从指针开始的给定大小的内存范围必须全部在单个已分配对象的范围内。
//! 请注意，在 Rust 中，每个 (stack-allocated) 变量都被视为一个单独的分配对象。
//! * 即使对于 [size zero][zst] 的操作，指针也不得指向已释放的内存，即，即使对于大小为零的操作，释放也会使指针无效。
//! 但是，将任何非零整数 *字面量* 强制转换为指针对于零大小的访问都是有效的，即使该地址恰好存在一些内存并被释放了。
//! 这相当于编写自己的分配器: 分配零大小的对象不是很困难。
//! 获得对零大小访问有效的指针的规范方法是 [`NonNull::dangling`]。
//! *  在用于在线程之间同步的 [atomic operations] 的意义上，此模块中的函数执行的所有访问都是非原子的。
//! 这意味着从两个不同的线程对同一位置执行两次并发访问是一种未定义的行为，除非两个访问均仅从内存中读取。
//! 请注意，这明确包含 [`read_volatile`] 和 [`write_volatile`]: 易失性访问不能用于线程间同步。
//! * 只要基础对象处于活动状态，并且不使用引用 (仅裸指针) 来访问同一内存，则对指针进行强制引用的结果是有效的。
//!
//! 这些公理，以及仔细地使用 [`offset`] 进行指针算术，足以在不安全的代码中正确实现许多有用的东西。随着 [aliasing] 规则的确定，最终将提供更强有力的保证。
//! 有关更多信息，请参见 [book] 以及专门针对 [undefined behavior][ub] 的引用中的部分。
//!
//! ## Alignment
//!
//! 上面定义的有效裸指针不一定正确对齐 (其中 "proper" 对齐由 pointee 类型定义，即 `*const T` 必须与 `mem::align_of::<T>()` 对齐)。
//! 但是，大多数函数要求其参数正确对齐，并将在其文档中明确说明此要求。
//! [`read_unaligned`] 和 [`write_unaligned`] 除外。
//!
//! 当一个函数需要适当的对齐时，即使访问的大小为 0，即实际上没有触摸到内存，它也需要进行适当的对齐。在这种情况下，请考虑使用 [`NonNull::dangling`]。
//!
//! ## 分配对象
//!
//! 对于一些操作，例如 [`offset`] 或 projection (`expr.field`)，"allocated object" 的概念变得相关。分配的对象是一个连续的内存区域。
//! 分配对象的常见示例包括栈分配变量 (每个变量都是一个单独的分配对象)、堆分配 (每个分配器创建的分配都是一个单独的分配对象) 和 `static` 变量。
//!
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

mod metadata;
pub(crate) use metadata::PtrRepr;
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// 执行指向值的析构函数 (如果有)。
///
/// 从语义上讲，这等效于调用 [`ptr::read`] 并丢弃结果，但是具有以下优点:
///
/// * 强制要求使用 `drop_in_place` 丢弃未定义大小的类型 (例如 trait 对象)，因为它们无法被读取到栈上并且无法正常丢弃。
///
/// * 当丢弃手动分配的内存时 (例如，在 `Box`/`Rc`/`Vec` 的实现中)，通过 [`ptr::read`] 进行此操作对优化器来说更友好，因为编译器不需要证明丢弃副本是合理的。
///
///
/// * 当 `T` 不是 `repr(packed)` 时，可用于丢弃 [pinned] 数据 (在丢弃固定的数据之前，不得移动固定的数据)。
///
/// 未对齐的值不能被直接丢弃，必须先使用 [`ptr::read_unaligned`] 将它们复制到对齐的位置。对于包装的结构体，此移动由编译器自动完成。
/// 这意味着已打包结构的字段不会被原地丢弃。
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `to_drop` 对于读写，必须为 [valid]。
///
/// * `to_drop` 必须正确对齐。
///
/// * `to_drop` 指向的值必须对丢弃有效，这可能意味着它必须支持其他不变式 - 这与类型有关。
///
/// 此外，如果 `T` 不是 [`Copy`]，则在调用 `drop_in_place` 之后使用指向的值可能会导致未定义的行为。请注意，`*to_drop = foo` 被视为使用，因为它将导致该值再次被丢弃。
/// [`write()`] 可用于覆盖数据而不会导致数据被丢弃。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
///
/// # Examples
///
/// 从 vector 手动删除最后一个项:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // 获取指向 `v` 中最后一个元素的裸指针。
///     let ptr = &mut v[1] as *mut _;
///     // 缩短 `v`，以防止丢弃最后一个项。
///     // 我们首先这样做是为了防止 `drop_in_place` 低于 panics。
///     v.set_len(1);
///     // 如果没有调用 `drop_in_place`，则最后一个项将永远不会被删除，并且它管理的内存也会泄漏。
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // 确保丢弃了最后一项。
/// assert!(weak.upgrade().is_none());
/// ```
///
/// 注意，编译器在丢弃包装好的结构时会自动执行这种复制，即，除非您手动调用 `drop_in_place`，否则通常不必担心此类问题。
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // 编译器会将其替换为真正的 drop glue。
    //

    // SAFETY: 见上面的评论
    unsafe { drop_in_place(to_drop) }
}

/// 创建一个空的裸指针。
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.24.0")]
#[rustc_diagnostic_item = "ptr_null"]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// 创建一个空的可变裸露指针。
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.24.0")]
#[rustc_diagnostic_item = "ptr_null_mut"]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

/// 根据指针和长度形成原始切片。
///
/// `len` 参数是 **元素** 的数量，而不是字节数。
///
/// 此函数是安全的，但实际上使用返回值是不安全的。
/// 有关切片的安全要求，请参见 [`slice::from_raw_parts`] 的文档。
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // 从指向第一个元素的指针开始创建切片指针
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    from_raw_parts(data.cast(), len)
}

/// 执行与 [`slice_from_raw_parts`] 相同的功能，但返回的是原始可变切片，而不是原始的不可变切片。
///
///
/// 有关更多详细信息，请参见 [`slice_from_raw_parts`] 的文档。
///
/// 此函数是安全的，但实际上使用返回值是不安全的。
/// 有关切片的安全要求，请参见 [`slice::from_raw_parts_mut`] 的文档。
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // 在切片中的索引处分配值
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    from_raw_parts_mut(data.cast(), len)
}

/// 在相同类型的两个可变位置交换值，而无需取消初始化任何一个。
///
/// 但是对于以下两个例外，此函数在语义上等效于 [`mem::swap`]:
///
///
/// * 它对裸指针而不是引用进行操作。
/// 如果引用可用，则应首选 [`mem::swap`]。
///
/// * 两个指向的值可能会重叠。
/// 如果值确实重叠，则将使用 `x` 的内存重叠区域。
/// 在下面的第二个示例中对此进行了演示。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * 对于读取和写入，`x` 和 `y` 都必须为 [valid]。
///
/// * `x` 和 `y` 必须正确对齐。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
///
/// # Examples
///
/// 交换两个不重叠的区域:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // 这是 `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // 这是 `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// 交换两个重叠的区域:
///
/// ```
/// use std::ptr;
///
/// let mut array: [i32; 4] = [0, 1, 2, 3];
///
/// let array_ptr: *mut i32 = array.as_mut_ptr();
///
/// let x = array_ptr as *mut [i32; 3]; // 这是 `array[0..3]`
/// let y = unsafe { array_ptr.add(1) } as *mut [i32; 3]; // 这是 `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // 切片的索引 `1..3` 在 `x` 和 `y` 之间重叠。
///     // 合理的结果将是 `[2, 3]`，因此索引 `0..3` 为 `[1, 2, 3]` (与 `swap` 匹配的 `y`) ; 或将它们设为 `[0, 1]`，以使索引 `1..4` 为 `[0, 1, 2]` (与 `swap` 之前的 `x` 匹配)。
/////
///     // 定义此实现是为了做出后一种选择。
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // 给自己一些工作的空间。
    // 我们不必担心丢弃: `MaybeUninit` 在丢弃时什么也不做。
    let mut tmp = MaybeUninit::<T>::uninit();

    // 执行交换
    // SAFETY: 调用者必须保证 `x` 和 `y` 对写入有效并且正确对齐。
    // `tmp` 不能与 `x` 或 `y` 重叠，因为 `tmp` 只是作为单独的已分配对象在栈上分配的。
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` 和 `y` 可能重叠
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// 从 `x` 和 `y` 开始在两个内存区域之间交换 `count * size_of::<T>()` 字节。
/// 这两个区域必须 *不能* 重叠。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `x` 和 `y` 都必须为 [valid] 才能读取和写入 `count *
///   size_of::<T>()` 个字节。
///
/// * `x` 和 `y` 必须正确对齐。
///
/// * 从 `x` 开始的内存区域，大小为 `count *
///   size_of::<T>()` 字节不得与以 `y` 开始且大小相同的内存区域重叠。
///
/// 请注意，即使有效复制的大小 (`count * size_of::<T>()`) 是 `0`，指针也必须非空的并且正确对齐。
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SAFETY: 调用者必须保证 `x` 和 `y` 对写入有效并且正确对齐。
    //
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // NOTE(eddyb) SPIR-V 的逻辑寻址模型不允许将值任意重新解释为 (chunkable) 字节数组，并且 `swap_nonoverlapping_bytes` 中块优化中的循环很难重写回 (unoptimized) 直接交换实现，因此我们禁用它。
    //
    // FIXME(eddyb) 块优化还阻止 MIR 优化理解 `mem::replace`、`Option::take` 等 - 更好的整体解决方案可能是使 `swap_nonoverlapping` 成为内联函数，后端可以选择使用块优化来实现或不实现。
    //
    //
    //
    //
    //
    #[cfg(not(target_arch = "spirv"))]
    {
        // 仅对至少与块大小一样大的类型应用 `swap_nonoverlapping_bytes` 中的块优化，以避免对 codegen 产生负面影响。
        //
        if mem::size_of::<T>() >= 32 {
            // SAFETY: 调用者必须坚持 `swap_nonoverlapping` 的安全保证。
            unsafe { swap_nonoverlapping(x, y, 1) };
            return;
        }
    }

    // 直接交换，用于未经过块优化的情况。
    // SAFETY: 调用者必须保证 `x` 和 `y` 对于写入有效，正确对齐且不重叠。
    //
    unsafe {
        let z = read(x);
        copy_nonoverlapping(y, x, 1);
        write(y, z);
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // 这里的方法是利用 simd 有效地交换 x 和 y。
    // 测试表明，一次交换 32 字节或 64 字节对于 Intel Haswell E 处理器是最有效的。
    // 如果我们实际上不直接使用该结构体，则 LLVM 更能够优化 #[repr(simd)]。
    //
    //
    // FIXME repr(simd) 在脚本和 redox 上损坏
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // 遍历 x 和 y，一次复制 `Block` 优化器应针对大多数类型的 NB 完全展开循环
    // 我们不能使用 for 循环，因为 `range` impl 递归调用 `mem::swap`
    //
    let mut i = 0;
    while i + block_size <= len {
        // 创建一些未初始化的内存作为暂存空间在此声明 `t` 可以避免在未使用此循环时对齐栈
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: 作为 `i < len`，并且由于调用方必须保证 `x` 和 `y` 对于 `len` 字节有效，因此 `x + i` 和 `y + i` 必须是有效地址，这满足了 `add` 的安全保证。
        //
        //
        // 同样，调用者必须保证 `x` 和 `y` 对于写入有效，正确对齐且不重叠，从而满足 `copy_nonoverlapping` 的安全保证。
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // 将 t 用作临时缓冲区交换 x&y 字节的字节块。应将其优化为有效的 SIMD 操作 (如果可用)
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // 交换所有剩余字节
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SAFETY: 请参见之前的安全注释。
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// 将 `src` 移至指定的 `dst`，返回先前的 `dst` 值。
///
/// 这两个值都不会被丢弃。
///
/// 该函数在语义上等效于 [`mem::replace`]，除了它在裸指针上而不是在引用上运行。
/// 如果引用可用，则应首选 [`mem::replace`]。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `dst` 对于读写，必须为 [valid]。
///
/// * `dst` 必须正确对齐。
///
/// * `dst` 必须指向类型为 `T` 的正确初始化的值。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` 不需要 unsafe 块将具有相同的效果。
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SAFETY: 调用者必须保证 `dst` 有效，可以强制转换为变量引用 (对写入，对齐，初始化有效)，并且不能与 `src` 重叠，因为 `dst` 必须指向不同的分配对象。
    //
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // 不能重叠
    }
    src
}

/// 从 `src` 读取值而不移动它。这将使 `src` 中的内存保持不变。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `src` 必须为 [valid] 才能读取。
///
/// * `src` 必须正确对齐。如果不是这种情况，请使用 [`read_unaligned`]。
///
/// * `src` 必须指向类型为 `T` 的正确初始化的值。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// 手动实现 [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // 在 `tmp` 中的 `a` 处创建值的按位副本。
///         let tmp = ptr::read(a);
///
///         // 此时退出 (通过显式返回或调用 panics 的函数) 将导致 `tmp` 中的值被丢弃，而 `a` 仍引用相同的值。
///         // 如果 `T` 不是 `Copy`，则可能触发未定义的行为。
/////
/////
///
///         // 在 `a` 中的 `b` 处创建值的按位副本。
///         // 这是安全的，因为可变引用不能使用别名。
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // 如上所述，退出此处可能会触发未定义的行为，因为 `a` 和 `b` 引用了相同的值。
/////
///
///         // 将 `tmp` 移至 `b`。
///         ptr::write(b, tmp);
///
///         // `tmp` 已被移动 (`write` 拥有其第二个参数的所有权)，因此此处未隐式丢弃任何内容。
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## 归还值的所有权
///
/// `read` 不管 `T` 是否为 [`Copy`]，都会创建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，则同时使用返回的值和 `*src` 的值可能会违反内存安全性。
/// 请注意，将分配给 `*src` 视为一种用途，因为它将尝试丢弃 `*src` 处的值。
///
/// [`write()`] 可用于覆盖数据而不会导致数据被丢弃。
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` 现在指向与 `s` 相同的基础内存。
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // 分配给 `s2` 会导致其原始值被丢弃。
///     // 除此之外，由于已释放基础内存，因此不能再使用 `s`。
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // 分配给 `s` 将导致旧值再次被丢弃，从而导致未定义的行为。
/////
///     // s = String::from("bar"); // 错误
///
///     // `ptr::write` 可用于覆盖一个值而不丢弃它。
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: 调用者必须保证 `src` 对于读取有效。
    // `src` 不能与 `tmp` 重叠，因为 `tmp` 只是作为单独的已分配对象在栈上分配的。
    //
    //
    // 另外，由于我们只是将有效值写入 `tmp`，因此可以确保正确初始化它。
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// 从 `src` 读取值而不移动它。这将使 `src` 中的内存保持不变。
///
/// 与 [`read`] 不同，`read_unaligned` 使用未对齐的指针。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `src` 必须为 [valid] 才能读取。
///
/// * `src` 必须指向类型为 `T` 的正确初始化的值。
///
/// 与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`read_unaligned` 都会创建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，则同时使用返回值和 `*src` 处的值都可以 [violate memory safety][read-ownership]。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空。
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## 在 `packed` 结构体上
///
/// 尝试使用诸如 `&packed.unaligned as *const FieldType` 的表达式创建指向 `unaligned` 结构体字段的裸指针，然后再将其转换为裸指针，这会产生一个中间未对齐的引用。
///
/// 引用是临时的并且立即强制转换是无关紧要的，因为编译器始终希望引用正确对齐。
/// 结果，使用 `&packed.unaligned as *const FieldType` 会在程序中立即导致* undefined 行为 *。
///
/// 相反，您必须使用 [`ptr::addr_of!`](addr_of) 宏来创建指针。您可以将返回的指针与此函数一起使用。
///
/// 一个不执行的操作以及它与 `read_unaligned` 的关系的示例是:
///
/// ```
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// // 取一个未对齐的 32 位整数的地址。
/// // 与 `&packed.unaligned as *const _` 相比，它没有未定义的行为。
/// let unaligned = std::ptr::addr_of!(packed.unaligned);
///
/// let v = unsafe { std::ptr::read_unaligned(unaligned) };
/// assert_eq!(v, 0x01020304);
/// ```
///
/// 但是，例如使用 `packed.unaligned` 直接访问未对齐的字段是安全的。
///
/// # Examples
///
/// 从字节缓冲区读取 usize 值:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAFETY: 调用者必须保证 `src` 对于读取有效。
    // `src` 不能与 `tmp` 重叠，因为 `tmp` 只是作为单独的已分配对象在栈上分配的。
    //
    //
    // 另外，由于我们只是将有效值写入 `tmp`，因此可以确保正确初始化它。
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// 用给定值覆盖存储位置，而无需读取或丢弃旧值。
///
/// `write` 不会丢弃 `dst` 的内容。
/// 这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。
///
///
/// 此外，它不会丢弃 `src`。在语义上，`src` 被移到 `dst` 指向的位置。
///
/// 这适用于初始化未初始化的内存，或覆盖以前是 [`read`] 的内存。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `dst` 必须为 [valid] 进行写入。
///
/// * `dst` 必须正确对齐。如果不是这种情况，请使用 [`write_unaligned`]。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// 手动实现 [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // 在 `tmp` 中的 `a` 处创建值的按位副本。
///         let tmp = ptr::read(a);
///
///         // 此时退出 (通过显式返回或调用 panics 的函数) 将导致 `tmp` 中的值被丢弃，而 `a` 仍引用相同的值。
///         // 如果 `T` 不是 `Copy`，则可能触发未定义的行为。
/////
/////
///
///         // 在 `a` 中的 `b` 处创建值的按位副本。
///         // 这是安全的，因为可变引用不能使用别名。
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // 如上所述，退出此处可能会触发未定义的行为，因为 `a` 和 `b` 引用了相同的值。
/////
///
///         // 将 `tmp` 移至 `b`。
///         ptr::write(b, tmp);
///
///         // `tmp` 已被移动 (`write` 拥有其第二个参数的所有权)，因此此处未隐式丢弃任何内容。
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // 我们直接调用内联函数是为了避免在生成的代码中调用函数，因为 `intrinsics::copy_nonoverlapping` 是包装函数。
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SAFETY: 调用者必须保证 `dst` 对写入有效。
    // `dst` `src` 不能与 `src` 重叠，因为当 `src` 属于此函数时，调用方可以对其进行灵活访问。
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// 用给定值覆盖存储位置，而无需读取或丢弃旧值。
///
/// 与 [`write()`] 不同，指针可能未对齐。
///
/// `write_unaligned` 不会丢弃 `dst` 的内容。这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。
///
/// 此外，它不会丢弃 `src`。在语义上，`src` 被移到 `dst` 指向的位置。
///
/// 这适用于初始化未初始化的内存，或覆盖以前用 [`read_unaligned`] 读取的内存。
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `dst` 必须为 [valid] 进行写入。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空。
///
/// [valid]: self#safety
///
/// ## 在 `packed` 结构体上
///
/// 尝试使用诸如 `&packed.unaligned as *const FieldType` 的表达式创建指向 `unaligned` 结构体字段的裸指针，然后再将其转换为裸指针，这会产生一个中间未对齐的引用。
///
/// 引用是临时的并且立即强制转换是无关紧要的，因为编译器始终希望引用正确对齐。
/// 结果，使用 `&packed.unaligned as *const FieldType` 会在程序中立即导致* undefined 行为 *。
///
/// 相反，您必须使用 [`ptr::addr_of_mut!`](addr_of_mut) 宏来创建指针。您可以将返回的指针与此函数一起使用。
///
/// 如何做到这一点以及这与 `write_unaligned` 的关系的一个例子是:
///
/// ```
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// // 取一个未对齐的 32 位整数的地址。
/// // 与 `&packed.unaligned as *mut _` 相比，它没有未定义的行为。
/// let unaligned = std::ptr::addr_of_mut!(packed.unaligned);
///
/// unsafe { std::ptr::write_unaligned(unaligned, 42) };
///
/// assert_eq!({packed.unaligned}, 42); // `{...}` 强制复制字段，而不创建引用。
/// ```
///
/// 然而，直接使用例如 `packed.unaligned` 访问未对齐的字段是安全的 (如上面的 `assert_eq!` 所示)。
///
/// # Examples
///
/// 将 usize 值写入字节缓冲区:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SAFETY: 调用者必须保证 `dst` 对写入有效。
    // `dst` `src` 不能与 `src` 重叠，因为当 `src` 属于此函数时，调用方可以对其进行灵活访问。
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // 我们直接调用内联函数以避免在生成的代码中进行函数调用。
        intrinsics::forget(src);
    }
}

/// 对 `src` 的值进行易失性读取，而无需移动它。这将使 `src` 中的内存保持不变。
///
/// 易失性操作旨在作用于 I/O 存储器，并保证编译器不会在其他易失性操作中对易失性操作进行清除或重新排序。
///
/// # Notes
///
/// Rust 当前没有严格和正式定义的内存模型，因此 "volatile" 此处所指的确切语义会随时间而变化。
/// 话虽如此，其语义几乎总是以与 [C11 对 volatile 的定义][c11] 相似的方式结束。
///
/// 编译器不应更改易失性存储器操作的相对顺序或数量。
/// 但是，零大小类型 (例如，如果将零大小类型传递给 `read_volatile`) 上的易失性存储器操作为无操作，可以忽略。
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `src` 必须为 [valid] 才能读取。
///
/// * `src` 必须正确对齐。
///
/// * `src` 必须指向类型为 `T` 的正确初始化的值。
///
/// 与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`read_volatile` 都会创建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，则同时使用返回值和 `*src` 处的值都可以 [violate memory safety][read-ownership]。
/// 但是，几乎可以肯定地将非 [`Copy`] 类型存储在易失性存储器中。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// 就像在 C 语言中一样，操作是否易失性与涉及从多个线程进行并发访问的问题无关。在这方面，易失性访问的行为与非原子访问完全相同。
///
/// 特别是，`read_volatile` 与任何对同一位置的写操作之间的争夺是未定义的行为。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // 不要 panic，以保持代码生成的影响较小。
        abort();
    }
    // SAFETY: 调用者必须坚持 `volatile_load` 的安全保证。
    unsafe { intrinsics::volatile_load(src) }
}

/// 使用给定值对存储单元执行易失性写操作，而无需读取或丢弃旧值。
///
/// 易失性操作旨在作用于 I/O 存储器，并保证编译器不会在其他易失性操作中对易失性操作进行清除或重新排序。
///
/// `write_volatile` 不会丢弃 `dst` 的内容。这是安全的，但可能会泄漏分配或资源，因此应注意不要覆盖应丢弃的对象。
///
/// 此外，它不会丢弃 `src`。在语义上，`src` 被移到 `dst` 指向的位置。
///
/// # Notes
///
/// Rust 当前没有严格和正式定义的内存模型，因此 "volatile" 此处所指的确切语义会随时间而变化。
/// 话虽如此，其语义几乎总是以与 [C11 对 volatile 的定义][c11] 相似的方式结束。
///
/// 编译器不应更改易失性存储器操作的相对顺序或数量。
/// 但是，零大小类型 (例如，如果将零大小类型传递给 `write_volatile`) 上的易失性存储器操作为无操作，可以忽略。
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `dst` 必须为 [valid] 进行写入。
///
/// * `dst` 必须正确对齐。
///
/// 请注意，即使 `T` 的大小为 `0`，指针也必须非空且正确对齐。
///
/// [valid]: self#safety
///
/// 就像在 C 语言中一样，操作是否易失性与涉及从多个线程进行并发访问的问题无关。在这方面，易失性访问的行为与非原子访问完全相同。
///
/// 特别是，`write_volatile` 与同一位置上的任何其他操作 (读取或写入) 之间的争夺是未定义的行为。
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // 不要 panic，以保持代码生成的影响较小。
        abort();
    }
    // SAFETY: 调用者必须坚持 `volatile_store` 的安全保证。
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// 对齐指针 `p`。
///
/// 计算必须应用于指针 `p` 的偏移量 (根据 `stride` 步幅)，以便指针 `p` 与 `a` 对齐。
///
/// Note: 此实现已针对非 panic 进行了精心设计。到 panic 是 UB。
/// 此处唯一可以进行的更改是 `INV_TABLE_MOD_16` 及其关联常量的更改。
///
/// 如果我们决定允许使用非 2 的幂的 `a` 调用内联函数，那么仅更改为幼稚的实现而不是尝试使其适应这种变化可能会更明智。
///
///
/// 如有任何疑问，请发送至 @nagisa。
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): 在 opt 级别 <= 上，直接使用这些内联函数可显着改善代码生成
    // 1，其中未内联这些操作的方法版本。
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// 计算 `x` 模 `m` 的乘法模逆。
    ///
    /// 此实现是针对 `align_offset` 量身定制的，并具有以下先决条件:
    ///
    /// * `m` 是二的幂;
    /// * `x < m`; (如果使用 `x ≥ m`，请改为传入 `x % m`)
    ///
    /// 此函数的实现不得为 panic。Ever.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// 乘模逆矩阵模 2⁴=16。
        ///
        /// 注意，该表不包含不存在反值的值 (例如，对于 `0⁻¹ mod 16`，`2⁻¹ mod 16` 等)。
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// `INV_TABLE_MOD_16` 的模数。
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SAFETY: `m` 必须为 2 的幂，因此不能为零。
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // 我们使用以下公式迭代 "up":
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2 - xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // 直到 2²ⁿ ≥ m。然后，我们可以通过取结果 `mod m` 减少到所需的 `m`。
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y = y * (2 - xy) mod n
                //
                // 注意，这里我们有意使用包装操作-原始公式使用减法 `mod n`。
                // 改用 `mod usize::MAX` 完全可以，因为无论如何我们将结果 `mod n` 放在最后。
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAFETY: `a` 为 2 的幂，因此非零。
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` 通过 `-p (mod a)` 可以更简单地计算大小写，但是这样做会限制 LLVM 选择 `lea` 之类的指令的能力。相反，我们计算
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // 它围绕承重来分配操作，但是对 `and` 进行了充分的模拟，以使 LLVM 能够利用它所了解的各种优化。
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // 已经对齐。Yay!
        return 0;
    } else if stride == 0 {
        // 如果指针未对齐，并且元素大小为零，则将没有任何元素可以对齐指针。
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SAFETY: a 是 2 的幂，因此非零。stride == 0 情况已在上面处理。
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAFETY: gcdpow 的上限上限是 usize 中的位数。
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAFETY: gcd 始终大于或等于 1。
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // 该分支求解以下线性同余方程:
        //
        // ` p + so = 0 mod a `
        //
        // `p` 这是指针值，`s`-`T` 的步幅，`o` 在 `T` 中的偏移量，`a` - 所请求的对齐方式。
        //
        // 使用 `g = gcd(a, s)`，并且上面的条件断言 `p` 也可以被 `g` 整除，我们可以表示 `a' = a/g`，`s' = s/g`，`p' = p/g`，那么它等效于:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // 第一项是 "the relative alignment of `p` to `a`" (除以 `g`)，第二项是 "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (再次除以 `g`)。
        //
        // 如果 `a` 和 `s` 不是互质的，则 `g` 的除法对于使逆结构良好是必要的。
        //
        // 此外，此解决方案产生的结果不是 "minimal"，因此必须获得结果 `o mod lcm(s, a)`。我们可以只用 `a'` 代替 `lcm(s, a)`。
        //
        //
        //
        //
        //

        // SAFETY: `gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SAFETY: `a2` 不为零。
        // 将 `a` 移位 `gcdpow` 不能移出 `a` 中的任何设置位 (其中只有一位)。
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SAFETY: `gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAFETY: `gcdpow` 的上限不大于 `a` 的尾随 0 位的数量。
        // 此外，减法不会溢出，因为 `a2 = a >> gcdpow` 将始终严格大于 `(p % a) >> gcdpow`。
        //
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAFETY: 如上所述，`a2` 是 2 的幂。
        // `s2` 严格小于 `a2`，因为 `(s % a) >> gcdpow` 严格小于 `a >> gcdpow`。
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // 根本无法对齐。
    usize::MAX
}

/// 比较裸指针是否相等。
///
/// 这与使用 `==` 运算符相同，但泛型较少:
/// 参数必须是 `*const T` 裸指针，而不是任何实现 `PartialEq` 的东西。
///
/// 这可用于按地址比较 `&T` 引用 (隐式强制为 `*const T`)，而不是比较它们指向的值 (`PartialEq for &T` 实现的作用)。
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// 切片还通过其长度 (胖指针) 进行比较:
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits 的实现方式也进行了比较:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // 指针具有相等的地址。
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // 对象具有相等的地址，但是 `Trait` 具有不同的实现。
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // 将引用转换为 `*const u8` 时，将按地址进行比较。
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// 散列一个裸指针。
///
/// 这可用于通过其地址而不是其指向的值 (`Hash for &T` 实现的作用) 对 `&T` 引用 (隐式强制为 `*const T`) 进行哈希处理。
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// 函数指针的 Impls
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR 需要使用 asize 中间转换，以便将源函数指针的地址空间保留在最终函数指针中。
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                //
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR 需要使用 asize 中间转换，以便将源函数指针的地址空间保留在最终函数指针中。
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                //
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // 没有参数为 0 的可变参数函数
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// 创建一个 `const` 裸指针到一个位置，而无需创建中间引用。
///
/// 仅当指针正确对齐并指向初始化数据时，才允许使用 `&`/`&mut` 创建引用。
/// 对于那些不满足要求的情况，应改用裸指针。
/// 但是，`&expr as *const _` 在将其强制转换为裸指针之前会创建一个引用，并且该引用与所有其他引用都遵循相同的规则。
///
/// 该宏可以创建一个裸指针，而无需先创建一个引用。
///
/// 但是请注意，`addr_of!(expr)` 中的 `expr` 仍受所有常规规则的约束。
/// 特别是，`addr_of!(*ptr::null())` 是未定义行为，因为它解引用空指针。
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` 会导致未对齐的引用，从而成为未定义的行为!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
/// 有关如何创建指向未初始化数据的指针，请参见 [`addr_of_mut`]。
/// 用 `addr_of` 这样做没有多大意义，因为人们只能读取数据，这将是未定义行为。
///
///
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// 创建一个 `mut` 裸指针到一个位置，而无需创建中间引用。
///
/// 仅当指针正确对齐并指向初始化数据时，才允许使用 `&`/`&mut` 创建引用。
/// 对于那些不满足要求的情况，应改用裸指针。
/// 但是，`&mut expr as *mut _` 在将其强制转换为裸指针之前会创建一个引用，并且该引用与所有其他引用都遵循相同的规则。
///
/// 该宏可以创建一个裸指针，而无需先创建一个引用。
///
/// 但请注意，`addr_of_mut!(expr)` 中的 `expr` 仍受所有常规规则的约束。
/// 特别是，`addr_of_mut!(*ptr::null_mut())` 是未定义行为，因为它解引用空指针。
///
/// # Examples
///
/// **创建指向未对齐数据的指针:**
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` 会导致未对齐的引用，从而成为未定义的行为!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` 强制复制字段，而不创建引用。
/// ```
///
/// **创建指向未初始化数据的指针:**
///
/// ```rust
/// use std::{ptr, mem::MaybeUninit};
///
/// struct Demo {
///     field: bool,
/// }
///
/// let mut uninit = MaybeUninit::<Demo>::uninit();
/// // `&uninit.as_mut().field` 将创建对未初始化的 `bool` 的引用，因此是未定义的行为!
/////
/// let f1_ptr = unsafe { ptr::addr_of_mut!((*uninit.as_mut_ptr()).field) };
/// unsafe { f1_ptr.write(true); }
/// let init = unsafe { uninit.assume_init() };
/// ```
///
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}