use alloc::string::String;
use core::mem::transmute;
use core::panic::BoxMeUp;
use core::ptr::copy_nonoverlapping;

const ANDROID_SET_ABORT_MESSAGE: &[u8] = b"android_set_abort_message\0";
type SetAbortMessageType = unsafe extern "C" fn(*const libc::c_char) -> ();

// 将终止消息转发到 libc 的 android_set_abort_message。
// 我们尽最大努力填充消息，但是由于该函数可能已经作为失败分配的一部分被调用，因此可能无法这样做。
//
// core 的一些方法是故意避免的 (例如 try_reserve)，因为这些方法依赖于 rust_eh_personality 的正确解析，它在 panic_abort 中松散地定义。
//
//
// 弱解析 android_set_abort_message 的符号。此函数仅适用于 API >= 21。
//
//
pub(crate) unsafe fn android_set_abort_message(payload: *mut &mut dyn BoxMeUp) {
    let func_addr =
        libc::dlsym(libc::RTLD_DEFAULT, ANDROID_SET_ABORT_MESSAGE.as_ptr() as *const libc::c_char)
            as usize;
    if func_addr == 0 {
        return;
    }

    let payload = (*payload).get();
    let msg = match payload.downcast_ref::<&'static str>() {
        Some(msg) => msg.as_bytes(),
        None => match payload.downcast_ref::<String>() {
            Some(msg) => msg.as_bytes(),
            None => &[],
        },
    };
    if msg.is_empty() {
        return;
    }

    // 分配一个新缓冲区以附加空字节。
    let size = msg.len() + 1usize;
    let buf = libc::malloc(size) as *mut libc::c_char;
    if buf.is_null() {
        return; // 分配失败
    }
    copy_nonoverlapping(msg.as_ptr(), buf as *mut u8, msg.len());
    buf.offset(msg.len() as isize).write(0);

    let func = transmute::<usize, SetAbortMessageType>(func_addr);
    func(buf);
}