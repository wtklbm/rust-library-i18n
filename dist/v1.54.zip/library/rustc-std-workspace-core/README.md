# `rustc-std-workspace-core` crate

crate 是一个填充码，空的 crate 仅依赖于 `libcore` 并重导出其所有内容。
crate 是授权标准库依赖 crates.io 的 crates 的关键

标准库所依赖的 crates.io 上的 Crates 需要依赖于 crates.io 上的 `rustc-std-workspace-core` crate，它为空。

我们使用 `[patch]` 将其覆盖到此仓库中的 crate。
结果，crates.io 上的 crates 将向该仓库中定义的版本 `libcore` 绘制一个依赖项 edge。
那应该绘制所有依赖项 edges，以确保 Cargo 成功构建 crates!

请注意，crates.io 上的 crates 必须依赖于名称为 `core` 的 crate 才能正常工作。为此，他们可以使用:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

通过使用 `package` 键，crate 重命名为 `core`，这意味着它看起来像

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

当 Cargo 调用编译器时，满足了编译器注入的隐式 `extern crate core` 指令。




