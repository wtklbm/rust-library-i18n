use core::ffi::c_void;
use core::fmt;

/// 检查当前调用栈，将所有活动帧传递到提供的闭包中以计算栈跟踪。
///
/// 该函数是该库在计算程序的栈跟踪时的主力。给定的闭包 `cb` 是 `Frame` 的实例，这些实例表示有关栈上该调用帧的信息。
/// 闭包以自上而下的方式生成框架 (最近称为函数优先)。
///
/// 闭包的返回值指示回溯是否应继续。`false` 的返回值将终止回溯并立即返回。
///
/// 一旦获取了 `Frame`，您可能希望调用 `backtrace::resolve` 将 `ip` (指令指针) 或符号地址转换为 `Symbol`，通过该 `Symbol` 可以了解名称或者文件名 / 行号。
///
///
/// 请注意，这是一个相对较为灵活的函数，例如，如果您想捕获回溯以供以后检查，则 `Backtrace` 类型可能更合适。
///
/// # 必备功能
///
/// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
///
/// # Panics
///
/// 这个函数尽量避免 panic，但是如果 `cb` 提供了 panics，则某些平台将强制使用双 panic 来终止进程。
/// 某些平台使用 C 库，该库在内部使用无法解开的回调，因此从 `cb` 恐慌可能会触发进程终止。
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // 继续回溯
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// 与 `trace` 相同，只是不安全，因为它未同步。
///
/// 该函数没有同步保证人，但是当未编译此 crate 的 `std` 功能时可用。
/// 有关更多文档和示例，请参见 `trace` 函数。
///
/// # Panics
///
/// 有关 `cb` 恐慌的注意事项，请参见 `trace` 上的信息。
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// 代表回溯的一帧的 trait 产生给此 crate 的 `trace` 函数。
///
/// 跟踪函数的闭包将是产生的帧，并且实际上将分派该帧，因为直到运行时才知道底层实现。
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// 返回此帧的当前指令指针。
    ///
    /// 通常，这是在框架中执行的下一条指令，但并非所有实现都以 100% 的精度列出该指令 (但通常非常接近)。
    ///
    ///
    /// 建议将此值传递给 `backtrace::resolve`，以将其转换为符号名称。
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// 返回此帧的当前栈指针。
    ///
    /// 如果后端无法恢复该帧的栈指针，则返回空指针。
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// 返回此函数框架的起始符号地址。
    ///
    /// 这将尝试将 `ip` 返回的指令指针回退到函数的开头，并返回该值。
    ///
    /// 但是，在某些情况下，后端只会从此函数返回 `ip`。
    ///
    /// 如果 `backtrace::resolve` 在上面给定的 `ip` 上失败，则有时可以使用返回值。
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// 返回框架所属模块的基地址。
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // 首先需要确保 Miri 优先于主机平台
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // 仅在 dbghelp 中使用象征
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}
