use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// 解析符号的地址，然后将符号传递给指定的闭包。
///
/// 该函数将在局部符号表，动态符号表或 DWARF 调试信息 (取决于激活的实现) 等区域中查找给定地址，以查找要产生的符号。
///
///
/// 如果无法执行解析，则可能不会调用闭包，对于内联函数，也可能会多次调用。
///
/// 产生的符号表示在指定的 `addr` 处的执行，并返回该地址的 file/line 对 (如果有)。
///
/// 请注意，如果您有 `Frame`，则建议使用 `resolve_frame` 函数而不是 `Frame` 函数。
///
/// # 必备功能
///
/// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
///
/// # Panics
///
/// 这个函数尽量避免 panic，但是如果 `cb` 提供了 panics，则某些平台将强制使用双 panic 来终止进程。
/// 某些平台使用 C 库，该库在内部使用无法解开的回调，因此从 `cb` 恐慌可能会触发进程终止。
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // 只看顶部框架
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// 将先前捕获的帧解析为符号，然后将符号传递给指定的闭包。
///
/// 该函数的功能与 `resolve` 相同，不同之处在于它使用 `Frame` 作为参数而不是地址。
/// 例如，这可以允许回溯的某些平台实现提供更准确的符号信息或有关内联帧的信息。
///
/// 如果可以的话，建议使用此功能。
///
/// # 必备功能
///
/// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
///
/// # Panics
///
/// 这个函数尽量避免 panic，但是如果 `cb` 提供了 panics，则某些平台将强制使用双 panic 来终止进程。
/// 某些平台使用 C 库，该库在内部使用无法解开的回调，因此从 `cb` 恐慌可能会触发进程终止。
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // 只看顶部框架
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// 来自栈帧的 IP 值通常是 (always?) 实际栈跟踪调用之后的指令。
// 对此进行符号化表示，导致 filename/line 数字在该函数的结尾附近，如果它在函数的末尾提前一个，并且可能成为空白。
//
// 在所有平台上，似乎基本上都是这种情况，因此我们总是从已解析的 ip 中减去一个，以将其解析为上一个调用指令，而不是返回到该指令。
//
//
// 理想情况下，我们不会这样做。
// 理想情况下，我们将要求 `resolve` API 的调用者在此处手动执行 -1，并说明他们需要 *previous* 指令 (而不是当前指令) 的位置信息。
// 理想情况下，如果我们确实是下一条指令或当前指令的地址，则也应在 `Frame` 上公开。
//
// 就目前而言，尽管这是一个非常特殊的问题，所以我们在内部始终总是减去一个。
// 消费者应该继续努力并取得不错的成绩，所以我们应该足够好。
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// 与 `resolve` 相同，只是不安全，因为它未同步。
///
/// 该函数没有同步保证人，但是当未编译此 crate 的 `std` 功能时可用。
/// 有关更多文档和示例，请参见 `resolve` 函数。
///
/// # Panics
///
/// 有关 `cb` 恐慌的注意事项，请参见 `resolve` 上的信息。
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// 与 `resolve_frame` 相同，只是不安全，因为它未同步。
///
/// 该函数没有同步保证人，但是当未编译此 crate 的 `std` 功能时可用。
/// 有关更多文档和示例，请参见 `resolve_frame` 函数。
///
/// # Panics
///
/// 有关 `cb` 恐慌的注意事项，请参见 `resolve_frame` 上的信息。
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait 表示文件中符号的分辨率。
///
/// trait 作为给 `backtrace::resolve` 函数的闭包的 trait 对象产生，并且实际上是分派的，因为未知其背后是哪种实现。
///
///
/// 符号可以提供有关函数的上下文信息，例如名称，文件名，行号，精确地址等。
/// 并非所有信息都始终在符号中可用，因此，所有方法都返回 `Option`。
///
///
pub struct Symbol {
    // TODO: 这个生命周期的界限最终需要坚持到 `Symbol`，但这是一个重大突破。
    // 现在，这是安全的，因为 `Symbol` 仅由引用分发，并且不能被克隆。
    //
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// 返回此函数的名称。
    ///
    /// 返回的结构体可用于查询有关符号名称的各种属性:
    ///
    ///
    /// * `Display` 的实现将打印出 demangled 符号。
    /// * 可以访问符号的原始 `str` 值 (如果它是有效的 utf-8)。
    /// * 可以访问符号名称的原始字节。
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// 返回此函数的起始地址。
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// 返回原始文件名作为切片。
    /// 这主要对 `no_std` 环境有用。
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// 返回此符号当前正在执行的位置的列号。
    ///
    /// 当前只有 gimli 在此处提供一个值，即使 `filename` 返回 `Some` 也是如此，因此也要受到类似的警告。
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// 返回此符号当前正在执行的行号。
    ///
    /// 如果 `filename` 返回 `Some`，则此返回值通常为 `Some`，因此也有类似的警告。
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// 返回定义此函数的文件名。
    ///
    /// 当前仅在使用 libbacktrace 或 gimli 时才可用 (例如
    /// unix 其他平台) 以及使用 debuginfo 编译二进制文件时。
    /// 如果这两个条件都不满足，则可能会返回 `None`。
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // 如果将损坏的符号解析为 Rust 失败，则可能是解析的 C++ 符号。
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // 确保保持这个零大小，这样 `cpp_demangle` 特性在禁用时没有成本。
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// 符号名称周围的包装器，以提供符合人体工程学的访问器来访问已分解的名称，原始字节，原始字符串等。
///
// 未启用 `cpp_demangle` 功能时，请使用无效代码。
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// 从原始基础字节创建一个新的符号名称。
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// 如果符号有效 utf-8，则将原始 (mangled) 符号名称返回为 `str`。
    ///
    /// 如果需要 demangled 版本，请使用 `Display` 实现。
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// 以字节列表形式返回原始符号名称
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // 如果被检索的符号实际上不是有效的，这可能会打印出来，所以通过不向外传播错误来优雅地处理这里的错误。
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// 尝试回收用于表示地址的缓存内存。
///
/// 此方法将尝试释放已全局缓存或在线程中缓存的任何数据结构，这些数据结构通常表示已解析的 DWARF 信息或类似信息。
///
///
/// # Caveats
///
/// 尽管此函数始终可用，但实际上在大多数实现中都没有任何作用。
/// 诸如 dbghelp 或 libbacktrace 之类的库不提供释放状态和管理分配的内存的功能。
/// 目前，此 crate 的 `gimli-symbolize` 功能是该函数起作用的唯一功能。
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
        any(not(backtrace_in_libstd), feature = "backtrace"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}
