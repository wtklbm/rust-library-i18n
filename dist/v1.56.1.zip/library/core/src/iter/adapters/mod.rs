use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccessNoCoerce;

#[unstable(feature = "iter_zip", issue = "83574")]
pub use self::zip::zip;

/// 此 trait 在以下条件下提供对迭代器适配器管道中源级的传递访问
/// * 迭代器源 `S` 本身实现 `SourceIter<Source = S>`
/// * 在源和管道使用者之间的管道中，每个适配器都有 trait 的委派实现。
///
/// 当源是拥有的迭代器结构体 (通常称为 `IntoIter`) 时，这对于专门化 [`FromIterator`] 实现或在迭代器部分用尽之后恢复其余元素很有用。
///
///
/// 注意，实现不一定必须提供对管道最内层源的访问。有状态的中间适配器可能会急切地评估管道的一部分，并将其内部存储公开为源。
///
/// trait 是不安全的，因为实现者必须维护其他安全属性。
/// 有关详细信息，请参见 [`as_inner`]。
///
/// # Examples
///
/// 检索部分消耗的源:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
#[doc(hidden)]
pub unsafe trait SourceIter {
    /// 迭代器管道中的源阶段。
    type Source: Iterator;

    /// 检索迭代器管道的源。
    ///
    /// # Safety
    ///
    /// 的实现必须为其生命周期返回相同的可变引用，除非被调用者替换。
    /// 调用者只有在停止迭代并在提取源之后丢弃迭代器管道时才可以替换引用。
    ///
    /// 这意味着迭代器适配器可以依赖在迭代过程中未更改的源，但不能在其 Drop 实现中依赖它。
    ///
    /// 实现此方法意味着适配器放弃对其源的仅私有访问，并且只能依赖基于方法接收者类型的保证。
    /// 缺少受限制的访问还要求适配器即使在访问其内部时也必须维护源的公共 API。
    ///
    /// 依次，调用者必须期望源处于与其公共 API 一致的任何状态，因为位于源和源之间的适配器具有相同的访问权限。
    /// 特别是适配器可能消耗了比严格需要更多的元素。
    ///
    /// 这些要求的总体目标是让管道的使用者使用
    /// * 迭代停止后保留在源中的所有内容
    /// * 推进消费迭代器而变得未使用的内存
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// 只要基础迭代器产生 `Result::Ok` 值，迭代器适配器就产生输出。
///
///
/// 如果遇到错误，则迭代器将停止并存储错误。
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// 处理给定的迭代器，就像产生 `T` 而不是 `Result<T, _>` 一样。
/// 任何错误都将停止内部迭代器，并且总体结果将是一个错误。
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Output = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I, E> SourceIter for ResultShunt<'_, I, E>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // SAFETY: 将不安全的函数转发到具有相同要求的不安全的函数
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

// SAFETY: ResultShunt::next 调用 I::find，它必须提前 `iter` 才能返回 `Some(_)`。
// 由于 `iter` 的类型为 `I: InPlaceIterable`，因此可以保证至少一个项将从基础源中移出。
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I, T, E> InPlaceIterable for ResultShunt<'_, I, E> where
    I: Iterator<Item = Result<T, E>> + InPlaceIterable
{
}
