//! 编译器内部函数。
//!
//! 相应的定义在 `compiler/rustc_codegen_llvm/src/intrinsic.rs` 中。
//! 相应的 const 实现在 `compiler/rustc_mir/src/interpret/intrinsics.rs` 中
//!
//! # 常量内部函数
//!
//! Note: 对内部函数常量的任何更改都应与语言团队讨论。
//! 这包括常量稳定性的变化。
//!
//! 为了使内部函数在编译时可用，需要将实现从 <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> 复制到 `compiler/rustc_mir/src/interpret/intrinsics.rs` 并将 `#[rustc_const_unstable(feature = "foo", issue = "01234")]` 添加到内部函数。
//!
//!
//! 如果应该从具有 `rustc_const_stable` 属性的 `const fn` 使用内部函数，则内部函数的属性也必须为 `rustc_const_stable`。
//! 如果没有 T-lang 咨询，则不应进行此类更改，因为它会将语言中的功能烘焙到没有编译器支持的情况下无法在用户代码中复制。
//!
//! # Volatiles
//!
//! volatile 内部函数提供旨在作用于 I/O 内存的操作，并保证编译器不会在其他 volatile 内部函数之间对它们进行重新排序。请参见 [[volatile]] 上的 LLVM 文档。
//!
//! [volatile]: https://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! 原子内部函数对机器字提供常见的原子操作，并具有多种可能的存储顺序。它们遵循与 C++ 11 相同的语义。请参见 [[atomics]] 上的 LLVM 文档。
//!
//! [atomics]: https://llvm.org/docs/Atomics.html
//!
//! 关于内存排序的快速回顾:
//!
//! * 获取 - 获取锁的障碍。屏障之后将进行后续的读取和写入。
//! * 释放 - 释放锁的障碍物。之前的读取和写入发生在该屏障之前。
//! * 顺序一致 - 顺序一致的操作可保证按顺序进行。这是处理原子类型的标准模式，等效于 Java 的 `volatile`。
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// 这些导入用于简化文档内链接
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SAFETY: 请参见 `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // 注意，这些内部函数采用裸指针，因为它们会使别名内存发生可变的，这对于 `&` 或 `&mut` 均无效。
    //

    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::Acquire`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::Release`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 作为 `success` 和 [`Ordering::Acquire`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `success` 和 [`Ordering::Acquire`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::Acquire`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::Acquire`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::Release`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 作为 `success` 和 [`Ordering::Acquire`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 用作 `success` 和 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    ///
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `success` 和 [`Ordering::Acquire`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::Acquire`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// 如果当前值与 `old` 值相同，则存储一个值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 作为 `success` 和 [`Ordering::Relaxed`] 作为 `failure` 参数，可以通过 `compare_exchange_weak` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// 加载指针的当前值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `load` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// 加载指针的当前值。
    ///
    /// 通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `load` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// 加载指针的当前值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `load` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// 将值存储在指定的存储位置。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `store` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// 将值存储在指定的存储位置。
    ///
    /// 通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `store` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// 将值存储在指定的存储位置。
    ///
    /// 通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `store` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// 将值存储在指定的内存位置，并返回旧值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `swap` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// 将值存储在指定的内存位置，并返回旧值。
    ///
    /// 通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `swap` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 将值存储在指定的内存位置，并返回旧值。
    ///
    /// 通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `swap` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 将值存储在指定的内存位置，并返回旧值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `swap` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 将值存储在指定的内存位置，并返回旧值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `swap` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 加到当前值，返回前一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_add` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// 加到当前值，返回前一个值。
    ///
    /// 通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_add` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 加到当前值，返回前一个值。
    ///
    /// 通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_add` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 加到当前值，返回前一个值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_add` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 加到当前值，返回前一个值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_add` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 从当前值减去，返回前一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_sub` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// 从当前值减去，返回前一个值。
    ///
    /// 通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_sub` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 从当前值减去，返回前一个值。
    ///
    /// 通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_sub` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 从当前值减去，返回前一个值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_sub` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 从当前值减去，返回前一个值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_sub` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 对当前值按位与，返回前一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_and` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// 对当前值按位与，返回前一个值。
    ///
    /// 通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_and` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 对当前值按位与，返回前一个值。
    ///
    /// 通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_and` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 对当前值按位与，返回前一个值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_and` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 对当前值按位与，返回前一个值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_and` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 对当前值按位与，返回前一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_nand` 方法在 [`AtomicBool`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// 对当前值按位与，返回前一个值。
    ///
    /// 通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_nand` 方法在 [`AtomicBool`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 对当前值按位与，返回前一个值。
    ///
    /// 通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_nand` 方法在 [`AtomicBool`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 对当前值按位与，返回前一个值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_nand` 方法在 [`AtomicBool`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 对当前值按位与，返回前一个值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_nand` 方法在 [`AtomicBool`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 按位或具有当前值，返回前一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_or` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位或具有当前值，返回前一个值。
    ///
    /// 通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_or` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位或具有当前值，返回前一个值。
    ///
    /// 通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_or` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位或具有当前值，返回前一个值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_or` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 按位或具有当前值，返回前一个值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_or` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 与当前值按位异或，返回前一个值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 作为 `order` 传递，可以通过 `fetch_xor` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// 与当前值按位异或，返回前一个值。
    ///
    /// 通过将 [`Ordering::Acquire`] 作为 `order` 传递，可以通过 `fetch_xor` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 与当前值按位异或，返回前一个值。
    ///
    /// 通过将 [`Ordering::Release`] 作为 `order` 传递，可以通过 `fetch_xor` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 与当前值按位异或，返回前一个值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 作为 `order` 传递，可以通过 `fetch_xor` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 与当前值按位异或，返回前一个值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 作为 `order` 传递，可以通过 `fetch_xor` 方法在 [`atomic`] 类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 使用带符号的比较将当前值设为最大值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用带符号的比较将当前值设为最大值。
    ///
    /// 通过将 [`Ordering::Acquire`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用带符号的比较将当前值设为最大值。
    ///
    /// 通过将 [`Ordering::Release`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用带符号的比较将当前值设为最大值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 当前值的最大值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 使用带符号的比较将当前值设为最小值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用带符号的比较将当前值设为最小值。
    ///
    /// 通过将 [`Ordering::Acquire`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用带符号的比较将当前值设为最小值。
    ///
    /// 通过将 [`Ordering::Release`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用带符号的比较将当前值设为最小值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用带符号的比较将当前值设为最小值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 有符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 使用无符号比较，使用当前值的最小值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用无符号比较，使用当前值的最小值。
    ///
    /// 通过将 [`Ordering::Acquire`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用无符号比较，使用当前值的最小值。
    ///
    /// 通过将 [`Ordering::Release`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用无符号比较，使用当前值的最小值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用无符号比较，使用当前值的最小值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 传递为 `order`，可以通过 `fetch_min` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// 使用无符号比较将当前值设为最大值。
    ///
    /// 通过将 [`Ordering::SeqCst`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用无符号比较将当前值设为最大值。
    ///
    /// 通过将 [`Ordering::Acquire`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用无符号比较将当前值设为最大值。
    ///
    /// 通过将 [`Ordering::Release`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用无符号比较将当前值设为最大值。
    ///
    /// 通过将 [`Ordering::AcqRel`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// 使用无符号比较将当前值设为最大值。
    ///
    /// 通过将 [`Ordering::Relaxed`] 传递为 `order`，可以通过 `fetch_max` 方法在 [`atomic`] 无符号整数类型上使用此内部函数的稳定版本。
    /// 例如， [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` 内部函数是对代码生成器的提示，如果支持的话，它会插入一个预取指令。否则，它是无操作的。
    /// 预取对程序的行为没有影响，但可以更改其性能特征。
    ///
    /// `locality` 参数必须是一个常量整数，并且是时间局部性说明符，范围从 (0) (无局部性) 到 (3) (在缓存中极其局部化)。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` 内部函数是对代码生成器的提示，如果支持的话，它会插入一个预取指令。否则，它是无操作的。
    /// 预取对程序的行为没有影响，但可以更改其性能特征。
    ///
    /// `locality` 参数必须是一个常量整数，并且是时间局部性说明符，范围从 (0) (无局部性) 到 (3) (在缓存中极其局部化)。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` 内部函数是对代码生成器的提示，如果支持的话，它会插入一个预取指令。否则，它是无操作的。
    /// 预取对程序的行为没有影响，但可以更改其性能特征。
    ///
    /// `locality` 参数必须是一个常量整数，并且是时间局部性说明符，范围从 (0) (无局部性) 到 (3) (在缓存中极其局部化)。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` 内部函数是对代码生成器的提示，如果支持的话，它会插入一个预取指令。否则，它是无操作的。
    /// 预取对程序的行为没有影响，但可以更改其性能特征。
    ///
    /// `locality` 参数必须是一个常量整数，并且是时间局部性说明符，范围从 (0) (无局部性) 到 (3) (在缓存中极其局部化)。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// 原子 fence。
    ///
    /// 通过将 [`Ordering::SeqCst`] 传递为 `order`，可以在 [`atomic::fence`] 中获得此内部函数的稳定版本。
    ///
    ///
    pub fn atomic_fence();
    /// 原子 fence。
    ///
    /// 通过将 [`Ordering::Acquire`] 传递为 `order`，可以在 [`atomic::fence`] 中获得此内部函数的稳定版本。
    ///
    ///
    pub fn atomic_fence_acq();
    /// 原子 fence。
    ///
    /// 通过将 [`Ordering::Release`] 传递为 `order`，可以在 [`atomic::fence`] 中获得此内部函数的稳定版本。
    ///
    ///
    pub fn atomic_fence_rel();
    /// 原子 fence。
    ///
    /// 通过将 [`Ordering::AcqRel`] 传递为 `order`，可以在 [`atomic::fence`] 中获得此内部函数的稳定版本。
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// 仅编译器的内存屏障。
    ///
    /// 编译器绝不会在此障碍上对内存访问进行重新排序，但不会为此发出任何指令。
    /// 这适用于可能被抢占的同一线程上的操作，例如与信号处理程序进行交互时。
    ///
    /// 通过将 [`Ordering::SeqCst`] 传递为 `order`，可以在 [`atomic::compiler_fence`] 中获得此内部函数的稳定版本。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// 仅编译器的内存屏障。
    ///
    /// 编译器绝不会在此障碍上对内存访问进行重新排序，但不会为此发出任何指令。
    /// 这适用于可能被抢占的同一线程上的操作，例如与信号处理程序进行交互时。
    ///
    /// 通过将 [`Ordering::Acquire`] 传递为 `order`，可以在 [`atomic::compiler_fence`] 中获得此内部函数的稳定版本。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// 仅编译器的内存屏障。
    ///
    /// 编译器绝不会在此障碍上对内存访问进行重新排序，但不会为此发出任何指令。
    /// 这适用于可能被抢占的同一线程上的操作，例如与信号处理程序进行交互时。
    ///
    /// 通过将 [`Ordering::Release`] 传递为 `order`，可以在 [`atomic::compiler_fence`] 中获得此内部函数的稳定版本。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// 仅编译器的内存屏障。
    ///
    /// 编译器绝不会在此障碍上对内存访问进行重新排序，但不会为此发出任何指令。
    /// 这适用于可能被抢占的同一线程上的操作，例如与信号处理程序进行交互时。
    ///
    /// 通过将 [`Ordering::AcqRel`] 传递为 `order`，可以在 [`atomic::compiler_fence`] 中获得此内部函数的稳定版本。
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// 从函数附带的属性中获取其含义的 magic 内部函数。
    ///
    /// 例如，数据流使用它来注入静态断言，以便 `rustc_peek(potentially_uninitialized)` 实际上会再次检查数据流确实确实计算出该数据流在控制流中未初始化。
    ///
    ///
    /// 不应在编译器外部使用此内部函数。
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// 中止进程的执行。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// [`std::process::abort`](../../std/process/fn.abort.html) 如果可能，最好是首选，因为它的行为更用户友好且更稳定。
    ///
    ///
    /// `intrinsics::abort` 的当前实现是在大多数平台上调用无效指令。
    /// 在 Unix 上，进程可能会以 `SIGABRT`、`SIGILL`、`SIGTRAP`、`SIGSEGV` 或 `SIGBUS` 之类的信号终止。
    /// 不能保证精确的行为并且不稳定。
    ///
    ///
    ///
    pub fn abort() -> !;

    /// 通知优化器代码中的这一点不可访问，从而可以进行进一步的优化。
    ///
    /// 注意，这与 `unreachable!()` 宏非常不同：与执行 panics 的宏不同，到达带有此函数标记的代码是 *undefined 行为*。
    ///
    ///
    /// 这个 intrinsic 的稳定版本是 [`core::hint::unreachable_unchecked`]。
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// 通知优化器条件始终为真。
    /// 如果条件为假，则行为是不确定的。
    ///
    /// 没有为该内部函数生成任何代码，但是优化器将尝试在通过之间保留它 (及其条件)，这可能会干扰周围代码的优化并降低性能。
    /// 如果优化器可以自己发现不可变变量，或者不启用任何重要的优化，则不应使用该变量。
    ///
    /// 此内部函数没有稳定的对应对象。
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// 提示编译器分支条件很可能是正确的。
    /// 返回传递给它的值。
    ///
    /// 除与 `if` 语句一起使用外，其他任何使用都可能无效。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// 提示编译器分支条件可能为 false。
    /// 返回传递给它的值。
    ///
    /// 除与 `if` 语句一起使用外，其他任何使用都可能无效。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// 执行一个断点陷阱，以供调试器检查。
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn breakpoint();

    /// 类型的大小 (以字节为单位)。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 更具体地说，这是相同类型的连续项之间的字节偏移量，包括对齐填充。
    ///
    ///
    /// 这个 intrinsic 的稳定版本是 [`core::mem::size_of`]。
    ///
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// 类型的最小对齐方式。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    ///
    /// 这个 intrinsic 的稳定版本是 [`core::mem::align_of`]。
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// 类型的首选对齐方式。
    ///
    /// 此内部函数没有稳定的对应对象。
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// 引用值的大小 (以字节为单位)。
    ///
    /// 此内部函数的稳定版本为 [`mem::size_of_val`]。
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// 参考值的所需对齐方式。
    ///
    /// 这个 intrinsic 的稳定版本是 [`core::mem::align_of_val`]。
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// 获取包含类型名称的静态字符串切片。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    ///
    /// 这个 intrinsic 的稳定版本是 [`core::any::type_name`]。
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// 获取一个标识符，该标识符对于指定的类型是全局唯一的。
    /// 无论调用哪个 crate，此函数都将为类型返回相同的值。
    ///
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 这个 intrinsic 的稳定版本是 [`core::any::TypeId::of`]。
    ///
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// 如果 `T` 未定义，则无法执行的不安全函数的守卫:
    /// 这将静态地为 panic，或者什么也不做。
    ///
    /// 此内部函数没有稳定的对应对象。
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// 如果 `T` 不允许零初始化，则永远不能执行的不安全函数的守卫：这将静态 panic，或者什么也不做。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn assert_zero_valid<T>();

    /// 如果 `T` 具有无效的位模式，则永远不能执行的不安全函数的守卫：这将静态地 panic，或者什么也不做。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn assert_uninit_valid<T>();

    /// 获取对静态 `Location` 的引用，以指示在何处调用了它。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    ///
    /// 可以考虑使用 [`core::panic::Location::caller`]。
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// 将值移出作用域。而无需运行丢弃守卫。
    ///
    /// 这仅适用于 [`mem::forget_unsized`]。正常情况下，请改用 `forget` 为 `ManuallyDrop`。
    ///
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// 将一种类型的值的位重新解释为另一种类型。
    ///
    /// 两种类型都必须具有相同的大小。
    /// [invalid value](../../nomicon/what-unsafe-does.html) 既不是原始版本，也不是结果。
    ///
    /// `transmute` 在语义上等效于从一种类型到另一种类型的按位移动。它将位从源值复制到目标值，然后忘记原始值。
    /// 就像 `transmute_copy` 一样，它等同于 C 的引擎盖下的 `memcpy`。
    ///
    /// 由于 `transmute` 是按值运算，因此不必担心 *transmuted values 本身的对齐*。
    /// 与任何其他函数一样，编译器已经确保 `T` 和 `U` 都正确对齐。
    /// 但是，当将 *point 的值转换为其他位置*(例如指针，引用，boxes…) 时，调用者必须确保所指向的值正确对齐。
    ///
    /// `transmute` 是非常不安全的。有很多方法可以使用此函数来导致 [未定义的行为][ub]。`transmute` 应该是绝对不得已的方法。
    ///
    /// 在 `const` 上下文中转换指向整数的指针是 [未定义的行为][ub]。
    /// 任何将结果值用于整数运算的尝试都将终止常量评估。
    ///
    /// [nomicon](../../nomicon/transmutes.html) 具有其他文档。
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` 确实有一些用途。
    ///
    /// 将指针转换为函数指针。对于函数指针和数据指针具有不同大小的机器，这不是可移植的。
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// 延长生命周期或缩短不变的生命周期。这是高级的，非常不安全的 Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// 不要失望: `transmute` 的许多用途可以通过其他方式实现。
    /// 以下是 `transmute` 的常见应用程序，可以用更安全的结构替换它。
    ///
    /// 将原始 bytes(`&[u8]`) 转换为 `u32`，`f64` 等:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // 改用 `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // 或使用 `u32::from_le_bytes` 或 `u32::from_be_bytes` 指定字节顺序
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// 将指针变成 `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // 请改用 `as` 进行类型转换
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// 将 `*mut T` 变成 `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // 改用借用
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// 将 `&mut T` 变成 `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // 现在，将 `as` 放在一起并重新借用 - 请注意，`as` `as` 的链接不是可传递的
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// 将 `&str` 变成 `&[u8]`:
    ///
    /// ```
    /// // 这不是执行此操作的好方法。
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // 您可以使用 `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // 或者，如果您可以控制字符串，则只需使用字节字符串即可。
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// 将 `Vec<&T>` 变成 `Vec<Option<&T>>`。
    ///
    /// 要转换容器内容的内部类型，必须确保不违反容器的任何不变式。
    /// 对于 `Vec`，这意味着内部类型的大小和对齐方式都必须匹配。
    /// 其他容器可能依赖于类型，对齐方式甚至 `TypeId` 的大小，在这种情况下，在不违反容器不变式的情况下根本不可能进行转换。
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // 克隆 vector，因为稍后我们将重用它们
    /// let v_clone = v_orig.clone();
    ///
    /// // 使用 transmute: 这依赖于 `Vec` 的未指定数据布局，这是一个坏主意，并可能导致未定义的行为。
    /////
    /// // 但是，它是无副本的。
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // 这是建议的安全方法。
    /// // 但是，它确实将整个 vector 复制到一个新数组中。
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // 这是 "transmuting" 和 `Vec` 的正确无复制，不安全的方式，而无需依赖数据布局。
    /// // 我们不执行字面上的调用 `transmute`，而是执行指针强制转换，但是就将原始内部类型 (`&i32`) 转换为新的 (`Option<&i32>`) 而言，这具有所有相同的警告。
    /////
    /// // 除了上面提供的信息之外，还请查阅 [`from_raw_parts`] 文档。
    /////
    /// let v_from_raw = unsafe {
    // FIXME 在 vec_into_raw_parts 稳定后更新它
    ///     // 确保原始 vector 没有被丢弃。
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// 实现 `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // 有多种方法可以执行此操作，并且以下 (transmute) 方法存在多个问题。
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // 第一：转换不是安全类型; 它所检查的只是 T 和 U 的大小相同。
    ///         // 其次，在这里，您有两个指向同一内存的可变引用。
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // 这消除了类型安全问题; `&mut *`* 仅 *将为您提供 `&mut T` 或 `* mut T` 的 `&mut T`。
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // 但是，您仍然有两个指向同一内存的可变引用。
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // 这就是标准库的工作方式。
    /// // 如果您需要执行以下操作，这是最好的方法
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // 现在，它具有三个指向同一内存的可变引用。`slice`，右值 ret.0 和右值 ret.1。
    ///         // `slice` `let ptr = ...` 之后从未使用过，因此可以将其视为 "dead"，因此，您只有两个实际的可变切片。
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// 如果 `T` 给出的实际类型需要丢弃 glue，则返回 `true`。如果为 `T` 提供的实际类型实现 `Copy`，则返回 `false`。
    ///
    ///
    /// 如果实际类型既不需要丢弃 glue 也不需要实现 `Copy`，则该函数的返回值不确定。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 此内部函数的稳定版本为 [`mem::needs_drop`](crate::mem::needs_drop)。
    ///
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// 计算与指针的偏移量。
    ///
    /// 这被实现为内部函数，以避免与整数进行转换，因为转换会丢弃别名信息。
    ///
    /// # Safety
    ///
    /// 起始指针和结果指针都必须在已分配对象末尾的范围之内或一个字节内。
    /// 如果指针越界或发生算术溢出，则进一步使用返回值将导致不确定的行为。
    ///
    ///
    /// 此内部函数的稳定版本为 [`pointer::offset`]。
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// 计算与指针的偏移量 (可能会自动换行)。
    ///
    /// 这被实现为内部函数，以避免与整数进行相互转换，因为该转换会禁止某些优化。
    ///
    /// # Safety
    ///
    /// 与 `offset` 内部函数不同，此内部函数不会限制结果指针指向已分配对象的末尾或指向该对象末尾一个字节，并且使用二进制补码算法进行换行。
    /// 结果值不一定有效地用于实际访问内存。
    ///
    /// 此内部函数的稳定版本为 [`pointer::wrapping_offset`]。
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// 等效于适当的 `llvm.memcpy.p0i8.0i8.*` 本征，大小为 `count`*`size_of::<T>()`，对齐方式为
    ///
    /// `min_align_of::<T>()`
    ///
    /// volatile 参数设置为 `true`，因此除非大小等于零，否则不会对其进行优化。
    ///
    /// 此内部函数没有稳定的对应对象。
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// 等效于适当的 `llvm.memmove.p0i8.0i8.*` 本征，大小为 `count* size_of::<T>()`，对齐方式为
    ///
    /// `min_align_of::<T>()`
    ///
    /// volatile 参数设置为 `true`，因此除非大小等于零，否则不会对其进行优化。
    ///
    /// 此内部函数没有稳定的对应对象。
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// 等效于适当的 `llvm.memset.p0i8.*` 内部函数，其大小为 `count* size_of::<T>()`，并且对齐方式为 `min_align_of::<T>()`。
    ///
    ///
    /// volatile 参数设置为 `true`，因此除非大小等于零，否则不会对其进行优化。
    ///
    /// 此内部函数没有稳定的对应对象。
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// 从 `src` 指针执行易失性加载。
    ///
    /// 这个 intrinsic 的稳定版本是 [`core::ptr::read_volatile`]。
    pub fn volatile_load<T>(src: *const T) -> T;
    /// 对 `dst` 指针执行易失性存储。
    ///
    /// 这个 intrinsic 的稳定版本是 [`core::ptr::write_volatile`]。
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// 从 `src` 指针执行易失性加载不需要将指针对齐。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// 对 `dst` 指针执行易失性存储。
    /// 指针不需要对齐。
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// 返回 `f32` 的平方根
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// 返回 `f64` 的平方根
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// 将 `f32` 提升为整数幂。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// 将 `f64` 提升为整数幂。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// 返回 `f32` 的正弦值。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// 返回 `f64` 的正弦值。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// 返回 `f32` 的余弦值。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// 返回 `f64` 的余弦值。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// 将 `f32` 提升到 `f32` 的幂。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// 将 `f64` 提升到 `f64` 的幂。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// 返回 `f32` 的指数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// 返回 `f64` 的指数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// 返回 2 乘以 `f32` 的幂。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// 返回 2 乘以 `f64` 的幂。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// 返回 `f32` 的自然对数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// 返回 `f64` 的自然对数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// 返回 `f32` 的以 10 为底的对数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// 返回 `f64` 的以 10 为底的对数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// 返回 `f32` 的以 2 为底的对数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// 返回 `f64` 的以 2 为底的对数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// 为 `f32` 值返回 `a * b + c`。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// 为 `f64` 值返回 `a * b + c`。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// 返回 `f32` 的绝对值。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// 返回 `f64` 的绝对值。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// 返回两个 `f32` 值中的最小值。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// 返回两个 `f64` 值中的最小值。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// 返回两个 `f32` 值的最大值。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// 返回两个 `f64` 值的最大值。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// 将 `f32` 值的符号从 `y` 复制到 `x`。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// 将 `f64` 值的符号从 `y` 复制到 `x`。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// 返回小于或等于 `f32` 的最大整数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// 返回小于或等于 `f64` 的最大整数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// 返回大于或等于 `f32` 的最小整数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// 返回大于或等于 `f64` 的最小整数。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// 返回 `f32` 的整数部分。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// 返回 `f64` 的整数部分。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// 返回最接近 `f32` 的整数。
    /// 如果参数不是整数，则可能会引发不精确的浮点异常。
    pub fn rintf32(x: f32) -> f32;
    /// 返回最接近 `f64` 的整数。
    /// 如果参数不是整数，则可能会引发不精确的浮点异常。
    pub fn rintf64(x: f64) -> f64;

    /// 返回最接近 `f32` 的整数。
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn nearbyintf32(x: f32) -> f32;
    /// 返回最接近 `f64` 的整数。
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn nearbyintf64(x: f64) -> f64;

    /// 返回最接近 `f32` 的整数。将中途案例从零舍入。
    ///
    /// 此内部函数的稳定版本是
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// 返回最接近 `f64` 的整数。将中途案例从零舍入。
    ///
    /// 此内部函数的稳定版本是
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// 浮点数加法允许基于代数规则进行优化。
    /// 可以假设输入是有限的。
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// 浮点减法允许基于代数规则进行优化。
    /// 可以假设输入是有限的。
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// 浮点乘法允许基于代数规则进行优化。
    /// 可以假设输入是有限的。
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// 浮点除法允许基于代数规则进行优化。
    /// 可以假设输入是有限的。
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// 浮余数允许基于代数规则进行优化。
    /// 可以假设输入是有限的。
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// 使用 LLVM 的 fptoui/fptosi 进行转换，对于越界的值可能会返回 undef
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// 稳定为 [`f32::to_int_unchecked`] 和 [`f64::to_int_unchecked`]。
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// 返回整数类型 `T` 中设置的位数
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `count_ones` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// 返回整数类型 `T` 的前导未设置位 (zeroes) 的数量。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `leading_zeros` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// 值为 `0` 的 `x` 将返回 `T` 的位宽。
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// 类似于 `ctlz`，但是非常不安全，因为当给定值 `0` 的 `x` 时，它返回 `undef`。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// 返回整数类型 `T` 的尾随未设置位 (zeroes) 的数量。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `trailing_zeros` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// 值为 `0` 的 `x` 将返回 `T` 的位宽:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// 类似于 `cttz`，但是非常不安全，因为当给定值 `0` 的 `x` 时，它返回 `undef`。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.53.0")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// 反转整数类型 `T` 中的字节。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `swap_bytes` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// 反转整数类型 `T` 中的位。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `reverse_bits` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// 执行检查的整数加法。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `overflowing_add` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// 执行检查的整数减法
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `overflowing_sub` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// 执行检查的整数乘法
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `overflowing_mul` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// 执行精确除法，从而导致 `x % y != 0` 或 `y == 0` 或 `x == T::MIN && y == -1` 出现不确定的行为
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// 执行未经检查的除法，从而导致 `y == 0` 或 `x == T::MIN && y == -1` 出现不确定的行为
    ///
    ///
    /// 可通过 `checked_div` 方法在整数原语上使用此内部函数的安全包装。
    /// 例如，
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// 返回未经检查的除法的其余部分，从而在 `y == 0` 或 `x == T::MIN && y == -1` 时导致未定义的行为
    ///
    ///
    /// 可通过 `checked_rem` 方法在整数原语上使用此内部函数的安全包装。
    /// 例如，
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// 执行未经检查的左移，导致 `y < 0` 或 `y >= N` 出现不确定的行为，其中 N 是 T 的宽度 (以位为单位)。
    ///
    ///
    /// 可通过 `checked_shl` 方法在整数原语上使用此内部函数的安全包装。
    /// 例如，
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// 执行未经检查的右移，导致 `y < 0` 或 `y >= N` 出现不确定的行为，其中 N 是 T 的宽度 (以位为单位)。
    ///
    ///
    /// 可通过 `checked_shr` 方法在整数原语上使用此内部函数的安全包装。
    /// 例如，
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// 返回未经检查的加法运算的结果，导致 `x + y > T::MAX` 或 `x + y < T::MIN` 出现不确定的行为。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// 返回未经检查的减法的结果，当 `x - y > T::MAX` 或 `x - y < T::MIN` 时导致未定义的行为。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// 返回未经检查的乘法的结果，当 `x *y > T::MAX` 或 `x* y < T::MIN` 时导致未定义的行为。
    ///
    ///
    /// 此内部函数没有稳定的对应对象。
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// 向左旋转。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `rotate_left` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// 向右旋转。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `rotate_right` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// 返回 (a + b) mod 2 <sup>N</sup>，其中 N 是 T 的宽度 (以位为单位)。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `wrapping_add` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// 返回 (a-b) mod 2 <sup>N</sup>，其中 N 是 T 的宽度 (以位为单位)。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `wrapping_sub` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// 返回 (a * b) mod 2 <sup>N</sup>，其中 N 是 T 的宽度 (以位为单位)。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `wrapping_mul` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// 计算 `a + b`，在数字范围内达到饱和。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `saturating_add` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// 计算 `a - b`，在数字范围内达到饱和。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    /// 可通过 `saturating_sub` 方法在整数原语上使用此内部函数的稳定版本。
    ///
    /// 例如，
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 返回 'v' 中成员的判别式的值;
    /// 如果 `T` 没有判别，则返回 `0`。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    ///
    /// 这个 intrinsic 的稳定版本是 [`core::mem::discriminant`]。
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// 返回强制转换为 `usize` 的 `T` 类型的成员的数量;
    /// 如果 `T` 没有成员，则返回 `0`。无人居住的成员将被计算在内。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    ///
    /// 此内部函数的稳定版本为 [`mem::variant_count`]。
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust 的 "try catch" 构造使用数据指针 `data` 调用函数指针 `try_fn`。
    ///
    /// 第三个参数是如果发生 panic 时调用的函数。
    /// 此函数采用数据指针和指向所捕获的特定于目标的异常对象的指针。
    ///
    /// 有关更多信息，请参见编译器的源代码以及 std 的 catch 实现。
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// 根据 LLVM 发出 `!nontemporal` 存储 (请参见其文档)。
    /// 可能永远都不会变得稳定。
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// 有关详细信息，请参见 `<*const T>::offset_from` 的文档。
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// 有关详细信息，请参见 `<*const T>::guaranteed_eq` 的文档。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// 有关详细信息，请参见 `<*const T>::guaranteed_ne` 的文档。
    ///
    /// 请注意，与大多数内部函数不同，这对调用是安全的;
    /// 它不需要 `unsafe` 块。
    /// 因此，实现不得要求用户维护任何安全不可变变量。
    ///
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// 在编译时分配。不应在运行时调用。
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;

    /// 确定两个值的原始字节是否相等。
    ///
    /// 这对于数组特别方便，因为它允许只比较 i96 而不是强制 `[6 x i16]` 的 alloca。
    ///
    /// 在某些后端决定的之上，这将发出 `memcmp` 调用，就像对相等阈值所做的那样，而不是导致大量代码大小。
    ///
    /// # Safety
    ///
    /// 如果 `*a` 或 `*b` 中的任何 *bytes* 未初始化，这是 UB 到调用 this。
    /// 请注意，这是一个比完全初始化 *values* 更严格的标准：如果 `T` 有填充，它是 UB 到调用这个内部函数。
    ///
    ///
    /// (该实现允许在比较结果上进行分支，如果它们的任何输入为 `undef`，则为 UB。)
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_raw_eq", issue = "none")]
    pub fn raw_eq<T>(a: &T, b: &T) -> bool;

    /// 有关详细信息，请参见 [`std::hint::black_box`] 的文档。
    ///
    /// [`std::hint::black_box`]: crate::hint::black_box
    #[cfg(not(bootstrap))]
    pub fn black_box<T>(dummy: T) -> T;
}

// 之所以在这里定义一些函数，是因为它们意外地在稳定模块中可用。
// 请参见 <https://github.com/rust-lang/rust/issues/15702>。
// (`transmute` 也属于此类别，但是由于检查 `T` 和 `U` 具有相同的大小，因此无法将其包装。)
//

/// 检查 `ptr` 是否相对于 `align_of::<T>()` 正确对齐。
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// 将 `count * size_of::<T>()` 字节从 `src` 复制到 `dst`。源和目标必须不重叠。
///
/// 对于可能重叠的内存区域，请改用 [`copy`]。
///
/// `copy_nonoverlapping` 在语义上等效于 C 的 [`memcpy`]，但是交换了参数顺序。
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `src` 对于 `count * size_of::<T>()` 字节的读取，必须是 [有效][valid] 的。
///
/// * `dst` 对于 `count * size_of::<T>()` 字节的写入，必须为 [有效][valid] 的。
///
/// * `src` 和 `dst` 必须正确对齐。
///
/// * 从 `src` 开始的内存区域，大小为 `count *
///   size_of::<T> () ` 字节不得与以 `dst` 开始且大小相同的内存区域重叠。
///
/// 与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`copy_nonoverlapping` 都会创建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，则使用两个以 `*src` 开头的区域和以 `*dst` 开头的区域中的值可以 [违反内存安全][read-ownership]。
///
///
/// 请注意，即使有效复制的大小 (`count * size_of::<T>()`) 是 `0`，指针也必须非空的并且正确对齐。
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// 手动实现 [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// 将 `src` 的所有元素移到 `dst`，将 `src` 留空。
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // 确保 `dst` 具有足够的容量来容纳所有 `src`。
///     dst.reserve(src_len);
///
///     unsafe {
///         // 偏移的调用始终是安全的，因为 `Vec` 分配的字节数永远不会超过 `isize::MAX` 字节。
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // 截断 `src` 而不丢弃其内容。
///         // 我们首先执行此操作，以避免在 panics 处出现问题时避免出现问题。
///         src.set_len(0);
///
///         // 这两个区域不能重叠，因为可变引用没有别名，并且两个不同的 vectors 不能拥有相同的内存。
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // 通知 `dst` 现在包含 `src` 的内容。
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        pub fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: 仅在运行时执行这些检查
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // 不要 panic，以保持代码生成的影响较小。
        abort();
    }*/

    // SAFETY: 调用者必须遵守 `copy_nonoverlapping` 的安全保证。
    //
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// 将 `count * size_of::<T>()` 字节从 `src` 复制到 `dst`。源和目标可能会重叠。
///
/// 如果源和目标永远不会重叠，则可以改用 [`copy_nonoverlapping`]。
///
/// `copy` 在语义上等效于 C 的 [`memmove`]，但是交换了参数顺序。
/// 就像将字节从 `src` 复制到临时数组，然后从数组复制到 `dst` 一样进行复制。
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `src` 对于 `count * size_of::<T>()` 字节的读取，必须是 [有效][valid] 的。
///
/// * `dst` 对于 `count * size_of::<T>()` 字节的写入，必须为 [有效][valid] 的。
///
/// * `src` 和 `dst` 必须正确对齐。
///
/// 与 [`read`] 一样，无论 `T` 是否为 [`Copy`]，`copy` 都会创建 `T` 的按位副本。
/// 如果 `T` 不是 [`Copy`]，则可以同时使用以 `*src` 开头的区域和以 `* dst` 开头的区域中的值。
///
///
/// 请注意，即使有效复制的大小 (`count * size_of::<T>()`) 是 `0`，指针也必须非空的并且正确对齐。
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// 从不安全的缓冲区有效地创建 Rust vector:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` 必须正确对齐其类型且非零。
/// /// * `ptr` 必须对读取 `T` 类型的 `elts` 连续元素有效。
/// /// * 除非 `T: Copy`，否则在调用此函数后不得使用这些元素。
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SAFETY: 我们的前提条件是确保源文件对齐和有效，而 `Vec::with_capacity` 确保我们有可用的空间来编写它们。
/////
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SAFETY: 我们之前已经用这么大的容量创建了它，而以前的 `copy` 已经初始化了这些元素。
/////
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: 仅在运行时执行这些检查
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // 不要 panic，以保持代码生成的影响较小。
        abort();
    }*/

    // SAFETY: 调用者必须遵守 `copy` 的安全保证。
    unsafe { copy(src, dst, count) }
}

/// 将从 `dst` 开始的 `count * size_of::<T>()` 内存字节设置为 `val`。
///
/// `write_bytes` 与 C 的 [`memset`] 类似，但是将 `count * size_of::<T>()` 字节设置为 `val`。
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// 如果违反以下任一条件，则行为是未定义的:
///
/// * `dst` 对于 `count * size_of::<T>()` 字节的写入，必须为 [有效][valid] 的。
///
/// * `dst` 必须正确对齐。
///
/// 此外，调用者必须确保将 `count * size_of::<T>()` 字节写入给定的内存区域会导致 `T` 的有效值。
/// 使用类型为 `T` 的内存区域包含无效的 `T` 值是未定义的行为。
///
/// 请注意，即使有效复制的大小 (`count * size_of::<T>()`) 是 `0`，指针也必须非空的并且正确对齐。
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// 基本用法:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// 创建一个无效值:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // 通过使用空指针覆盖 `Box<T>`，泄漏先前保留的值。
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // 此时，使用或丢弃 `v` 会导致未定义的行为。
/// // drop(v); // ERROR
///
/// // 即使 `v` "uses" 泄漏了它，因此也是未定义的行为。
/// // mem::forget(v); // 错误
///
/// // 事实上，根据原始类型布局不变性，`v` 是无效的，因此，任何触及它的操作都是未定义的行为。
/////
/// // let v2 = v; // ERROR
///
/// unsafe {
///     // 让我们输入一个有效值
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // 现在 box 很好
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SAFETY: 调用者必须遵守 `write_bytes` 的安全保证。
    unsafe { write_bytes(dst, val, count) }
}
