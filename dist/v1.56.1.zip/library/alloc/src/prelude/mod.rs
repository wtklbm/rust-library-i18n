//! 分配 Prelude
//!
//! 该模块的目的是通过在模块顶部添加全局导入来减轻 `alloc` crate 常用项的导入:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;
