#[cfg(not(no_global_oom_handling))]
use super::AsVecIntoIter;
use crate::alloc::{Allocator, Global};
#[cfg(not(no_global_oom_handling))]
use crate::collections::VecDeque;
use crate::raw_vec::RawVec;
use core::array;
use core::fmt;
use core::iter::{
    FusedIterator, InPlaceIterable, SourceIter, TrustedLen, TrustedRandomAccessNoCoerce,
};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit, SizedTypeProperties};
#[cfg(not(no_global_oom_handling))]
use core::ops::Deref;
use core::ptr::{self, NonNull};
use core::slice::{self};

/// An iterator that moves out of a vector. <br>从 vector 移出的迭代器。<br>
///
/// This `struct` is created by the `into_iter` method on [`Vec`](super::Vec) (provided by the [`IntoIterator`] trait). <br>该 `struct` 是通过 [`Vec`](super::Vec) (由 [`IntoIterator`] trait 提供) 上的 `into_iter` 方法创建的。<br>
///
///
/// # Example
///
/// ```
/// let v = vec![0, 1, 2];
/// let iter: std::vec::IntoIter<_> = v.into_iter();
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_insignificant_dtor]
pub struct IntoIter<
    T,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> {
    pub(super) buf: NonNull<T>,
    pub(super) phantom: PhantomData<T>,
    pub(super) cap: usize,
    // the drop impl reconstructs a RawVec from buf, cap and alloc to avoid dropping the allocator twice we need to wrap it into ManuallyDrop <br>drop impl 从 buf，cap 和 alloc 重建一个 RawVec，以避免两次丢弃分配器，我们需要将其包装到 ManuallyDrop 中<br>
    //
    pub(super) alloc: ManuallyDrop<A>,
    pub(super) ptr: *const T,
    pub(super) end: *const T, // If T is a ZST, this is actually ptr+len. <br>如果 T 是 ZST，则实际上是 ptr + len。<br> This encoding is picked so that <br>选择此编码，以便<br>
                              // ptr == end is a quick test for the Iterator being empty, that works for both ZST and non-ZST. <br>ptr == end 是对 Iterator 为空的快速测试，适用于 ZST 和非 ZST。<br>
                              //
}

#[stable(feature = "vec_intoiter_debug", since = "1.13.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for IntoIter<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}

impl<T, A: Allocator> IntoIter<T, A> {
    /// Returns the remaining items of this iterator as a slice. <br>返回此迭代器的其余项作为切片。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let vec = vec!['a', 'b', 'c'];
    /// let mut into_iter = vec.into_iter();
    /// assert_eq!(into_iter.as_slice(), &['a', 'b', 'c']);
    /// let _ = into_iter.next().unwrap();
    /// assert_eq!(into_iter.as_slice(), &['b', 'c']);
    /// ```
    #[stable(feature = "vec_into_iter_as_slice", since = "1.15.0")]
    pub fn as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr, self.len()) }
    }

    /// Returns the remaining items of this iterator as a mutable slice. <br>以可变切片的形式返回此迭代器的其余项。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let vec = vec!['a', 'b', 'c'];
    /// let mut into_iter = vec.into_iter();
    /// assert_eq!(into_iter.as_slice(), &['a', 'b', 'c']);
    /// into_iter.as_mut_slice()[2] = 'z';
    /// assert_eq!(into_iter.next().unwrap(), 'a');
    /// assert_eq!(into_iter.next().unwrap(), 'b');
    /// assert_eq!(into_iter.next().unwrap(), 'z');
    /// ```
    #[stable(feature = "vec_into_iter_as_slice", since = "1.15.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        unsafe { &mut *self.as_raw_mut_slice() }
    }

    /// Returns a reference to the underlying allocator. <br>返回底层分配器的引用。<br>
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn as_raw_mut_slice(&mut self) -> *mut [T] {
        ptr::slice_from_raw_parts_mut(self.ptr as *mut T, self.len())
    }

    /// Drops remaining elements and relinquishes the backing allocation. <br>丢弃剩余的元素并放弃支持分配。<br>
    /// This method guarantees it won't panic before relinquishing the backing allocation. <br>这种方法保证它在放弃支持分配之前不会 panic。<br>
    ///
    /// This is roughly equivalent to the following, but more efficient <br>这大致等效于以下内容，但效率更高<br>
    ///
    /// ```
    /// # let mut into_iter = Vec::<u8>::with_capacity(10).into_iter();
    /// let mut into_iter = std::mem::replace(&mut into_iter, Vec::new().into_iter());
    /// (&mut into_iter).for_each(core::mem::drop);
    /// std::mem::forget(into_iter);
    /// ```
    ///
    /// This method is used by in-place iteration, refer to the vec::in_place_collect documentation for an overview. <br>在就地迭代的时候会使用这个方法，请参见 vec::in_place_collect 文档以获取概述。<br>
    ///
    ///
    #[cfg(not(no_global_oom_handling))]
    pub(super) fn forget_allocation_drop_remaining(&mut self) {
        let remaining = self.as_raw_mut_slice();

        // overwrite the individual fields instead of creating a new struct and then overwriting &mut self. <br>覆盖各个字段，而不是创建一个新的结构体，然后覆盖 &mut self。<br>
        //
        // this creates less assembly <br>这将创建更少的部件<br>
        self.cap = 0;
        self.buf = unsafe { NonNull::new_unchecked(RawVec::NEW.ptr()) };
        self.ptr = self.buf.as_ptr();
        self.end = self.buf.as_ptr();

        // Dropping the remaining elements can panic, so this needs to be done only after updating the other fields. <br>丢弃剩余的元素可能会发生 panic，因此仅在更新其他字段后才需要这样做。<br>
        //
        unsafe {
            ptr::drop_in_place(remaining);
        }
    }

    /// Forgets to Drop the remaining elements while still allowing the backing allocation to be freed. <br>忘记丢弃剩余元素，同时仍然允许释放后备分配。<br>
    pub(crate) fn forget_remaining_elements(&mut self) {
        // For th ZST case, it is crucial that we mutate `end` here, not `ptr`. <br>对于 ZST 案例，至关重要的是我们在这里改变 `end`，而不是 `ptr`。<br>
        // `ptr` must stay aligned, while `end` may be unaligned. <br>`ptr` 必须保持对齐，而 `end` 可能未对齐。<br>
        self.end = self.ptr;
    }

    #[cfg(not(no_global_oom_handling))]
    #[inline]
    pub(crate) fn into_vecdeque(self) -> VecDeque<T, A> {
        // Keep our `Drop` impl from dropping the elements and the allocator <br>保持我们的 `Drop` impl 丢弃元素和分配器<br>
        let mut this = ManuallyDrop::new(self);

        // SAFETY: This allocation originally came from a `Vec`, so it passes all those checks. <br>此分配最初来自 `Vec`，因此它通过了所有这些检查。<br>
        // We have `this.buf` ≤ `this.ptr` ≤ `this.end`, so the `sub_ptr`s below cannot wrap, and will produce a well-formed range. <br>我们有 `this.buf` ≤ `this.ptr` ≤ `this.end`，所以下面的 sub_ptr 不能换行，并且会产生一个格式正确的范围。<br>
        // `end` ≤ `buf + cap`, so the range will be in-bounds. <br>`end` ≤ `buf + cap`，因此范围在边界内。<br>
        // Taking `alloc` is ok because nothing else is going to look at it, since our `Drop` impl isn't going to run so there's no more code. <br>采用 `alloc` 是可以的，因为没有其他东西会查看它，因为我们的 `Drop` impl 不会运行，所以没有更多的代码。<br>
        //
        //
        unsafe {
            let buf = this.buf.as_ptr();
            let initialized = if T::IS_ZST {
                // All the pointers are the same for ZSTs, so it's fine to say that they're all at the beginning of the "allocation". <br>ZST 的所有指针都是相同的，所以可以说它们都在 "allocation" 的开头。<br>
                //
                0..this.len()
            } else {
                this.ptr.sub_ptr(buf)..this.end.sub_ptr(buf)
            };
            let cap = this.cap;
            let alloc = ManuallyDrop::take(&mut this.alloc);
            VecDeque::from_contiguous_raw_parts_in(buf, initialized, cap, alloc)
        }
    }
}

#[stable(feature = "vec_intoiter_as_ref", since = "1.46.0")]
impl<T, A: Allocator> AsRef<[T]> for IntoIter<T, A> {
    fn as_ref(&self) -> &[T] {
        self.as_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send, A: Allocator + Send> Send for IntoIter<T, A> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync, A: Allocator + Sync> Sync for IntoIter<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Iterator for IntoIter<T, A> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        if self.ptr == self.end {
            None
        } else if T::IS_ZST {
            // `ptr` has to stay where it is to remain aligned, so we reduce the length by 1 by reducing the `end`. <br>`ptr` 必须留在原处以保持对齐，因此我们通过减少 `end` 将长度减少 1。<br>
            //
            self.end = self.end.wrapping_byte_sub(1);

            // Make up a value of this ZST. <br>组成此 ZST 的值。<br>
            Some(unsafe { mem::zeroed() })
        } else {
            let old = self.ptr;
            self.ptr = unsafe { self.ptr.add(1) };

            Some(unsafe { ptr::read(old) })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = if T::IS_ZST {
            self.end.addr().wrapping_sub(self.ptr.addr())
        } else {
            unsafe { self.end.sub_ptr(self.ptr) }
        };
        (exact, Some(exact))
    }

    #[inline]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        let step_size = self.len().min(n);
        let to_drop = ptr::slice_from_raw_parts_mut(self.ptr as *mut T, step_size);
        if T::IS_ZST {
            // See `next` for why we sub `end` here. <br>请参见 `next`，了解我们为何在此处子 `end`。<br>
            self.end = self.end.wrapping_byte_sub(step_size);
        } else {
            // SAFETY: the min() above ensures that step_size is in bounds <br>上面的 min() 确保 step_size 在界限内<br>
            self.ptr = unsafe { self.ptr.add(step_size) };
        }
        // SAFETY: the min() above ensures that step_size is in bounds <br>上面的 min() 确保 step_size 在界限内<br>
        unsafe {
            ptr::drop_in_place(to_drop);
        }
        if step_size < n {
            return Err(step_size);
        }
        Ok(())
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn next_chunk<const N: usize>(&mut self) -> Result<[T; N], core::array::IntoIter<T, N>> {
        let mut raw_ary = MaybeUninit::uninit_array();

        let len = self.len();

        if T::IS_ZST {
            if len < N {
                self.forget_remaining_elements();
                // Safety: ZSTs can be conjured ex nihilo, only the amount has to be correct <br>安全性: ZST 可以凭空变出，只有数量必须正确<br>
                return Err(unsafe { array::IntoIter::new_unchecked(raw_ary, 0..len) });
            }

            self.end = self.end.wrapping_byte_sub(N);
            // Safety: ditto <br>安全: 同上<br>
            return Ok(unsafe { raw_ary.transpose().assume_init() });
        }

        if len < N {
            // Safety: `len` indicates that this many elements are available and we just checked that it fits into the array. <br>安全性: `len` 表示有这么多元素可用，我们刚刚检查了它是否适合数组。<br>
            //
            unsafe {
                ptr::copy_nonoverlapping(self.ptr, raw_ary.as_mut_ptr() as *mut T, len);
                self.forget_remaining_elements();
                return Err(array::IntoIter::new_unchecked(raw_ary, 0..len));
            }
        }

        // Safety: `len` is larger than the array size. <br>安全性: `len` 大于数组大小。<br>
        // Copy a fixed amount here to fully initialize the array. <br>在此处复制固定数量以完全初始化数组。<br>
        return unsafe {
            ptr::copy_nonoverlapping(self.ptr, raw_ary.as_mut_ptr() as *mut T, N);
            self.ptr = self.ptr.add(N);
            Ok(raw_ary.transpose().assume_init())
        };
    }

    unsafe fn __iterator_get_unchecked(&mut self, i: usize) -> Self::Item
    where
        Self: TrustedRandomAccessNoCoerce,
    {
        // SAFETY: the caller must guarantee that `i` is in bounds of the `Vec<T>`, so `i` cannot overflow an `isize`, and the `self.ptr.add(i)` is guaranteed to pointer to an element of the `Vec<T>` and thus guaranteed to be valid to dereference. <br>调用者必须保证 `i` 在 `Vec<T>` 的范围内，因此 `i` 不会溢出 `isize`，并且保证 `self.ptr.add(i)` 指向 `Vec<T>` 的元素，从而保证对解引用有效。<br>
        //
        //
        // Also note the implementation of `Self: TrustedRandomAccess` requires that `T: Copy` so reading elements from the buffer doesn't invalidate them for `Drop`. <br>还要注意，`Self: TrustedRandomAccess` 的实现要求 `T: Copy`，因此从缓冲区读取元素不会使它们对于 `Drop` 无效。<br>
        //
        //
        //
        //
        unsafe {
            if T::IS_ZST { mem::zeroed() } else { ptr::read(self.ptr.add(i)) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> DoubleEndedIterator for IntoIter<T, A> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        if self.end == self.ptr {
            None
        } else if T::IS_ZST {
            // See above for why 'ptr.offset' isn't used <br>有关为何不使用 'ptr.offset' 的信息，请参见上文<br>
            self.end = self.end.wrapping_byte_sub(1);

            // Make up a value of this ZST. <br>组成此 ZST 的值。<br>
            Some(unsafe { mem::zeroed() })
        } else {
            self.end = unsafe { self.end.sub(1) };

            Some(unsafe { ptr::read(self.end) })
        }
    }

    #[inline]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        let step_size = self.len().min(n);
        if T::IS_ZST {
            // SAFETY: same as for advance_by() <br>与 advance_by() 相同<br>
            self.end = self.end.wrapping_byte_sub(step_size);
        } else {
            // SAFETY: same as for advance_by() <br>与 advance_by() 相同<br>
            self.end = unsafe { self.end.sub(step_size) };
        }
        let to_drop = ptr::slice_from_raw_parts_mut(self.end as *mut T, step_size);
        // SAFETY: same as for advance_by() <br>与 advance_by() 相同<br>
        unsafe {
            ptr::drop_in_place(to_drop);
        }
        if step_size < n {
            return Err(step_size);
        }
        Ok(())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ExactSizeIterator for IntoIter<T, A> {
    fn is_empty(&self) -> bool {
        self.ptr == self.end
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T, A: Allocator> FusedIterator for IntoIter<T, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T, A: Allocator> TrustedLen for IntoIter<T, A> {}

#[doc(hidden)]
#[unstable(issue = "none", feature = "std_internals")]
#[rustc_unsafe_specialization_marker]
pub trait NonDrop {}

// T: Copy as approximation for !Drop since get_unchecked does not advance self.ptr and thus we can't implement drop-handling <br>复制为 !Drop 的近似值，因为 get_unchecked 不会推进 self.ptr，因此我们无法实现丢弃处理<br>
//
#[unstable(issue = "none", feature = "std_internals")]
impl<T: Copy> NonDrop for T {}

#[doc(hidden)]
#[unstable(issue = "none", feature = "std_internals")]
// TrustedRandomAccess (without NoCoerce) must not be implemented because subtypes/supertypes of `T` might not be `NonDrop` <br>不得实现 TrustedRandomAccess (无 NoCoerce)，因为 `T` 的 subtypes/supertypes 可能不是 `NonDrop`<br>
//
unsafe impl<T, A: Allocator> TrustedRandomAccessNoCoerce for IntoIter<T, A>
where
    T: NonDrop,
{
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "vec_into_iter_clone", since = "1.8.0")]
impl<T: Clone, A: Allocator + Clone> Clone for IntoIter<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        self.as_slice().to_vec_in(self.alloc.deref().clone()).into_iter()
    }
    #[cfg(test)]
    fn clone(&self) -> Self {
        crate::slice::to_vec(self.as_slice(), self.alloc.deref().clone()).into_iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for IntoIter<T, A> {
    fn drop(&mut self) {
        struct DropGuard<'a, T, A: Allocator>(&'a mut IntoIter<T, A>);

        impl<T, A: Allocator> Drop for DropGuard<'_, T, A> {
            fn drop(&mut self) {
                unsafe {
                    // `IntoIter::alloc` is not used anymore after this and will be dropped by RawVec <br>`IntoIter::alloc` 在此之后不再使用，它会被 RawVec 丢弃<br>
                    let alloc = ManuallyDrop::take(&mut self.0.alloc);
                    // RawVec handles deallocation <br>RawVec 处理重新分配<br>
                    let _ = RawVec::from_raw_parts_in(self.0.buf.as_ptr(), self.0.cap, alloc);
                }
            }
        }

        let guard = DropGuard(self);
        // destroy the remaining elements <br>销毁剩余的元素<br>
        unsafe {
            ptr::drop_in_place(guard.0.as_raw_mut_slice());
        }
        // now `guard` will be dropped and do the rest <br>现在，`guard` 将被丢弃并执行其余的操作<br>
    }
}

// In addition to the SAFETY invariants of the following three unsafe traits also refer to the vec::in_place_collect module documentation to get an overview <br>除了以下三个不安全的 traits 的 SAFETY 不变量之外，还可以参考 vec::in_place_collect 模块文档以获得概述<br>
//
#[unstable(issue = "none", feature = "inplace_iteration")]
#[doc(hidden)]
unsafe impl<T, A: Allocator> InPlaceIterable for IntoIter<T, A> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
#[doc(hidden)]
unsafe impl<T, A: Allocator> SourceIter for IntoIter<T, A> {
    type Source = Self;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[cfg(not(no_global_oom_handling))]
unsafe impl<T> AsVecIntoIter for IntoIter<T> {
    type Item = T;

    fn as_into_iter(&mut self) -> &mut IntoIter<Self::Item> {
        self
    }
}
