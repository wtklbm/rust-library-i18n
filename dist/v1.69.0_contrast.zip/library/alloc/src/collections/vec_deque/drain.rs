use core::iter::FusedIterator;
use core::marker::PhantomData;
use core::mem::{self, SizedTypeProperties};
use core::ptr::NonNull;
use core::{fmt, ptr};

use crate::alloc::{Allocator, Global};

use super::VecDeque;

/// A draining iterator over the elements of a `VecDeque`. <br>`VecDeque` 的元素上的 draining 迭代器。<br>
///
/// This `struct` is created by the [`drain`] method on [`VecDeque`]. <br>该 `struct` 是通过 [`VecDeque`] 上的 [`drain`] 方法创建的。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
///
/// [`drain`]: VecDeque::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<
    'a,
    T: 'a,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> {
    // We can't just use a &mut VecDeque<T, A>, as that would make Drain invariant over T and we want it to be covariant instead <br>我们不能只使用 &mut VecDeque<T, A>，因为那样会使 Drain 在 T 上不变，我们希望它是协变的<br>
    //
    deque: NonNull<VecDeque<T, A>>,
    // drain_start is stored in deque.len <br>drain_start 存放在 deque.len<br>
    drain_len: usize,
    // index into the logical array, not the physical one (always lies in [0..deque.len)) <br>索引到逻辑数组，而不是物理数组 (总是位于 [0..deque.len))<br>
    idx: usize,
    // number of elements after the drain range <br>drain 范围之后的元素数<br>
    tail_len: usize,
    remaining: usize,
    // Needed to make Drain covariant over T <br>需要使 Drain 在 T 上协变<br>
    _marker: PhantomData<&'a T>,
}

impl<'a, T, A: Allocator> Drain<'a, T, A> {
    pub(super) unsafe fn new(
        deque: &'a mut VecDeque<T, A>,
        drain_start: usize,
        drain_len: usize,
    ) -> Self {
        let orig_len = mem::replace(&mut deque.len, drain_start);
        let tail_len = orig_len - drain_start - drain_len;
        Drain {
            deque: NonNull::from(deque),
            drain_len,
            idx: drain_start,
            tail_len,
            remaining: drain_len,
            _marker: PhantomData,
        }
    }

    // Only returns pointers to the slices, as that's all we need to drop them. <br>只返回指向切片的指针，因为这就是我们丢弃它们所需要的。<br>
    // May only be called if `self.remaining != 0`. <br>只能在 `self.remaining != 0` 时调用。<br>
    unsafe fn as_slices(&self) -> (*mut [T], *mut [T]) {
        unsafe {
            let deque = self.deque.as_ref();
            // FIXME: This is doing almost exactly the same thing as the else branch in `VecDeque::slice_ranges`. <br>这与 `VecDeque::slice_ranges` 中的 else 分支几乎完全相同。<br>
            // Unfortunately, we can't just call `slice_ranges` here, as the deque's `len` is currently just `drain_start`, so the range check would (almost) always panic. <br>不幸的是，我们不能在这里只调用 `slice_ranges`，因为双端队列的 `len` 目前只是 `drain_start`，所以范围检查总是会导致 (almost) 崩溃。<br>
            // Between temporarily adjusting the deques `len` to call `slice_ranges`, and just copy pasting the `slice_ranges` implementation, this seemed like the less hacky solution, though it might be good to find a better one in the future. <br>在暂时将双端队列 `len` 调整为调用 `slice_ranges` 和复制粘贴 `slice_ranges` 实现之间，这似乎是一个不那么棘手的解决方案，尽管在 future 中找到一个更好的解决方案可能会很好。<br>
            //
            //
            //

            // because `self.remaining != 0`, we know that `self.idx < deque.original_len`, so it's a valid logical index. <br>因为 `self.remaining != 0`，我们知道 `self.idx < deque.original_len`，所以它是一个有效的逻辑索引。<br>
            //
            let wrapped_start = deque.to_physical_idx(self.idx);

            let head_len = deque.capacity() - wrapped_start;

            let (a_range, b_range) = if head_len >= self.remaining {
                (wrapped_start..wrapped_start + self.remaining, 0..0)
            } else {
                let tail_len = self.remaining - head_len;
                (wrapped_start..deque.capacity(), 0..tail_len)
            };

            // SAFETY: the range `self.idx..self.idx+self.remaining` lies strictly inside the range `0..deque.original_len`. <br>`self.idx..self.idx+self.remaining` 范围严格位于 `0..deque.original_len` 范围内。<br>
            // because of this, and because of the fact that we acquire `a_range` and `b_range` exactly like `slice_ranges` would, it's guaranteed that `a_range` and `b_range` represent valid ranges into the deques buffer. <br>因此，由于我们获取 `a_range` 和 `b_range` 的方式与 `slice_ranges` 完全相同，因此可以保证 `a_range` 和 `b_range` 代表双端队列缓冲区中的有效范围。<br>
            //
            //
            //
            (deque.buffer_range(a_range), deque.buffer_range(b_range))
        }
    }
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Drain<'_, T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain")
            .field(&self.drain_len)
            .field(&self.idx)
            .field(&self.tail_len)
            .field(&self.remaining)
            .finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl<T: Sync, A: Allocator + Sync> Sync for Drain<'_, T, A> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl<T: Send, A: Allocator + Send> Send for Drain<'_, T, A> {}

#[stable(feature = "drain", since = "1.6.0")]
impl<T, A: Allocator> Drop for Drain<'_, T, A> {
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, A: Allocator>(&'r mut Drain<'a, T, A>);

        impl<'r, 'a, T, A: Allocator> Drop for DropGuard<'r, 'a, T, A> {
            fn drop(&mut self) {
                if self.0.remaining != 0 {
                    unsafe {
                        // SAFETY: We just checked that `self.remaining != 0`. <br>我们刚刚检查了 `self.remaining != 0`。<br>
                        let (front, back) = self.0.as_slices();
                        ptr::drop_in_place(front);
                        ptr::drop_in_place(back);
                    }
                }

                let source_deque = unsafe { self.0.deque.as_mut() };

                let drain_start = source_deque.len();
                let drain_len = self.0.drain_len;
                let drain_end = drain_start + drain_len;

                let orig_len = self.0.tail_len + drain_end;

                if T::IS_ZST {
                    // no need to copy around any memory if T is a ZST <br>如果 T 是 ZST，则无需复制任何内存<br>
                    source_deque.len = orig_len - drain_len;
                    return;
                }

                let head_len = drain_start;
                let tail_len = self.0.tail_len;

                match (head_len, tail_len) {
                    (0, 0) => {
                        source_deque.head = 0;
                        source_deque.len = 0;
                    }
                    (0, _) => {
                        source_deque.head = source_deque.to_physical_idx(drain_len);
                        source_deque.len = orig_len - drain_len;
                    }
                    (_, 0) => {
                        source_deque.len = orig_len - drain_len;
                    }
                    _ => unsafe {
                        if head_len <= tail_len {
                            source_deque.wrap_copy(
                                source_deque.head,
                                source_deque.to_physical_idx(drain_len),
                                head_len,
                            );
                            source_deque.head = source_deque.to_physical_idx(drain_len);
                            source_deque.len = orig_len - drain_len;
                        } else {
                            source_deque.wrap_copy(
                                source_deque.to_physical_idx(head_len + drain_len),
                                source_deque.to_physical_idx(head_len),
                                tail_len,
                            );
                            source_deque.len = orig_len - drain_len;
                        }
                    },
                }
            }
        }

        let guard = DropGuard(self);
        if guard.0.remaining != 0 {
            unsafe {
                // SAFETY: We just checked that `self.remaining != 0`. <br>我们刚刚检查了 `self.remaining != 0`。<br>
                let (front, back) = guard.0.as_slices();
                // since idx is a logical index, we don't need to worry about wrapping. <br>因为 idx 是一个逻辑索引，所以我们不需要担心换行。<br>
                guard.0.idx += front.len();
                guard.0.remaining -= front.len();
                ptr::drop_in_place(front);
                guard.0.remaining = 0;
                ptr::drop_in_place(back);
            }
        }

        // Dropping `guard` handles moving the remaining elements into place. <br>丢弃 `guard` 处理将剩余元素移动到位。<br>
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T, A: Allocator> Iterator for Drain<'_, T, A> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        if self.remaining == 0 {
            return None;
        }
        let wrapped_idx = unsafe { self.deque.as_ref().to_physical_idx(self.idx) };
        self.idx += 1;
        self.remaining -= 1;
        Some(unsafe { self.deque.as_mut().buffer_read(wrapped_idx) })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.remaining;
        (len, Some(len))
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T, A: Allocator> DoubleEndedIterator for Drain<'_, T, A> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        if self.remaining == 0 {
            return None;
        }
        self.remaining -= 1;
        let wrapped_idx = unsafe { self.deque.as_ref().to_physical_idx(self.idx + self.remaining) };
        Some(unsafe { self.deque.as_mut().buffer_read(wrapped_idx) })
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T, A: Allocator> ExactSizeIterator for Drain<'_, T, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T, A: Allocator> FusedIterator for Drain<'_, T, A> {}
