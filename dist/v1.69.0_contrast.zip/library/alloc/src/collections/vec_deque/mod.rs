//! A double-ended queue (deque) implemented with a growable ring buffer. <br>使用可增长的环形缓冲区实现的双端队列 (deque)。<br>
//!
//! This queue has *O*(1) amortized inserts and removals from both ends of the container. <br>此队列具有 *O*(1) 容器两端的摊销插入和删除。<br>
//! It also has *O*(1) indexing like a vector. <br>它还具有像 vector 一样的 *O*(1) 索引。<br>
//! The contained elements are not required to be copyable, and the queue will be sendable if the contained type is sendable. <br>所包含的元素不需要是可复制的，并且如果所包含的类型是可发送的，则队列将是可发送的。<br>
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_n, repeat_with, ByRefSized, FromIterator};
use core::mem::{ManuallyDrop, SizedTypeProperties};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;

// This is used in a bunch of intra-doc links. <br>这用于一堆文档内链接。<br>
// FIXME: For some reason, `#[cfg(doc)]` wasn't sufficient, resulting in failures in linkchecker even though rustdoc built the docs just fine. <br>由于某种原因，`#[cfg(doc)]` 还不够，导致链接检查器失败，即使 rustdoc 构建的文档很好。<br>
//
#[allow(unused_imports)]
use core::mem;

use crate::alloc::{Allocator, Global};
use crate::collections::TryReserveError;
use crate::collections::TryReserveErrorKind;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

#[cfg(test)]
mod tests;

/// A double-ended queue implemented with a growable ring buffer. <br>使用可增长的环形缓冲区实现的双端队列。<br>
///
/// The "default" usage of this type as a queue is to use [`push_back`] to add to the queue, and [`pop_front`] to remove from the queue. <br>"default" 作为队列的这种用法是使用 [`push_back`] 添加到队列，使用 [`pop_front`] 从队列中删除。<br>
///
/// [`extend`] and [`append`] push onto the back in this manner, and iterating over `VecDeque` goes front to back. <br>[`extend`] 和 [`append`] 以这种方式推到后面，并从前到后迭代 `VecDeque`。<br>
///
/// A `VecDeque` with a known list of items can be initialized from an array: <br>可以从数组初始化具有已知项列表的 `VecDeque`：<br>
///
/// ```
/// use std::collections::VecDeque;
///
/// let deq = VecDeque::from([-1, 0, 1]);
/// ```
///
/// Since `VecDeque` is a ring buffer, its elements are not necessarily contiguous in memory. <br>由于 `VecDeque` 是环形缓冲区，因此它的元素在内存中不一定是连续的。<br>
/// If you want to access the elements as a single slice, such as for efficient sorting, you can use [`make_contiguous`]. <br>如果要以单个切片的形式访问元素 (例如为了进行有效的排序)，则可以使用 [`make_contiguous`]。<br>
/// It rotates the `VecDeque` so that its elements do not wrap, and returns a mutable slice to the now-contiguous element sequence. <br>它旋转 `VecDeque`，以使其元素不环绕，并向当前连续的元素序列返回可变切片。<br>
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "VecDeque")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_insignificant_dtor]
pub struct VecDeque<
    T,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> {
    // `self[0]`, if it exists, is `buf[head]`. <br>如果 `self[0]` 存在，则为 `buf[head]`。<br>
    // `head < buf.capacity()`, unless `buf.capacity() == 0` when `head == 0`. <br>`head < buf.capacity()`，`head == 0` 时除非 `buf.capacity() == 0`。<br>
    head: usize,
    // the number of initialized elements, starting from the one at `head` and potentially wrapping around. <br>初始化元素的数量，从 `head` 处的元素开始并可能环绕。<br>
    // if `len == 0`, the exact value of `head` is unimportant. <br>如果是 `len == 0`，`head` 的确切值并不重要。<br>
    // if `T` is zero-Sized, then `self.len <= usize::MAX`, otherwise `self.len <= isize::MAX as usize`. <br>如果 `T` 是零大小，则 `self.len <= usize::MAX`，否则 `self.len <= isize::MAX as usize`。<br>
    len: usize,
    buf: RawVec<T, A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for VecDeque<T, A> {
    fn clone(&self) -> Self {
        let mut deq = Self::with_capacity_in(self.len(), self.allocator().clone());
        deq.extend(self.iter().cloned());
        deq
    }

    fn clone_from(&mut self, other: &Self) {
        self.clear();
        self.extend(other.iter().cloned());
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for VecDeque<T, A> {
    fn drop(&mut self) {
        /// Runs the destructor for all items in the slice when it gets dropped (normally or during unwinding). <br>当切片被丢弃时 (正常情况下或在展开期间)，对切片中的所有项运行析构函数。<br>
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // use drop for [T]
            ptr::drop_in_place(front);
        }
        // RawVec handles deallocation <br>RawVec 处理重新分配<br>
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Creates an empty deque. <br>创建一个空的双端队列。<br>
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T, A: Allocator> VecDeque<T, A> {
    /// Marginally more convenient <br>稍微方便一点<br>
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Moves an element out of the buffer <br>将元素移出缓冲区<br>
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Writes an element into the buffer, moving it. <br>将元素写入缓冲区，然后将其移动。<br>
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Returns a slice pointer into the buffer. <br>将切片指针返回到缓冲区中。<br>
    /// `range` must lie inside `0..self.capacity()`. <br>`range` 必须位于 `0..self.capacity()` 内部。<br>
    #[inline]
    unsafe fn buffer_range(&self, range: Range<usize>) -> *mut [T] {
        unsafe {
            ptr::slice_from_raw_parts_mut(self.ptr().add(range.start), range.end - range.start)
        }
    }

    /// Returns `true` if the buffer is at full capacity. <br>如果缓冲区已满，则返回 `true`。<br>
    #[inline]
    fn is_full(&self) -> bool {
        self.len == self.capacity()
    }

    /// Returns the index in the underlying buffer for a given logical element index + addend. <br>返回给定逻辑元素索引 + 加数的底层缓冲区中的索引。<br>
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.capacity())
    }

    #[inline]
    fn to_physical_idx(&self, idx: usize) -> usize {
        self.wrap_add(self.head, idx)
    }

    /// Returns the index in the underlying buffer for a given logical element index - subtrahend. <br>返回给定逻辑元素索引 - 减数的底层缓冲区中的索引。<br>
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend).wrapping_add(self.capacity()), self.capacity())
    }

    /// Copies a contiguous block of memory len long from src to dst <br>将一个连续的 len 长的内存块从 src 复制到 dst<br>
    #[inline]
    unsafe fn copy(&mut self, src: usize, dst: usize, len: usize) {
        debug_assert!(
            dst + len <= self.capacity(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.capacity()
        );
        debug_assert!(
            src + len <= self.capacity(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.capacity()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Copies a contiguous block of memory len long from src to dst <br>将一个连续的 len 长的内存块从 src 复制到 dst<br>
    #[inline]
    unsafe fn copy_nonoverlapping(&mut self, src: usize, dst: usize, len: usize) {
        debug_assert!(
            dst + len <= self.capacity(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.capacity()
        );
        debug_assert!(
            src + len <= self.capacity(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.capacity()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Copies a potentially wrapping block of memory len long from src to dest. <br>从 src 复制一个长度为 len 的潜在包装内存块到 dest。<br>
    /// (abs(dst - src) + len) must be no larger than capacity() (There must be at most one continuous overlapping region between src and dest). <br>(abs(dst - src) + len) 必须不大于 capacity() (src 和 dest 之间最多只能有一个连续的重叠区域)。<br>
    ///
    unsafe fn wrap_copy(&mut self, src: usize, dst: usize, len: usize) {
        debug_assert!(
            cmp::min(src.abs_diff(dst), self.capacity() - src.abs_diff(dst)) + len
                <= self.capacity(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.capacity()
        );

        // If T is a ZST, don't do any copying. <br>如果 T 是 ZST，则不要进行任何复制。<br>
        if T::IS_ZST || src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.capacity() - src;
        let dst_pre_wrap_len = self.capacity() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src doesn't wrap, dst doesn't wrap <br>src 不换行，dst 不换行<br>
                //
                //
                //        S . . .
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D . . .
                //
                unsafe {
                    self.copy(src, dst, len);
                }
            }
            (false, false, true) => {
                // dst before src, src doesn't wrap, dst wraps <br>src 之前的 dst，src 不环绕，dst 环绕<br>
                //
                //
                //    S . . .
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] ..  D .
                //
                unsafe {
                    self.copy(src, dst, dst_pre_wrap_len);
                    self.copy(src + dst_pre_wrap_len, 0, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src before dst, src doesn't wrap, dst wraps <br>dst 之前的 src，src 不换行，dst 换行<br>
                //
                //
                //              S . . .
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] ..  D .
                //
                unsafe {
                    self.copy(src + dst_pre_wrap_len, 0, len - dst_pre_wrap_len);
                    self.copy(src, dst, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst before src, src wraps, dst doesn't wrap <br>src 之前的 dst，src 换行，dst 不换行<br>
                //
                //
                //    .. S .
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D . . .
                //
                unsafe {
                    self.copy(src, dst, src_pre_wrap_len);
                    self.copy(0, dst + src_pre_wrap_len, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src before dst, src wraps, dst doesn't wrap <br>dst 之前的 src，src 换行，dst 不换行<br>
                //
                //
                //    .. S .
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D . . .
                //
                unsafe {
                    self.copy(0, dst + src_pre_wrap_len, len - src_pre_wrap_len);
                    self.copy(src, dst, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst before src, src wraps, dst wraps <br>src 之前的 dst，src 换行，dst 换行<br>
                //
                //
                //    . .. S .
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] ..  D . .
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(src, dst, src_pre_wrap_len);
                    self.copy(0, dst + src_pre_wrap_len, delta);
                    self.copy(delta, 0, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src before dst, src wraps, dst wraps <br>dst 之前的 src，src 换行，dst 换行<br>
                //
                //
                //    .. S . .
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G] . ..  D .
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(0, delta, len - src_pre_wrap_len);
                    self.copy(self.capacity() - delta, 0, delta);
                    self.copy(src, dst, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Copies all values from `src` to `dst`, wrapping around if needed. <br>将所有值从 `src` 复制到 `dst`，并在需要时进行包装。<br>
    /// Assumes capacity is sufficient. <br>假设容量足够。<br>
    #[inline]
    unsafe fn copy_slice(&mut self, dst: usize, src: &[T]) {
        debug_assert!(src.len() <= self.capacity());
        let head_room = self.capacity() - dst;
        if src.len() <= head_room {
            unsafe {
                ptr::copy_nonoverlapping(src.as_ptr(), self.ptr().add(dst), src.len());
            }
        } else {
            let (left, right) = src.split_at(head_room);
            unsafe {
                ptr::copy_nonoverlapping(left.as_ptr(), self.ptr().add(dst), left.len());
                ptr::copy_nonoverlapping(right.as_ptr(), self.ptr(), right.len());
            }
        }
    }

    /// Writes all values from `iter` to `dst`. <br>将所有值从 `iter` 写入 `dst`。<br>
    ///
    /// # Safety
    ///
    /// Assumes no wrapping around happens. <br>假设没有环绕发生。<br>
    /// Assumes capacity is sufficient. <br>假设容量足够。<br>
    #[inline]
    unsafe fn write_iter(
        &mut self,
        dst: usize,
        iter: impl Iterator<Item = T>,
        written: &mut usize,
    ) {
        iter.enumerate().for_each(|(i, element)| unsafe {
            self.buffer_write(dst + i, element);
            *written += 1;
        });
    }

    /// Writes all values from `iter` to `dst`, wrapping at the end of the buffer and returns the number of written values. <br>写入从 `iter` 到 `dst` 的所有值，在缓冲区末尾换行并返回写入值的数量。<br>
    ///
    ///
    /// # Safety
    ///
    /// Assumes that `iter` yields at most `len` items. <br>假设 `iter` 最多产生 `len` 项。<br>
    /// Assumes capacity is sufficient. <br>假设容量足够。<br>
    ///
    unsafe fn write_iter_wrapping(
        &mut self,
        dst: usize,
        mut iter: impl Iterator<Item = T>,
        len: usize,
    ) -> usize {
        struct Guard<'a, T, A: Allocator> {
            deque: &'a mut VecDeque<T, A>,
            written: usize,
        }

        impl<'a, T, A: Allocator> Drop for Guard<'a, T, A> {
            fn drop(&mut self) {
                self.deque.len += self.written;
            }
        }

        let head_room = self.capacity() - dst;

        let mut guard = Guard { deque: self, written: 0 };

        if head_room >= len {
            unsafe { guard.deque.write_iter(dst, iter, &mut guard.written) };
        } else {
            unsafe {
                guard.deque.write_iter(
                    dst,
                    ByRefSized(&mut iter).take(head_room),
                    &mut guard.written,
                );
                guard.deque.write_iter(0, iter, &mut guard.written)
            };
        }

        guard.written
    }

    /// Frobs the head and tail sections around to handle the fact that we just reallocated. <br>绕着 head 和 tail 进行处理，以处理我们刚刚重新分配的事实。<br>
    /// Unsafe because it trusts old_capacity. <br>不安全，因为它信任 old_capacity。<br>
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.capacity();
        debug_assert!(new_capacity >= old_capacity);

        // Move the shortest contiguous section of the ring buffer <br>移动环形缓冲区的最短连续部分<br>
        //
        // H := head L := last element (`self.to_physical_idx(self.len - 1)`)
        //
        //
        //    H           L
        //   [o o o o o o o . ]
        //    H           L A [o o o o o o o . . . . . . . . . ] L H
        //   [o o o o o o o o ]
        //          H           L B [. . . o o o o o o o . . . . . . ] L H
        //   [o o o o o o o o ]
        //            L                   H C [o o o o o . . . . . . . . .
        //            o o ]
        //
        //
        //
        //

        // can't use is_contiguous() because the capacity is already updated. <br>不能使用 is_contiguous()，因为容量已经更新。<br>
        if self.head <= old_capacity - self.len {
            // A Nop
            //
        } else {
            let head_len = old_capacity - self.head;
            let tail_len = self.len - head_len;
            if head_len > tail_len && new_capacity - old_capacity >= tail_len {
                // B
                unsafe {
                    self.copy_nonoverlapping(0, old_capacity, tail_len);
                }
            } else {
                // C
                let new_head = new_capacity - head_len;
                unsafe {
                    // can't use copy_nonoverlapping here, because if e.g. <br>不能在这里使用 copy_nonoverlapping，因为如果例如<br>
                    // head_len = 2 and new_capacity = old_capacity + 1, then the heads overlap. <br>head_len = 2 和 new_capacity = old_capacity + 1，然后头部进行重叠。<br>
                    self.copy(self.head, new_head, head_len);
                }
                self.head = new_head;
            }
        }
        debug_assert!(self.head < self.capacity() || self.capacity() == 0);
    }
}

impl<T> VecDeque<T> {
    /// Creates an empty deque. <br>创建一个空的双端队列。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<u32> = VecDeque::new();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_vec_deque_new", since = "1.68.0")]
    #[must_use]
    pub const fn new() -> VecDeque<T> {
        // FIXME: This should just be `VecDeque::new_in(Global)` once that hits stable. <br>一旦达到稳定，这应该只是 `VecDeque::new_in(Global)`。<br>
        VecDeque { head: 0, len: 0, buf: RawVec::NEW }
    }

    /// Creates an empty deque with space for at least `capacity` elements. <br>为至少 `capacity` 个元素创建一个空的双端队列。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        Self::with_capacity_in(capacity, Global)
    }
}

impl<T, A: Allocator> VecDeque<T, A> {
    /// Creates an empty deque. <br>创建一个空的双端队列。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<u32> = VecDeque::new();
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> VecDeque<T, A> {
        VecDeque { head: 0, len: 0, buf: RawVec::new_in(alloc) }
    }

    /// Creates an empty deque with space for at least `capacity` elements. <br>为至少 `capacity` 个元素创建一个空的双端队列。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> VecDeque<T, A> {
        VecDeque { head: 0, len: 0, buf: RawVec::with_capacity_in(capacity, alloc) }
    }

    /// Creates a `VecDeque` from a raw allocation, when the initialized part of that allocation forms a *contiguous* subslice thereof. <br>当分配的初始化部分形成其*连续*子片时，从原始分配创建 `VecDeque`。<br>
    ///
    /// For use by `vec::IntoIter::into_vecdeque` <br>供 `vec::IntoIter::into_vecdeque` 使用<br>
    ///
    /// # Safety
    ///
    /// All the usual requirements on the allocated memory like in `Vec::from_raw_parts_in`, but takes a *range* of elements that are initialized rather than only supporting `0..len`. <br>与 `Vec::from_raw_parts_in` 一样，对分配内存的所有常见要求，但采用*范围*的元素进行初始化，而不是仅支持 `0..len`。<br>
    /// Requires that `initialized.start` ≤ `initialized.end` ≤ `capacity`. <br>要求 `initialized.start` ≤ `initialized.end` ≤ `capacity`。<br>
    ///
    ///
    ///
    #[inline]
    pub(crate) unsafe fn from_contiguous_raw_parts_in(
        ptr: *mut T,
        initialized: Range<usize>,
        capacity: usize,
        alloc: A,
    ) -> Self {
        debug_assert!(initialized.start <= initialized.end);
        debug_assert!(initialized.end <= capacity);

        // SAFETY: Our safety precondition guarantees the range length won't wrap, and that the allocation is valid for use in `RawVec`. <br>我们的安全前提条件保证范围长度不会回绕，并且分配对于在 `RawVec` 中使用是有效的。<br>
        //
        unsafe {
            VecDeque {
                head: initialized.start,
                len: initialized.end.unchecked_sub(initialized.start),
                buf: RawVec::from_raw_parts_in(ptr, capacity, alloc),
            }
        }
    }

    /// Provides a reference to the element at the given index. <br>提供给定索引处元素的引用。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// buf.push_back(6);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len {
            let idx = self.to_physical_idx(index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Provides a mutable reference to the element at the given index. <br>提供给定索引处元素的可变引用。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// buf.push_back(6);
    /// assert_eq!(buf[1], 4);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len {
            let idx = self.to_physical_idx(index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Swaps elements at indices `i` and `j`. <br>交换索引为 `i` 和 `j` 的元素。<br>
    ///
    /// `i` and `j` may be equal. <br>`i` 和 `j` 可能是相等的。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Panics
    ///
    /// Panics if either index is out of bounds. <br>如果任一索引越界，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.to_physical_idx(i);
        let rj = self.to_physical_idx(j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Returns the number of elements the deque can hold without reallocating. <br>返回双端队列在不重新分配的情况下可以容纳的元素数。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        if T::IS_ZST { usize::MAX } else { self.buf.capacity() }
    }

    /// Reserves the minimum capacity for at least `additional` more elements to be inserted in the given deque. <br>为至少 `additional` 多个要插入给定双端队列的元素保留最小容量。<br>
    /// Does nothing if the capacity is already sufficient. <br>如果容量已经足够，则不执行任何操作。<br>
    ///
    /// Note that the allocator may give the collection more space than it requests. <br>请注意，分配器可能会给集合提供比其请求更多的空间。<br>
    /// Therefore capacity can not be relied upon to be precisely minimal. <br>因此，不能依靠容量来精确地将其最小化。<br>
    /// Prefer [`reserve`] if future insertions are expected. <br>如果预计将来会插入，则最好使用 [`reserve`]。<br>
    ///
    /// # Panics
    ///
    /// Panics if the new capacity overflows `usize`. <br>如果新容量溢出 `usize`，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = [1].into();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        let new_cap = self.len.checked_add(additional).expect("capacity overflow");
        let old_cap = self.capacity();

        if new_cap > old_cap {
            self.buf.reserve_exact(self.len, additional);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Reserves capacity for at least `additional` more elements to be inserted in the given deque. <br>为至少 `additional` 多个要插入给定双端队列的元素保留容量。<br>
    /// The collection may reserve more space to speculatively avoid frequent reallocations. <br>集合可以保留更多空间来推测性地避免频繁的重新分配。<br>
    ///
    /// # Panics
    ///
    /// Panics if the new capacity overflows `usize`. <br>如果新容量溢出 `usize`，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = [1].into();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let new_cap = self.len.checked_add(additional).expect("capacity overflow");
        let old_cap = self.capacity();

        if new_cap > old_cap {
            // we don't need to reserve_exact(), as the size doesn't have to be a power of <br>我们不需要 reserve_exact()，因为大小不一定是的幂<br> 2.
            //
            self.buf.reserve(self.len, additional);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Tries to reserve the minimum capacity for at least `additional` more elements to be inserted in the given deque. <br>尝试为至少 `additional` 多个要插入给定双端队列的元素保留最小容量。<br>
    /// After calling `try_reserve_exact`, capacity will be greater than or equal to `self.len() + additional` if it returns `Ok(())`. <br>调用 `try_reserve_exact` 后，如果返回 `Ok(())`，则容量将大于或等于 `self.len() + additional`。<br>
    ///
    /// Does nothing if the capacity is already sufficient. <br>如果容量已经足够，则不执行任何操作。<br>
    ///
    /// Note that the allocator may give the collection more space than it requests. <br>请注意，分配器可能会给集合提供比其请求更多的空间。<br>
    /// Therefore, capacity can not be relied upon to be precisely minimal. <br>因此，不能依靠容量来精确地最小化。<br>
    /// Prefer [`try_reserve`] if future insertions are expected. <br>如果希望将来插入，则首选 [`try_reserve`]。<br>
    ///
    /// [`try_reserve`]: VecDeque::try_reserve
    ///
    /// # Errors
    ///
    /// If the capacity overflows `usize`, or the allocator reports a failure, then an error is returned. <br>如果容量溢出 `usize`，或者分配器报告失败，则返回错误。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Pre-reserve the memory, exiting if we can't <br>预先保留内存，如果不能，则退出<br>
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Now we know this can't OOM(Out-Of-Memory) in the middle of our complex work <br>现在我们知道这不能 OOM(Out-Of-Memory) 完成我们复杂的工作<br>
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // very complicated <br>非常复杂<br>
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[stable(feature = "try_reserve", since = "1.57.0")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let new_cap =
            self.len.checked_add(additional).ok_or(TryReserveErrorKind::CapacityOverflow)?;
        let old_cap = self.capacity();

        if new_cap > old_cap {
            self.buf.try_reserve_exact(self.len, additional)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Tries to reserve capacity for at least `additional` more elements to be inserted in the given deque. <br>尝试为要插入给定双端队列的至少 `additional` 更多元素保留容量。<br>
    /// The collection may reserve more space to speculatively avoid frequent reallocations. <br>集合可以保留更多空间来推测性地避免频繁的重新分配。<br>
    /// After calling `try_reserve`, capacity will be greater than or equal to `self.len() + additional` if it returns `Ok(())`. <br>调用 `try_reserve` 后，如果返回 `Ok(())`，容量将大于等于 `self.len() + additional`。<br>
    ///
    /// Does nothing if capacity is already sufficient. <br>如果容量已经足够，则不执行任何操作。<br>
    /// This method preserves the contents even if an error occurs. <br>即使发生错误，此方法也会保留内容。<br>
    ///
    /// # Errors
    ///
    /// If the capacity overflows `usize`, or the allocator reports a failure, then an error is returned. <br>如果容量溢出 `usize`，或者分配器报告失败，则返回错误。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Pre-reserve the memory, exiting if we can't <br>预先保留内存，如果不能，则退出<br>
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Now we know this can't OOM in the middle of our complex work <br>现在我们知道在我们复杂的工作中这不能 OOM<br>
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // very complicated <br>非常复杂<br>
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[stable(feature = "try_reserve", since = "1.57.0")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let new_cap =
            self.len.checked_add(additional).ok_or(TryReserveErrorKind::CapacityOverflow)?;
        let old_cap = self.capacity();

        if new_cap > old_cap {
            self.buf.try_reserve(self.len, additional)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Shrinks the capacity of the deque as much as possible. <br>尽可能缩小双端队列的容量。<br>
    ///
    /// It will drop down as close as possible to the length but the allocator may still inform the deque that there is space for a few more elements. <br>它将尽可能接近长度丢弃，但分配器仍可能通知双端队列有空间容纳更多元素。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Shrinks the capacity of the deque with a lower bound. <br>用下限缩小双端队列的容量。<br>
    ///
    /// The capacity will remain at least as large as both the length and the supplied value. <br>容量将至少保持与长度和提供的值一样大。<br>
    ///
    ///
    /// If the current capacity is less than the lower limit, this is a no-op. <br>如果当前容量小于下限，则为无操作。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "shrink_to", since = "1.56.0")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let target_cap = min_capacity.max(self.len);

        // never shrink ZSTs <br>永不缩小 ZSTs<br>
        if T::IS_ZST || self.capacity() <= target_cap {
            return;
        }

        // There are three cases of interest: <br>有以下三种有趣的情况：<br>
        //   All elements are out of desired bounds Elements are contiguous, and tail is out of desired bounds Elements are discontiguous <br>所有元素都超出了所需的范围元素是连续的，尾部超出了所需的范围元素是不连续的<br>
        //
        //
        // At all other times, element positions are unaffected. <br>在其他所有时间，元素位置均不受影响。<br>
        //

        // `head` and `len` are at most `isize::MAX` and `target_cap < self.capacity()`, so nothing can overflow. <br>`head` 和 `len` 至多是 `isize::MAX` 和 `target_cap < self.capacity()`，所以什么都不会溢出。<br>
        //
        let tail_outside = (target_cap + 1..=self.capacity()).contains(&(self.head + self.len));

        if self.len == 0 {
            self.head = 0;
        } else if self.head >= target_cap && tail_outside {
            // Head and tail are both out of bounds, so copy all of them to the front. <br>head 和 tail 都是越界的，所以全部复制到前面。<br>
            //
            //
            //  H := head L := last element H           L
            //   [. . . . . . . . o o o o o o o . ]
            //    H           L
            //   [o o o o o o o . ]
            //
            unsafe {
                // nonoverlapping because `self.head >= target_cap >= self.len`. <br>不重叠，因为 `self.head >= target_cap >= self.len`。<br>
                self.copy_nonoverlapping(self.head, 0, self.len);
            }
            self.head = 0;
        } else if self.head < target_cap && tail_outside {
            // Head is in bounds, tail is out of bounds. <br>头在界内，尾在界外。<br>
            // Copy the overflowing part to the beginning of the buffer. <br>将溢出的部分复制到缓冲区的开头。<br>
            // This won't overlap because `target_cap >= self.len`. <br>这不会重叠，因为 `target_cap >= self.len`。<br>
            //
            //  H := head L := last element H           L
            //   [. . . o o o o o o o . . . . . . ]
            //      L   H
            //   [o o . o o o o o ]
            //
            //
            let len = self.head + self.len - target_cap;
            unsafe {
                self.copy_nonoverlapping(target_cap, 0, len);
            }
        } else if !self.is_contiguous() {
            // The head slice is at least partially out of bounds, tail is in bounds. <br>头部切片至少部分越界，尾部在范围内。<br>
            //
            // Copy the head backwards so it lines up with the target capacity. <br>向后复制头部，使其与目标容量对齐。<br>
            // This won't overlap because `target_cap >= self.len`. <br>这不会重叠，因为 `target_cap >= self.len`。<br>
            //
            //  H := head L := last element L                   H
            //   [o o o o o . . . . . . . . . o o ]
            //            L   H
            //   [o o o o o . o o ]
            //
            let head_len = self.capacity() - self.head;
            let new_head = target_cap - head_len;
            unsafe {
                // can't use `copy_nonoverlapping()` here because the new and old regions for the head might overlap. <br>不能在这里使用 `copy_nonoverlapping()`，因为头部的新旧区域可能会重叠。<br>
                //
                self.copy(self.head, new_head, head_len);
            }
            self.head = new_head;
        }
        self.buf.shrink_to_fit(target_cap);

        debug_assert!(self.head < self.capacity() || self.capacity() == 0);
        debug_assert!(self.len <= self.capacity());
    }

    /// Shortens the deque, keeping the first `len` elements and dropping the rest. <br>缩短双端队列，保留前 `len` 个元素并丢弃其余元素。<br>
    ///
    ///
    /// If `len` is greater than the deque's current length, this has no effect. <br>如果 `len` 大于双端队列的当前长度，则无效。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Runs the destructor for all items in the slice when it gets dropped (normally or during unwinding). <br>当切片被丢弃时 (正常情况下或在展开期间)，对切片中的所有项运行析构函数。<br>
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Safe because: <br>安全是因为：<br>
        //
        // * Any slice passed to `drop_in_place` is valid; <br>传递给 `drop_in_place` 的任何切片都是有效的；<br> the second case has `len <= front.len()` and returning on `len > self.len()` ensures `begin <= back.len()` in the first case <br>第二种情况为 `len <= front.len()`，返回 `len > self.len()` 可确保第一种情况为 `begin <= back.len()`<br>
        //
        // * The head of the VecDeque is moved before calling `drop_in_place`, so no value is dropped twice if `drop_in_place` panics <br>VecDeque 的头部在调用 `drop_in_place` 之前已移动，因此如果 `drop_in_place` panics 没有两次删除任何值<br>
        //
        //
        unsafe {
            if len >= self.len {
                return;
            }

            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.len = len;
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.len = len;

                // Make sure the second half is dropped even when a destructor in the first one panics. <br>即使第一个中的析构函数发生 panic，也要确保后半部分被丢弃。<br>
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Returns a reference to the underlying allocator. <br>返回底层分配器的引用。<br>
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Returns a front-to-back iterator. <br>返回从前到后的迭代器。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        let (a, b) = self.as_slices();
        Iter::new(a.iter(), b.iter())
    }

    /// Returns a front-to-back iterator that returns mutable references. <br>返回从前到后的迭代器，该迭代器返回可变引用。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        let (a, b) = self.as_mut_slices();
        IterMut::new(a.iter_mut(), b.iter_mut())
    }

    /// Returns a pair of slices which contain, in order, the contents of the deque. <br>返回一对按顺序包含双端队列内容的切片。<br>
    ///
    /// If [`make_contiguous`] was previously called, all elements of the deque will be in the first slice and the second slice will be empty. <br>如果之前调用了 [`make_contiguous`]，则双端队列的所有元素都将在第一个切片中，而第二个切片将为空。<br>
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut deque = VecDeque::new();
    ///
    /// deque.push_back(0);
    /// deque.push_back(1);
    /// deque.push_back(2);
    ///
    /// assert_eq!(deque.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// deque.push_front(10);
    /// deque.push_front(9);
    ///
    /// assert_eq!(deque.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        let (a_range, b_range) = self.slice_ranges(..);
        // SAFETY: `slice_ranges` always returns valid ranges into the physical buffer. <br>`slice_ranges` 始终将有效范围返回到物理缓冲区。<br>
        //
        unsafe { (&*self.buffer_range(a_range), &*self.buffer_range(b_range)) }
    }

    /// Returns a pair of slices which contain, in order, the contents of the deque. <br>返回一对按顺序包含双端队列内容的切片。<br>
    ///
    /// If [`make_contiguous`] was previously called, all elements of the deque will be in the first slice and the second slice will be empty. <br>如果之前调用了 [`make_contiguous`]，则双端队列的所有元素都将在第一个切片中，而第二个切片将为空。<br>
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut deque = VecDeque::new();
    ///
    /// deque.push_back(0);
    /// deque.push_back(1);
    ///
    /// deque.push_front(10);
    /// deque.push_front(9);
    ///
    /// deque.as_mut_slices().0[0] = 42;
    /// deque.as_mut_slices().1[0] = 24;
    /// assert_eq!(deque.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        let (a_range, b_range) = self.slice_ranges(..);
        // SAFETY: `slice_ranges` always returns valid ranges into the physical buffer. <br>`slice_ranges` 始终将有效范围返回到物理缓冲区。<br>
        //
        unsafe { (&mut *self.buffer_range(a_range), &mut *self.buffer_range(b_range)) }
    }

    /// Returns the number of elements in the deque. <br>返回双端队列中的元素数。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut deque = VecDeque::new();
    /// assert_eq!(deque.len(), 0);
    /// deque.push_back(1);
    /// assert_eq!(deque.len(), 1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Returns `true` if the deque is empty. <br>如果双端队列为空，则返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut deque = VecDeque::new();
    /// assert!(deque.is_empty());
    /// deque.push_front(1);
    /// assert!(!deque.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    /// Given a range into the logical buffer of the deque, this function return two ranges into the physical buffer that correspond to the given range. <br>给定双端队列逻辑缓冲区中的范围，此函数将两个范围返回到与给定范围相对应的物理缓冲区中。<br>
    ///
    ///
    fn slice_ranges<R>(&self, range: R) -> (Range<usize>, Range<usize>)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len);
        let len = end - start;

        if len == 0 {
            (0..0, 0..0)
        } else {
            // `slice::range` guarantees that `start <= end <= self.len`. <br>`slice::range` 保证 `start <= end <= self.len`。<br>
            // because `len != 0`, we know that `start < end`, so `start < self.len` and the indexing is valid. <br>因为 `len != 0`，我们知道 `start < end`，所以 `start < self.len` 和索引是有效的。<br>
            //
            let wrapped_start = self.to_physical_idx(start);

            // this subtraction can never overflow because `wrapped_start` is at most `self.capacity()` (and if `self.capacity != 0`, then `wrapped_start` is strictly less than `self.capacity`). <br>这个减法永远不会溢出，因为 `wrapped_start` 最多是 `self.capacity()` (如果是 `self.capacity != 0`，那么 `wrapped_start` 严格小于 `self.capacity`)。<br>
            //
            //
            let head_len = self.capacity() - wrapped_start;

            if head_len >= len {
                // we know that `len + wrapped_start <= self.capacity <= usize::MAX`, so this addition can't overflow <br>我们知道 `len + wrapped_start <= self.capacity <= usize::MAX`，所以这个加法不会溢出<br>
                (wrapped_start..wrapped_start + len, 0..0)
            } else {
                // can't overflow because of the if condition <br>由于 if 条件不能溢出<br>
                let tail_len = len - head_len;
                (wrapped_start..self.capacity(), 0..tail_len)
            }
        }
    }

    /// Creates an iterator that covers the specified range in the deque. <br>创建一个覆盖双端队列中指定范围的迭代器。<br>
    ///
    /// # Panics
    ///
    /// Panics if the starting point is greater than the end point or if the end point is greater than the length of the deque. <br>如果起点大于终点或终点大于双端队列的长度，则会出现 panic。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = [1, 2, 3].into();
    /// let range = deque.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // A full range covers all contents <br>全方位涵盖所有内容<br>
    /// let all = deque.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (a_range, b_range) = self.slice_ranges(range);
        // SAFETY: The ranges returned by `slice_ranges` are valid ranges into the physical buffer, so it's ok to pass them to `buffer_range` and dereference the result. <br>`slice_ranges` 返回的范围是物理缓冲区中的有效范围，因此可以将它们传递给 `buffer_range` 并解释使用结果。<br>
        //
        //
        //
        let a = unsafe { &*self.buffer_range(a_range) };
        let b = unsafe { &*self.buffer_range(b_range) };
        Iter::new(a.iter(), b.iter())
    }

    /// Creates an iterator that covers the specified mutable range in the deque. <br>创建一个迭代器，覆盖双端队列中指定的无效范围。<br>
    ///
    /// # Panics
    ///
    /// Panics if the starting point is greater than the end point or if the end point is greater than the length of the deque. <br>如果起点大于终点或终点大于双端队列的长度，则会出现 panic。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = [1, 2, 3].into();
    /// for v in deque.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(deque, [1, 2, 6]);
    ///
    /// // A full range covers all contents <br>全方位涵盖所有内容<br>
    /// for v in deque.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(deque, [2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (a_range, b_range) = self.slice_ranges(range);
        // SAFETY: The ranges returned by `slice_ranges` are valid ranges into the physical buffer, so it's ok to pass them to `buffer_range` and dereference the result. <br>`slice_ranges` 返回的范围是物理缓冲区中的有效范围，因此可以将它们传递给 `buffer_range` 并解释使用结果。<br>
        //
        //
        //
        let a = unsafe { &mut *self.buffer_range(a_range) };
        let b = unsafe { &mut *self.buffer_range(b_range) };
        IterMut::new(a.iter_mut(), b.iter_mut())
    }

    /// Removes the specified range from the deque in bulk, returning all removed elements as an iterator. <br>从双端队列中批量删除指定范围，并以迭代器的形式返回所有删除的元素。<br> If the iterator is dropped before being fully consumed, it drops the remaining removed elements. <br>如果迭代器在被完全消耗之前被丢弃，它会丢弃剩余的已删除元素。<br>
    ///
    /// The returned iterator keeps a mutable borrow on the queue to optimize its implementation. <br>返回的迭代器在队列上保留一个可变借用以优化其实现。<br>
    ///
    /// # Panics
    ///
    /// Panics if the starting point is greater than the end point or if the end point is greater than the length of the deque. <br>如果起点大于终点或终点大于双端队列的长度，则会出现 panic。<br>
    ///
    /// # Leaking
    ///
    /// If the returned iterator goes out of scope without being dropped (due to [`mem::forget`], for example), the deque may have lost and leaked elements arbitrarily, including elements outside the range. <br>如果返回的迭代器离开作用域而没有被丢弃 (例如，由于 [`mem::forget`])，则双端队列可能会任意丢失和泄漏元素，包括范围之外的元素。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = [1, 2, 3].into();
    /// let drained = deque.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(deque, [1, 2]);
    ///
    /// // A full range clears all contents, like `clear()` does <br>全范围清除所有内容，就像 `clear()` 一样<br>
    /// deque.drain(..);
    /// assert!(deque.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Memory safety <br>内存安全<br>
        //
        // When the Drain is first created, the source deque is shortened to make sure no uninitialized or moved-from elements are accessible at all if the Drain's destructor never gets to run. <br>首次创建 Drain 时，将缩短源双端队列，以确保在 Drain 的析构函数从不运行的情况下，根本无法访问未初始化或移出的元素。<br>
        //
        //
        // Drain will ptr::read out the values to remove. <br>Drain 将 ptr::read 取出要删除的值。<br>
        // When finished, the remaining data will be copied back to cover the hole, and the head/tail values will be restored correctly. <br>完成后，剩余的数据将被复制回以覆盖 hole，并且 head/tail 值将被正确恢复。<br>
        //
        //
        //
        let Range { start, end } = slice::range(range, ..self.len);
        let drain_start = start;
        let drain_len = end - start;

        // The deque's elements are parted into three segments: <br>双端队列的元素分为三个部分：<br>
        // * 0  -> drain_start
        // * drain_start -> drain_start+drain_len
        // * drain_start+drain_len -> self.len
        //
        // H = self.head;  T = self.head+self.len;  t = drain_start+drain_len;  h = drain_head
        //
        // We store drain_start as self.len, and drain_len and self.len as drain_len and orig_len respectively on the Drain. <br>我们将 drain_start 存储为 self.len，将 drain_len 和 self.len 分别存储为 Drain 上的 drain_len 和 orig_len。<br>
        // This also truncates the effective array such that if the Drain is leaked, we have forgotten about the potentially moved values after the start of the drain. <br>这也将截断有效数组，以使如果 Drain 泄漏，我们将在 drain 开始后忘记可能移动的值。<br>
        //
        //
        //        H   h   t   T
        // [. . . o o x x o o . . .]
        //
        // "forget" about the values after the start of the drain until after the drain is complete and the Drain destructor is run. <br>"forget" 关于 drain 开始之后的值，直到 drain 完成并且 Drain 析构函数运行之后。<br>
        //
        //
        //

        unsafe { Drain::new(self, drain_start, drain_len) }
    }

    /// Clears the deque, removing all values. <br>清除双端队列，删除所有值。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut deque = VecDeque::new();
    /// deque.push_back(1);
    /// deque.clear();
    /// assert!(deque.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
        // Not strictly necessary, but leaves things in a more consistent/predictable state. <br>并非绝对必要，但会使事情处于更 consistent/predictable 的状态。<br>
        self.head = 0;
    }

    /// Returns `true` if the deque contains an element equal to the given value. <br>如果双端队列包含等于给定值的元素，则返回 `true`。<br>
    ///
    /// This operation is *O*(*n*). <br>这个操作是 *O*(*n*)。<br>
    ///
    /// Note that if you have a sorted `VecDeque`, [`binary_search`] may be faster. <br>请注意，如果您有一个排序的 `VecDeque`，[`binary_search`] 可能会更快。<br>
    ///
    ///
    /// [`binary_search`]: VecDeque::binary_search
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<u32> = VecDeque::new();
    ///
    /// deque.push_back(0);
    /// deque.push_back(1);
    ///
    /// assert_eq!(deque.contains(&1), true);
    /// assert_eq!(deque.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Provides a reference to the front element, or `None` if the deque is empty. <br>提供对前面元素的引用，如果双端队列为空，则为 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Provides a mutable reference to the front element, or `None` if the deque is empty. <br>提供对前面元素的，可变引用，如果双端队列为空，则为 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Provides a reference to the back element, or `None` if the deque is empty. <br>提供对后退元素的引用，如果双端队列为空，则为 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len.wrapping_sub(1))
    }

    /// Provides a mutable reference to the back element, or `None` if the deque is empty. <br>如果双端队列为空，则为后面的元素提供一个，可变引用，或 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len.wrapping_sub(1))
    }

    /// Removes the first element and returns it, or `None` if the deque is empty. <br>删除第一个元素并返回它，如果双端队列为空，则返回 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let old_head = self.head;
            self.head = self.to_physical_idx(1);
            self.len -= 1;
            Some(unsafe { self.buffer_read(old_head) })
        }
    }

    /// Removes the last element from the deque and returns it, or `None` if it is empty. <br>从双端队列中移除最后一个元素并返回它，如果为空则返回 `None`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.len -= 1;
            Some(unsafe { self.buffer_read(self.to_physical_idx(self.len)) })
        }
    }

    /// Prepends an element to the deque. <br>将元素添加到双端队列。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.head = self.wrap_sub(self.head, 1);
        self.len += 1;

        unsafe {
            self.buffer_write(self.head, value);
        }
    }

    /// Appends an element to the back of the deque. <br>将一个元素追加到双端队列的后面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        unsafe { self.buffer_write(self.to_physical_idx(self.len), value) }
        self.len += 1;
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // Do the calculation like this to avoid overflowing if len + head > usize::MAX <br>如果 len + head > usize::MAX，请这样计算以避免溢出<br>
        self.head <= self.capacity() - self.len
    }

    /// Removes an element from anywhere in the deque and returns it, replacing it with the first element. <br>从双端队列中的任何位置移除一个元素并返回它，用第一个元素替换它。<br>
    ///
    ///
    /// This does not preserve ordering, but is *O*(1). <br>这不会保留顺序，而是 *O*(1)。<br>
    ///
    /// Returns `None` if `index` is out of bounds. <br>如果 `index` 越界，则返回 `None`。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len;
        if index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Removes an element from anywhere in the deque and returns it, replacing it with the last element. <br>从双端队列中的任何位置移除一个元素并返回它，用最后一个元素替换它。<br>
    ///
    ///
    /// This does not preserve ordering, but is *O*(1). <br>这不会保留顺序，而是 *O*(1)。<br>
    ///
    /// Returns `None` if `index` is out of bounds. <br>如果 `index` 越界，则返回 `None`。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len;
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Inserts an element at `index` within the deque, shifting all elements with indices greater than or equal to `index` towards the back. <br>在双端队列中的 `index` 处插入一个元素，将所有索引大于或等于 `index` 的元素向后移动。<br>
    ///
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Panics
    ///
    /// Panics if `index` is greater than deque's length <br>如果 `index` 大于双端队列的长度，则会产生 panic<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        let k = self.len - index;
        if k < index {
            // `index + 1` can't overflow, because if index was usize::MAX, then either the assert would've failed, or the deque would've tried to grow past usize::MAX and panicked. <br>`index + 1` 不能溢出，因为如果索引是 usize::MAX，那么要么断言会失败，要么双端队列会试图超过 usize::MAX 并发生 panic。<br>
            //
            //
            unsafe {
                // see `remove()` for explanation why this wrap_copy() call is safe. <br>请参见 `remove()` 以了解为什么此 wrap_copy() 调用是安全的。<br>
                self.wrap_copy(self.to_physical_idx(index), self.to_physical_idx(index + 1), k);
                self.buffer_write(self.to_physical_idx(index), value);
                self.len += 1;
            }
        } else {
            let old_head = self.head;
            self.head = self.wrap_sub(self.head, 1);
            unsafe {
                self.wrap_copy(old_head, self.head, index);
                self.buffer_write(self.to_physical_idx(index), value);
                self.len += 1;
            }
        }
    }

    /// Removes and returns the element at `index` from the deque. <br>从双端队列中移除并返回 `index` 处的元素。<br>
    /// Whichever end is closer to the removal point will be moved to make room, and all the affected elements will be moved to new positions. <br>靠近移除点的任意一端将被移动以腾出空间，所有受影响的元素将被移动到新位置。<br>
    ///
    /// Returns `None` if `index` is out of bounds. <br>如果 `index` 越界，则返回 `None`。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.len <= index {
            return None;
        }

        let wrapped_idx = self.to_physical_idx(index);

        let elem = unsafe { Some(self.buffer_read(wrapped_idx)) };

        let k = self.len - index - 1;
        // safety: due to the nature of the if-condition, whichever wrap_copy gets called, its length argument will be at most `self.len / 2`, so there can't be more than one overlapping area. <br>安全性: 由于 if 条件的性质，无论调用哪个 wrap_copy，其长度参数最多为 `self.len / 2`，因此重叠区域不会超过一个。<br>
        //
        //
        if k < index {
            unsafe { self.wrap_copy(self.wrap_add(wrapped_idx, 1), wrapped_idx, k) };
            self.len -= 1;
        } else {
            let old_head = self.head;
            self.head = self.to_physical_idx(1);
            unsafe { self.wrap_copy(old_head, self.head, index) };
            self.len -= 1;
        }

        elem
    }

    /// Splits the deque into two at the given index. <br>在给定索引处将双端队列拆分为两个。<br>
    ///
    /// Returns a newly allocated `VecDeque`. <br>返回新分配的 `VecDeque`。<br>
    /// `self` contains elements `[0, at)`, and the returned deque contains elements `[at, len)`. <br>`self` 包含元素 `[0, at)`，返回的双端队列包含元素 `[at, len)`。<br>
    ///
    /// Note that the capacity of `self` does not change. <br>请注意，`self` 的容量不会改变。<br>
    ///
    /// Element at index 0 is the front of the queue. <br>索引为 0 的元素在队列的最前面。<br>
    ///
    /// # Panics
    ///
    /// Panics if `at > len`. <br>如果为 `at > len`，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = [1, 2, 3].into();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        let len = self.len;
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity_in(other_len, self.allocator().clone());

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` lies in the first half. <br>`at` 位于前半部分。<br>
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // just take all of the second half. <br>下半部分全部拿下。<br>
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` lies in the second half, need to factor in the elements we skipped in the first half. <br>`at` 位于后半部分，需要考虑我们在前半部分跳过的元素。<br>
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Cleanup where the ends of the buffers are <br>清理缓冲区末端的位置<br>
        self.len = at;
        other.len = other_len;

        other
    }

    /// Moves all the elements of `other` into `self`, leaving `other` empty. <br>将 `other` 的所有元素移到 `self`，将 `other` 留空。<br>
    ///
    /// # Panics
    ///
    /// Panics if the new number of elements in self overflows a `usize`. <br>如果 self 中的新元素数溢出了一个 `usize`，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = [1, 2].into();
    /// let mut buf2: VecDeque<_> = [3, 4].into();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        if T::IS_ZST {
            self.len = self.len.checked_add(other.len).expect("capacity overflow");
            other.len = 0;
            other.head = 0;
            return;
        }

        self.reserve(other.len);
        unsafe {
            let (left, right) = other.as_slices();
            self.copy_slice(self.to_physical_idx(self.len), left);
            // no overflow, because self.capacity() >= old_cap + left.len() >= self.len + left.len() <br>没有溢出，因为 self.capacity() >=old_cap + left.len() >= self.len + left.len()<br>
            self.copy_slice(self.to_physical_idx(self.len + left.len()), right);
        }
        // SAFETY: Update pointers after copying to avoid leaving doppelganger in case of panics. <br>复制后更新指针，以避免在 panics 的情况下留下分身。<br>
        //
        self.len += other.len;
        // Now that we own its values, forget everything in `other`. <br>现在我们拥有了它的值，忘记 `other` 中的一切。<br>
        other.len = 0;
        other.head = 0;
    }

    /// Retains only the elements specified by the predicate. <br>仅保留谓词指定的元素。<br>
    ///
    /// In other words, remove all elements `e` for which `f(&e)` returns false. <br>换句话说，删除 `f(&e)` 返回 false 的所有元素 `e`。<br>
    /// This method operates in place, visiting each element exactly once in the original order, and preserves the order of the retained elements. <br>此方法在原位运行，以原始顺序恰好一次访问每个元素，并保留保留元素的顺序。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Because the elements are visited exactly once in the original order, external state may be used to decide which elements to keep. <br>由于按原始顺序仅对元素进行过一次访问，因此可以使用外部状态来确定要保留哪些元素。<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// buf.retain(|_| *iter.next().unwrap());
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.retain_mut(|elem| f(elem));
    }

    /// Retains only the elements specified by the predicate. <br>仅保留谓词指定的元素。<br>
    ///
    /// In other words, remove all elements `e` for which `f(&e)` returns false. <br>换句话说，删除 `f(&e)` 返回 false 的所有元素 `e`。<br>
    /// This method operates in place, visiting each element exactly once in the original order, and preserves the order of the retained elements. <br>此方法在原位运行，以原始顺序恰好一次访问每个元素，并保留保留元素的顺序。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain_mut(|x| if *x % 2 == 0 {
    ///     *x += 1;
    ///     true
    /// } else {
    ///     false
    /// });
    /// assert_eq!(buf, [3, 5]);
    /// ```
    #[stable(feature = "vec_retain_mut", since = "1.61.0")]
    pub fn retain_mut<F>(&mut self, mut f: F)
    where
        F: FnMut(&mut T) -> bool,
    {
        let len = self.len;
        let mut idx = 0;
        let mut cur = 0;

        // Stage 1: All values are retained. <br>第 1 阶段：保留所有值。<br>
        while cur < len {
            if !f(&mut self[cur]) {
                cur += 1;
                break;
            }
            cur += 1;
            idx += 1;
        }
        // Stage 2: Swap retained value into current idx. <br>第 2 阶段：将保留值交换为当前 idx。<br>
        while cur < len {
            if !f(&mut self[cur]) {
                cur += 1;
                continue;
            }

            self.swap(idx, cur);
            cur += 1;
            idx += 1;
        }
        // Stage 3: Truncate all values after idx. <br>阶段 3: 截断 idx 之后的所有值。<br>
        if cur != idx {
            self.truncate(idx);
        }
    }

    // Double the buffer size. <br>将缓冲区大小增加一倍。<br>
    // This method is inline(never), so we expect it to only be called in cold paths. <br>这个方法是 inline(never)，所以我们希望它只在 cold 路径中被调用。<br>
    // This may panic or abort <br>这可能会导致 panic 或终止<br>
    #[inline(never)]
    fn grow(&mut self) {
        // Extend or possibly remove this assertion when valid use-cases for growing the buffer without it being full emerge <br>当有效的用例出现时，扩展或者可能删除这个断言，从而在缓冲区没有满的情况下增长它<br>
        //
        debug_assert!(self.is_full());
        let old_cap = self.capacity();
        self.buf.reserve_for_push(old_cap);
        unsafe {
            self.handle_capacity_increase(old_cap);
        }
        debug_assert!(!self.is_full());
    }

    /// Modifies the deque in-place so that `len()` is equal to `new_len`, either by removing excess elements from the back or by appending elements generated by calling `generator` to the back. <br>通过从后面删除多余的元素或通过将调用 `generator` 生成的元素，追加，到后面，就地修改双端队列，使 `len()` 等于 `new_len`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len;

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Rearranges the internal storage of this deque so it is one contiguous slice, which is then returned. <br>重新排列此双端队列的内部存储，使其成为一个连续的切片，然后将其返回。<br>
    ///
    /// This method does not allocate and does not change the order of the inserted elements. <br>此方法不分配也不更改插入元素的顺序。<br> As it returns a mutable slice, this can be used to sort a deque. <br>当它返回可变切片时，可用于对双端队列进行排序。<br>
    ///
    /// Once the internal storage is contiguous, the [`as_slices`] and [`as_mut_slices`] methods will return the entire contents of the deque in a single slice. <br>一旦内部存储是连续的，[`as_slices`] 和 [`as_mut_slices`] 方法将在单个切片中返回双端队列的全部内容。<br>
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Sorting the content of a deque. <br>对双端队列的内容进行排序。<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // sorting the deque <br>排序双端队列<br>
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // sorting it in reverse order <br>反向排序<br>
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Getting immutable access to the contiguous slice. <br>不可变地访问连续的切片。<br>
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // we can now be sure that `slice` contains all elements of the deque, while still having immutable access to `buf`. <br>现在，我们可以确定 `slice` 包含了双端队列的所有元素，同时仍具有对 `buf` 的不可变访问权限。<br>
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if T::IS_ZST {
            self.head = 0;
        }

        if self.is_contiguous() {
            unsafe { return slice::from_raw_parts_mut(self.ptr().add(self.head), self.len) }
        }

        let &mut Self { head, len, .. } = self;
        let ptr = self.ptr();
        let cap = self.capacity();

        let free = cap - len;
        let head_len = cap - head;
        let tail = len - head_len;
        let tail_len = tail;

        if free >= head_len {
            // there is enough free space to copy the head in one go, this means that we first shift the tail backwards, and then copy the head to the correct position. <br>有足够的空闲空间来一次性复制头部，这意味着我们先将尾部向后移动，然后再将头部复制到正确的位置。<br>
            //
            //
            // from: DEFGH....ABC to:   ABCDEFGH ....
            //
            //
            unsafe {
                self.copy(0, head_len, tail_len);
                // ...DEFGH.ABC
                self.copy_nonoverlapping(head, 0, head_len);
                // ABCDEFGH....
            }

            self.head = 0;
        } else if free >= tail_len {
            // there is enough free space to copy the tail in one go, this means that we first shift the head forwards, and then copy the tail to the correct position. <br>有足够的空闲空间来一次性复制尾部，这意味着我们首先向前移动头部，然后将尾部复制到正确的位置。<br>
            //
            //
            // from: FGH....ABCDE to:   ...ABCDEFGH. <br>从: FGH....ABCDE 到: ...ABCDEFGH。<br>
            //
            //
            unsafe {
                self.copy(head, tail, head_len);
                // FGHABCDE....
                self.copy_nonoverlapping(0, tail + head_len, tail_len);
                // ...ABCDEFGH.
            }

            self.head = tail;
        } else {
            // `free` is smaller than both `head_len` and `tail_len`. <br>`free` 小于 `head_len` 和 `tail_len`。<br>
            // the general algorithm for this first moves the slices right next to each other and then uses `slice::rotate` to rotate them into place: <br>这个的一般算法首先将切片彼此紧挨着移动，然后使用 `slice::rotate` 将它们旋转到位:<br>
            //
            //
            // initially:   HIJK..ABCDEFG step 1:      ..HIJKABCDEFG step 2:      ..ABCDEFGHIJK
            //
            // or:
            //
            // initially:   FGHIJK..ABCDE step 1:      FGHIJKABCDE..
            // step 2:      ABCDEFGHIJK..
            //
            //
            //
            //

            // pick the shorter of the 2 slices to reduce the amount of memory that needs to be moved around. <br>选择 2 个切片中较短的一个以减少需要移动的内存量。<br>
            //
            if head_len > tail_len {
                // tail is shorter, so: <br>尾巴较短，所以:<br>
                //  1. copy tail forwards <br>复制尾部向前<br>
                //  2. rotate used part of the buffer <br>旋转缓冲区的已用部分<br>
                //  3. update head to point to the new beginning (which is just `free`) <br>更新 head 指向新的开始 (就是 `free`)<br>

                unsafe {
                    // if there is no free space in the buffer, then the slices are already right next to each other and we don't need to move any memory. <br>如果缓冲区中没有可用空间，则切片已经紧挨着彼此，我们不需要移动任何内存。<br>
                    //
                    if free != 0 {
                        // because we only move the tail forward as much as there's free space behind it, we don't overwrite any elements of the head slice, and the slices end up right next to each other. <br>因为我们只将尾巴向前移动到它后面有可用空间的程度，所以我们不会覆盖头部切片的任何元素，并且切片最终彼此紧挨着。<br>
                        //
                        //
                        self.copy(0, free, tail_len);
                    }

                    // We just copied the tail right next to the head slice, so all of the elements in the range are initialized <br>我们只是将尾部复制到头部切片的旁边，因此该范围内的所有元素都已初始化<br>
                    //
                    let slice = &mut *self.buffer_range(free..self.capacity());

                    // because the deque wasn't contiguous, we know that `tail_len < self.len == slice.len()`, so this will never panic. <br>因为 deque 不是连续的，我们知道 `tail_len < self.len == slice.len()`，所以这永远不会 panic。<br>
                    //
                    slice.rotate_left(tail_len);

                    // the used part of the buffer now is `free..self.capacity()`, so set `head` to the beginning of that range. <br>现在缓冲区的使用部分是 `free..self.capacity()`，因此将 `head` 设置为该范围的开头。<br>
                    //
                    self.head = free;
                }
            } else {
                // head is shorter so: <br>头较短，所以:<br>
                //  1. copy head backwards <br>向后复制头部<br>
                //  2. rotate used part of the buffer <br>旋转缓冲区的已用部分<br>
                //  3. update head to point to the new beginning (which is the beginning of the buffer) <br>更新 head 以指向新的开始 (这是缓冲区的开始)<br>

                unsafe {
                    // if there is no free space in the buffer, then the slices are already right next to each other and we don't need to move any memory. <br>如果缓冲区中没有可用空间，则切片已经紧挨着彼此，我们不需要移动任何内存。<br>
                    //
                    if free != 0 {
                        // copy the head slice to lie right behind the tail slice. <br>将头部切片复制到尾部切片的正后方。<br>
                        self.copy(self.head, tail_len, head_len);
                    }

                    // because we copied the head slice so that both slices lie right next to each other, all the elements in the range are initialized. <br>因为我们复制了头部切片，所以两个切片都紧挨着彼此，所以范围内的所有元素都被初始化了。<br>
                    //
                    let slice = &mut *self.buffer_range(0..self.len);

                    // because the deque wasn't contiguous, we know that `head_len < self.len == slice.len()` so this will never panic. <br>因为 deque 不是连续的，我们知道 `head_len < self.len == slice.len()` 所以这永远不会 panic。<br>
                    //
                    slice.rotate_right(head_len);

                    // the used part of the buffer now is `0..self.len`, so set `head` to the beginning of that range. <br>现在缓冲区的使用部分是 `0..self.len`，因此将 `head` 设置为该范围的开头。<br>
                    //
                    self.head = 0;
                }
            }
        }

        unsafe { slice::from_raw_parts_mut(ptr.add(self.head), self.len) }
    }

    /// Rotates the double-ended queue `mid` places to the left. <br>将双端队列 `mid` 放置到左侧。<br>
    ///
    /// Equivalently,
    /// - Rotates item `mid` into the first position. <br>将项 `mid` 旋转到第一个位置。<br>
    /// - Pops the first `mid` items and pushes them to the end. <br>弹出第一个 `mid` 项并将其推到末尾。<br>
    /// - Rotates `len() - mid` places to the right. <br>向右旋转 `len() - mid` 位置。<br>
    ///
    /// # Panics
    ///
    /// If `mid` is greater than `len()`. <br>如果 `mid` 大于 `len()`。<br>
    /// Note that `mid == len()` does _not_ panic and is a no-op rotation. <br>请注意，`mid == len()` 执行 _not_ panic，并且是无操作旋转。<br>
    ///
    /// # Complexity
    ///
    /// Takes `*O*(min(mid, len() - mid))` time and no extra space. <br>花费 `*O*(min(mid, len() - mid))` 的时间，没有多余的空间。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Rotates the double-ended queue `k` places to the right. <br>向右旋转 `k` 位置的双端队列。<br>
    ///
    /// Equivalently,
    /// - Rotates the first item into position `k`. <br>将第一个项旋转到位置 `k`。<br>
    /// - Pops the last `k` items and pushes them to the front. <br>弹出最后一个 `k` 项并将其推到前面。<br>
    /// - Rotates `len() - k` places to the left. <br>将 `len() - k` 位置向左旋转。<br>
    ///
    /// # Panics
    ///
    /// If `k` is greater than `len()`. <br>如果 `k` 大于 `len()`。<br>
    /// Note that `k == len()` does _not_ panic and is a no-op rotation. <br>请注意，`k == len()` 执行 _not_ panic，并且是无操作旋转。<br>
    ///
    /// # Complexity
    ///
    /// Takes `*O*(min(k, len() - k))` time and no extra space. <br>花费 `*O*(min(k, len() - k))` 的时间，没有多余的空间。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SAFETY: the following two methods require that the rotation amount be less than half the length of the deque. <br>以下两种方法要求旋转量小于双端队列的长度的一半。<br>
    //
    // `wrap_copy` requires that `min(x, capacity() - x) + copy_len <= capacity()`, but then `min` is never more than half the capacity, regardless of x, so it's sound to call here because we're calling with something less than half the length, which is never above half the capacity. <br>`wrap_copy` 需要 `min(x, capacity() - x) + copy_len <= capacity()`，但是 `min` 永远不会超过容量的一半，无论 x 是什么，所以在这里调用是合理的，因为我们调用的长度小于一半，这永远不会超过容量的一半。<br>
    //
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.to_physical_idx(self.len), mid);
        }
        self.head = self.to_physical_idx(mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        unsafe {
            self.wrap_copy(self.to_physical_idx(self.len), self.head, k);
        }
    }

    /// Binary searches this `VecDeque` for a given element. <br>二进制搜索在这个 `VecDeque` 中搜索给定的元素。<br>
    /// This behaves similarly to [`contains`] if this `VecDeque` is sorted. <br>如果对这个 `VecDeque` 进行排序，则其行为类似于 [`contains`]。<br>
    ///
    /// If the value is found then [`Result::Ok`] is returned, containing the index of the matching element. <br>如果找到该值，则返回 [`Result::Ok`]，其中包含匹配元素的索引。<br>
    /// If there are multiple matches, then any one of the matches could be returned. <br>如果有多个匹配项，则可以返回任何一个匹配项。<br>
    /// If the value is not found then [`Result::Err`] is returned, containing the index where a matching element could be inserted while maintaining sorted order. <br>如果找不到该值，则返回 [`Result::Err`]，其中包含在保留排序顺序的同时可以在其中插入匹配元素的索引。<br>
    ///
    ///
    /// See also [`binary_search_by`], [`binary_search_by_key`], and [`partition_point`]. <br>另请参见 [`binary_search_by`]，[`binary_search_by_key`] 和 [`partition_point`]。<br>
    ///
    /// [`contains`]: VecDeque::contains
    /// [`binary_search_by`]: VecDeque::binary_search_by
    /// [`binary_search_by_key`]: VecDeque::binary_search_by_key
    /// [`partition_point`]: VecDeque::partition_point
    ///
    /// # Examples
    ///
    /// Looks up a series of four elements. <br>查找一系列四个元素。<br>
    /// The first is found, with a uniquely determined position; <br>找到第一个，具有唯一确定的位置；<br> the second and third are not found; <br>没有找到第二个和第三个；<br> the fourth could match any position in `[1, 4]`. <br>第四个可以匹配 `[1, 4]` 中的任何位置。<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// If you want to insert an item to a sorted deque, while maintaining sort order, consider using [`partition_point`]: <br>如果要在已排序的双端队列中插入项，同时保持排序顺序，请考虑使用 [`partition_point`]:<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.partition_point(|&x| x < num);
    /// // The above is equivalent to `let idx = deque.binary_search(&num).unwrap_or_else(|x| x);` <br>以上等价于 `let idx = deque.binary_search(&num).unwrap_or_else(|x| x);`<br>
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vecdeque_binary_search", since = "1.54.0")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binary searches this `VecDeque` with a comparator function. <br>二进制搜索使用比较器函数搜索这个 `VecDeque`。<br>
    /// This behaves similarly to [`contains`] if this `VecDeque` is sorted. <br>如果对这个 `VecDeque` 进行排序，则其行为类似于 [`contains`]。<br>
    ///
    /// The comparator function should implement an order consistent with the sort order of the deque, returning an order code that indicates whether its argument is `Less`, `Equal` or `Greater` than the desired target. <br>比较器函数应该实现与双端队列的排序顺序一致的顺序，返回一个顺序代码，指示其参数是 `Less`、`Equal` 还是 `Greater`，而不是所需的目标。<br>
    ///
    ///
    /// If the value is found then [`Result::Ok`] is returned, containing the index of the matching element. <br>如果找到该值，则返回 [`Result::Ok`]，其中包含匹配元素的索引。<br> If there are multiple matches, then any one of the matches could be returned. <br>如果有多个匹配项，则可以返回任何一个匹配项。<br>
    /// If the value is not found then [`Result::Err`] is returned, containing the index where a matching element could be inserted while maintaining sorted order. <br>如果找不到该值，则返回 [`Result::Err`]，其中包含在保留排序顺序的同时可以在其中插入匹配元素的索引。<br>
    ///
    /// See also [`binary_search`], [`binary_search_by_key`], and [`partition_point`]. <br>另请参见 [`binary_search`]，[`binary_search_by_key`] 和 [`partition_point`]。<br>
    ///
    /// [`contains`]: VecDeque::contains
    /// [`binary_search`]: VecDeque::binary_search
    /// [`binary_search_by_key`]: VecDeque::binary_search_by_key
    /// [`partition_point`]: VecDeque::partition_point
    ///
    /// # Examples
    ///
    /// Looks up a series of four elements. <br>查找一系列四个元素。<br> The first is found, with a uniquely determined position; <br>找到第一个，具有唯一确定的位置；<br> the second and third are not found; <br>没有找到第二个和第三个；<br> the fourth could match any position in `[1, 4]`. <br>第四个可以匹配 `[1, 4]` 中的任何位置。<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "vecdeque_binary_search", since = "1.54.0")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();
        let cmp_back = back.first().map(|elem| f(elem));

        if let Some(Ordering::Equal) = cmp_back {
            Ok(front.len())
        } else if let Some(Ordering::Less) = cmp_back {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary searches this `VecDeque` with a key extraction function. <br>二进制搜索使用键提取函数搜索此 `VecDeque`。<br>
    /// This behaves similarly to [`contains`] if this `VecDeque` is sorted. <br>如果对这个 `VecDeque` 进行排序，则其行为类似于 [`contains`]。<br>
    ///
    /// Assumes that the deque is sorted by the key, for instance with [`make_contiguous().sort_by_key()`] using the same key extraction function. <br>假设双端队列按键排序，例如 [`make_contiguous().sort_by_key()`] 使用相同的键提取函数。<br>
    ///
    /// If the value is found then [`Result::Ok`] is returned, containing the index of the matching element. <br>如果找到该值，则返回 [`Result::Ok`]，其中包含匹配元素的索引。<br>
    /// If there are multiple matches, then any one of the matches could be returned. <br>如果有多个匹配项，则可以返回任何一个匹配项。<br>
    /// If the value is not found then [`Result::Err`] is returned, containing the index where a matching element could be inserted while maintaining sorted order. <br>如果找不到该值，则返回 [`Result::Err`]，其中包含在保留排序顺序的同时可以在其中插入匹配元素的索引。<br>
    ///
    ///
    /// See also [`binary_search`], [`binary_search_by`], and [`partition_point`]. <br>另请参见 [`binary_search`]，[`binary_search_by`] 和 [`partition_point`]。<br>
    ///
    /// [`contains`]: VecDeque::contains
    /// [`make_contiguous().sort_by_key()`]: VecDeque::make_contiguous
    /// [`binary_search`]: VecDeque::binary_search
    /// [`binary_search_by`]: VecDeque::binary_search_by
    /// [`partition_point`]: VecDeque::partition_point
    ///
    /// # Examples
    ///
    /// Looks up a series of four elements in a slice of pairs sorted by their second elements. <br>在成对的切片中按其第二个元素排序的一系列四个元素中查找。<br>
    /// The first is found, with a uniquely determined position; <br>找到第一个，具有唯一确定的位置；<br> the second and third are not found; <br>没有找到第二个和第三个；<br> the fourth could match any position in `[1, 4]`. <br>第四个可以匹配 `[1, 4]` 中的任何位置。<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = [(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "vecdeque_binary_search", since = "1.54.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Returns the index of the partition point according to the given predicate (the index of the first element of the second partition). <br>根据给定的谓词返回分区点的索引 (第二个分区的第一个元素的索引)。<br>
    ///
    /// The deque is assumed to be partitioned according to the given predicate. <br>假定双端队列根据给定的谓词进行了分区。<br>
    /// This means that all elements for which the predicate returns true are at the start of the deque and all elements for which the predicate returns false are at the end. <br>这意味着谓词返回 true 的所有元素都在双端队列的开头，而谓词返回 false 的所有元素都在末尾。<br>
    ///
    /// For example, `[7, 15, 3, 5, 4, 12, 6]` is partitioned under the predicate `x % 2 != 0` (all odd numbers are at the start, all even at the end). <br>例如，`[7, 15, 3, 5, 4, 12, 6]` 在谓词 `x % 2 != 0` 下进行分区 (所有奇数都在开头，所有偶数都在结尾)。<br>
    ///
    /// If the deque is not partitioned, the returned result is unspecified and meaningless, as this method performs a kind of binary search. <br>如果双端队列没有分区，则返回的结果是未指定且无意义的，因为此方法执行一种二分查找。<br>
    ///
    /// See also [`binary_search`], [`binary_search_by`], and [`binary_search_by_key`]. <br>另请参见 [`binary_search`]，[`binary_search_by`] 和 [`binary_search_by_key`]。<br>
    ///
    /// [`binary_search`]: VecDeque::binary_search
    /// [`binary_search_by`]: VecDeque::binary_search_by
    /// [`binary_search_by_key`]: VecDeque::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = [1, 2, 3, 3, 5, 6, 7].into();
    /// let i = deque.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(deque.iter().take(i).all(|&x| x < 5));
    /// assert!(deque.iter().skip(i).all(|&x| !(x < 5)));
    /// ```
    ///
    /// If you want to insert an item to a sorted deque, while maintaining sort order: <br>如果要在已排序的双端队列中插入项，同时保持排序顺序:<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.partition_point(|&x| x < num);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "vecdeque_binary_search", since = "1.54.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let (front, back) = self.as_slices();

        if let Some(true) = back.first().map(|v| pred(v)) {
            back.partition_point(pred) + front.len()
        } else {
            front.partition_point(pred)
        }
    }
}

impl<T: Clone, A: Allocator> VecDeque<T, A> {
    /// Modifies the deque in-place so that `len()` is equal to new_len, either by removing excess elements from the back or by appending clones of `value` to the back. <br>通过从后面删除多余的元素或将 `value` 的克隆，追加，到后面，就地修改双端队列以使 `len()` 等于 new_len。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        if new_len > self.len() {
            let extra = new_len - self.len();
            self.extend(repeat_n(value, extra))
        } else {
            self.truncate(new_len);
        }
    }
}

/// Returns the index in the underlying buffer for a given logical element index. <br>返回给定逻辑元素索引的底层缓冲区中的索引。<br>
#[inline]
fn wrap_index(logical_index: usize, capacity: usize) -> usize {
    debug_assert!(
        (logical_index == 0 && capacity == 0)
            || logical_index < capacity
            || (logical_index - capacity) < capacity
    );
    if logical_index >= capacity { logical_index - capacity } else { logical_index }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq, A: Allocator> PartialEq for VecDeque<T, A> {
    fn eq(&self, other: &Self) -> bool {
        if self.len != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Always divisible in three sections, for example: <br>始终可分为三部分，例如：<br>
            // self:  [a b c|d e f] other: [0 1 2 3|4 5] front = 3, mid = 1, [a b c] == [0 1 2] && [d] == [3] && [e f] == [4 5]
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for VecDeque<T, A> {}

__impl_slice_eq1! { [] VecDeque<T, A>, Vec<U, A>, }
__impl_slice_eq1! { [] VecDeque<T, A>, &[U], }
__impl_slice_eq1! { [] VecDeque<T, A>, &mut [U], }
__impl_slice_eq1! { [const N: usize] VecDeque<T, A>, [U; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<T, A>, &[U; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<T, A>, &mut [U; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for VecDeque<T, A> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for VecDeque<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for VecDeque<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        state.write_length_prefix(self.len);
        // It's not possible to use Hash::hash_slice on slices returned by as_slices method as their length can vary in otherwise identical deques. <br>在 as_slices 方法返回的切片上无法使用 Hash::hash_slice，因为它们的长度会因其他双端队列相同而有所不同。<br>
        //
        //
        // Hasher only guarantees equivalence for the exact same set of calls to its methods. <br>Hasher 仅保证对其方法的完全相同的调用集是等效的。<br>
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Index<usize> for VecDeque<T, A> {
    type Output = T;

    #[inline]
    fn index(&self, index: usize) -> &T {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IndexMut<usize> for VecDeque<T, A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut T {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for VecDeque<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> VecDeque<T> {
        SpecFromIter::spec_from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for VecDeque<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Consumes the deque into a front-to-back iterator yielding elements by value. <br>将双端队列消耗到一个从前到后的迭代器中，按值产生元素。<br>
    ///
    fn into_iter(self) -> IntoIter<T, A> {
        IntoIter::new(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a VecDeque<T, A> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut VecDeque<T, A> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for VecDeque<T, A> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter());
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy, A: Allocator> Extend<&'a T> for VecDeque<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for VecDeque<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T, A: Allocator> From<Vec<T, A>> for VecDeque<T, A> {
    /// Turn a [`Vec<T>`] into a [`VecDeque<T>`]. <br>将 [`Vec<T>`] 变成 [`VecDeque<T>`]。<br>
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// This conversion is guaranteed to run in *O*(1) time and to not re-allocate the `Vec`'s buffer or allocate any additional memory. <br>此转换保证在 *O*(1) 时间内运行，并且不会重新分配 `Vec` 的缓冲区或分配任何额外的内存。<br>
    ///
    ///
    #[inline]
    fn from(other: Vec<T, A>) -> Self {
        let (ptr, len, cap, alloc) = other.into_raw_parts_with_alloc();
        Self { head: 0, len, buf: unsafe { RawVec::from_raw_parts_in(ptr, cap, alloc) } }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T, A: Allocator> From<VecDeque<T, A>> for Vec<T, A> {
    /// Turn a [`VecDeque<T>`] into a [`Vec<T>`]. <br>将 [`VecDeque<T>`] 变成 [`Vec<T>`]。<br>
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// This never needs to re-allocate, but does need to do *O*(*n*) data movement if the circular buffer doesn't happen to be at the beginning of the allocation. <br>这永远不需要重新分配，但是如果循环缓冲区恰好不在分配开始时，则确实需要进行 *O*(*n*) 数据移动。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // This one is *O*(1). <br>这是 *O*(1)。<br>
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // This one needs data rearranging. <br>这一项需要重新整理数据。<br>
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T, A>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.capacity();
            let alloc = ptr::read(other.allocator());

            if other.head != 0 {
                ptr::copy(buf.add(other.head), buf, len);
            }
            Vec::from_raw_parts_in(buf, len, cap, alloc)
        }
    }
}

#[stable(feature = "std_collections_from_array", since = "1.56.0")]
impl<T, const N: usize> From<[T; N]> for VecDeque<T> {
    /// Converts a `[T; N]` into a `VecDeque<T>`. <br>将 `[T; N]` 转换为 `VecDeque<T>`。<br>
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let deq1 = VecDeque::from([1, 2, 3, 4]);
    /// let deq2: VecDeque<_> = [1, 2, 3, 4].into();
    /// assert_eq!(deq1, deq2);
    /// ```
    fn from(arr: [T; N]) -> Self {
        let mut deq = VecDeque::with_capacity(N);
        let arr = ManuallyDrop::new(arr);
        if !<T>::IS_ZST {
            // SAFETY: VecDeque::with_capacity ensures that there is enough capacity. <br>VecDeque::with_capacity 确保有足够的容量。<br>
            unsafe {
                ptr::copy_nonoverlapping(arr.as_ptr(), deq.ptr(), N);
            }
        }
        deq.head = 0;
        deq.len = N;
        deq
    }
}
