//! A private parser implementation of IPv4, IPv6, and socket addresses. <br>IPv4，IPv6 和套接字地址的专用解析器实现。<br>
//!
//! This module is "publicly exported" through the `FromStr` implementations below. <br>此该模块通过下面的 `FromStr` 实现 "公开导出"。<br>
//!

use crate::convert::TryInto;
use crate::error::Error;
use crate::fmt;
use crate::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr, SocketAddrV4, SocketAddrV6};
use crate::str::FromStr;

trait ReadNumberHelper: crate::marker::Sized {
    const ZERO: Self;
    fn checked_mul(&self, other: u32) -> Option<Self>;
    fn checked_add(&self, other: u32) -> Option<Self>;
}

macro_rules! impl_helper {
    ($($t:ty)*) => ($(impl ReadNumberHelper for $t {
        const ZERO: Self = 0;
        #[inline]
        fn checked_mul(&self, other: u32) -> Option<Self> {
            Self::checked_mul(*self, other.try_into().ok()?)
        }
        #[inline]
        fn checked_add(&self, other: u32) -> Option<Self> {
            Self::checked_add(*self, other.try_into().ok()?)
        }
    })*)
}

impl_helper! { u8 u16 u32 }

struct Parser<'a> {
    // Parsing as ASCII, so can use byte array. <br>解析为 ASCII，因此可以使用字节数组。<br>
    state: &'a [u8],
}

impl<'a> Parser<'a> {
    fn new(input: &'a [u8]) -> Parser<'a> {
        Parser { state: input }
    }

    /// Run a parser, and restore the pre-parse state if it fails. <br>运行解析器，如果解析失败，则还原其解析状态。<br>
    fn read_atomically<T, F>(&mut self, inner: F) -> Option<T>
    where
        F: FnOnce(&mut Parser<'_>) -> Option<T>,
    {
        let state = self.state;
        let result = inner(self);
        if result.is_none() {
            self.state = state;
        }
        result
    }

    /// Run a parser, but fail if the entire input wasn't consumed. <br>运行解析器，但如果未消耗全部输入，则会失败。<br>
    /// Doesn't run atomically. <br>不会自动运行。<br>
    fn parse_with<T, F>(&mut self, inner: F, kind: AddrKind) -> Result<T, AddrParseError>
    where
        F: FnOnce(&mut Parser<'_>) -> Option<T>,
    {
        let result = inner(self);
        if self.state.is_empty() { result } else { None }.ok_or(AddrParseError(kind))
    }

    /// Peek the next character from the input <br>Peek 输入的下一个字符<br>
    fn peek_char(&self) -> Option<char> {
        self.state.first().map(|&b| char::from(b))
    }

    /// Read the next character from the input <br>从输入中读取下一个字符<br>
    fn read_char(&mut self) -> Option<char> {
        self.state.split_first().map(|(&b, tail)| {
            self.state = tail;
            char::from(b)
        })
    }

    #[must_use]
    /// Read the next character from the input if it matches the target. <br>如果输入匹配目标，则从输入中读取下一个字符。<br>
    fn read_given_char(&mut self, target: char) -> Option<()> {
        self.read_atomically(|p| {
            p.read_char().and_then(|c| if c == target { Some(()) } else { None })
        })
    }

    /// Helper for reading separators in an indexed loop. <br>用于在索引循环中读取分隔符的帮助程序。<br> Reads the separator character iff index > 0, then runs the parser. <br>读取分隔符 iff index> 0，然后运行解析器。<br>
    ///
    /// When used in a loop, the separator character will only be read on index > 0 (see read_ipv4_addr for an example) <br>在循环中使用分隔符时，只会在索引 > 0 时读取 (请参见 read_ipv4_addr 的示例)<br>
    ///
    fn read_separator<T, F>(&mut self, sep: char, index: usize, inner: F) -> Option<T>
    where
        F: FnOnce(&mut Parser<'_>) -> Option<T>,
    {
        self.read_atomically(move |p| {
            if index > 0 {
                p.read_given_char(sep)?;
            }
            inner(p)
        })
    }

    // Read a number off the front of the input in the given radix, stopping at the first non-digit character or eof. <br>在给定的基数中从输入的开头读取一个数字，停在第一个非数字字符或 eof 处。<br>
    // Fails if the number has more digits than max_digits or if there is no number. <br>如果该数字的位数大于 max_digits 或没有数字，则失败。<br>
    //
    fn read_number<T: ReadNumberHelper>(
        &mut self,
        radix: u32,
        max_digits: Option<usize>,
        allow_zero_prefix: bool,
    ) -> Option<T> {
        self.read_atomically(move |p| {
            let mut result = T::ZERO;
            let mut digit_count = 0;
            let has_leading_zero = p.peek_char() == Some('0');

            while let Some(digit) = p.read_atomically(|p| p.read_char()?.to_digit(radix)) {
                result = result.checked_mul(radix)?;
                result = result.checked_add(digit)?;
                digit_count += 1;
                if let Some(max_digits) = max_digits {
                    if digit_count > max_digits {
                        return None;
                    }
                }
            }

            if digit_count == 0 {
                None
            } else if !allow_zero_prefix && has_leading_zero && digit_count > 1 {
                None
            } else {
                Some(result)
            }
        })
    }

    /// Read an IPv4 address. <br>读取一个 IPv4 地址。<br>
    fn read_ipv4_addr(&mut self) -> Option<Ipv4Addr> {
        self.read_atomically(|p| {
            let mut groups = [0; 4];

            for (i, slot) in groups.iter_mut().enumerate() {
                *slot = p.read_separator('.', i, |p| {
                    // Disallow octal number in IP string. <br>禁止在 IP 字符串中使用八进制数。<br>
                    // https://tools.ietf.org/html/rfc6943#section-3.1.1
                    p.read_number(10, Some(3), false)
                })?;
            }

            Some(groups.into())
        })
    }

    /// Read an IPv6 Address. <br>读取 IPv6 地址。<br>
    fn read_ipv6_addr(&mut self) -> Option<Ipv6Addr> {
        /// Read a chunk of an IPv6 address into `groups`. <br>将 IPv6 地址的一部分读入 `groups`。<br>
        /// Returns the number of groups read, along with a bool indicating if an embedded trailing IPv4 address was read. <br>返回读取的组数，以及一个 bool，指示是否读取了嵌入式尾随 IPv4 地址。<br>
        /// Specifically, read a series of colon-separated IPv6 groups (0x0000 - 0xFFFF), with an optional trailing embedded IPv4 address. <br>具体来说，请读取一系列用冒号分隔的 IPv6 组 (0x0000-0xFFFF)，并带有一个可选的尾随嵌入式 IPv4 地址。<br>
        ///
        ///
        fn read_groups(p: &mut Parser<'_>, groups: &mut [u16]) -> (usize, bool) {
            let limit = groups.len();

            for (i, slot) in groups.iter_mut().enumerate() {
                // Try to read a trailing embedded IPv4 address. <br>尝试读取尾随的嵌入式 IPv4 地址。<br>
                // There must be at least two groups left. <br>至少还剩下两组。<br>
                if i < limit - 1 {
                    let ipv4 = p.read_separator(':', i, |p| p.read_ipv4_addr());

                    if let Some(v4_addr) = ipv4 {
                        let [one, two, three, four] = v4_addr.octets();
                        groups[i + 0] = u16::from_be_bytes([one, two]);
                        groups[i + 1] = u16::from_be_bytes([three, four]);
                        return (i + 2, true);
                    }
                }

                let group = p.read_separator(':', i, |p| p.read_number(16, Some(4), true));

                match group {
                    Some(g) => *slot = g,
                    None => return (i, false),
                }
            }
            (groups.len(), false)
        }

        self.read_atomically(|p| {
            // Read the front part of the address; <br>读取地址的开头；<br> either the whole thing, or up to the first :: <br>要么整件事，或者直到第一个 :：<br>
            //
            let mut head = [0; 8];
            let (head_size, head_ipv4) = read_groups(p, &mut head);

            if head_size == 8 {
                return Some(head.into());
            }

            // IPv4 part is not allowed before `::` <br>在 `::` 之前不允许使用 IPv4 部分<br>
            if head_ipv4 {
                return None;
            }

            // Read `::` if previous code parsed less than 8 groups. <br>如果先前的代码解析少于 8 组，则读取 `::`。<br>
            // `::` indicates one or more groups of 16 bits of zeros. <br>`::` 表示一组或多组 16 位零。<br>
            p.read_given_char(':')?;
            p.read_given_char(':')?;

            // Read the back part of the address. <br>读地址的后面部分。<br>
            // The :: must contain at least one set of zeroes, so our max length is <br>:: 必须至少包含一组零，所以我们的最大长度是<br> 7.
            let mut tail = [0; 7];
            let limit = 8 - (head_size + 1);
            let (tail_size, _) = read_groups(p, &mut tail[..limit]);

            // Concat the head and tail of the IP address <br>连接 IP 地址的开头和结尾<br>
            head[(8 - tail_size)..8].copy_from_slice(&tail[..tail_size]);

            Some(head.into())
        })
    }

    /// Read an IP Address, either IPv4 or IPv6. <br>读取一个 IP 地址，IPv4 或 IPv6。<br>
    fn read_ip_addr(&mut self) -> Option<IpAddr> {
        self.read_ipv4_addr().map(IpAddr::V4).or_else(move || self.read_ipv6_addr().map(IpAddr::V6))
    }

    /// Read a `:` followed by a port in base 10. <br>读取 `:`，然后读取基数为 10 的端口。<br>
    fn read_port(&mut self) -> Option<u16> {
        self.read_atomically(|p| {
            p.read_given_char(':')?;
            p.read_number(10, None, true)
        })
    }

    /// Read a `%` followed by a scope ID in base 10. <br>读 `%`，后跟以 10 为底的作用域 ID。<br>
    fn read_scope_id(&mut self) -> Option<u32> {
        self.read_atomically(|p| {
            p.read_given_char('%')?;
            p.read_number(10, None, true)
        })
    }

    /// Read an IPv4 address with a port. <br>读取带有端口的 IPv4 地址。<br>
    fn read_socket_addr_v4(&mut self) -> Option<SocketAddrV4> {
        self.read_atomically(|p| {
            let ip = p.read_ipv4_addr()?;
            let port = p.read_port()?;
            Some(SocketAddrV4::new(ip, port))
        })
    }

    /// Read an IPv6 address with a port. <br>读取带有端口的 IPv6 地址。<br>
    fn read_socket_addr_v6(&mut self) -> Option<SocketAddrV6> {
        self.read_atomically(|p| {
            p.read_given_char('[')?;
            let ip = p.read_ipv6_addr()?;
            let scope_id = p.read_scope_id().unwrap_or(0);
            p.read_given_char(']')?;

            let port = p.read_port()?;
            Some(SocketAddrV6::new(ip, port, 0, scope_id))
        })
    }

    /// Read an IP address with a port <br>使用端口读取 IP 地址<br>
    fn read_socket_addr(&mut self) -> Option<SocketAddr> {
        self.read_socket_addr_v4()
            .map(SocketAddr::V4)
            .or_else(|| self.read_socket_addr_v6().map(SocketAddr::V6))
    }
}

impl IpAddr {
    /// Parse an IP address from a slice of bytes. <br>从字节片中解析 IP 地址。<br>
    ///
    /// ```
    /// #![feature(addr_parse_ascii)]
    ///
    /// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
    ///
    /// let localhost_v4 = IpAddr::V4(Ipv4Addr::new(127, 0, 0, 1));
    /// let localhost_v6 = IpAddr::V6(Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 1));
    ///
    /// assert_eq!(IpAddr::parse_ascii(b"127.0.0.1"), Ok(localhost_v4));
    /// assert_eq!(IpAddr::parse_ascii(b"::1"), Ok(localhost_v6));
    /// ```
    #[unstable(feature = "addr_parse_ascii", issue = "101035")]
    pub fn parse_ascii(b: &[u8]) -> Result<Self, AddrParseError> {
        Parser::new(b).parse_with(|p| p.read_ip_addr(), AddrKind::Ip)
    }
}

#[stable(feature = "ip_addr", since = "1.7.0")]
impl FromStr for IpAddr {
    type Err = AddrParseError;
    fn from_str(s: &str) -> Result<IpAddr, AddrParseError> {
        Self::parse_ascii(s.as_bytes())
    }
}

impl Ipv4Addr {
    /// Parse an IPv4 address from a slice of bytes. <br>从字节片中解析 IPv4 地址。<br>
    ///
    /// ```
    /// #![feature(addr_parse_ascii)]
    ///
    /// use std::net::Ipv4Addr;
    ///
    /// let localhost = Ipv4Addr::new(127, 0, 0, 1);
    ///
    /// assert_eq!(Ipv4Addr::parse_ascii(b"127.0.0.1"), Ok(localhost));
    /// ```
    #[unstable(feature = "addr_parse_ascii", issue = "101035")]
    pub fn parse_ascii(b: &[u8]) -> Result<Self, AddrParseError> {
        // don't try to parse if too long <br>如果太长的话，就不要尝试解析<br>
        if b.len() > 15 {
            Err(AddrParseError(AddrKind::Ipv4))
        } else {
            Parser::new(b).parse_with(|p| p.read_ipv4_addr(), AddrKind::Ipv4)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for Ipv4Addr {
    type Err = AddrParseError;
    fn from_str(s: &str) -> Result<Ipv4Addr, AddrParseError> {
        Self::parse_ascii(s.as_bytes())
    }
}

impl Ipv6Addr {
    /// Parse an IPv6 address from a slice of bytes. <br>从字节片中解析 IPv6 地址。<br>
    ///
    /// ```
    /// #![feature(addr_parse_ascii)]
    ///
    /// use std::net::Ipv6Addr;
    ///
    /// let localhost = Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 1);
    ///
    /// assert_eq!(Ipv6Addr::parse_ascii(b"::1"), Ok(localhost));
    /// ```
    #[unstable(feature = "addr_parse_ascii", issue = "101035")]
    pub fn parse_ascii(b: &[u8]) -> Result<Self, AddrParseError> {
        Parser::new(b).parse_with(|p| p.read_ipv6_addr(), AddrKind::Ipv6)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for Ipv6Addr {
    type Err = AddrParseError;
    fn from_str(s: &str) -> Result<Ipv6Addr, AddrParseError> {
        Self::parse_ascii(s.as_bytes())
    }
}

impl SocketAddrV4 {
    /// Parse an IPv4 socket address from a slice of bytes. <br>从字节片中解析 IPv4 套接字地址。<br>
    ///
    /// ```
    /// #![feature(addr_parse_ascii)]
    ///
    /// use std::net::{Ipv4Addr, SocketAddrV4};
    ///
    /// let socket = SocketAddrV4::new(Ipv4Addr::new(127, 0, 0, 1), 8080);
    ///
    /// assert_eq!(SocketAddrV4::parse_ascii(b"127.0.0.1:8080"), Ok(socket));
    /// ```
    #[unstable(feature = "addr_parse_ascii", issue = "101035")]
    pub fn parse_ascii(b: &[u8]) -> Result<Self, AddrParseError> {
        Parser::new(b).parse_with(|p| p.read_socket_addr_v4(), AddrKind::SocketV4)
    }
}

#[stable(feature = "socket_addr_from_str", since = "1.5.0")]
impl FromStr for SocketAddrV4 {
    type Err = AddrParseError;
    fn from_str(s: &str) -> Result<SocketAddrV4, AddrParseError> {
        Self::parse_ascii(s.as_bytes())
    }
}

impl SocketAddrV6 {
    /// Parse an IPv6 socket address from a slice of bytes. <br>从字节片中解析 IPv6 套接字地址。<br>
    ///
    /// ```
    /// #![feature(addr_parse_ascii)]
    ///
    /// use std::net::{Ipv6Addr, SocketAddrV6};
    ///
    /// let socket = SocketAddrV6::new(Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1), 8080, 0, 0);
    ///
    /// assert_eq!(SocketAddrV6::parse_ascii(b"[2001:db8::1]:8080"), Ok(socket));
    /// ```
    #[unstable(feature = "addr_parse_ascii", issue = "101035")]
    pub fn parse_ascii(b: &[u8]) -> Result<Self, AddrParseError> {
        Parser::new(b).parse_with(|p| p.read_socket_addr_v6(), AddrKind::SocketV6)
    }
}

#[stable(feature = "socket_addr_from_str", since = "1.5.0")]
impl FromStr for SocketAddrV6 {
    type Err = AddrParseError;
    fn from_str(s: &str) -> Result<SocketAddrV6, AddrParseError> {
        Self::parse_ascii(s.as_bytes())
    }
}

impl SocketAddr {
    /// Parse a socket address from a slice of bytes. <br>从字节片中解析套接字地址。<br>
    ///
    /// ```
    /// #![feature(addr_parse_ascii)]
    ///
    /// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};
    ///
    /// let socket_v4 = SocketAddr::new(IpAddr::V4(Ipv4Addr::new(127, 0, 0, 1)), 8080);
    /// let socket_v6 = SocketAddr::new(IpAddr::V6(Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 1)), 8080);
    ///
    /// assert_eq!(SocketAddr::parse_ascii(b"127.0.0.1:8080"), Ok(socket_v4));
    /// assert_eq!(SocketAddr::parse_ascii(b"[::1]:8080"), Ok(socket_v6));
    /// ```
    #[unstable(feature = "addr_parse_ascii", issue = "101035")]
    pub fn parse_ascii(b: &[u8]) -> Result<Self, AddrParseError> {
        Parser::new(b).parse_with(|p| p.read_socket_addr(), AddrKind::Socket)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for SocketAddr {
    type Err = AddrParseError;
    fn from_str(s: &str) -> Result<SocketAddr, AddrParseError> {
        Self::parse_ascii(s.as_bytes())
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum AddrKind {
    Ip,
    Ipv4,
    Ipv6,
    Socket,
    SocketV4,
    SocketV6,
}

/// An error which can be returned when parsing an IP address or a socket address. <br>解析 IP 地址或套接字地址时可以返回的错误。<br>
///
/// This error is used as the error type for the [`FromStr`] implementation for [`IpAddr`], [`Ipv4Addr`], [`Ipv6Addr`], [`SocketAddr`], [`SocketAddrV4`], and [`SocketAddrV6`]. <br>该错误用作 [`IpAddr`]，[`Ipv4Addr`]，[`Ipv6Addr`]，[`SocketAddr`]，[`SocketAddrV4`] 和 [`SocketAddrV6`] 的 [`FromStr`] 实现的错误类型。<br>
///
/// # Potential causes <br>潜在原因<br>
///
/// `AddrParseError` may be thrown because the provided string does not parse as the given type, often because it includes information only handled by a different address type. <br>`AddrParseError` 可能会被抛出，因为提供的字符串没有解析为给定的类型，通常是因为它包含的信息仅由不同的地址类型处理。<br>
///
///
/// ```should_panic
/// use std::net::IpAddr;
/// let _foo: IpAddr = "127.0.0.1:8080".parse().expect("Cannot handle the socket port");
/// ```
///
/// [`IpAddr`] doesn't handle the port. <br>[`IpAddr`] 不处理端口。<br> Use [`SocketAddr`] instead. <br>请改用 [`SocketAddr`]。<br>
///
/// ```
/// use std::net::SocketAddr;
///
/// // No problem, the `panic!` message has disappeared. <br>没问题，`panic!` 消息已消失。<br>
/// let _foo: SocketAddr = "127.0.0.1:8080".parse().expect("unreachable panic");
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AddrParseError(AddrKind);

#[stable(feature = "addr_parse_error_error", since = "1.4.0")]
impl fmt::Display for AddrParseError {
    #[allow(deprecated, deprecated_in_future)]
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.write_str(self.description())
    }
}

#[stable(feature = "addr_parse_error_error", since = "1.4.0")]
impl Error for AddrParseError {
    #[allow(deprecated)]
    fn description(&self) -> &str {
        match self.0 {
            AddrKind::Ip => "invalid IP address syntax",
            AddrKind::Ipv4 => "invalid IPv4 address syntax",
            AddrKind::Ipv6 => "invalid IPv6 address syntax",
            AddrKind::Socket => "invalid socket address syntax",
            AddrKind::SocketV4 => "invalid IPv4 socket address syntax",
            AddrKind::SocketV6 => "invalid IPv6 socket address syntax",
        }
    }
}
