use crate::cmp::Ordering;
use crate::fmt::{self, Write};
use crate::mem::transmute;

use super::display_buffer::DisplayBuffer;

/// An IP address, either IPv4 or IPv6. <br>IP 地址，IPv4 或 IPv6。<br>
///
/// This enum can contain either an [`Ipv4Addr`] or an [`Ipv6Addr`], see their respective documentation for more details. <br>该枚举可以包含 [`Ipv4Addr`] 或 [`Ipv6Addr`]，有关更多详细信息，请参见其各自的文档。<br>
///
///
/// # Examples
///
/// ```
/// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
///
/// let localhost_v4 = IpAddr::V4(Ipv4Addr::new(127, 0, 0, 1));
/// let localhost_v6 = IpAddr::V6(Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 1));
///
/// assert_eq!("127.0.0.1".parse(), Ok(localhost_v4));
/// assert_eq!("::1".parse(), Ok(localhost_v6));
///
/// assert_eq!(localhost_v4.is_ipv6(), false);
/// assert_eq!(localhost_v4.is_ipv4(), true);
/// ```
#[cfg_attr(not(test), rustc_diagnostic_item = "IpAddr")]
#[stable(feature = "ip_addr", since = "1.7.0")]
#[derive(Copy, Clone, Eq, PartialEq, Hash, PartialOrd, Ord)]
pub enum IpAddr {
    /// An IPv4 address. <br>IPv4 地址。<br>
    #[stable(feature = "ip_addr", since = "1.7.0")]
    V4(#[stable(feature = "ip_addr", since = "1.7.0")] Ipv4Addr),
    /// An IPv6 address. <br>IPv6 地址。<br>
    #[stable(feature = "ip_addr", since = "1.7.0")]
    V6(#[stable(feature = "ip_addr", since = "1.7.0")] Ipv6Addr),
}

/// An IPv4 address. <br>IPv4 地址。<br>
///
/// IPv4 addresses are defined as 32-bit integers in [IETF RFC 791]. <br>IPv4 地址在 [IETF RFC 791] 中定义为 32 位整数。<br>
/// They are usually represented as four octets. <br>它们通常表示为四个八位位组。<br>
///
/// See [`IpAddr`] for a type encompassing both IPv4 and IPv6 addresses. <br>有关同时包含 IPv4 和 IPv6 地址的类型，请参见 [`IpAddr`]。<br>
///
/// [IETF RFC 791]: https://tools.ietf.org/html/rfc791
///
/// # Textual representation <br>文字表达<br>
///
/// `Ipv4Addr` provides a [`FromStr`] implementation. <br>`Ipv4Addr` 提供了一个 [`FromStr`] 的实现。<br> The four octets are in decimal notation, divided by `.` (this is called "dot-decimal notation"). <br>四个八位位组用十进制表示法除以 `.` (称为 "点十进制表示法")。<br>
/// Notably, octal numbers (which are indicated with a leading `0`) and hexadecimal numbers (which are indicated with a leading `0x`) are not allowed per [IETF RFC 6943]. <br>值得注意的是，每个 [IETF RFC 6943] 不允许使用八进制数 (以 `0` 开头) 和十六进制数 (以 `0x` 开头)。<br>
///
///
/// [IETF RFC 6943]: https://tools.ietf.org/html/rfc6943#section-3.1.1
/// [`FromStr`]: crate::str::FromStr
///
/// # Examples
///
/// ```
/// use std::net::Ipv4Addr;
///
/// let localhost = Ipv4Addr::new(127, 0, 0, 1);
/// assert_eq!("127.0.0.1".parse(), Ok(localhost));
/// assert_eq!(localhost.is_loopback(), true);
/// assert!("012.004.002.000".parse::<Ipv4Addr>().is_err()); // all octets are in octal <br>所有八位字节都是八进制的<br>
/// assert!("0000000.0.0.0".parse::<Ipv4Addr>().is_err()); // first octet is a zero in octal <br>第一个八位字节是八进制中的零<br>
/// assert!("0xcb.0x0.0x71.0x00".parse::<Ipv4Addr>().is_err()); // all octets are in hex <br>所有八位字节都是十六进制的<br>
/// ```
///
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ipv4Addr {
    octets: [u8; 4],
}

/// An IPv6 address. <br>IPv6 地址。<br>
///
/// IPv6 addresses are defined as 128-bit integers in [IETF RFC 4291]. <br>IPv6 地址在 [IETF RFC 4291] 中定义为 128 位整数。<br>
/// They are usually represented as eight 16-bit segments. <br>它们通常表示为八个 16 位段。<br>
///
/// [IETF RFC 4291]: https://tools.ietf.org/html/rfc4291
///
/// # Embedding IPv4 Addresses <br>嵌入 IPv4 地址<br>
///
/// See [`IpAddr`] for a type encompassing both IPv4 and IPv6 addresses. <br>有关同时包含 IPv4 和 IPv6 地址的类型，请参见 [`IpAddr`]。<br>
///
/// To assist in the transition from IPv4 to IPv6 two types of IPv6 addresses that embed an IPv4 address were defined: <br>为了帮助从 IPv4 过渡到 IPv6，定义了两种类型的 IPv6 地址，它们嵌入了 IPv4 地址：<br>
/// IPv4-compatible and IPv4-mapped addresses. <br>IPv4 兼容地址和 IPv4 映射地址。<br> Of these IPv4-compatible addresses have been officially deprecated. <br>其中这些与 IPv4 兼容的地址已被正式弃用。<br>
///
/// Both types of addresses are not assigned any special meaning by this implementation, other than what the relevant standards prescribe. <br>除了相关标准规定的内容外，此实现并未为这两种类型的地址分配任何特殊含义。<br>
/// This means that an address like `::ffff:127.0.0.1`, while representing an IPv4 loopback address, is not itself an IPv6 loopback address; <br>这意味着像 `::ffff:127.0.0.1` 这样的地址，虽然代表 IPv4 回环地址，但它本身并不是 IPv6 回环地址；<br> only `::1` is. <br>只有 `::1` 是。<br>
/// To handle these so called "IPv4-in-IPv6" addresses, they have to first be converted to their canonical IPv4 address. <br>要处理这些所谓的 "IPv4-in-IPv6" 地址，必须首先将它们转换为规范的 IPv4 地址。<br>
///
/// ### IPv4-Compatible IPv6 Addresses <br>兼容 IPv4 的 IPv6 地址<br>
///
/// IPv4-compatible IPv6 addresses are defined in [IETF RFC 4291 Section 2.5.5.1], and have been officially deprecated. <br>IPv4 兼容的 IPv6 地址在 [IETF RFC 4291 第 2.5.5.1 节][IETF RFC 4291 Section 2.5.5.1] 中定义，并已被正式弃用。<br>
/// The RFC describes the format of an "IPv4-Compatible IPv6 address" as follows: <br>RFC 描述了 "IPv4 兼容 IPv6 地址" 的格式如下：<br>
///
/// ```text
/// |                80 bits               | 16 |      32 bits        |
/// +--------------------------------------+--------------------------+
/// |0000..............................0000|0000|    IPv4 address     |
/// +--------------------------------------+----+---------------------+
/// ```
/// So `::a.b.c.d` would be an IPv4-compatible IPv6 address representing the IPv4 address `a.b.c.d`. <br>因此 `::a.b.c.d` 将是表示 IPv4 地址 `a.b.c.d` 的 IPv4 兼容 IPv6 地址。<br>
///
/// To convert from an IPv4 address to an IPv4-compatible IPv6 address, use [`Ipv4Addr::to_ipv6_compatible`]. <br>要将 IPv4 地址转换为与 IPv4 兼容的 IPv6 地址，请使用 [`Ipv4Addr::to_ipv6_compatible`]。<br>
/// Use [`Ipv6Addr::to_ipv4`] to convert an IPv4-compatible IPv6 address to the canonical IPv4 address. <br>使用 [`Ipv6Addr::to_ipv4`] 将兼容 IPv4 的 IPv6 地址转换为规范的 IPv4 地址。<br>
///
/// [IETF RFC 4291 Section 2.5.5.1]: https://datatracker.ietf.org/doc/html/rfc4291#section-2.5.5.1
///
/// ### IPv4-Mapped IPv6 Addresses <br>IPv4 映射的 IPv6 地址<br>
///
/// IPv4-mapped IPv6 addresses are defined in [IETF RFC 4291 Section 2.5.5.2]. <br>IPv4 映射的 IPv6 地址在 [IETF RFC 4291 第 2.5.5.2 节][IETF RFC 4291 Section 2.5.5.2] 中定义。<br>
/// The RFC describes the format of an "IPv4-Mapped IPv6 address" as follows: <br>RFC 描述了 "IPv4-Mapped IPv6 address" 的格式如下：<br>
///
/// ```text
/// |                80 bits               | 16 |      32 bits        |
/// +--------------------------------------+--------------------------+
/// |0000..............................0000|FFFF|    IPv4 address     |
/// +--------------------------------------+----+---------------------+
/// ```
/// So `::ffff:a.b.c.d` would be an IPv4-mapped IPv6 address representing the IPv4 address `a.b.c.d`. <br>因此 `::ffff:a.b.c.d` 将是表示 IPv4 地址 `a.b.c.d` 的 IPv4 映射 IPv6 地址。<br>
///
/// To convert from an IPv4 address to an IPv4-mapped IPv6 address, use [`Ipv4Addr::to_ipv6_mapped`]. <br>要将 IPv4 地址转换为 IPv4 映射的 IPv6 地址，请使用 [`Ipv4Addr::to_ipv6_mapped`]。<br>
/// Use [`Ipv6Addr::to_ipv4`] to convert an IPv4-mapped IPv6 address to the canonical IPv4 address. <br>使用 [`Ipv6Addr::to_ipv4`] 将 IPv4 映射的 IPv6 地址转换为规范的 IPv4 地址。<br>
/// Note that this will also convert the IPv6 loopback address `::1` to `0.0.0.1`. <br>请注意，这也会将 IPv6 回环地址 `::1` 转换为 `0.0.0.1`。<br> Use [`Ipv6Addr::to_ipv4_mapped`] to avoid this. <br>使用 [`Ipv6Addr::to_ipv4_mapped`] 可以避免这种情况。<br>
///
/// [IETF RFC 4291 Section 2.5.5.2]: https://datatracker.ietf.org/doc/html/rfc4291#section-2.5.5.2
///
/// # Textual representation <br>文字表达<br>
///
/// `Ipv6Addr` provides a [`FromStr`] implementation. <br>`Ipv6Addr` 提供了一个 [`FromStr`] 的实现。<br>
/// There are many ways to represent an IPv6 address in text, but in general, each segments is written in hexadecimal notation, and segments are separated by `:`. <br>有多种方法可以用文本表示 IPv6 地址，但通常，每个段都以十六进制表示法，并且段之间用 `:` 分隔。<br>
///
/// For more information, see [IETF RFC 5952]. <br>有关更多信息，请参见 [IETF RFC 5952]。<br>
///
/// [`FromStr`]: crate::str::FromStr
/// [IETF RFC 5952]: https://tools.ietf.org/html/rfc5952
///
/// # Examples
///
/// ```
/// use std::net::Ipv6Addr;
///
/// let localhost = Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 1);
/// assert_eq!("::1".parse(), Ok(localhost));
/// assert_eq!(localhost.is_loopback(), true);
/// ```
///
///
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ipv6Addr {
    octets: [u8; 16],
}

/// Scope of an [IPv6 multicast address] as defined in [IETF RFC 7346 section 2]. <br>[IETF RFC 7346 第 2 节][IETF RFC 7346 section 2] 中定义的 [IPv6 多播地址][IPv6 multicast address] 的范围。<br>
///
/// # Stability Guarantees <br>稳定性保证<br>
///
/// Not all possible values for a multicast scope have been assigned. <br>并非多播作用域的所有可能值都已分配。<br>
/// Future RFCs may introduce new scopes, which will be added as variants to this enum; <br>未来的 RFC 可能会引入新的作用域，它将作为变体添加到此枚举中；<br>
/// because of this the enum is marked as `#[non_exhaustive]`. <br>因此，枚举被标记为 `#[non_exhaustive]`。<br>
///
/// # Examples
/// ```
/// #![feature(ip)]
///
/// use std::net::Ipv6Addr;
/// use std::net::Ipv6MulticastScope::*;
///
/// // An IPv6 multicast address with global scope (`ff0e::`). <br>具有全局作用域 (`ff0e::`) 的 IPv6 多播地址。<br>
/// let address = Ipv6Addr::new(0xff0e, 0, 0, 0, 0, 0, 0, 0);
///
/// // Will print "Global scope". <br>将打印 "Global scope"。<br>
/// match address.multicast_scope() {
///     Some(InterfaceLocal) => println!("Interface-Local scope"),
///     Some(LinkLocal) => println!("Link-Local scope"),
///     Some(RealmLocal) => println!("Realm-Local scope"),
///     Some(AdminLocal) => println!("Admin-Local scope"),
///     Some(SiteLocal) => println!("Site-Local scope"),
///     Some(OrganizationLocal) => println!("Organization-Local scope"),
///     Some(Global) => println!("Global scope"),
///     Some(_) => println!("Unknown scope"),
///     None => println!("Not a multicast address!")
/// }
///
/// ```
///
/// [IPv6 multicast address]: Ipv6Addr
/// [IETF RFC 7346 section 2]: https://tools.ietf.org/html/rfc7346#section-2
#[derive(Copy, PartialEq, Eq, Clone, Hash, Debug)]
#[unstable(feature = "ip", issue = "27709")]
#[non_exhaustive]
pub enum Ipv6MulticastScope {
    /// Interface-Local scope. <br>Interface-Local 作用域。<br>
    InterfaceLocal,
    /// Link-Local scope. <br>Link-Local 作用域。<br>
    LinkLocal,
    /// Realm-Local scope. <br>Realm-Local 作用域。<br>
    RealmLocal,
    /// Admin-Local scope. <br>Admin-Local 作用域。<br>
    AdminLocal,
    /// Site-Local scope. <br>Site-Local 作用域。<br>
    SiteLocal,
    /// Organization-Local scope. <br>Organization-Local 作用域。<br>
    OrganizationLocal,
    /// Global scope. <br>Global 作用域。<br>
    Global,
}

impl IpAddr {
    /// Returns [`true`] for the special 'unspecified' address. <br>返回 [`true`] 作为特殊的 'unspecified' 地址。<br>
    ///
    /// See the documentation for [`Ipv4Addr::is_unspecified()`] and [`Ipv6Addr::is_unspecified()`] for more details. <br>有关更多详细信息，请参见 [`Ipv4Addr::is_unspecified()`] 和 [`Ipv6Addr::is_unspecified()`] 的文档。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(IpAddr::V4(Ipv4Addr::new(0, 0, 0, 0)).is_unspecified(), true);
    /// assert_eq!(IpAddr::V6(Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 0)).is_unspecified(), true);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(feature = "ip_shared", since = "1.12.0")]
    #[must_use]
    #[inline]
    pub const fn is_unspecified(&self) -> bool {
        match self {
            IpAddr::V4(ip) => ip.is_unspecified(),
            IpAddr::V6(ip) => ip.is_unspecified(),
        }
    }

    /// Returns [`true`] if this is a loopback address. <br>如果这是一个回环地址，则返回 [`true`]。<br>
    ///
    /// See the documentation for [`Ipv4Addr::is_loopback()`] and [`Ipv6Addr::is_loopback()`] for more details. <br>有关更多详细信息，请参见 [`Ipv4Addr::is_loopback()`] 和 [`Ipv6Addr::is_loopback()`] 的文档。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(IpAddr::V4(Ipv4Addr::new(127, 0, 0, 1)).is_loopback(), true);
    /// assert_eq!(IpAddr::V6(Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 0x1)).is_loopback(), true);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(feature = "ip_shared", since = "1.12.0")]
    #[must_use]
    #[inline]
    pub const fn is_loopback(&self) -> bool {
        match self {
            IpAddr::V4(ip) => ip.is_loopback(),
            IpAddr::V6(ip) => ip.is_loopback(),
        }
    }

    /// Returns [`true`] if the address appears to be globally routable. <br>如果该地址似乎是可全局路由的，则返回 [`true`]。<br>
    ///
    /// See the documentation for [`Ipv4Addr::is_global()`] and [`Ipv6Addr::is_global()`] for more details. <br>有关更多详细信息，请参见 [`Ipv4Addr::is_global()`] 和 [`Ipv6Addr::is_global()`] 的文档。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(IpAddr::V4(Ipv4Addr::new(80, 9, 12, 3)).is_global(), true);
    /// assert_eq!(IpAddr::V6(Ipv6Addr::new(0, 0, 0x1c9, 0, 0, 0xafc8, 0, 0x1)).is_global(), true);
    /// ```
    #[rustc_const_unstable(feature = "const_ip", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_global(&self) -> bool {
        match self {
            IpAddr::V4(ip) => ip.is_global(),
            IpAddr::V6(ip) => ip.is_global(),
        }
    }

    /// Returns [`true`] if this is a multicast address. <br>如果这是一个多播地址，则返回 [`true`]。<br>
    ///
    /// See the documentation for [`Ipv4Addr::is_multicast()`] and [`Ipv6Addr::is_multicast()`] for more details. <br>有关更多详细信息，请参见 [`Ipv4Addr::is_multicast()`] 和 [`Ipv6Addr::is_multicast()`] 的文档。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(IpAddr::V4(Ipv4Addr::new(224, 254, 0, 0)).is_multicast(), true);
    /// assert_eq!(IpAddr::V6(Ipv6Addr::new(0xff00, 0, 0, 0, 0, 0, 0, 0)).is_multicast(), true);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(feature = "ip_shared", since = "1.12.0")]
    #[must_use]
    #[inline]
    pub const fn is_multicast(&self) -> bool {
        match self {
            IpAddr::V4(ip) => ip.is_multicast(),
            IpAddr::V6(ip) => ip.is_multicast(),
        }
    }

    /// Returns [`true`] if this address is in a range designated for documentation. <br>如果此地址在文档指定的范围内，则返回 [`true`]。<br>
    ///
    /// See the documentation for [`Ipv4Addr::is_documentation()`] and [`Ipv6Addr::is_documentation()`] for more details. <br>有关更多详细信息，请参见 [`Ipv4Addr::is_documentation()`] 和 [`Ipv6Addr::is_documentation()`] 的文档。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(IpAddr::V4(Ipv4Addr::new(203, 0, 113, 6)).is_documentation(), true);
    /// assert_eq!(
    ///     IpAddr::V6(Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 0)).is_documentation(),
    ///     true
    /// );
    /// ```
    #[rustc_const_unstable(feature = "const_ip", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_documentation(&self) -> bool {
        match self {
            IpAddr::V4(ip) => ip.is_documentation(),
            IpAddr::V6(ip) => ip.is_documentation(),
        }
    }

    /// Returns [`true`] if this address is in a range designated for benchmarking. <br>如果此地址在为基准测试指定的范围内，则返回 [`true`]。<br>
    ///
    /// See the documentation for [`Ipv4Addr::is_benchmarking()`] and [`Ipv6Addr::is_benchmarking()`] for more details. <br>有关更多详细信息，请参见 [`Ipv4Addr::is_benchmarking()`] 和 [`Ipv6Addr::is_benchmarking()`] 的文档。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(IpAddr::V4(Ipv4Addr::new(198, 19, 255, 255)).is_benchmarking(), true);
    /// assert_eq!(IpAddr::V6(Ipv6Addr::new(0x2001, 0x2, 0, 0, 0, 0, 0, 0)).is_benchmarking(), true);
    /// ```
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_benchmarking(&self) -> bool {
        match self {
            IpAddr::V4(ip) => ip.is_benchmarking(),
            IpAddr::V6(ip) => ip.is_benchmarking(),
        }
    }

    /// Returns [`true`] if this address is an [`IPv4` address], and [`false`] otherwise. <br>如果此地址是 [`IPv4` address]，则返回 [`true`]，否则返回 [`false`]。<br>
    ///
    ///
    /// [`IPv4` address]: IpAddr::V4
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(IpAddr::V4(Ipv4Addr::new(203, 0, 113, 6)).is_ipv4(), true);
    /// assert_eq!(IpAddr::V6(Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 0)).is_ipv4(), false);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(feature = "ipaddr_checker", since = "1.16.0")]
    #[must_use]
    #[inline]
    pub const fn is_ipv4(&self) -> bool {
        matches!(self, IpAddr::V4(_))
    }

    /// Returns [`true`] if this address is an [`IPv6` address], and [`false`] otherwise. <br>如果此地址是 [`IPv6` address]，则返回 [`true`]，否则返回 [`false`]。<br>
    ///
    ///
    /// [`IPv6` address]: IpAddr::V6
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(IpAddr::V4(Ipv4Addr::new(203, 0, 113, 6)).is_ipv6(), false);
    /// assert_eq!(IpAddr::V6(Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 0)).is_ipv6(), true);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(feature = "ipaddr_checker", since = "1.16.0")]
    #[must_use]
    #[inline]
    pub const fn is_ipv6(&self) -> bool {
        matches!(self, IpAddr::V6(_))
    }

    /// Converts this address to an `IpAddr::V4` if it is an IPv4-mapped IPv6 addresses, otherwise it return `self` as-is. <br>如果它是 IPv4 映射的 IPv6 地址，则将此地址转换为 `IpAddr::V4`，否则按原样返回 `self`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    /// use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(IpAddr::V4(Ipv4Addr::new(127, 0, 0, 1)).to_canonical().is_loopback(), true);
    /// assert_eq!(IpAddr::V6(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0x7f00, 0x1)).is_loopback(), false);
    /// assert_eq!(IpAddr::V6(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0x7f00, 0x1)).to_canonical().is_loopback(), true);
    /// ```
    #[inline]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[rustc_const_unstable(feature = "const_ip", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    pub const fn to_canonical(&self) -> IpAddr {
        match self {
            &v4 @ IpAddr::V4(_) => v4,
            IpAddr::V6(v6) => v6.to_canonical(),
        }
    }
}

impl Ipv4Addr {
    /// Creates a new IPv4 address from four eight-bit octets. <br>从四个八位八位字节创建一个新的 IPv4 地址。<br>
    ///
    /// The result will represent the IP address `a`.`b`.`c`.`d`. <br>结果将代表 IP 地址 `a`.`b`.`c`.`d`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// let addr = Ipv4Addr::new(127, 0, 0, 1);
    /// ```
    #[rustc_const_stable(feature = "const_ip_32", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    #[inline]
    pub const fn new(a: u8, b: u8, c: u8, d: u8) -> Ipv4Addr {
        Ipv4Addr { octets: [a, b, c, d] }
    }

    /// An IPv4 address with the address pointing to localhost: `127.0.0.1` <br>一个 IPv4 地址，地址指向 localhost: `127.0.0.1`<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// let addr = Ipv4Addr::LOCALHOST;
    /// assert_eq!(addr, Ipv4Addr::new(127, 0, 0, 1));
    /// ```
    #[stable(feature = "ip_constructors", since = "1.30.0")]
    pub const LOCALHOST: Self = Ipv4Addr::new(127, 0, 0, 1);

    /// An IPv4 address representing an unspecified address: `0.0.0.0` <br>代表未指定地址的 IPv4 地址: `0.0.0.0`<br>
    ///
    /// This corresponds to the constant `INADDR_ANY` in other languages. <br>这对应于其他语言中的常量 `INADDR_ANY`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// let addr = Ipv4Addr::UNSPECIFIED;
    /// assert_eq!(addr, Ipv4Addr::new(0, 0, 0, 0));
    /// ```
    #[doc(alias = "INADDR_ANY")]
    #[stable(feature = "ip_constructors", since = "1.30.0")]
    pub const UNSPECIFIED: Self = Ipv4Addr::new(0, 0, 0, 0);

    /// An IPv4 address representing the broadcast address: `255.255.255.255` <br>代表广播地址的 IPv4 地址: `255.255.255.255`<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// let addr = Ipv4Addr::BROADCAST;
    /// assert_eq!(addr, Ipv4Addr::new(255, 255, 255, 255));
    /// ```
    #[stable(feature = "ip_constructors", since = "1.30.0")]
    pub const BROADCAST: Self = Ipv4Addr::new(255, 255, 255, 255);

    /// Returns the four eight-bit integers that make up this address. <br>返回组成该地址的四个八位整数。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// let addr = Ipv4Addr::new(127, 0, 0, 1);
    /// assert_eq!(addr.octets(), [127, 0, 0, 1]);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    #[inline]
    pub const fn octets(&self) -> [u8; 4] {
        self.octets
    }

    /// Returns [`true`] for the special 'unspecified' address (`0.0.0.0`). <br>为特殊的 'unspecified' 地址 (`0.0.0.0`) 返回 [`true`]。<br>
    ///
    /// This property is defined in _UNIX Network Programming, Second Edition_, W. <br>此属性在 _UNIX Network Programming, Second Edition_，W 中定义。<br> Richard Stevens,  p.
    /// 891; see also [ip7]. <br>891; 另请参见 [ip7]。<br>
    ///
    /// [ip7]: https://man7.org/linux/man-pages/man7/ip.7.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// assert_eq!(Ipv4Addr::new(0, 0, 0, 0).is_unspecified(), true);
    /// assert_eq!(Ipv4Addr::new(45, 22, 13, 197).is_unspecified(), false);
    /// ```
    #[rustc_const_stable(feature = "const_ip_32", since = "1.32.0")]
    #[stable(feature = "ip_shared", since = "1.12.0")]
    #[must_use]
    #[inline]
    pub const fn is_unspecified(&self) -> bool {
        u32::from_be_bytes(self.octets) == 0
    }

    /// Returns [`true`] if this is a loopback address (`127.0.0.0/8`). <br>如果这是回环地址 (`127.0.0.0/8`)，则返回 [`true`]。<br>
    ///
    /// This property is defined by [IETF RFC 1122]. <br>此属性由 [IETF RFC 1122] 定义。<br>
    ///
    /// [IETF RFC 1122]: https://tools.ietf.org/html/rfc1122
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// assert_eq!(Ipv4Addr::new(127, 0, 0, 1).is_loopback(), true);
    /// assert_eq!(Ipv4Addr::new(45, 22, 13, 197).is_loopback(), false);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(since = "1.7.0", feature = "ip_17")]
    #[must_use]
    #[inline]
    pub const fn is_loopback(&self) -> bool {
        self.octets()[0] == 127
    }

    /// Returns [`true`] if this is a private address. <br>如果这是一个专用地址，则返回 [`true`]。<br>
    ///
    /// The private address ranges are defined in [IETF RFC 1918] and include: <br>专用地址范围在 [IETF RFC 1918] 中定义，包括：<br>
    ///
    ///  - `10.0.0.0/8`
    ///  - `172.16.0.0/12`
    ///  - `192.168.0.0/16`
    ///
    /// [IETF RFC 1918]: https://tools.ietf.org/html/rfc1918
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// assert_eq!(Ipv4Addr::new(10, 0, 0, 1).is_private(), true);
    /// assert_eq!(Ipv4Addr::new(10, 10, 10, 10).is_private(), true);
    /// assert_eq!(Ipv4Addr::new(172, 16, 10, 10).is_private(), true);
    /// assert_eq!(Ipv4Addr::new(172, 29, 45, 14).is_private(), true);
    /// assert_eq!(Ipv4Addr::new(172, 32, 0, 2).is_private(), false);
    /// assert_eq!(Ipv4Addr::new(192, 168, 0, 2).is_private(), true);
    /// assert_eq!(Ipv4Addr::new(192, 169, 0, 2).is_private(), false);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(since = "1.7.0", feature = "ip_17")]
    #[must_use]
    #[inline]
    pub const fn is_private(&self) -> bool {
        match self.octets() {
            [10, ..] => true,
            [172, b, ..] if b >= 16 && b <= 31 => true,
            [192, 168, ..] => true,
            _ => false,
        }
    }

    /// Returns [`true`] if the address is link-local (`169.254.0.0/16`). <br>如果地址是本地链接 (`169.254.0.0/16`)，则返回 [`true`]。<br>
    ///
    /// This property is defined by [IETF RFC 3927]. <br>此属性由 [IETF RFC 3927] 定义。<br>
    ///
    /// [IETF RFC 3927]: https://tools.ietf.org/html/rfc3927
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// assert_eq!(Ipv4Addr::new(169, 254, 0, 0).is_link_local(), true);
    /// assert_eq!(Ipv4Addr::new(169, 254, 10, 65).is_link_local(), true);
    /// assert_eq!(Ipv4Addr::new(16, 89, 10, 65).is_link_local(), false);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(since = "1.7.0", feature = "ip_17")]
    #[must_use]
    #[inline]
    pub const fn is_link_local(&self) -> bool {
        matches!(self.octets(), [169, 254, ..])
    }

    /// Returns [`true`] if the address appears to be globally reachable as specified by the [IANA IPv4 Special-Purpose Address Registry]. <br>如果地址看起来是由 [IANA IPv4 Special-Purpose Address Registry] 指定的全局可访问的，则返回 [`true`]。<br>
    /// Whether or not an address is practically reachable will depend on your network configuration. <br>一个地址是否实际可访问将取决于您的网络配置。<br>
    ///
    /// Most IPv4 addresses are globally reachable; <br>大多数 IPv4 地址都是全局可达的;<br>
    /// unless they are specifically defined as *not* globally reachable. <br>除非它们被明确定义为 *not* 全局可达。<br>
    ///
    /// Non-exhaustive list of notable addresses that are not globally reachable: <br>全球无法访问的显着地址的非详尽列表:<br>
    ///
    /// - The [unspecified address] ([`is_unspecified`](Ipv4Addr::is_unspecified)) <br>[unspecified address] ([`is_unspecified`](Ipv4Addr::is_unspecified))<br>
    /// - Addresses reserved for private use ([`is_private`](Ipv4Addr::is_private)) <br>保留供 private 使用的地址 ([`is_private`](Ipv4Addr::is_private))<br>
    /// - Addresses in the shared address space ([`is_shared`](Ipv4Addr::is_shared)) <br>共享地址空间 ([`is_shared`](Ipv4Addr::is_shared)) 中的地址<br>
    /// - Loopback addresses ([`is_loopback`](Ipv4Addr::is_loopback)) <br>回环地址 ([`is_loopback`](Ipv4Addr::is_loopback))<br>
    /// - Link-local addresses ([`is_link_local`](Ipv4Addr::is_link_local)) <br>链路本地地址 ([`is_link_local`](Ipv4Addr::is_link_local))<br>
    /// - Addresses reserved for documentation ([`is_documentation`](Ipv4Addr::is_documentation)) <br>为文档 ([`is_documentation`](Ipv4Addr::is_documentation)) 保留的地址<br>
    /// - Addresses reserved for benchmarking ([`is_benchmarking`](Ipv4Addr::is_benchmarking)) <br>为 ([`is_benchmarking`](Ipv4Addr::is_benchmarking)) 基准测试保留的地址<br>
    /// - Reserved addresses ([`is_reserved`](Ipv4Addr::is_reserved)) <br>保留地址 ([`is_reserved`](Ipv4Addr::is_reserved))<br>
    /// - The [broadcast address] ([`is_broadcast`](Ipv4Addr::is_broadcast)) <br>[broadcast address] ([`is_broadcast`](Ipv4Addr::is_broadcast))<br>
    ///
    /// For the complete overview of which addresses are globally reachable, see the table at the [IANA IPv4 Special-Purpose Address Registry]. <br>有关哪些地址可全局访问的完整概览，请参见 [IANA IPv4 Special-Purpose Address Registry] 中的表格。<br>
    ///
    /// [IANA IPv4 Special-Purpose Address Registry]: https://www.iana.org/assignments/iana-ipv4-special-registry/iana-ipv4-special-registry.xhtml
    /// [unspecified address]: Ipv4Addr::UNSPECIFIED
    /// [broadcast address]: Ipv4Addr::BROADCAST
    ///

    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::Ipv4Addr;
    ///
    /// // Most IPv4 addresses are globally reachable: <br>大多数 IPv4 地址都是全局可达的:<br>
    /// assert_eq!(Ipv4Addr::new(80, 9, 12, 3).is_global(), true);
    ///
    /// // However some addresses have been assigned a special meaning that makes them not globally reachable. <br>但是，某些地址已被赋予特殊含义，使它们无法全局访问。<br>
    /// // Some examples are: <br>一些例子是:<br>
    ///
    /// // The unspecified address (`0.0.0.0`) <br>未指定的地址 (`0.0.0.0`)<br>
    /// assert_eq!(Ipv4Addr::UNSPECIFIED.is_global(), false);
    ///
    /// // Addresses reserved for private use (`10.0.0.0/8`, `172.16.0.0/12`, 192.168.0.0/16) <br>保留供 private 使用的地址 (`10.0.0.0/8`, `172.16.0.0/12`, 192.168.0.0/16)<br>
    /// assert_eq!(Ipv4Addr::new(10, 254, 0, 0).is_global(), false);
    /// assert_eq!(Ipv4Addr::new(192, 168, 10, 65).is_global(), false);
    /// assert_eq!(Ipv4Addr::new(172, 16, 10, 65).is_global(), false);
    ///
    /// // Addresses in the shared address space (`100.64.0.0/10`) <br>共享地址空间 (`100.64.0.0/10`) 中的地址<br>
    /// assert_eq!(Ipv4Addr::new(100, 100, 0, 0).is_global(), false);
    ///
    /// // The loopback addresses (`127.0.0.0/8`) <br>回环地址 (`127.0.0.0/8`)<br>
    /// assert_eq!(Ipv4Addr::LOCALHOST.is_global(), false);
    ///
    /// // Link-local addresses (`169.254.0.0/16`) <br>链路本地地址 (`169.254.0.0/16`)<br>
    /// assert_eq!(Ipv4Addr::new(169, 254, 45, 1).is_global(), false);
    ///
    /// // Addresses reserved for documentation (`192.0.2.0/24`, `198.51.100.0/24`, `203.0.113.0/24`) <br>为文档保留的地址 (`192.0.2.0/24`、`198.51.100.0/24`、`203.0.113.0/24`)<br>
    /// assert_eq!(Ipv4Addr::new(192, 0, 2, 255).is_global(), false);
    /// assert_eq!(Ipv4Addr::new(198, 51, 100, 65).is_global(), false);
    /// assert_eq!(Ipv4Addr::new(203, 0, 113, 6).is_global(), false);
    ///
    /// // Addresses reserved for benchmarking (`198.18.0.0/15`) <br>为 (`198.18.0.0/15`) 基准测试保留的地址<br>
    /// assert_eq!(Ipv4Addr::new(198, 18, 0, 0).is_global(), false);
    ///
    /// // Reserved addresses (`240.0.0.0/4`) <br>保留地址 (`240.0.0.0/4`)<br>
    /// assert_eq!(Ipv4Addr::new(250, 10, 20, 30).is_global(), false);
    ///
    /// // The broadcast address (`255.255.255.255`) <br>广播地址 (`255.255.255.255`)<br>
    /// assert_eq!(Ipv4Addr::BROADCAST.is_global(), false);
    ///
    /// // For a complete overview see the IANA IPv4 Special-Purpose Address Registry. <br>有关完整概述，请参见 IANA IPv4 专用地址注册表。<br>
    /// ```
    #[rustc_const_unstable(feature = "const_ipv4", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_global(&self) -> bool {
        !(self.octets()[0] == 0 // "This network"
            || self.is_private()
            || self.is_shared()
            || self.is_loopback()
            || self.is_link_local()
            // addresses reserved for future protocols (`192.0.0.0/24`) <br>为 future 协议 (`192.0.0.0/24`) 保留的地址<br>
            ||(self.octets()[0] == 192 && self.octets()[1] == 0 && self.octets()[2] == 0)
            || self.is_documentation()
            || self.is_benchmarking()
            || self.is_reserved()
            || self.is_broadcast())
    }

    /// Returns [`true`] if this address is part of the Shared Address Space defined in [IETF RFC 6598] (`100.64.0.0/10`). <br>如果此地址是 [IETF RFC 6598] (`100.64.0.0/10`) 中定义的共享地址空间的一部分，则返回 [`true`]。<br>
    ///
    ///
    /// [IETF RFC 6598]: https://tools.ietf.org/html/rfc6598
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    /// use std::net::Ipv4Addr;
    ///
    /// assert_eq!(Ipv4Addr::new(100, 64, 0, 0).is_shared(), true);
    /// assert_eq!(Ipv4Addr::new(100, 127, 255, 255).is_shared(), true);
    /// assert_eq!(Ipv4Addr::new(100, 128, 0, 0).is_shared(), false);
    /// ```
    #[rustc_const_unstable(feature = "const_ipv4", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_shared(&self) -> bool {
        self.octets()[0] == 100 && (self.octets()[1] & 0b1100_0000 == 0b0100_0000)
    }

    /// Returns [`true`] if this address part of the `198.18.0.0/15` range, which is reserved for network devices benchmarking. <br>如果此地址属于 `198.18.0.0/15` 范围 (为网络设备基准测试保留)，则返回 [`true`]。<br>
    /// This range is defined in [IETF RFC 2544] as `192.18.0.0` through `198.19.255.255` but [errata 423] corrects it to `198.18.0.0/15`. <br>[IETF RFC 2544] 将该范围定义为 `192.18.0.0` 至 `198.19.255.255`，但 [勘误表 423][errata 423] 将其更正为 `198.18.0.0/15`。<br>
    ///
    ///
    /// [IETF RFC 2544]: https://tools.ietf.org/html/rfc2544
    /// [errata 423]: https://www.rfc-editor.org/errata/eid423
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    /// use std::net::Ipv4Addr;
    ///
    /// assert_eq!(Ipv4Addr::new(198, 17, 255, 255).is_benchmarking(), false);
    /// assert_eq!(Ipv4Addr::new(198, 18, 0, 0).is_benchmarking(), true);
    /// assert_eq!(Ipv4Addr::new(198, 19, 255, 255).is_benchmarking(), true);
    /// assert_eq!(Ipv4Addr::new(198, 20, 0, 0).is_benchmarking(), false);
    /// ```
    #[rustc_const_unstable(feature = "const_ipv4", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_benchmarking(&self) -> bool {
        self.octets()[0] == 198 && (self.octets()[1] & 0xfe) == 18
    }

    /// Returns [`true`] if this address is reserved by IANA for future use. <br>如果此地址由 IANA 保留供 future 使用，则返回 [`true`]。<br> [IETF RFC 1112] defines the block of reserved addresses as `240.0.0.0/4`. <br>[IETF RFC 1112] 将保留地址块定义为 `240.0.0.0/4`。<br>
    /// This range normally includes the broadcast address `255.255.255.255`, but this implementation explicitly excludes it, since it is obviously not reserved for future use. <br>此范围通常包括广播地址 `255.255.255.255`，但是此实现方案明确将其排除在外，因为它显然不保留供 future 使用。<br>
    ///
    ///
    /// [IETF RFC 1112]: https://tools.ietf.org/html/rfc1112
    ///
    /// # Warning
    ///
    /// As IANA assigns new addresses, this method will be updated. <br>随着 IANA 分配新地址，此方法将被更新。<br>
    /// This may result in non-reserved addresses being treated as reserved in code that relies on an outdated version of this method. <br>这可能会导致未保留的地址被视为依赖于此方法的过时版本的代码中的保留地址。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    /// use std::net::Ipv4Addr;
    ///
    /// assert_eq!(Ipv4Addr::new(240, 0, 0, 0).is_reserved(), true);
    /// assert_eq!(Ipv4Addr::new(255, 255, 255, 254).is_reserved(), true);
    ///
    /// assert_eq!(Ipv4Addr::new(239, 255, 255, 255).is_reserved(), false);
    /// // The broadcast address is not considered as reserved for future use by this implementation <br>此实现不将广播地址视为保留给 future 使用<br>
    /// assert_eq!(Ipv4Addr::new(255, 255, 255, 255).is_reserved(), false);
    /// ```
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_ipv4", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_reserved(&self) -> bool {
        self.octets()[0] & 240 == 240 && !self.is_broadcast()
    }

    /// Returns [`true`] if this is a multicast address (`224.0.0.0/4`). <br>如果这是多播地址 (`224.0.0.0/4`)，则返回 [`true`]。<br>
    ///
    /// Multicast addresses have a most significant octet between `224` and `239`, and is defined by [IETF RFC 5771]. <br>多播地址在 `224` 和 `239` 之间有一个最重要的八位字节，由 [IETF RFC 5771] 定义。<br>
    ///
    ///
    /// [IETF RFC 5771]: https://tools.ietf.org/html/rfc5771
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// assert_eq!(Ipv4Addr::new(224, 254, 0, 0).is_multicast(), true);
    /// assert_eq!(Ipv4Addr::new(236, 168, 10, 65).is_multicast(), true);
    /// assert_eq!(Ipv4Addr::new(172, 16, 10, 65).is_multicast(), false);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(since = "1.7.0", feature = "ip_17")]
    #[must_use]
    #[inline]
    pub const fn is_multicast(&self) -> bool {
        self.octets()[0] >= 224 && self.octets()[0] <= 239
    }

    /// Returns [`true`] if this is a broadcast address (`255.255.255.255`). <br>如果这是广播地址 (`255.255.255.255`)，则返回 [`true`]。<br>
    ///
    /// A broadcast address has all octets set to `255` as defined in [IETF RFC 919]. <br>广播地址的所有八位字节都设置为 `255`，如 [IETF RFC 919] 中所定义。<br>
    ///
    /// [IETF RFC 919]: https://tools.ietf.org/html/rfc919
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// assert_eq!(Ipv4Addr::new(255, 255, 255, 255).is_broadcast(), true);
    /// assert_eq!(Ipv4Addr::new(236, 168, 10, 65).is_broadcast(), false);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(since = "1.7.0", feature = "ip_17")]
    #[must_use]
    #[inline]
    pub const fn is_broadcast(&self) -> bool {
        u32::from_be_bytes(self.octets()) == u32::from_be_bytes(Self::BROADCAST.octets())
    }

    /// Returns [`true`] if this address is in a range designated for documentation. <br>如果此地址在文档指定的范围内，则返回 [`true`]。<br>
    ///
    /// This is defined in [IETF RFC 5737]: <br>这在 [IETF RFC 5737] 中定义：<br>
    ///
    /// - `192.0.2.0/24` (TEST-NET-1)
    /// - `198.51.100.0/24` (TEST-NET-2)
    /// - `203.0.113.0/24` (TEST-NET-3)
    ///
    /// [IETF RFC 5737]: https://tools.ietf.org/html/rfc5737
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// assert_eq!(Ipv4Addr::new(192, 0, 2, 255).is_documentation(), true);
    /// assert_eq!(Ipv4Addr::new(198, 51, 100, 65).is_documentation(), true);
    /// assert_eq!(Ipv4Addr::new(203, 0, 113, 6).is_documentation(), true);
    /// assert_eq!(Ipv4Addr::new(193, 34, 17, 19).is_documentation(), false);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(since = "1.7.0", feature = "ip_17")]
    #[must_use]
    #[inline]
    pub const fn is_documentation(&self) -> bool {
        matches!(self.octets(), [192, 0, 2, _] | [198, 51, 100, _] | [203, 0, 113, _])
    }

    /// Converts this address to an [IPv4-compatible] [`IPv6` address]. <br>将此地址转换为 [IPv4 兼容][IPv4-compatible] 的 [`IPv6` 地址][`IPv6` address]。<br>
    ///
    /// `a.b.c.d` becomes `::a.b.c.d` <br>`a.b.c.d` 变成 `::a.b.c.d`<br>
    ///
    /// Note that IPv4-compatible addresses have been officially deprecated. <br>请注意，与 IPv4 兼容的地址已被正式弃用。<br>
    /// If you don't explicitly need an IPv4-compatible address for legacy reasons, consider using `to_ipv6_mapped` instead. <br>如果出于遗留原因，您没有明确需要与 IPv4 兼容的地址，请考虑改用 `to_ipv6_mapped`。<br>
    ///
    /// [IPv4-compatible]: Ipv6Addr#ipv4-compatible-ipv6-addresses
    /// [`IPv6` address]: Ipv6Addr
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(
    ///     Ipv4Addr::new(192, 0, 2, 255).to_ipv6_compatible(),
    ///     Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0xc000, 0x2ff)
    /// );
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    pub const fn to_ipv6_compatible(&self) -> Ipv6Addr {
        let [a, b, c, d] = self.octets();
        Ipv6Addr { octets: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, a, b, c, d] }
    }

    /// Converts this address to an [IPv4-mapped] [`IPv6` address]. <br>将此地址转换为 [IPv4 映射][IPv4-mapped] 的 [`IPv6` 地址][`IPv6` address]。<br>
    ///
    /// `a.b.c.d` becomes `::ffff:a.b.c.d` <br>`a.b.c.d` 变成 `::ffff:a.b.c.d`<br>
    ///
    /// [IPv4-mapped]: Ipv6Addr#ipv4-mapped-ipv6-addresses
    /// [`IPv6` address]: Ipv6Addr
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(Ipv4Addr::new(192, 0, 2, 255).to_ipv6_mapped(),
    ///            Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc000, 0x2ff));
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    pub const fn to_ipv6_mapped(&self) -> Ipv6Addr {
        let [a, b, c, d] = self.octets();
        Ipv6Addr { octets: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xFF, 0xFF, a, b, c, d] }
    }
}

#[stable(feature = "ip_addr", since = "1.7.0")]
impl fmt::Display for IpAddr {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            IpAddr::V4(ip) => ip.fmt(fmt),
            IpAddr::V6(ip) => ip.fmt(fmt),
        }
    }
}

#[stable(feature = "ip_addr", since = "1.7.0")]
impl fmt::Debug for IpAddr {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self, fmt)
    }
}

#[stable(feature = "ip_from_ip", since = "1.16.0")]
impl From<Ipv4Addr> for IpAddr {
    /// Copies this address to a new `IpAddr::V4`. <br>将此地址复制到新的 `IpAddr::V4`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{IpAddr, Ipv4Addr};
    ///
    /// let addr = Ipv4Addr::new(127, 0, 0, 1);
    ///
    /// assert_eq!(
    ///     IpAddr::V4(addr),
    ///     IpAddr::from(addr)
    /// )
    /// ```
    #[inline]
    fn from(ipv4: Ipv4Addr) -> IpAddr {
        IpAddr::V4(ipv4)
    }
}

#[stable(feature = "ip_from_ip", since = "1.16.0")]
impl From<Ipv6Addr> for IpAddr {
    /// Copies this address to a new `IpAddr::V6`. <br>将此地址复制到新的 `IpAddr::V6`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{IpAddr, Ipv6Addr};
    ///
    /// let addr = Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff);
    ///
    /// assert_eq!(
    ///     IpAddr::V6(addr),
    ///     IpAddr::from(addr)
    /// );
    /// ```
    #[inline]
    fn from(ipv6: Ipv6Addr) -> IpAddr {
        IpAddr::V6(ipv6)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Ipv4Addr {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let octets = self.octets();

        // If there are no alignment requirements, write the IP address directly to `f`. <br>如果没有对齐要求，直接将 IP 地址写入 `f`。<br>
        // Otherwise, write it to a local buffer and then use `f.pad`. <br>否则，将其写入本地缓冲区，然后使用 `f.pad`。<br>
        if fmt.precision().is_none() && fmt.width().is_none() {
            write!(fmt, "{}.{}.{}.{}", octets[0], octets[1], octets[2], octets[3])
        } else {
            const LONGEST_IPV4_ADDR: &str = "255.255.255.255";

            let mut buf = DisplayBuffer::<{ LONGEST_IPV4_ADDR.len() }>::new();
            // Buffer is long enough for the longest possible IPv4 address, so this should never fail. <br>缓冲区足够长，可以容纳最长的 IPv4 地址，所以这永远不会失败。<br>
            write!(buf, "{}.{}.{}.{}", octets[0], octets[1], octets[2], octets[3]).unwrap();

            fmt.pad(buf.as_str())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for Ipv4Addr {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self, fmt)
    }
}

#[stable(feature = "ip_cmp", since = "1.16.0")]
impl PartialEq<Ipv4Addr> for IpAddr {
    #[inline]
    fn eq(&self, other: &Ipv4Addr) -> bool {
        match self {
            IpAddr::V4(v4) => v4 == other,
            IpAddr::V6(_) => false,
        }
    }
}

#[stable(feature = "ip_cmp", since = "1.16.0")]
impl PartialEq<IpAddr> for Ipv4Addr {
    #[inline]
    fn eq(&self, other: &IpAddr) -> bool {
        match other {
            IpAddr::V4(v4) => self == v4,
            IpAddr::V6(_) => false,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ipv4Addr {
    #[inline]
    fn partial_cmp(&self, other: &Ipv4Addr) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "ip_cmp", since = "1.16.0")]
impl PartialOrd<Ipv4Addr> for IpAddr {
    #[inline]
    fn partial_cmp(&self, other: &Ipv4Addr) -> Option<Ordering> {
        match self {
            IpAddr::V4(v4) => v4.partial_cmp(other),
            IpAddr::V6(_) => Some(Ordering::Greater),
        }
    }
}

#[stable(feature = "ip_cmp", since = "1.16.0")]
impl PartialOrd<IpAddr> for Ipv4Addr {
    #[inline]
    fn partial_cmp(&self, other: &IpAddr) -> Option<Ordering> {
        match other {
            IpAddr::V4(v4) => self.partial_cmp(v4),
            IpAddr::V6(_) => Some(Ordering::Less),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ipv4Addr {
    #[inline]
    fn cmp(&self, other: &Ipv4Addr) -> Ordering {
        self.octets.cmp(&other.octets)
    }
}

#[stable(feature = "ip_u32", since = "1.1.0")]
impl From<Ipv4Addr> for u32 {
    /// Converts an `Ipv4Addr` into a host byte order `u32`. <br>将 `Ipv4Addr` 转换为主机字节顺序 `u32`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// let addr = Ipv4Addr::new(0x12, 0x34, 0x56, 0x78);
    /// assert_eq!(0x12345678, u32::from(addr));
    /// ```
    #[inline]
    fn from(ip: Ipv4Addr) -> u32 {
        u32::from_be_bytes(ip.octets)
    }
}

#[stable(feature = "ip_u32", since = "1.1.0")]
impl From<u32> for Ipv4Addr {
    /// Converts a host byte order `u32` into an `Ipv4Addr`. <br>将主机字节顺序 `u32` 转换为 `Ipv4Addr`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// let addr = Ipv4Addr::from(0x12345678);
    /// assert_eq!(Ipv4Addr::new(0x12, 0x34, 0x56, 0x78), addr);
    /// ```
    #[inline]
    fn from(ip: u32) -> Ipv4Addr {
        Ipv4Addr { octets: ip.to_be_bytes() }
    }
}

#[stable(feature = "from_slice_v4", since = "1.9.0")]
impl From<[u8; 4]> for Ipv4Addr {
    /// Creates an `Ipv4Addr` from a four element byte array. <br>从一个四元素字节数组创建一个 `Ipv4Addr`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv4Addr;
    ///
    /// let addr = Ipv4Addr::from([13u8, 12u8, 11u8, 10u8]);
    /// assert_eq!(Ipv4Addr::new(13, 12, 11, 10), addr);
    /// ```
    #[inline]
    fn from(octets: [u8; 4]) -> Ipv4Addr {
        Ipv4Addr { octets }
    }
}

#[stable(feature = "ip_from_slice", since = "1.17.0")]
impl From<[u8; 4]> for IpAddr {
    /// Creates an `IpAddr::V4` from a four element byte array. <br>从一个四元素字节数组创建一个 `IpAddr::V4`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{IpAddr, Ipv4Addr};
    ///
    /// let addr = IpAddr::from([13u8, 12u8, 11u8, 10u8]);
    /// assert_eq!(IpAddr::V4(Ipv4Addr::new(13, 12, 11, 10)), addr);
    /// ```
    #[inline]
    fn from(octets: [u8; 4]) -> IpAddr {
        IpAddr::V4(Ipv4Addr::from(octets))
    }
}

impl Ipv6Addr {
    /// Creates a new IPv6 address from eight 16-bit segments. <br>从八个 16 位段创建一个新的 IPv6 地址。<br>
    ///
    /// The result will represent the IP address `a:b:c:d:e:f:g:h`. <br>结果将代表 IP 地址 `a:b:c:d:e:f:g:h`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// let addr = Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff);
    /// ```
    #[rustc_const_stable(feature = "const_ip_32", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    #[inline]
    pub const fn new(a: u16, b: u16, c: u16, d: u16, e: u16, f: u16, g: u16, h: u16) -> Ipv6Addr {
        let addr16 = [
            a.to_be(),
            b.to_be(),
            c.to_be(),
            d.to_be(),
            e.to_be(),
            f.to_be(),
            g.to_be(),
            h.to_be(),
        ];
        Ipv6Addr {
            // All elements in `addr16` are big endian. <br>`addr16` 中的所有元素均为大端。<br>
            // SAFETY: `[u16; 8]` is always safe to transmute to `[u8; 16]`. <br>`[u16; 8]` 始终可以安全地转换为 `[u8; 16]`。<br>
            octets: unsafe { transmute::<_, [u8; 16]>(addr16) },
        }
    }

    /// An IPv6 address representing localhost: `::1`. <br>代表本地主机的 IPv6 地址: `::1`。<br>
    ///
    /// This corresponds to constant `IN6ADDR_LOOPBACK_INIT` or `in6addr_loopback` in other languages. <br>这对应其他语言的常量 `IN6ADDR_LOOPBACK_INIT` 或 `in6addr_loopback`。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// let addr = Ipv6Addr::LOCALHOST;
    /// assert_eq!(addr, Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 1));
    /// ```
    #[doc(alias = "IN6ADDR_LOOPBACK_INIT")]
    #[doc(alias = "in6addr_loopback")]
    #[stable(feature = "ip_constructors", since = "1.30.0")]
    pub const LOCALHOST: Self = Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 1);

    /// An IPv6 address representing the unspecified address: `::` <br>代表未指定地址的 IPv6 地址: `::`<br>
    ///
    /// This corresponds to constant `IN6ADDR_ANY_INIT` or `in6addr_any` in other languages. <br>这对应其他语言的常量 `IN6ADDR_ANY_INIT` 或 `in6addr_any`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// let addr = Ipv6Addr::UNSPECIFIED;
    /// assert_eq!(addr, Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 0));
    /// ```
    #[doc(alias = "IN6ADDR_ANY_INIT")]
    #[doc(alias = "in6addr_any")]
    #[stable(feature = "ip_constructors", since = "1.30.0")]
    pub const UNSPECIFIED: Self = Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 0);

    /// Returns the eight 16-bit segments that make up this address. <br>返回组成该地址的八个 16 位段。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff).segments(),
    ///            [0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff]);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    #[inline]
    pub const fn segments(&self) -> [u16; 8] {
        // All elements in `self.octets` must be big endian. <br>`self.octets` 中的所有元素都必须是大端。<br>
        // SAFETY: `[u8; 16]` is always safe to transmute to `[u16; 8]`. <br>`[u8; 16]` 始终可以安全地转换为 `[u16; 8]`。<br>
        let [a, b, c, d, e, f, g, h] = unsafe { transmute::<_, [u16; 8]>(self.octets) };
        // We want native endian u16 <br>我们想要本地字节序 u16<br>
        [
            u16::from_be(a),
            u16::from_be(b),
            u16::from_be(c),
            u16::from_be(d),
            u16::from_be(e),
            u16::from_be(f),
            u16::from_be(g),
            u16::from_be(h),
        ]
    }

    /// Returns [`true`] for the special 'unspecified' address (`::`). <br>为特殊的 'unspecified' 地址 (`::`) 返回 [`true`]。<br>
    ///
    /// This property is defined in [IETF RFC 4291]. <br>此属性在 [IETF RFC 4291] 中定义。<br>
    ///
    /// [IETF RFC 4291]: https://tools.ietf.org/html/rfc4291
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff).is_unspecified(), false);
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 0).is_unspecified(), true);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(since = "1.7.0", feature = "ip_17")]
    #[must_use]
    #[inline]
    pub const fn is_unspecified(&self) -> bool {
        u128::from_be_bytes(self.octets()) == u128::from_be_bytes(Ipv6Addr::UNSPECIFIED.octets())
    }

    /// Returns [`true`] if this is the [loopback address] (`::1`), as defined in [IETF RFC 4291 section 2.5.3]. <br>如果这是 [环回地址][loopback address] (`::1`)，如 [IETF RFC 4291 第 2.5.3 节][IETF RFC 4291 section 2.5.3] 中所定义，则返回 [`true`]。<br>
    ///
    ///
    /// Contrary to IPv4, in IPv6 there is only one loopback address. <br>与 IPv4 相反，IPv6 只有一个回环地址。<br>
    ///
    /// [loopback address]: Ipv6Addr::LOCALHOST
    /// [IETF RFC 4291 section 2.5.3]: https://tools.ietf.org/html/rfc4291#section-2.5.3
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff).is_loopback(), false);
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 0x1).is_loopback(), true);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(since = "1.7.0", feature = "ip_17")]
    #[must_use]
    #[inline]
    pub const fn is_loopback(&self) -> bool {
        u128::from_be_bytes(self.octets()) == u128::from_be_bytes(Ipv6Addr::LOCALHOST.octets())
    }

    /// Returns [`true`] if the address appears to be globally reachable as specified by the [IANA IPv6 Special-Purpose Address Registry]. <br>如果地址看起来是由 [IANA IPv6 Special-Purpose Address Registry] 指定的全局可访问的，则返回 [`true`]。<br>
    /// Whether or not an address is practically reachable will depend on your network configuration. <br>一个地址是否实际可访问将取决于您的网络配置。<br>
    ///
    /// Most IPv6 addresses are globally reachable; <br>大多数 IPv6 地址都是全局可达的;<br>
    /// unless they are specifically defined as *not* globally reachable. <br>除非它们被明确定义为 *not* 全局可达。<br>
    ///
    /// Non-exhaustive list of notable addresses that are not globally reachable: <br>全球无法访问的显着地址的非详尽列表:<br>
    /// - The [unspecified address] ([`is_unspecified`](Ipv6Addr::is_unspecified)) <br>[unspecified address] ([`is_unspecified`](Ipv6Addr::is_unspecified))<br>
    /// - The [loopback address] ([`is_loopback`](Ipv6Addr::is_loopback)) <br>[loopback address] ([`is_loopback`](Ipv6Addr::is_loopback))<br>
    /// - IPv4-mapped addresses <br>IPv4 映射地址<br>
    /// - Addresses reserved for benchmarking <br>为基准测试保留的地址<br>
    /// - Addresses reserved for documentation ([`is_documentation`](Ipv6Addr::is_documentation)) <br>为文档 ([`is_documentation`](Ipv6Addr::is_documentation)) 保留的地址<br>
    /// - Unique local addresses ([`is_unique_local`](Ipv6Addr::is_unique_local)) <br>唯一的本地地址 ([`is_unique_local`](Ipv6Addr::is_unique_local))<br>
    /// - Unicast addresses with link-local scope ([`is_unicast_link_local`](Ipv6Addr::is_unicast_link_local)) <br>具有链路本地作用域 ([`is_unicast_link_local`](Ipv6Addr::is_unicast_link_local)) 的单播地址<br>
    ///
    /// For the complete overview of which addresses are globally reachable, see the table at the [IANA IPv6 Special-Purpose Address Registry]. <br>有关哪些地址可全局访问的完整概览，请参见 [IANA IPv6 Special-Purpose Address Registry] 中的表格。<br>
    ///
    /// Note that an address having global scope is not the same as being globally reachable, and there is no direct relation between the two concepts: There exist addresses with global scope that are not globally reachable (for example unique local addresses), and addresses that are globally reachable without having global scope (multicast addresses with non-global scope). <br>请注意，地址具有以下作用: 存在与全局可访问相同的地址，并且这两个概念之间没有直接关系是全球可访问的，没有具有非域范围的多播地址 (多播地址)。<br>
    ///
    ///
    /// [IANA IPv6 Special-Purpose Address Registry]: https://www.iana.org/assignments/iana-ipv6-special-registry/iana-ipv6-special-registry.xhtml
    /// [unspecified address]: Ipv6Addr::UNSPECIFIED
    /// [loopback address]: Ipv6Addr::LOCALHOST
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::Ipv6Addr;
    ///
    /// // Most IPv6 addresses are globally reachable: <br>大多数 IPv6 地址都是全局可达的:<br>
    /// assert_eq!(Ipv6Addr::new(0x26, 0, 0x1c9, 0, 0, 0xafc8, 0x10, 0x1).is_global(), true);
    ///
    /// // However some addresses have been assigned a special meaning that makes them not globally reachable. <br>但是，某些地址已被赋予特殊含义，使它们无法全局访问。<br>
    /// // Some examples are: <br>一些例子是:<br>
    ///
    /// // The unspecified address (`::`) <br>未指定的地址 (`::`)<br>
    /// assert_eq!(Ipv6Addr::UNSPECIFIED.is_global(), false);
    ///
    /// // The loopback address (`::1`) <br>回环地址 (`::1`)<br>
    /// assert_eq!(Ipv6Addr::LOCALHOST.is_global(), false);
    ///
    /// // IPv4-mapped addresses (`::ffff:0:0/96`) <br>IPv4 映射地址 (`::ffff:0:0/96`)<br>
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff).is_global(), false);
    ///
    /// // Addresses reserved for benchmarking (`2001:2::/48`) <br>为 (`2001:2::/48`) 基准测试保留的地址<br>
    /// assert_eq!(Ipv6Addr::new(0x2001, 2, 0, 0, 0, 0, 0, 1,).is_global(), false);
    ///
    /// // Addresses reserved for documentation (`2001:db8::/32`) <br>为文档 (`2001:db8::/32`) 保留的地址<br>
    /// assert_eq!(Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 1).is_global(), false);
    ///
    /// // Unique local addresses (`fc00::/7`) <br>唯一的本地地址 (`fc00::/7`)<br>
    /// assert_eq!(Ipv6Addr::new(0xfc02, 0, 0, 0, 0, 0, 0, 1).is_global(), false);
    ///
    /// // Unicast addresses with link-local scope (`fe80::/10`) <br>具有链路本地作用域 (`fe80::/10`) 的单播地址<br>
    /// assert_eq!(Ipv6Addr::new(0xfe81, 0, 0, 0, 0, 0, 0, 1).is_global(), false);
    ///
    /// // For a complete overview see the IANA IPv6 Special-Purpose Address Registry. <br>有关完整概述，请参见 IANA IPv6 专用地址注册表。<br>
    /// ```
    ///
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_ipv6", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_global(&self) -> bool {
        !(self.is_unspecified()
            || self.is_loopback()
            // IPv4-mapped Address (`::ffff:0:0/96`) <br>IPv4 映射地址 (`::ffff:0:0/96`)<br>
            || matches!(self.segments(), [0, 0, 0, 0, 0, 0xffff, _, _])
            // IPv4-IPv6 Translat. <br>IPv4-IPv6 Translat。<br> (`64:ff9b:1::/48`)
            || matches!(self.segments(), [0x64, 0xff9b, 1, _, _, _, _, _])
            // Discard-Only Address Block (`100::/64`) <br>仅丢弃地址块 (`100::/64`)<br>
            || matches!(self.segments(), [0x100, 0, 0, 0, _, _, _, _])
            // IETF Protocol Assignments (`2001::/23`) <br>IETF 协议分配 (`2001::/23`)<br>
            || (matches!(self.segments(), [0x2001, b, _, _, _, _, _, _] if b < 0x200)
                && !(
                    // Port Control Protocol Anycast (`2001:1::1`) <br>端口控制协议任播 (`2001:1::1`)<br>
                    u128::from_be_bytes(self.octets()) == 0x2001_0001_0000_0000_0000_0000_0000_0001
                    // Traversal Using Relays around NAT Anycast (`2001:1::2`) <br>在 NAT Anycast (`2001:1::2`) 周围使用中继进行遍历<br>
                    || u128::from_be_bytes(self.octets()) == 0x2001_0001_0000_0000_0000_0000_0000_0002
                    // AMT (`2001:3::/32`)
                    || matches!(self.segments(), [0x2001, 3, _, _, _, _, _, _])
                    // AS112-v6 (`2001:4:112::/48`)
                    || matches!(self.segments(), [0x2001, 4, 0x112, _, _, _, _, _])
                    // ORCHIDv2 (`2001:20::/28`)
                    || matches!(self.segments(), [0x2001, b, _, _, _, _, _, _] if b >= 0x20 && b <= 0x2F)
                ))
            || self.is_documentation()
            || self.is_unique_local()
            || self.is_unicast_link_local())
    }

    /// Returns [`true`] if this is a unique local address (`fc00::/7`). <br>如果这是唯一的本地地址 (`fc00::/7`)，则返回 [`true`]。<br>
    ///
    /// This property is defined in [IETF RFC 4193]. <br>此属性在 [IETF RFC 4193] 中定义。<br>
    ///
    /// [IETF RFC 4193]: https://tools.ietf.org/html/rfc4193
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::Ipv6Addr;
    ///
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff).is_unique_local(), false);
    /// assert_eq!(Ipv6Addr::new(0xfc02, 0, 0, 0, 0, 0, 0, 0).is_unique_local(), true);
    /// ```
    #[rustc_const_unstable(feature = "const_ipv6", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_unique_local(&self) -> bool {
        (self.segments()[0] & 0xfe00) == 0xfc00
    }

    /// Returns [`true`] if this is a unicast address, as defined by [IETF RFC 4291]. <br>如果这是 [IETF RFC 4291] 定义的单播地址，则返回 [`true`]。<br>
    /// Any address that is not a [multicast address] (`ff00::/8`) is unicast. <br>任何不是 [多播地址][multicast address] (`ff00::/8`) 的地址都是单播的。<br>
    ///
    /// [IETF RFC 4291]: https://tools.ietf.org/html/rfc4291
    /// [multicast address]: Ipv6Addr::is_multicast
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::Ipv6Addr;
    ///
    /// // The unspecified and loopback addresses are unicast. <br>未指定地址和回环地址是单播的。<br>
    /// assert_eq!(Ipv6Addr::UNSPECIFIED.is_unicast(), true);
    /// assert_eq!(Ipv6Addr::LOCALHOST.is_unicast(), true);
    ///
    /// // Any address that is not a multicast address (`ff00::/8`) is unicast. <br>任何不是多播地址 (`ff00::/8`) 的地址都是单播的。<br>
    /// assert_eq!(Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 0).is_unicast(), true);
    /// assert_eq!(Ipv6Addr::new(0xff00, 0, 0, 0, 0, 0, 0, 0).is_unicast(), false);
    /// ```
    #[rustc_const_unstable(feature = "const_ipv6", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_unicast(&self) -> bool {
        !self.is_multicast()
    }

    /// Returns `true` if the address is a unicast address with link-local scope, as defined in [RFC 4291]. <br>如果地址是具有链接本地作用域的单播地址，则返回 `true`，如 [RFC 4291] 中所定义。<br>
    ///
    /// A unicast address has link-local scope if it has the prefix `fe80::/10`, as per [RFC 4291 section 2.4]. <br>如果单播地址具有前缀 `fe80::/10`，则它具有链路本地作用域，如 [RFC 4291 section 2.4]。<br>
    /// Note that this encompasses more addresses than those defined in [RFC 4291 section 2.5.6], which describes "Link-Local IPv6 Unicast Addresses" as having the following stricter format: <br>请注意，这包含比 [RFC 4291 第 2.5.6 节][RFC 4291 section 2.5.6] 中定义的地址更多的地址，[RFC 4291 第 2.5.6 节] 将 "链路本地 IPv6 单播地址" 描述为具有以下更严格的格式：<br>
    ///
    /// ```text
    /// | 10 bits  |         54 bits         |          64 bits           |
    /// +----------+-------------------------+----------------------------+
    /// |1111111010|           0             |       interface ID         |
    /// +----------+-------------------------+----------------------------+
    /// ```
    /// So while currently the only addresses with link-local scope an application will encounter are all in `fe80::/64`, this might change in the future with the publication of new standards. <br>因此，虽然目前应用程序将遇到的唯一具有本地链接作用域的地址都在 `fe80::/64` 中，但随着新标准的发布，这可能会在 future 中发生变化。<br>
    /// More addresses in `fe80::/10` could be allocated, and those addresses will have link-local scope. <br>`fe80::/10` 中可以分配更多的地址，这些地址将具有本地链接作用域。<br>
    ///
    /// Also note that while [RFC 4291 section 2.5.3] mentions about the [loopback address] (`::1`) that "it is treated as having Link-Local scope", this does not mean that the loopback address actually has link-local scope and this method will return `false` on it. <br>另请注意，虽然 [RFC 4291 第 2.5.3 章][RFC 4291 section 2.5.3] 提到 "它被视为具有 Link-Local 作用域" 的 [环回地址][loopback address] (`::1`)，但这并不意味着回环地址实际上具有链接本地作用域，并且此方法将在其上返回 `false`。<br>
    ///
    ///
    /// [RFC 4291]: https://tools.ietf.org/html/rfc4291
    /// [RFC 4291 section 2.4]: https://tools.ietf.org/html/rfc4291#section-2.4
    /// [RFC 4291 section 2.5.3]: https://tools.ietf.org/html/rfc4291#section-2.5.3
    /// [RFC 4291 section 2.5.6]: https://tools.ietf.org/html/rfc4291#section-2.5.6
    /// [loopback address]: Ipv6Addr::LOCALHOST
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::Ipv6Addr;
    ///
    /// // The loopback address (`::1`) does not actually have link-local scope. <br>回环地址 (`::1`) 实际上并没有链接本地作用域。<br>
    /// assert_eq!(Ipv6Addr::LOCALHOST.is_unicast_link_local(), false);
    ///
    /// // Only addresses in `fe80::/10` have link-local scope. <br>只有 `fe80::/10` 中的地址具有本地链接作用域。<br>
    /// assert_eq!(Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 0).is_unicast_link_local(), false);
    /// assert_eq!(Ipv6Addr::new(0xfe80, 0, 0, 0, 0, 0, 0, 0).is_unicast_link_local(), true);
    ///
    /// // Addresses outside the stricter `fe80::/64` also have link-local scope. <br>更严格的 `fe80::/64` 之外的地址也具有链接本地作用域。<br>
    /// assert_eq!(Ipv6Addr::new(0xfe80, 0, 0, 1, 0, 0, 0, 0).is_unicast_link_local(), true);
    /// assert_eq!(Ipv6Addr::new(0xfe81, 0, 0, 0, 0, 0, 0, 0).is_unicast_link_local(), true);
    /// ```
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_ipv6", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_unicast_link_local(&self) -> bool {
        (self.segments()[0] & 0xffc0) == 0xfe80
    }

    /// Returns [`true`] if this is an address reserved for documentation (`2001:db8::/32`). <br>如果这是为文档 (`2001:db8::/32`) 保留的地址，则返回 [`true`]。<br>
    ///
    ///
    /// This property is defined in [IETF RFC 3849]. <br>此属性在 [IETF RFC 3849] 中定义。<br>
    ///
    /// [IETF RFC 3849]: https://tools.ietf.org/html/rfc3849
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::Ipv6Addr;
    ///
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff).is_documentation(), false);
    /// assert_eq!(Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 0).is_documentation(), true);
    /// ```
    #[rustc_const_unstable(feature = "const_ipv6", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_documentation(&self) -> bool {
        (self.segments()[0] == 0x2001) && (self.segments()[1] == 0xdb8)
    }

    /// Returns [`true`] if this is an address reserved for benchmarking (`2001:2::/48`). <br>如果这是为基准测试 (`2001:2::/48`) 保留的地址，则返回 [`true`]。<br>
    ///
    /// This property is defined in [IETF RFC 5180], where it is mistakenly specified as covering the range `2001:0200::/48`. <br>此属性在 [IETF RFC 5180] 中定义，其中错误地将其指定为覆盖范围 `2001:0200::/48`。<br>
    /// This is corrected in [IETF RFC Errata 1752] to `2001:0002::/48`. <br>这在 [IETF RFC Errata 1752] 到 `2001:0002::/48` 中得到纠正。<br>
    ///
    /// [IETF RFC 5180]: https://tools.ietf.org/html/rfc5180
    /// [IETF RFC Errata 1752]: https://www.rfc-editor.org/errata_search.php?eid=1752
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::Ipv6Addr;
    ///
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc613, 0x0).is_benchmarking(), false);
    /// assert_eq!(Ipv6Addr::new(0x2001, 0x2, 0, 0, 0, 0, 0, 0).is_benchmarking(), true);
    /// ```
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_benchmarking(&self) -> bool {
        (self.segments()[0] == 0x2001) && (self.segments()[1] == 0x2) && (self.segments()[2] == 0)
    }

    /// Returns [`true`] if the address is a globally routable unicast address. <br>如果该地址是全局可路由的单播地址，则返回 [`true`]。<br>
    ///
    /// The following return false: <br>以下返回 false：<br>
    ///
    /// - the loopback address <br>回环地址<br>
    /// - the link-local addresses <br>链接本地地址<br>
    /// - unique local addresses <br>唯一的本地地址<br>
    /// - the unspecified address <br>未指定地址<br>
    /// - the address range reserved for documentation <br>保留用于文档的地址范围<br>
    ///
    /// This method returns [`true`] for site-local addresses as per [RFC 4291 section 2.5.7] <br>此方法根据 [RFC 4291 第 2.5.7 节][RFC 4291 section 2.5.7] 返回 [`true`] 作为站点本地地址<br>
    ///
    /// ```no_rust
    /// The special behavior of [the site-local unicast] prefix defined in [RFC3513] must no longer
    /// be supported in new implementations (i.e., new implementations must treat this prefix as
    /// Global Unicast).
    /// ```
    ///
    /// [RFC 4291 section 2.5.7]: https://tools.ietf.org/html/rfc4291#section-2.5.7
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::Ipv6Addr;
    ///
    /// assert_eq!(Ipv6Addr::new(0x2001, 0xdb8, 0, 0, 0, 0, 0, 0).is_unicast_global(), false);
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff).is_unicast_global(), true);
    /// ```
    #[rustc_const_unstable(feature = "const_ipv6", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn is_unicast_global(&self) -> bool {
        self.is_unicast()
            && !self.is_loopback()
            && !self.is_unicast_link_local()
            && !self.is_unique_local()
            && !self.is_unspecified()
            && !self.is_documentation()
            && !self.is_benchmarking()
    }

    /// Returns the address's multicast scope if the address is multicast. <br>如果该地址是多播的，则返回该地址的多播作用域。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    ///
    /// use std::net::{Ipv6Addr, Ipv6MulticastScope};
    ///
    /// assert_eq!(
    ///     Ipv6Addr::new(0xff0e, 0, 0, 0, 0, 0, 0, 0).multicast_scope(),
    ///     Some(Ipv6MulticastScope::Global)
    /// );
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff).multicast_scope(), None);
    /// ```
    #[rustc_const_unstable(feature = "const_ipv6", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use]
    #[inline]
    pub const fn multicast_scope(&self) -> Option<Ipv6MulticastScope> {
        if self.is_multicast() {
            match self.segments()[0] & 0x000f {
                1 => Some(Ipv6MulticastScope::InterfaceLocal),
                2 => Some(Ipv6MulticastScope::LinkLocal),
                3 => Some(Ipv6MulticastScope::RealmLocal),
                4 => Some(Ipv6MulticastScope::AdminLocal),
                5 => Some(Ipv6MulticastScope::SiteLocal),
                8 => Some(Ipv6MulticastScope::OrganizationLocal),
                14 => Some(Ipv6MulticastScope::Global),
                _ => None,
            }
        } else {
            None
        }
    }

    /// Returns [`true`] if this is a multicast address (`ff00::/8`). <br>如果这是多播地址 (`ff00::/8`)，则返回 [`true`]。<br>
    ///
    /// This property is defined by [IETF RFC 4291]. <br>此属性由 [IETF RFC 4291] 定义。<br>
    ///
    /// [IETF RFC 4291]: https://tools.ietf.org/html/rfc4291
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// assert_eq!(Ipv6Addr::new(0xff00, 0, 0, 0, 0, 0, 0, 0).is_multicast(), true);
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff).is_multicast(), false);
    /// ```
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(since = "1.7.0", feature = "ip_17")]
    #[must_use]
    #[inline]
    pub const fn is_multicast(&self) -> bool {
        (self.segments()[0] & 0xff00) == 0xff00
    }

    /// Converts this address to an [`IPv4` address] if it's an [IPv4-mapped] address, as defined in [IETF RFC 4291 section 2.5.5.2], otherwise returns [`None`]. <br>如果它是 [IPv4 映射][IPv4-mapped] 地址 (如 [IETF RFC 4291 第 2.5.5.2 节][IETF RFC 4291 section 2.5.5.2] 中所定义)，则将此地址转换为 [`IPv4` address]，否则返回 [`None`]。<br>
    ///
    ///
    /// `::ffff:a.b.c.d` becomes `a.b.c.d`. <br>`::ffff:a.b.c.d` 变成 `a.b.c.d`。<br>
    /// All addresses *not* starting with `::ffff` will return `None`. <br>所有非以 `::ffff` 开头的地址都将返回 `None`。<br>
    ///
    /// [`IPv4` address]: Ipv4Addr
    /// [IPv4-mapped]: Ipv6Addr
    /// [IETF RFC 4291 section 2.5.5.2]: https://tools.ietf.org/html/rfc4291#section-2.5.5.2
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(Ipv6Addr::new(0xff00, 0, 0, 0, 0, 0, 0, 0).to_ipv4_mapped(), None);
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff).to_ipv4_mapped(),
    ///            Some(Ipv4Addr::new(192, 10, 2, 255)));
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 1).to_ipv4_mapped(), None);
    /// ```
    #[rustc_const_unstable(feature = "const_ipv6", issue = "76205")]
    #[stable(feature = "ipv6_to_ipv4_mapped", since = "1.63.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    pub const fn to_ipv4_mapped(&self) -> Option<Ipv4Addr> {
        match self.octets() {
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xff, 0xff, a, b, c, d] => {
                Some(Ipv4Addr::new(a, b, c, d))
            }
            _ => None,
        }
    }

    /// Converts this address to an [`IPv4` address] if it is either an [IPv4-compatible] address as defined in [IETF RFC 4291 section 2.5.5.1], or an [IPv4-mapped] address as defined in [IETF RFC 4291 section 2.5.5.2], otherwise returns [`None`]. <br>如果此地址是 [IETF RFC 4291 第 2.5.5.1 节][IETF RFC 4291 section 2.5.5.1] 中定义的 [IPv4 兼容][IPv4-compatible] 地址或 [IETF RFC 4291 第 2.5.5.2 节][IETF RFC 4291 section 2.5.5.2] 中定义的 [ IPv4 映射][IPv4-mapped] 地址，则将此地址转换为 [`IPv4` 地址][`IPv4` address]，否则返回 [`None`]。<br>
    ///
    ///
    /// Note that this will return an [`IPv4` address] for the IPv6 loopback address `::1`. <br>请注意，这将为 IPv6 回环地址 `::1` 返回一个 [`IPv4` address]。<br> Use [`Ipv6Addr::to_ipv4_mapped`] to avoid this. <br>使用 [`Ipv6Addr::to_ipv4_mapped`] 可以避免这种情况。<br>
    ///
    /// `::a.b.c.d` and `::ffff:a.b.c.d` become `a.b.c.d`. <br>`::a.b.c.d` 和 `::ffff:a.b.c.d` 变成了 `a.b.c.d`。<br> `::1` becomes `0.0.0.1`. <br>`::1` 变成了 `0.0.0.1`。<br>
    /// All addresses *not* starting with either all zeroes or `::ffff` will return `None`. <br>所有*不*以全零或 `::ffff` 开头的地址都将返回 `None`。<br>
    ///
    /// [`IPv4` address]: Ipv4Addr
    /// [IPv4-compatible]: Ipv6Addr#ipv4-compatible-ipv6-addresses
    /// [IPv4-mapped]: Ipv6Addr#ipv4-mapped-ipv6-addresses
    /// [IETF RFC 4291 section 2.5.5.1]: https://tools.ietf.org/html/rfc4291#section-2.5.5.1
    /// [IETF RFC 4291 section 2.5.5.2]: https://tools.ietf.org/html/rfc4291#section-2.5.5.2
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{Ipv4Addr, Ipv6Addr};
    ///
    /// assert_eq!(Ipv6Addr::new(0xff00, 0, 0, 0, 0, 0, 0, 0).to_ipv4(), None);
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0xc00a, 0x2ff).to_ipv4(),
    ///            Some(Ipv4Addr::new(192, 10, 2, 255)));
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 1).to_ipv4(),
    ///            Some(Ipv4Addr::new(0, 0, 0, 1)));
    /// ```
    ///
    ///
    ///
    #[rustc_const_stable(feature = "const_ip_50", since = "1.50.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    pub const fn to_ipv4(&self) -> Option<Ipv4Addr> {
        if let [0, 0, 0, 0, 0, 0 | 0xffff, ab, cd] = self.segments() {
            let [a, b] = ab.to_be_bytes();
            let [c, d] = cd.to_be_bytes();
            Some(Ipv4Addr::new(a, b, c, d))
        } else {
            None
        }
    }

    /// Converts this address to an `IpAddr::V4` if it is an IPv4-mapped addresses, otherwise it returns self wrapped in an `IpAddr::V6`. <br>如果此地址是 IPv4 映射地址，则将此地址转换为 `IpAddr::V4`，否则返回自包装在 `IpAddr::V6` 中。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ip)]
    /// use std::net::Ipv6Addr;
    ///
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0x7f00, 0x1).is_loopback(), false);
    /// assert_eq!(Ipv6Addr::new(0, 0, 0, 0, 0, 0xffff, 0x7f00, 0x1).to_canonical().is_loopback(), true);
    /// ```
    #[rustc_const_unstable(feature = "const_ipv6", issue = "76205")]
    #[unstable(feature = "ip", issue = "27709")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    pub const fn to_canonical(&self) -> IpAddr {
        if let Some(mapped) = self.to_ipv4_mapped() {
            return IpAddr::V4(mapped);
        }
        IpAddr::V6(*self)
    }

    /// Returns the sixteen eight-bit integers the IPv6 address consists of. <br>返回 IPv6 地址组成的 16 个八位整数。<br>
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// assert_eq!(Ipv6Addr::new(0xff00, 0, 0, 0, 0, 0, 0, 0).octets(),
    ///            [255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
    /// ```
    #[rustc_const_stable(feature = "const_ip_32", since = "1.32.0")]
    #[stable(feature = "ipv6_to_octets", since = "1.12.0")]
    #[must_use]
    #[inline]
    pub const fn octets(&self) -> [u8; 16] {
        self.octets
    }
}

/// Write an Ipv6Addr, conforming to the canonical style described by [RFC 5952](https://tools.ietf.org/html/rfc5952). <br>编写一个符合 [RFC 5952](https://tools.ietf.org/html/rfc5952) 描述的规范样式的 Ivv6Addr。<br>
///
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Ipv6Addr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // If there are no alignment requirements, write the IP address directly to `f`. <br>如果没有对齐要求，直接将 IP 地址写入 `f`。<br>
        // Otherwise, write it to a local buffer and then use `f.pad`. <br>否则，将其写入本地缓冲区，然后使用 `f.pad`。<br>
        if f.precision().is_none() && f.width().is_none() {
            let segments = self.segments();

            // Special case for :: and ::1; <br>:: 和 ::1 的特殊情况；<br> otherwise they get written with the IPv4 formatter <br>否则，它们将使用 IPv4 格式化程序编写<br>
            //
            if self.is_unspecified() {
                f.write_str("::")
            } else if self.is_loopback() {
                f.write_str("::1")
            } else if let Some(ipv4) = self.to_ipv4() {
                match segments[5] {
                    // IPv4 Compatible address <br>IPv4 兼容地址<br>
                    0 => write!(f, "::{}", ipv4),
                    // IPv4 Mapped address <br>IPv4 映射地址<br>
                    0xffff => write!(f, "::ffff:{}", ipv4),
                    _ => unreachable!(),
                }
            } else {
                #[derive(Copy, Clone, Default)]
                struct Span {
                    start: usize,
                    len: usize,
                }

                // Find the inner 0 span <br>找出内部 0 跨度<br>
                let zeroes = {
                    let mut longest = Span::default();
                    let mut current = Span::default();

                    for (i, &segment) in segments.iter().enumerate() {
                        if segment == 0 {
                            if current.len == 0 {
                                current.start = i;
                            }

                            current.len += 1;

                            if current.len > longest.len {
                                longest = current;
                            }
                        } else {
                            current = Span::default();
                        }
                    }

                    longest
                };

                /// Write a colon-separated part of the address <br>写一个用冒号分隔的地址部分<br>
                #[inline]
                fn fmt_subslice(f: &mut fmt::Formatter<'_>, chunk: &[u16]) -> fmt::Result {
                    if let Some((first, tail)) = chunk.split_first() {
                        write!(f, "{:x}", first)?;
                        for segment in tail {
                            f.write_char(':')?;
                            write!(f, "{:x}", segment)?;
                        }
                    }
                    Ok(())
                }

                if zeroes.len > 1 {
                    fmt_subslice(f, &segments[..zeroes.start])?;
                    f.write_str("::")?;
                    fmt_subslice(f, &segments[zeroes.start + zeroes.len..])
                } else {
                    fmt_subslice(f, &segments)
                }
            }
        } else {
            const LONGEST_IPV6_ADDR: &str = "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff";

            let mut buf = DisplayBuffer::<{ LONGEST_IPV6_ADDR.len() }>::new();
            // Buffer is long enough for the longest possible IPv6 address, so this should never fail. <br>缓冲区足够长，可以容纳最长的 IPv6 地址，所以这永远不会失败。<br>
            write!(buf, "{}", self).unwrap();

            f.pad(buf.as_str())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for Ipv6Addr {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self, fmt)
    }
}

#[stable(feature = "ip_cmp", since = "1.16.0")]
impl PartialEq<IpAddr> for Ipv6Addr {
    #[inline]
    fn eq(&self, other: &IpAddr) -> bool {
        match other {
            IpAddr::V4(_) => false,
            IpAddr::V6(v6) => self == v6,
        }
    }
}

#[stable(feature = "ip_cmp", since = "1.16.0")]
impl PartialEq<Ipv6Addr> for IpAddr {
    #[inline]
    fn eq(&self, other: &Ipv6Addr) -> bool {
        match self {
            IpAddr::V4(_) => false,
            IpAddr::V6(v6) => v6 == other,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ipv6Addr {
    #[inline]
    fn partial_cmp(&self, other: &Ipv6Addr) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "ip_cmp", since = "1.16.0")]
impl PartialOrd<Ipv6Addr> for IpAddr {
    #[inline]
    fn partial_cmp(&self, other: &Ipv6Addr) -> Option<Ordering> {
        match self {
            IpAddr::V4(_) => Some(Ordering::Less),
            IpAddr::V6(v6) => v6.partial_cmp(other),
        }
    }
}

#[stable(feature = "ip_cmp", since = "1.16.0")]
impl PartialOrd<IpAddr> for Ipv6Addr {
    #[inline]
    fn partial_cmp(&self, other: &IpAddr) -> Option<Ordering> {
        match other {
            IpAddr::V4(_) => Some(Ordering::Greater),
            IpAddr::V6(v6) => self.partial_cmp(v6),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ipv6Addr {
    #[inline]
    fn cmp(&self, other: &Ipv6Addr) -> Ordering {
        self.segments().cmp(&other.segments())
    }
}

#[stable(feature = "i128", since = "1.26.0")]
impl From<Ipv6Addr> for u128 {
    /// Convert an `Ipv6Addr` into a host byte order `u128`. <br>将 `Ipv6Addr` 转换为主机字节顺序 `u128`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// let addr = Ipv6Addr::new(
    ///     0x1020, 0x3040, 0x5060, 0x7080,
    ///     0x90A0, 0xB0C0, 0xD0E0, 0xF00D,
    /// );
    /// assert_eq!(0x102030405060708090A0B0C0D0E0F00D_u128, u128::from(addr));
    /// ```
    #[inline]
    fn from(ip: Ipv6Addr) -> u128 {
        u128::from_be_bytes(ip.octets)
    }
}
#[stable(feature = "i128", since = "1.26.0")]
impl From<u128> for Ipv6Addr {
    /// Convert a host byte order `u128` into an `Ipv6Addr`. <br>将主机字节顺序 `u128` 转换为 `Ipv6Addr`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// let addr = Ipv6Addr::from(0x102030405060708090A0B0C0D0E0F00D_u128);
    /// assert_eq!(
    ///     Ipv6Addr::new(
    ///         0x1020, 0x3040, 0x5060, 0x7080,
    ///         0x90A0, 0xB0C0, 0xD0E0, 0xF00D,
    ///     ),
    ///     addr);
    /// ```
    #[inline]
    fn from(ip: u128) -> Ipv6Addr {
        Ipv6Addr::from(ip.to_be_bytes())
    }
}

#[stable(feature = "ipv6_from_octets", since = "1.9.0")]
impl From<[u8; 16]> for Ipv6Addr {
    /// Creates an `Ipv6Addr` from a sixteen element byte array. <br>从 16 个元素的字节数组创建 `Ipv6Addr`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// let addr = Ipv6Addr::from([
    ///     25u8, 24u8, 23u8, 22u8, 21u8, 20u8, 19u8, 18u8,
    ///     17u8, 16u8, 15u8, 14u8, 13u8, 12u8, 11u8, 10u8,
    /// ]);
    /// assert_eq!(
    ///     Ipv6Addr::new(
    ///         0x1918, 0x1716,
    ///         0x1514, 0x1312,
    ///         0x1110, 0x0f0e,
    ///         0x0d0c, 0x0b0a
    ///     ),
    ///     addr
    /// );
    /// ```
    #[inline]
    fn from(octets: [u8; 16]) -> Ipv6Addr {
        Ipv6Addr { octets }
    }
}

#[stable(feature = "ipv6_from_segments", since = "1.16.0")]
impl From<[u16; 8]> for Ipv6Addr {
    /// Creates an `Ipv6Addr` from an eight element 16-bit array. <br>从 8 个元素的 16 位数组创建 `Ipv6Addr`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::Ipv6Addr;
    ///
    /// let addr = Ipv6Addr::from([
    ///     525u16, 524u16, 523u16, 522u16,
    ///     521u16, 520u16, 519u16, 518u16,
    /// ]);
    /// assert_eq!(
    ///     Ipv6Addr::new(
    ///         0x20d, 0x20c,
    ///         0x20b, 0x20a,
    ///         0x209, 0x208,
    ///         0x207, 0x206
    ///     ),
    ///     addr
    /// );
    /// ```
    #[inline]
    fn from(segments: [u16; 8]) -> Ipv6Addr {
        let [a, b, c, d, e, f, g, h] = segments;
        Ipv6Addr::new(a, b, c, d, e, f, g, h)
    }
}

#[stable(feature = "ip_from_slice", since = "1.17.0")]
impl From<[u8; 16]> for IpAddr {
    /// Creates an `IpAddr::V6` from a sixteen element byte array. <br>从 16 个元素的字节数组创建 `IpAddr::V6`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{IpAddr, Ipv6Addr};
    ///
    /// let addr = IpAddr::from([
    ///     25u8, 24u8, 23u8, 22u8, 21u8, 20u8, 19u8, 18u8,
    ///     17u8, 16u8, 15u8, 14u8, 13u8, 12u8, 11u8, 10u8,
    /// ]);
    /// assert_eq!(
    ///     IpAddr::V6(Ipv6Addr::new(
    ///         0x1918, 0x1716,
    ///         0x1514, 0x1312,
    ///         0x1110, 0x0f0e,
    ///         0x0d0c, 0x0b0a
    ///     )),
    ///     addr
    /// );
    /// ```
    #[inline]
    fn from(octets: [u8; 16]) -> IpAddr {
        IpAddr::V6(Ipv6Addr::from(octets))
    }
}

#[stable(feature = "ip_from_slice", since = "1.17.0")]
impl From<[u16; 8]> for IpAddr {
    /// Creates an `IpAddr::V6` from an eight element 16-bit array. <br>从 8 个元素的 16 位数组创建 `IpAddr::V6`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::net::{IpAddr, Ipv6Addr};
    ///
    /// let addr = IpAddr::from([
    ///     525u16, 524u16, 523u16, 522u16,
    ///     521u16, 520u16, 519u16, 518u16,
    /// ]);
    /// assert_eq!(
    ///     IpAddr::V6(Ipv6Addr::new(
    ///         0x20d, 0x20c,
    ///         0x20b, 0x20a,
    ///         0x209, 0x208,
    ///         0x207, 0x206
    ///     )),
    ///     addr
    /// );
    /// ```
    #[inline]
    fn from(segments: [u16; 8]) -> IpAddr {
        IpAddr::V6(Ipv6Addr::from(segments))
    }
}
