//! Networking primitives for IP communication. <br>IP 通信的网络原语。<br>
//!
//! This module provides types for IP and socket addresses. <br>此模块提供 IP 和套接字地址的类型。<br>
//!
//! # Organization
//!
//! * [`IpAddr`] represents IP addresses of either IPv4 or IPv6; <br>[`IpAddr`] 代表 IPv4 或 IPv6 的 IP 地址；<br> [`Ipv4Addr`] and [`Ipv6Addr`] are respectively IPv4 and IPv6 addresses <br>[`Ipv4Addr`] 和 [`Ipv6Addr`] 分别是 IPv4 和 IPv6 地址<br>
//! * [`SocketAddr`] represents socket addresses of either IPv4 or IPv6; <br>[`SocketAddr`] 代表 IPv4 或 IPv6 的套接字地址；<br> [`SocketAddrV4`] and [`SocketAddrV6`] are respectively IPv4 and IPv6 socket addresses <br>[`SocketAddrV4`] 和 [`SocketAddrV6`] 分别是 IPv4 和 IPv6 套接字地址<br>
//!
//!

#![unstable(feature = "ip_in_core", issue = "108443")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::ip_addr::{IpAddr, Ipv4Addr, Ipv6Addr, Ipv6MulticastScope};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::parser::AddrParseError;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::socket_addr::{SocketAddr, SocketAddrV4, SocketAddrV6};

mod display_buffer;
mod ip_addr;
mod parser;
mod socket_addr;
