use crate::fmt;
use crate::ops::{Generator, GeneratorState};
use crate::pin::Pin;

/// Creates a new iterator where each iteration calls the provided generator. <br>创建一个新的迭代器，每次迭代都调用提供的生成器。<br>
///
/// Similar to [`iter::from_fn`]. <br>类似于 [`iter::from_fn`]。<br>
///
/// [`iter::from_fn`]: crate::iter::from_fn
///
/// # Examples
///
/// ```
/// #![feature(generators)]
/// #![feature(iter_from_generator)]
///
/// let it = std::iter::from_generator(|| {
///     yield 1;
///     yield 2;
///     yield 3;
/// });
/// let v: Vec<_> = it.collect();
/// assert_eq!(v, [1, 2, 3]);
/// ```
#[inline]
#[unstable(feature = "iter_from_generator", issue = "43122", reason = "generators are unstable")]
pub fn from_generator<G: Generator<Return = ()> + Unpin>(generator: G) -> FromGenerator<G> {
    FromGenerator(generator)
}

/// An iterator over the values yielded by an underlying generator. <br>对底层生成器产生的值的迭代器。<br>
///
/// This `struct` is created by the [`iter::from_generator()`] function. <br>这个 `struct` 是由 [`iter::from_generator()`] 函数创造的。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
///
/// [`iter::from_generator()`]: from_generator
#[unstable(feature = "iter_from_generator", issue = "43122", reason = "generators are unstable")]
#[derive(Clone)]
pub struct FromGenerator<G>(G);

#[unstable(feature = "iter_from_generator", issue = "43122", reason = "generators are unstable")]
impl<G: Generator<Return = ()> + Unpin> Iterator for FromGenerator<G> {
    type Item = G::Yield;

    fn next(&mut self) -> Option<Self::Item> {
        match Pin::new(&mut self.0).resume(()) {
            GeneratorState::Yielded(n) => Some(n),
            GeneratorState::Complete(()) => None,
        }
    }
}

#[unstable(feature = "iter_from_generator", issue = "43122", reason = "generators are unstable")]
impl<G> fmt::Debug for FromGenerator<G> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromGenerator").finish()
    }
}
