/// Conversion from an [`Iterator`]. <br>从 [`Iterator`] 转换。<br>
///
/// By implementing `FromIterator` for a type, you define how it will be created from an iterator. <br>通过为类型实现 `FromIterator`，可以定义如何从迭代器创建它。<br>
/// This is common for types which describe a collection of some kind. <br>这对于描述某种集合的类型很常见。<br>
///
/// If you want to create a collection from the contents of an iterator, the [`Iterator::collect()`] method is preferred. <br>如果想从迭代器的内容中创建一个集合，则首选 [`Iterator::collect()`] 方法。<br>
/// However, when you need to specify the container type, [`FromIterator::from_iter()`] can be more readable than using a turbofish (e.g. <br>但是，当您需要指定容器类型时，[`FromIterator::from_iter()`] 比使用 turbofish 更具可读性 (例如<br>
///
/// `::<Vec<_>>()`).
/// See the [`Iterator::collect()`] documentation for more examples of its use. <br>有关其使用的更多示例，请参见 [`Iterator::collect()`] 文档。<br>
///
/// See also: [`IntoIterator`]. <br>另请参见：[`IntoIterator`]。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Using [`Iterator::collect()`] to implicitly use `FromIterator`: <br>使用 [`Iterator::collect()`] 隐式使用 `FromIterator`：<br>
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Using [`FromIterator::from_iter()`] as a more readable alternative to <br>使用 [`FromIterator::from_iter()`] 作为更易读的替代方案<br>
/// [`Iterator::collect()`]:
///
/// ```
/// use std::collections::VecDeque;
/// let first = (0..10).collect::<VecDeque<i32>>();
/// let second = VecDeque::from_iter(0..10);
///
/// assert_eq!(first, second);
/// ```
///
/// Implementing `FromIterator` for your type: <br>为您的类型实现 `FromIterator`：<br>
///
/// ```
/// // A sample collection, that's just a wrapper over Vec<T> <br>一个样本集合，这只是 Vec<T> 的包装<br>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Let's give it some methods so we can create one and add things to it. <br>让我们给它一些方法，以便我们可以创建一个方法并向其中添加一些东西。<br>
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // and we'll implement FromIterator <br>我们将实现 FromIterator<br>
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Now we can make a new iterator <br>现在我们可以创建一个新的迭代器<br>...
/// let iter = (0..5).into_iter();
///
/// // ... and make a MyCollection out of it <br>并用它制作一个 MyCollection<br>
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // collect works too! <br>也收集作品！<br>
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[{A}]",
        message = "a slice of type `{Self}` cannot be built since `{Self}` has no definite size",
        label = "try explicitly collecting into a `Vec<{A}>`",
    ),
    on(
        all(A = "{integer}", any(_Self = "[{integral}]",)),
        message = "a slice of type `{Self}` cannot be built since `{Self}` has no definite size",
        label = "try explicitly collecting into a `Vec<{A}>`",
    ),
    on(
        _Self = "[{A}; _]",
        message = "an array of type `{Self}` cannot be built directly from an iterator",
        label = "try collecting into a `Vec<{A}>`, then using `.try_into()`",
    ),
    on(
        all(A = "{integer}", any(_Self = "[{integral}; _]",)),
        message = "an array of type `{Self}` cannot be built directly from an iterator",
        label = "try collecting into a `Vec<{A}>`, then using `.try_into()`",
    ),
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
#[rustc_diagnostic_item = "FromIterator"]
pub trait FromIterator<A>: Sized {
    /// Creates a value from an iterator. <br>从迭代器创建一个值。<br>
    ///
    /// See the [module-level documentation] for more. <br>有关更多信息，请参见 [模块级文档][module-level documentation]。<br>
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Conversion into an [`Iterator`]. <br>转换为 [`Iterator`]。<br>
///
/// By implementing `IntoIterator` for a type, you define how it will be converted to an iterator. <br>通过为类型实现 `IntoIterator`，可以定义如何将其转换为迭代器。<br>
/// This is common for types which describe a collection of some kind. <br>这对于描述某种集合的类型很常见。<br>
///
/// One benefit of implementing `IntoIterator` is that your type will [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator). <br>实现 `IntoIterator` 的好处之一是您的类型将为 [使用 Rust 的 `for` 循环语法](crate::iter#for-loops-and-intoiterator)。<br>
///
///
/// See also: [`FromIterator`]. <br>另请参见：[`FromIterator`]。<br>
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// let v = [1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementing `IntoIterator` for your type: <br>为您的类型实现 `IntoIterator`：<br>
///
/// ```
/// // A sample collection, that's just a wrapper over Vec<T> <br>一个样本集合，这只是 Vec<T> 的包装<br>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Let's give it some methods so we can create one and add things to it. <br>让我们给它一些方法，以便我们可以创建一个方法并向其中添加一些东西。<br>
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // and we'll implement IntoIterator <br>我们将实现 IntoIterator<br>
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Now we can make a new collection <br>现在我们可以做一个新的集合<br>...
/// let mut c = MyCollection::new();
///
/// // ... add some stuff to it ... <br>添加一些东西...<br>
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... and then turn it into an Iterator: <br>然后将其转换为迭代器：<br>
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// It is common to use `IntoIterator` as a trait bound. <br>通常将 `IntoIterator` 用作 trait bound。<br> This allows the input collection type to change, so long as it is still an iterator. <br>只要它仍然是迭代器，就可以更改输入集合类型。<br>
/// Additional bounds can be specified by restricting on <br>可以通过限制限制来指定其他范围<br>
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{item:?}"))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[rustc_skip_array_during_method_dispatch]
#[stable(feature = "rust1", since = "1.0.0")]
#[const_trait]
pub trait IntoIterator {
    /// The type of the elements being iterated over. <br>被迭代的元素的类型。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Which kind of iterator are we turning this into? <br>我们将其变成哪种迭代器？<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Creates an iterator from a value. <br>从一个值创建一个迭代器。<br>
    ///
    /// See the [module-level documentation] for more. <br>有关更多信息，请参见 [模块级文档][module-level documentation]。<br>
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// let v = [1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[rustc_const_unstable(feature = "const_intoiterator_identity", issue = "90603")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> const IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    #[inline]
    fn into_iter(self) -> I {
        self
    }
}

/// Extend a collection with the contents of an iterator. <br>用迭代器的内容扩展集合。<br>
///
/// Iterators produce a series of values, and collections can also be thought of as a series of values. <br>迭代器产生一系列值，并且集合也可以视为一系列值。<br>
/// The `Extend` trait bridges this gap, allowing you to extend a collection by including the contents of that iterator. <br>`Extend` trait 弥补了这一差距，使您可以通过包含该迭代器的内容来扩展集合。<br>
/// When extending a collection with an already existing key, that entry is updated or, in the case of collections that permit multiple entries with equal keys, that entry is inserted. <br>当使用已经存在的键扩展集合时，该条目将被更新; 如果集合允许多个具有相同键的条目，则将插入该条目。<br>
///
///
/// # Examples
///
/// Basic usage: <br>基本用法：<br>
///
/// ```
/// // You can extend a String with some chars: <br>您可以使用一些字符扩展 String：<br>
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementing `Extend`: <br>实现 `Extend`：<br>
///
/// ```
/// // A sample collection, that's just a wrapper over Vec<T> <br>一个样本集合，这只是 Vec<T> 的包装<br>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Let's give it some methods so we can create one and add things to it. <br>让我们给它一些方法，以便我们可以创建一个方法并向其中添加一些东西。<br>
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // since MyCollection has a list of i32s, we implement Extend for i32 <br>由于 MyCollection 包含 i32 的列表，因此我们为 i32 实现 Extend<br>
/// impl Extend<i32> for MyCollection {
///
///     // This is a bit simpler with the concrete type signature: we can call extend on anything which can be turned into an Iterator which gives us i32s. <br>使用具体的类型签名，这要简单一些：我们可以调用扩展为可转换为 It32 的 Iterator 的任何内容。<br>
///     // Because we need i32s to put into MyCollection. <br>因为我们需要将 i32 放入 MyCollection 中。<br>
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // The implementation is very straightforward: loop through the iterator, and add() each element to ourselves. <br>实现非常简单：遍历迭代器，然后将每个元素 add() 传递给我们自己。<br>
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // let's extend our collection with three more numbers <br>让我们用三个数字扩展集合<br>
/// c.extend(vec![1, 2, 3]);
///
/// // we've added these elements onto the end <br>我们已经将这些元素添加到最后<br>
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{c:?}"));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Extends a collection with the contents of an iterator. <br>使用迭代器的内容扩展集合。<br>
    ///
    /// As this is the only required method for this trait, the [trait-level] docs contain more details. <br>由于这是此 trait 唯一需要的方法，因此 [trait-level] 文档包含更多详细信息。<br>
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Basic usage: <br>基本用法：<br>
    ///
    /// ```
    /// // You can extend a String with some chars: <br>您可以使用一些字符扩展 String：<br>
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Extends a collection with exactly one element. <br>用一个元素扩展一个集合。<br>
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reserves capacity in a collection for the given number of additional elements. <br>在集合中为给定数量的附加元素保留容量。<br>
    ///
    /// The default implementation does nothing. <br>默认实现不执行任何操作。<br>
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}

#[stable(feature = "extend_for_tuple", since = "1.56.0")]
impl<A, B, ExtendA, ExtendB> Extend<(A, B)> for (ExtendA, ExtendB)
where
    ExtendA: Extend<A>,
    ExtendB: Extend<B>,
{
    /// Allows to `extend` a tuple of collections that also implement `Extend`. <br>允许 `extend` 一个集合的元组也实现 `Extend`。<br>
    ///
    /// See also: [`Iterator::unzip`] <br>另请参见：[`Iterator::unzip`]<br>
    ///
    /// # Examples
    /// ```
    /// let mut tuple = (vec![0], vec![1]);
    /// tuple.extend([(2, 3), (4, 5), (6, 7)]);
    /// assert_eq!(tuple.0, [0, 2, 4, 6]);
    /// assert_eq!(tuple.1, [1, 3, 5, 7]);
    ///
    /// // also allows for arbitrarily nested tuples as elements <br>还允许任意嵌套的元组作为元素<br>
    /// let mut nested_tuple = (vec![1], (vec![2], vec![3]));
    /// nested_tuple.extend([(4, (5, 6)), (7, (8, 9))]);
    ///
    /// let (a, (b, c)) = nested_tuple;
    /// assert_eq!(a, [1, 4, 7]);
    /// assert_eq!(b, [2, 5, 8]);
    /// assert_eq!(c, [3, 6, 9]);
    /// ```
    fn extend<T: IntoIterator<Item = (A, B)>>(&mut self, into_iter: T) {
        let (a, b) = self;
        let iter = into_iter.into_iter();

        fn extend<'a, A, B>(
            a: &'a mut impl Extend<A>,
            b: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                a.extend_one(t);
                b.extend_one(u);
            }
        }

        let (lower_bound, _) = iter.size_hint();
        if lower_bound > 0 {
            a.extend_reserve(lower_bound);
            b.extend_reserve(lower_bound);
        }

        iter.fold((), extend(a, b));
    }

    fn extend_one(&mut self, item: (A, B)) {
        self.0.extend_one(item.0);
        self.1.extend_one(item.1);
    }

    fn extend_reserve(&mut self, additional: usize) {
        self.0.extend_reserve(additional);
        self.1.extend_reserve(additional);
    }
}
