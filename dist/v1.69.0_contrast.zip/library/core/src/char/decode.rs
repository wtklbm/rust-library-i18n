//! UTF-8 and UTF-16 decoding iterators <br>UTF-8 和 UTF-16 解码迭代器<br>

use crate::error::Error;
use crate::fmt;

/// An iterator that decodes UTF-16 encoded code points from an iterator of `u16`s. <br>一个迭代器，用于解码来自 u16 迭代器的 UTF-16 编码的代码点。<br>
///
/// This `struct` is created by the [`decode_utf16`] method on [`char`]. <br>这个 `struct` 是通过 [`char`] 上的 [`decode_utf16`] 方法创建的。<br>
/// See its documentation for more. <br>有关更多信息，请参见其文档。<br>
///
/// [`decode_utf16`]: char::decode_utf16
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Clone, Debug)]
pub struct DecodeUtf16<I>
where
    I: Iterator<Item = u16>,
{
    iter: I,
    buf: Option<u16>,
}

/// An error that can be returned when decoding UTF-16 code points. <br>解码 UTF-16 代码点时可以返回的错误。<br>
///
/// This `struct` is created when using the [`DecodeUtf16`] type. <br>该 `struct` 是在使用 [`DecodeUtf16`] 类型时创建的。<br>
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct DecodeUtf16Error {
    code: u16,
}

/// Creates an iterator over the UTF-16 encoded code points in `iter`, returning unpaired surrogates as `Err`s. <br>在 `iter` 中的 UTF-16 编码的代码点上创建一个迭代器，将不成对的代理返回为 `Err`s。<br>
/// See [`char::decode_utf16`]. <br>请参见 [`char::decode_utf16`]。<br>
#[inline]
pub(super) fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
    DecodeUtf16 { iter: iter.into_iter(), buf: None }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl<I: Iterator<Item = u16>> Iterator for DecodeUtf16<I> {
    type Item = Result<char, DecodeUtf16Error>;

    fn next(&mut self) -> Option<Result<char, DecodeUtf16Error>> {
        let u = match self.buf.take() {
            Some(buf) => buf,
            None => self.iter.next()?,
        };

        if !u.is_utf16_surrogate() {
            // SAFETY: not a surrogate <br>不是代理<br>
            Some(Ok(unsafe { char::from_u32_unchecked(u as u32) }))
        } else if u >= 0xDC00 {
            // a trailing surrogate <br>尾随代理<br>
            Some(Err(DecodeUtf16Error { code: u }))
        } else {
            let u2 = match self.iter.next() {
                Some(u2) => u2,
                // eof
                None => return Some(Err(DecodeUtf16Error { code: u })),
            };
            if u2 < 0xDC00 || u2 > 0xDFFF {
                // not a trailing surrogate so we're not a valid surrogate pair, so rewind to redecode u2 next time. <br>不是尾随的代理，因此我们不是有效的代理对，因此请回绕以在下一次重新编码 u2。<br>
                //
                self.buf = Some(u2);
                return Some(Err(DecodeUtf16Error { code: u }));
            }

            // all ok, so lets decode it. <br>一切正常，让我们对其进行解码。<br>
            let c = (((u & 0x3ff) as u32) << 10 | (u2 & 0x3ff) as u32) + 0x1_0000;
            // SAFETY: we checked that it's a legal unicode value <br>我们检查了这是合法的 unicode 值<br>
            Some(Ok(unsafe { char::from_u32_unchecked(c) }))
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let (low, high) = self.iter.size_hint();

        let (low_buf, high_buf) = match self.buf {
            // buf is empty, no additional elements from it. <br>buf 为空，其中没有其他元素。<br>
            None => (0, 0),
            // `u` is a non surrogate, so it's always an additional character. <br>`u` 是一个非代理，所以它总是一个附加字符。<br>
            Some(u) if !u.is_utf16_surrogate() => (1, 1),
            // `u` is a leading surrogate (it can never be a trailing surrogate and it's a surrogate due to the previous branch) and `self.iter` is empty. <br>`u` 是一个前导代理 (它永远不能是一个尾随代理，并且由于前一个分支它是一个代理) 并且 `self.iter` 是空的。<br>
            //
            //
            // `u` can't be paired, since the `self.iter` is empty, so it will always become an additional element (error). <br>`u` 不能配对，因为 `self.iter` 是空的，所以它总是会成为一个附加元素 (error)。<br>
            //
            Some(_u) if high == Some(0) => (1, 1),
            // `u` is a leading surrogate and `iter` may be non-empty. <br>`u` 是一个前导代理，`iter` 可能是非空的。<br>
            //
            // `u` can either pair with a trailing surrogate, in which case no additional elements are produced, or it can become an error, in which case it's an additional character (error). <br>`u` 可以与尾随代理配对，在这种情况下不会产生额外的元素，或者它可能成为错误，在这种情况下它是一个额外的字符 (error)。<br>
            //
            Some(_u) => (0, 1),
        };

        // `self.iter` could contain entirely valid surrogates (2 elements per char), or entirely non-surrogates (1 element per char). <br>`self.iter` 可以包含完全有效的代理 (每个字符 2 个元素)，或完全非代理 (每个字符 1 个元素)。<br>
        //
        //
        // On odd lower bound, at least one element must stay unpaired (with other elements from `self.iter`), so we round up. <br>在奇数下界，至少一个元素必须保持不成对 (与 `self.iter` 中的其他元素)，所以我们四舍五入。<br>
        //
        let low = low.div_ceil(2) + low_buf;
        let high = high.and_then(|h| h.checked_add(high_buf));

        (low, high)
    }
}

impl DecodeUtf16Error {
    /// Returns the unpaired surrogate which caused this error. <br>返回导致此错误的未配对代理。<br>
    #[must_use]
    #[stable(feature = "decode_utf16", since = "1.9.0")]
    pub fn unpaired_surrogate(&self) -> u16 {
        self.code
    }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl fmt::Display for DecodeUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "unpaired surrogate found: {:x}", self.code)
    }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl Error for DecodeUtf16Error {
    #[allow(deprecated)]
    fn description(&self) -> &str {
        "unpaired surrogate found"
    }
}
