//! Utilities for comparing and ordering values. <br>用于比较和排序值的实用工具。<br>
//!
//! This module contains various tools for comparing and ordering values. <br>该模块包含用于比较和排序值的各种工具。<br> In summary: <br>在总结中：<br>
//!
//! * [`Eq`] and [`PartialEq`] are traits that allow you to define total and partial equality between values, respectively. <br>[`Eq`] 和 [`PartialEq`] 是 traits，允许您分别定义值之间的完全相等和部分相等。<br>
//! Implementing them overloads the `==` and `!=` operators. <br>实现它们会使 `==` 和 `!=` 运算符重载。<br>
//! * [`Ord`] and [`PartialOrd`] are traits that allow you to define total and partial orderings between values, respectively. <br>[`Ord`] 和 [`PartialOrd`] 是 traits，允许您分别定义值之间的全部排序和部分排序。<br>
//!
//! Implementing them overloads the `<`, `<=`, `>`, and `>=` operators. <br>实现它们会使 `<`，`<=`，`>` 和 `>=` 运算符重载。<br>
//! * [`Ordering`] is an enum returned by the main functions of [`Ord`] and [`PartialOrd`], and describes an ordering. <br>[`Ordering`] 是 [`Ord`] 和 [`PartialOrd`] 的 `main` 函数返回的枚举，描述了一种排序。<br>
//! * [`Reverse`] is a struct that allows you to easily reverse an ordering. <br>[`Reverse`] 是一种结构体，可让您轻松地颠倒顺序。<br>
//! * [`max`] and [`min`] are functions that build off of [`Ord`] and allow you to find the maximum or minimum of two values. <br>[`max`] 和 [`min`] 是建立在 [`Ord`] 基础上的函数，允许您找到两个值的最大值或最小值。<br>
//!
//! For more details, see the respective documentation of each item in the list. <br>有关更多详细信息，请参见列表中每个项的相应文档。<br>
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod bytewise;
pub(crate) use bytewise::BytewiseEq;

use crate::marker::Destruct;

use self::Ordering::*;

/// Trait for equality comparisons. <br>Trait 等值比较。<br>
///
/// `x.eq(y)` can also be written `x == y`, and `x.ne(y)` can be written `x != y`. <br>`x.eq(y)` 也可以写成 `x == y`，`x.ne(y)`，也可以写成 `x != y`。<br>
/// We use the easier-to-read infix notation in the remainder of this documentation. <br>在本文档的其余部分中，我们使用了更易于阅读的中缀符号。<br>
///
/// This trait allows for partial equality, for types that do not have a full equivalence relation. <br>对于没有完全等价关系的类型，这个 trait 允许部分相等。<br>
/// For example, in floating point numbers `NaN != NaN`, so floating point types implement `PartialEq` but not [`trait@Eq`]. <br>例如，在浮点数 `NaN != NaN` 中，因此浮点类型实现 `PartialEq`，但不实现 [`trait@Eq`]。<br>
/// Formally speaking, when `Rhs == Self`, this trait corresponds to a [partial equivalence relation](https://en.wikipedia.org/wiki/Partial_equivalence_relation). <br>形式上来说，当 `Rhs == Self` 时，这个 trait 对应一个 [partial equivalence relation](https://en.wikipedia.org/wiki/Partial_equivalence_relation)。<br>
///
/// Implementations must ensure that `eq` and `ne` are consistent with each other: <br>实现必须确保 `eq` 和 `ne` 彼此一致：<br>
///
/// - `a != b` if and only if `!(a == b)`. <br>`a != b` 当且仅当 `!(a == b)`。<br>
///
/// The default implementation of `ne` provides this consistency and is almost always sufficient. <br>`ne` 的默认实现提供了这种一致性，并且几乎总是足够的。<br> It should not be overridden without very good reason. <br>没有很好的理由不应该覆盖它。<br>
///
/// If [`PartialOrd`] or [`Ord`] are also implemented for `Self` and `Rhs`, their methods must also be consistent with `PartialEq` (see the documentation of those traits for the exact requirements). <br>如果 `Self` 和 `Rhs` 也实现了 [`PartialOrd`] 或 [`Ord`]，则它们的方法也必须与 `PartialEq` 一致 (具体要求请参见那些 traits 的文档)。<br>
/// It's easy to accidentally make them disagree by deriving some of the traits and manually implementing others. <br>通过派生一些 traits 并手动实现其他一些行为，很容易使它们不以为然。<br>
///
/// The equality relation `==` must satisfy the following conditions (for all `a`, `b`, `c` of type `A`, `B`, `C`): <br>等式关系 `==` 必须满足以下条件 (对于所有类型为 `A`、`B`、`C` 的 `a`、`b`、`c`) ：<br>
///
/// - **Symmetric**: if `A: PartialEq<B>` and `B: PartialEq<A>`, then **`a == b` implies `b == a`**; and <br>**对称**: 如果 `A: PartialEq<B>` 和 `B: PartialEq<A>`，则 **`a == b` 意味着 'b == a`**; 和<br>
///
/// - **Transitive**: if `A: PartialEq<B>` and `B: PartialEq<C>` and `A: <br>**可传递**: 如果 `A: PartialEq<B>` 和 `B: PartialEq<C>` 以及 `A：<br>
///   PartialEq<C>`, then **`a == b` and `b == c` implies `a == c`**. <br>PartialEq<C>`，然后 **`a == b`，并且 `b == c` 暗示了 `a == c`**。<br>
///
/// Note that the `B: PartialEq<A>` (symmetric) and `A: PartialEq<C>` (transitive) impls are not forced to exist, but these requirements apply whenever they do exist. <br>请注意，`B: PartialEq<A>` (symmetric) 和 `A: PartialEq<C>` (transitive) 强制不是强制存在的，但是这些要求只要存在就适用。<br>
///
/// ## Derivable
///
/// This trait can be used with `#[derive]`. <br>该 trait 可以与 `#[derive]` 一起使用。<br> When `derive`d on structs, two instances are equal if all fields are equal, and not equal if any fields are not equal. <br>在结构体上 `derive` d 时，如果所有字段都相等，则两个实例相等; 如果任何字段不相等，则两个实例不相等。<br> When `derive`d on enums, two instances are equal if they are the same variant and all fields are equal. <br>当在枚举上 `派生` 时，如果两个实例是相同的变体并且所有字段都相等，则它们是相等的。<br>
///
/// ## How can I implement `PartialEq`? <br>如何实现 `PartialEq`？<br>
///
/// An example implementation for a domain in which two books are considered the same book if their ISBN matches, even if the formats differ: <br>一个域的示例实现，在该域中，即使两本书的 ISBN 匹配，即使格式不同，也将其视为同一本书：<br>
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## How can I compare two different types? <br>如何比较两种不同的类型？<br>
///
/// The type you can compare with is controlled by `PartialEq`'s type parameter. <br>您可以比较的类型由 `PartialEq` 的类型参数控制。<br>
/// For example, let's tweak our previous code a bit: <br>例如，让我们对之前的代码进行一些调整：<br>
///
/// ```
/// // The derive implements <BookFormat> == <BookFormat> comparisons <br>衍生工具 <BookFormat> == <BookFormat> 比较<br>
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Implement <Book> == <BookFormat> comparisons <br>实现 <Book> == <BookFormat> 比较<br>
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Implement <BookFormat> == <Book> comparisons <br>实现 <BookFormat> == <Book> 比较<br>
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// By changing `impl PartialEq for Book` to `impl PartialEq<BookFormat> for Book`, we allow `BookFormat`s to be compared with `Book`s. <br>通过将 `impl PartialEq for Book` 更改为 `impl PartialEq<BookFormat> for Book`，我们可以将 BookFormat 和 Book 进行比较。<br>
///
/// A comparison like the one above, which ignores some fields of the struct, can be dangerous. <br>像上面这样的比较 (它忽略了结构体的某些字段) 可能很危险。<br> It can easily lead to an unintended violation of the requirements for a partial equivalence relation. <br>这很容易导致意外违反部分对等关系的要求。<br>
/// For example, if we kept the above implementation of `PartialEq<Book>` for `BookFormat` and added an implementation of `PartialEq<Book>` for `Book` (either via a `#[derive]` or via the manual implementation from the first example) then the result would violate transitivity: <br>例如，如果我们保留了以上针对 `BookFormat` 的 `PartialEq<Book>` 的实现，并为 `Book` 添加了 `PartialEq<Book>` 的实现 (通过 `#[derive]` 或第一个示例中的手动实现)，则结果将违反传递性：<br>
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't. <br>以下应该通过传递性来保持，但不是。<br>
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`",
    append_const_msg
)]
#[const_trait]
#[rustc_diagnostic_item = "PartialEq"]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// This method tests for `self` and `other` values to be equal, and is used by `==`. <br>此方法测试 `self` 和 `other` 值是否相等，并由 `==` 使用。<br>
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// This method tests for `!=`. <br>此方法测试 `!=`。<br>
    /// The default implementation is almost always sufficient, and should not be overridden without very good reason. <br>默认实现几乎总是足够的，并且不应在没有充分理由的情况下被覆盖。<br>
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Derive macro generating an impl of the trait `PartialEq`. <br>派生宏，生成 `PartialEq` trait 的 impl。<br>
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait for equality comparisons which are [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation). <br>[等价关系](https://en.wikipedia.org/wiki/Equivalence_relation) 等式比较的 Trait。<br>
///
/// This means, that in addition to `a == b` and `a != b` being strict inverses, the equality must be (for all `a`, `b` and `c`): <br>这意味着，除了 `a == b` 和 `a != b` 是严格的逆之外，相等必须是 (对于所有 `a`，`b` 和 `c`) ：<br>
///
/// - reflexive: `a == a`; <br>反射: `a == a`；<br>
/// - symmetric: `a == b` implies `b == a`; <br>对称: `a == b` 表示 `b == a`；<br> and
/// - transitive: `a == b` and `b == c` implies `a == c`. <br>可传递的: `a == b` 和 `b == c` 表示 `a == c`。<br>
///
/// This property cannot be checked by the compiler, and therefore `Eq` implies [`PartialEq`], and has no extra methods. <br>编译器无法检查此属性，因此 `Eq` 表示 [`PartialEq`]，并且没有其他方法。<br>
///
/// ## Derivable
///
/// This trait can be used with `#[derive]`. <br>该 trait 可以与 `#[derive]` 一起使用。<br>
/// When `derive`d, because `Eq` has no extra methods, it is only informing the compiler that this is an equivalence relation rather than a partial equivalence relation. <br>当 `derived' 时，由于 `Eq` 没有额外的方法，它只是通知编译器这是一个等价关系，而不是部分等价关系。<br>
///
/// Note that the `derive` strategy requires all fields are `Eq`, which isn't always desired. <br>请注意，`derive` 策略要求所有字段均为 `Eq`，这并不总是需要的。<br>
///
/// ## How can I implement `Eq`? <br>如何实现 `Eq`？<br>
///
/// If you cannot use the `derive` strategy, specify that your type implements `Eq`, which has no methods: <br>如果您不能使用 `derive` 策略，请指定您的类型实现 `Eq`，它没有方法：<br>
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Eq"]
pub trait Eq: PartialEq<Self> {
    // this method is used solely by #[deriving] to assert that every component of a type implements #[deriving] itself, the current deriving infrastructure means doing this assertion without using a method on this trait is nearly impossible. <br>#[deriving] 只能单独使用此方法来断言类型的每个组件本身都实现 #[deriving]，当前派生基础结构意味着在此 trait 上不使用任何方法来进行断言几乎是不可能的。<br>
    //
    //
    // This should never be implemented by hand. <br>绝不能手工实现。<br>
    //
    //
    //
    #[doc(hidden)]
    #[no_coverage] // rust-lang/rust#84605
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Derive macro generating an impl of the trait `Eq`. <br>派生宏，生成 `Eq` trait 的 impl。<br>
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match, no_coverage)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: this struct is used solely by #[derive] to assert that every component of a type implements Eq. <br>#[derive] 单独使用此结构体来断言类型的每个组件都实现 Eq。<br>
//
//
// This struct should never appear in user code. <br>该结构体永远不会出现在用户代码中。<br>
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// An `Ordering` is the result of a comparison between two values. <br>`Ordering` 是两个值之间比较的结果。<br>
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, Eq, Debug, Hash)]
#[derive_const(PartialOrd, Ord, PartialEq)]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(i8)]
pub enum Ordering {
    /// An ordering where a compared value is less than another. <br>比较值小于另一个值的排序。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// An ordering where a compared value is equal to another. <br>比较值等于另一个的排序。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// An ordering where a compared value is greater than another. <br>比较值大于另一个值的排序。<br>
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Returns `true` if the ordering is the `Equal` variant. <br>如果排序的是 `Equal` 变体，则返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "ordering_helpers", since = "1.53.0")]
    #[stable(feature = "ordering_helpers", since = "1.53.0")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Returns `true` if the ordering is not the `Equal` variant. <br>如果排序的不是 `Equal` 变体，则返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "ordering_helpers", since = "1.53.0")]
    #[stable(feature = "ordering_helpers", since = "1.53.0")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Returns `true` if the ordering is the `Less` variant. <br>如果排序的是 `Less` 变体，则返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "ordering_helpers", since = "1.53.0")]
    #[stable(feature = "ordering_helpers", since = "1.53.0")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Returns `true` if the ordering is the `Greater` variant. <br>如果排序的是 `Greater` 变体，则返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "ordering_helpers", since = "1.53.0")]
    #[stable(feature = "ordering_helpers", since = "1.53.0")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Returns `true` if the ordering is either the `Less` or `Equal` variant. <br>如果排序的是 `Less` 或 `Equal` 变体，则返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "ordering_helpers", since = "1.53.0")]
    #[stable(feature = "ordering_helpers", since = "1.53.0")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Returns `true` if the ordering is either the `Greater` or `Equal` variant. <br>如果排序的是 `Greater` 或 `Equal` 变体，则返回 `true`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "ordering_helpers", since = "1.53.0")]
    #[stable(feature = "ordering_helpers", since = "1.53.0")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Reverses the `Ordering`. <br>反转 `Ordering`。<br>
    ///
    /// * `Less` becomes `Greater`. <br>`Less` 变成 `Greater`。<br>
    /// * `Greater` becomes `Less`. <br>`Greater` 变成 `Less`。<br>
    /// * `Equal` becomes `Equal`. <br>`Equal` 变成 `Equal`。<br>
    ///
    /// # Examples
    ///
    /// Basic behavior: <br>基本行为：<br>
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// This method can be used to reverse a comparison: <br>此方法可用于反转比较：<br>
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // sort the array from largest to smallest. <br>从最大到最小对数组进行排序。<br>
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Chains two orderings. <br>链接两个排序。<br>
    ///
    /// Returns `self` when it's not `Equal`. <br>如果不是 `Equal`，则返回 `self`。<br> Otherwise returns `other`. <br>否则返回 `other`。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Chains the ordering with the given function. <br>用给定的函数链接顺序。<br>
    ///
    /// Returns `self` when it's not `Equal`. <br>如果不是 `Equal`，则返回 `self`。<br>
    /// Otherwise calls `f` and returns the result. <br>否则，调用 `f` 并返回结果。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// A helper struct for reverse ordering. <br>用于逆序排序的辅助结构体。<br>
///
/// This struct is a helper to be used with functions like [`Vec::sort_by_key`] and can be used to reverse order a part of a key. <br>该结构是一个帮助器，可与 [`Vec::sort_by_key`] 等函数一起使用，并且可以用于对键的一部分进行反向排序。<br>
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
impl<T: ~const PartialOrd> const PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Clone> Clone for Reverse<T> {
    #[inline]
    fn clone(&self) -> Reverse<T> {
        Reverse(self.0.clone())
    }

    #[inline]
    fn clone_from(&mut self, other: &Self) {
        self.0.clone_from(&other.0)
    }
}

/// Trait for types that form a [total order](https://en.wikipedia.org/wiki/Total_order). <br>一个用于形成 [全序关系](https://en.wikipedia.org/wiki/Total_order) 的类型的 trait。<br>
///
/// Implementations must be consistent with the [`PartialOrd`] implementation, and ensure `max`, `min`, and `clamp` are consistent with `cmp`: <br>实现必须与 [`PartialOrd`] 实现一致，并确保 `max`、`min` 和 `clamp` 与 `cmp` 一致：<br>
///
/// - `partial_cmp(a, b) == Some(cmp(a, b))`.
/// - `max(a, b) == max_by(a, b, cmp)` (ensured by the default implementation). <br>`max(a, b) == max_by(a, b, cmp)` (由默认实现确保)。<br>
/// - `min(a, b) == min_by(a, b, cmp)` (ensured by the default implementation). <br>`min(a, b) == min_by(a, b, cmp)` (由默认实现确保)。<br>
/// - For `a.clamp(min, max)`, see the [method docs](#method.clamp) (ensured by the default implementation). <br>对于 `a.clamp(min, max)`，请参见 [方法文档](#method.clamp) (由默认实现确保)。<br>
///
/// It's easy to accidentally make `cmp` and `partial_cmp` disagree by deriving some of the traits and manually implementing others. <br>通过派生一些 traits 并手动实现其他的，很容易意外地使 `cmp` 和 `partial_cmp` 不一致。<br>
///
/// ## Corollaries
///
/// From the above and the requirements of `PartialOrd`, it follows that `<` defines a strict total order. <br>综上所述，根据 `PartialOrd` 的要求，`<` 定义了严格的总顺序。<br>
/// This means that for all `a`, `b` and `c`: <br>这意味着对于所有 `a`、`b` 和 `c`：<br>
///
/// - exactly one of `a < b`, `a == b` or `a > b` is true; <br>`a < b`、`a == b` 或 `a > b` 中恰好有一个为 true；<br> and
/// - `<` is transitive: `a < b` and `b < c` implies `a < c`. <br>`<` 是可传递的: `a < b` 和 `b < c` 意味着 `a < c`。<br> The same must hold for both `==` and `>`. <br>`==` 和 `>` 必须保持相同。<br>
///
/// ## Derivable
///
/// This trait can be used with `#[derive]`. <br>该 trait 可以与 `#[derive]` 一起使用。<br>
///
/// When `derive`d on structs, it will produce a [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ordering based on the top-to-bottom declaration order of the struct's members. <br>在结构体上 `derive` d 时，它将基于结构体成员的自上而下的声明顺序生成 [词典](https://en.wikipedia.org/wiki/Lexicographic_order) 顺序。<br>
///
///
/// When `derive`d on enums, variants are ordered by their discriminants. <br>当在枚举上 `derive`d 时，变体按其判别式排序。<br>
/// By default, the discriminant is smallest for variants at the top, and largest for variants at the bottom. <br>默认情况下，对于顶部的变体，判别式最小，底部变体的判别式最大。<br> Here's an example: <br>下面是一个例子：<br>
///
/// ```
/// #[derive(PartialEq, Eq, PartialOrd, Ord)]
/// enum E {
///     Top,
///     Bottom,
/// }
///
/// assert!(E::Top < E::Bottom);
/// ```
///
/// However, manually setting the discriminants can override this default behavior: <br>但是，手动设置判别式可以覆盖此默认行为:<br>
///
/// ```
/// #[derive(PartialEq, Eq, PartialOrd, Ord)]
/// enum E {
///     Top = 2,
///     Bottom = 1,
/// }
///
/// assert!(E::Bottom < E::Top);
/// ```
///
/// ## Lexicographical comparison <br>词典比较<br>
///
/// Lexicographical comparison is an operation with the following properties: <br>词典比较是一种具有以下属性的操作：<br>
///  - Two sequences are compared element by element. <br>逐个元素比较两个序列。<br>
///  - The first mismatching element defines which sequence is lexicographically less or greater than the other. <br>第一个不匹配元素定义了哪个序列在词典上小于或大于另一个序列。<br>
///  - If one sequence is a prefix of another, the shorter sequence is lexicographically less than the other. <br>如果一个序列是另一个序列的前缀，则从字典上看，较短的序列比另一个序列小。<br>
///  - If two sequence have equivalent elements and are of the same length, then the sequences are lexicographically equal. <br>如果两个序列具有相等的元素并且长度相同，则序列在字典上是相等的。<br>
///  - An empty sequence is lexicographically less than any non-empty sequence. <br>在字典上，空序列比任何非空序列都少。<br>
///  - Two empty sequences are lexicographically equal. <br>两个空序列在字典上是相等的。<br>
///
/// ## How can I implement `Ord`? <br>如何实现 `Ord`？<br>
///
/// `Ord` requires that the type also be [`PartialOrd`] and [`Eq`] (which requires [`PartialEq`]). <br>`Ord` 要求类型也是 [`PartialOrd`] 和 [`Eq`] (需要 [`PartialEq`])。<br>
///
/// Then you must define an implementation for [`cmp`]. <br>然后，您必须定义 [`cmp`] 的实现。<br> You may find it useful to use [`cmp`] on your type's fields. <br>您可能会发现在类型的字段上使用 [`cmp`] 很有用。<br>
///
/// Here's an example where you want to sort people by height only, disregarding `id` and `name`: <br>这是一个示例，您只想按高度对人员进行排序，而不考虑 `id` 和 `name`：<br>
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
///
///
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Ord"]
#[const_trait]
pub trait Ord: Eq + PartialOrd<Self> {
    /// This method returns an [`Ordering`] between `self` and `other`. <br>此方法返回 `self` 和 `other` 之间的 [`Ordering`]。<br>
    ///
    /// By convention, `self.cmp(&other)` returns the ordering matching the expression `self <operator> other` if true. <br>按照惯例，如果为 true，则 `self.cmp(&other)` 返回与表达式 `self <operator> other` 匹配的顺序。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Compares and returns the maximum of two values. <br>比较并返回两个值中的最大值。<br>
    ///
    /// Returns the second argument if the comparison determines them to be equal. <br>如果比较确定它们相等，则返回第二个参数。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
        Self: ~const Destruct,
    {
        match self.cmp(&other) {
            Ordering::Less | Ordering::Equal => other,
            Ordering::Greater => self,
        }
    }

    /// Compares and returns the minimum of two values. <br>比较并返回两个值中的最小值。<br>
    ///
    /// Returns the first argument if the comparison determines them to be equal. <br>如果比较确定它们相等，则返回第一个参数。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
        Self: ~const Destruct,
    {
        match self.cmp(&other) {
            Ordering::Less | Ordering::Equal => self,
            Ordering::Greater => other,
        }
    }

    /// Restrict a value to a certain interval. <br>将值限制在某个时间间隔内。<br>
    ///
    /// Returns `max` if `self` is greater than `max`, and `min` if `self` is less than `min`. <br>如果 `self` 大于 `max`，则返回 `max`; 如果 `self` 小于 `min`，则返回 `min`。<br>
    /// Otherwise this returns `self`. <br>否则，将返回 `self`。<br>
    ///
    /// # Panics
    ///
    /// Panics if `min > max`. <br>如果 `min > max`，就会出现 panics。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
        Self: ~const Destruct,
        Self: ~const PartialOrd,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Derive macro generating an impl of the trait `Ord`. <br>派生宏，生成 `Ord` trait 的 impl。<br>
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

/// Trait for types that form a [partial order](https://en.wikipedia.org/wiki/Partial_order). <br>一个用于形成 [部分顺序][partial order](https://en.wikipedia.org/wiki/Partial_order) 的类型的 trait。<br>
///
/// The `lt`, `le`, `gt`, and `ge` methods of this trait can be called using the `<`, `<=`, `>`, and `>=` operators, respectively. <br>此 trait 的 `lt`、`le`、`gt` 和 `ge` 方法可以分别使用 `<`、`<=`、`>` 和 `>=` 相互调用。<br>
///
/// The methods of this trait must be consistent with each other and with those of [`PartialEq`]. <br>这个 trait 的方法必须相互一致，并且与 [`PartialEq`] 的方法一致。<br>
/// The following conditions must hold: <br>必须满足以下条件:<br>
///
/// 1. `a == b` if and only if `partial_cmp(a, b) == Some(Equal)`. <br>`a == b` 当且仅当 `partial_cmp(a, b) == Some(Equal)`。<br>
/// 2. `a < b` if and only if `partial_cmp(a, b) == Some(Less)` <br>`a < b` 当且仅当 `partial_cmp(a, b) == Some(Less)`<br>
/// 3. `a > b` if and only if `partial_cmp(a, b) == Some(Greater)` <br>`a > b` 当且仅当 `partial_cmp(a, b) == Some(Greater)`<br>
/// 4. `a <= b` if and only if `a < b || a == b` <br>`a <= b` 当且仅当 `a < b || a == b`<br>
/// 5. `a >= b` if and only if `a > b || a == b` <br>`a >= b` 当且仅当 `a > b || a == b`<br>
/// 6. `a != b` if and only if `!(a == b)`. <br>`a != b` 当且仅当 `!(a == b)`。<br>
///
/// Conditions 2–5 above are ensured by the default implementation. <br>上述条件 2-5 由默认实现保证。<br>
/// Condition 6 is already ensured by [`PartialEq`]. <br>[`PartialEq`] 已经保证了条件 6。<br>
///
/// If [`Ord`] is also implemented for `Self` and `Rhs`, it must also be consistent with `partial_cmp` (see the documentation of that trait for the exact requirements). <br>如果 [`Ord`] 也为 `Self` 和 `Rhs` 实现，它也必须与 `partial_cmp` 一致 (具体要求请参见 trait 的文档)。<br>
/// It's easy to accidentally make them disagree by deriving some of the traits and manually implementing others. <br>通过派生一些 traits 并手动实现其他一些行为，很容易使它们不以为然。<br>
///
/// The comparison must satisfy, for all `a`, `b` and `c`: <br>对于所有 `a`，`b` 和 `c`，比较必须满足：<br>
///
/// - transitivity: `a < b` and `b < c` implies `a < c`. <br>可传递性: `a < b` 和 `b < c` 表示 `a < c`。<br> The same must hold for both `==` and `>`. <br>`==` 和 `>` 必须保持相同。<br>
/// - duality: `a < b` if and only if `b > a`. <br>二元性: `a < b` 当且仅当 `b > a`。<br>
///
/// Note that these requirements mean that the trait itself must be implemented symmetrically and transitively: if `T: PartialOrd<U>` and `U: PartialOrd<V>` then `U: PartialOrd<T>` and `T: PartialOrd<V>`. <br>请注意，这些要求意味着 trait 本身必须对称且可传递地实现：如果 `T: PartialOrd<U>` 和 `U: PartialOrd<V>`，则 `U: PartialOrd<T>` 和 `T: PartialOrd<V>`。<br>
///
///
/// ## Corollaries
///
/// The following corollaries follow from the above requirements: <br>从上述要求得出以下推论：<br>
///
/// - irreflexivity of `<` and `>`: `!(a < a)`, `!(a > a)` <br>`<` 和 `>` 的非反射性: `!(a < a)`、`!(a > a)`<br>
/// - transitivity of `>`: if `a > b` and `b > c` then `a > c` <br>`>` 的传递性：如果 `a > b` 并且 `b > c`，则 `a > c`<br>
/// - duality of `partial_cmp`: `partial_cmp(a, b) == partial_cmp(b, a).map(Ordering::reverse)` <br>`partial_cmp` 的对偶性: `partial_cmp(a, b) == partial_cmp(b, a).map(Ordering::reverse)`<br>
///
/// ## Derivable
///
/// This trait can be used with `#[derive]`. <br>该 trait 可以与 `#[derive]` 一起使用。<br>
///
/// When `derive`d on structs, it will produce a [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ordering based on the top-to-bottom declaration order of the struct's members. <br>在结构体上 `derive` d 时，它将基于结构体成员的自上而下的声明顺序生成 [词典](https://en.wikipedia.org/wiki/Lexicographic_order) 顺序。<br>
///
/// When `derive`d on enums, variants are ordered by their discriminants. <br>当在枚举上 `derive`d 时，变体按其判别式排序。<br>
/// By default, the discriminant is smallest for variants at the top, and largest for variants at the bottom. <br>默认情况下，对于顶部的变体，判别式最小，底部变体的判别式最大。<br> Here's an example: <br>下面是一个例子：<br>
///
/// ```
/// #[derive(PartialEq, PartialOrd)]
/// enum E {
///     Top,
///     Bottom,
/// }
///
/// assert!(E::Top < E::Bottom);
/// ```
///
/// However, manually setting the discriminants can override this default behavior: <br>但是，手动设置判别式可以覆盖此默认行为:<br>
///
/// ```
/// #[derive(PartialEq, PartialOrd)]
/// enum E {
///     Top = 2,
///     Bottom = 1,
/// }
///
/// assert!(E::Bottom < E::Top);
/// ```
///
/// ## How can I implement `PartialOrd`? <br>如何实现 `PartialOrd`？<br>
///
/// `PartialOrd` only requires implementation of the [`partial_cmp`] method, with the others generated from default implementations. <br>`PartialOrd` 只需要实现 [`partial_cmp`] 方法，其他方法从默认实现中生成。<br>
///
/// However it remains possible to implement the others separately for types which do not have a total order. <br>但是，对于没有总顺序的类型，仍然可以单独实现其他类型。<br> For example, for floating point numbers, `NaN < 0 == false` and `NaN >= 0 == false` (cf. <br>例如，对于浮点数，`NaN < 0 == false` 和 `NaN >= 0 == false` (参见<br>
/// IEEE 754-2008 section 5.11). <br>IEEE 754-2008 第 5.11 节)。<br>
///
/// `PartialOrd` requires your type to be [`PartialEq`]. <br>`PartialOrd` 要求您的类型为 [`PartialEq`]。<br>
///
/// If your type is [`Ord`], you can implement [`partial_cmp`] by using [`cmp`]: <br>如果您的类型是 [`Ord`]，则可以使用 [`cmp`] 来实现 [`partial_cmp`]：<br>
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// You may also find it useful to use [`partial_cmp`] on your type's fields. <br>您可能还会发现在类型的字段上使用 [`partial_cmp`] 很有用。<br> Here is an example of `Person` types who have a floating-point `height` field that is the only field to be used for sorting: <br>这是 `Person` 类型的示例，它们具有一个浮点 `height` 字段，该字段是唯一用于排序的字段：<br>
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`",
    append_const_msg
)]
#[const_trait]
#[rustc_diagnostic_item = "PartialOrd"]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// This method returns an ordering between `self` and `other` values if one exists. <br>如果存在，则此方法返回 `self` 和 `other` 值之间的顺序。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// When comparison is impossible: <br>如果无法进行比较：<br>
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// This method tests less than (for `self` and `other`) and is used by the `<` operator. <br>此方法测试的内容少于 (对于 `self` 和 `other`)，并且由 `<` 操作员使用。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// This method tests less than or equal to (for `self` and `other`) and is used by the `<=` operator. <br>此方法测试小于或等于 (对于 `self` 和 `other`)，并且由 `<=` 运算符使用。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// This method tests greater than (for `self` and `other`) and is used by the `>` operator. <br>此方法测试大于 (对于 `self` 和 `other`)，并且由 `>` 操作员使用。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// This method tests greater than or equal to (for `self` and `other`) and is used by the `>=` operator. <br>此方法测试是否大于或等于 (对于 `self` 和 `other`)，并且由 `>=` 运算符使用。<br>
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Derive macro generating an impl of the trait `PartialOrd`. <br>派生宏，生成 `PartialOrd` trait 的 impl。<br>
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Compares and returns the minimum of two values. <br>比较并返回两个值中的最小值。<br>
///
/// Returns the first argument if the comparison determines them to be equal. <br>如果比较确定它们相等，则返回第一个参数。<br>
///
/// Internally uses an alias to [`Ord::min`]. <br>在内部使用 [`Ord::min`] 的别名。<br>
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
#[cfg_attr(not(test), rustc_diagnostic_item = "cmp_min")]
pub const fn min<T: ~const Ord + ~const Destruct>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Returns the minimum of two values with respect to the specified comparison function. <br>返回相对于指定比较函数的两个值中的最小值。<br>
///
/// Returns the first argument if the comparison determines them to be equal. <br>如果比较确定它们相等，则返回第一个参数。<br>
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[stable(feature = "cmp_min_max_by", since = "1.53.0")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Returns the element that gives the minimum value from the specified function. <br>返回给出指定函数中最小值的元素。<br>
///
/// Returns the first argument if the comparison determines them to be equal. <br>如果比较确定它们相等，则返回第一个参数。<br>
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[stable(feature = "cmp_min_max_by", since = "1.53.0")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Compares and returns the maximum of two values. <br>比较并返回两个值中的最大值。<br>
///
/// Returns the second argument if the comparison determines them to be equal. <br>如果比较确定它们相等，则返回第二个参数。<br>
///
/// Internally uses an alias to [`Ord::max`]. <br>在内部使用 [`Ord::max`] 的别名。<br>
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
#[cfg_attr(not(test), rustc_diagnostic_item = "cmp_max")]
pub const fn max<T: ~const Ord + ~const Destruct>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Returns the maximum of two values with respect to the specified comparison function. <br>返回有关指定比较函数的两个值中的最大值。<br>
///
/// Returns the second argument if the comparison determines them to be equal. <br>如果比较确定它们相等，则返回第二个参数。<br>
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[stable(feature = "cmp_min_max_by", since = "1.53.0")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Returns the element that gives the maximum value from the specified function. <br>返回给出指定函数最大值的元素。<br>
///
/// Returns the second argument if the comparison determines them to be equal. <br>如果比较确定它们相等，则返回第二个参数。<br>
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[stable(feature = "cmp_min_max_by", since = "1.53.0")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Implementation of PartialEq, Eq, PartialOrd and Ord for primitive types <br>原始类型的 PartialEq，Eq，PartialOrd 和 Ord 的实现<br>
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
            impl const PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
    impl const PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
            impl const PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (*self <= *other, *self >= *other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
    impl const PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
    impl const PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
            impl const PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
            impl const Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // The order here is important to generate more optimal assembly. <br>此处的顺序对于生成更优化的装配很重要。<br>
                    // See <https://github.com/rust-lang/rust/issues/63758> for more info. <br>有关更多信息，请参见 <https://github.com/rust-lang/rust/issues/63758>。<br>
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
    impl const Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
    impl const Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Casting to i8's and converting the difference to an Ordering generates more optimal assembly. <br>转换为 i8 并将差异转换为 Ordering 可以生成更优化的装配。<br>
            //
            // See <https://github.com/rust-lang/rust/issues/66780> for more info. <br>有关更多信息，请参见 <https://github.com/rust-lang/rust/issues/66780>。<br>
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SAFETY: bool as i8 returns 0 or 1, so the difference can't be anything else <br>由于 i8 返回的 bool 为 0 或 1，因此其差值不能为其他值<br>
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
    impl const PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
    impl const PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
    impl const Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // & pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
    impl<A: ?Sized, B: ?Sized> const PartialEq<&B> for &A
    where
        A: ~const PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cmp", issue = "92391")]
    impl<A: ?Sized, B: ?Sized> const PartialOrd<&B> for &A
    where
        A: ~const PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers <br>&mut 指针<br>

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}
