#![stable(feature = "core_hint", since = "1.27.0")]

//! Hints to compiler that affects how code should be emitted or optimized. <br>对编译器的提示，该提示会影响应如何发出或优化代码。<br>
//! Hints may be compile time or runtime. <br>提示可能是编译时或运行时。<br>

use crate::intrinsics;

/// Informs the compiler that the site which is calling this function is not reachable, possibly enabling further optimizations. <br>通知编译器调用此函数的站点不可访问，可能会启用进一步优化。<br>
///
/// # Safety
///
/// Reaching this function is *Undefined Behavior*. <br>达到这个函数是 *未定义的行为*。<br>
///
/// As the compiler assumes that all forms of Undefined Behavior can never happen, it will eliminate all branches in the surrounding code that it can determine will invariably lead to a call to `unreachable_unchecked()`. <br>由于编译器假定所有形式的未定义行为永远不会发生，它将消除周围代码中的所有分支，它可以确定总是会导致调用 `unreachable_unchecked()`。<br>
///
/// If the assumptions embedded in using this function turn out to be wrong - that is, if the site which is calling `unreachable_unchecked()` is actually reachable at runtime - the compiler may have generated nonsensical machine instructions for this situation, including in seemingly unrelated code, causing difficult-to-debug problems. <br>如果使用这个函数的假设被证明是错误的 -- 也就是说，如果调用 `unreachable_unchecked()` 的站点在运行时实际上是可访问的 -- 编译器可能已经为这种情况生成了无意义的机器指令，包括看似不相关的代码，导致难以 - 调试问题。<br>
///
///
/// Use this function sparingly. <br>谨慎使用此功能。<br>
/// Consider using the [`unreachable!`] macro, which may prevent some optimizations but will safely panic in case it is actually reached at runtime. <br>考虑使用 [`unreachable!`] 宏，这可能会阻止一些优化，但如果在运行时实际达到它会安全地 panic。<br> Benchmark your code to find out if using `unreachable_unchecked()` comes with a performance benefit. <br>对您的代码进行基准测试，以确定使用 `unreachable_unchecked()` 是否具有性能优势。<br>
///
/// # Examples
///
/// `unreachable_unchecked()` can be used in situations where the compiler can't prove invariants that were previously established. <br>`unreachable_unchecked()` 可用于编译器无法证明先前建立的不，变体，的情况。<br> Such situations have a higher chance of occurring if those invariants are upheld by external code that the compiler can't analyze. <br>如果编译器无法分析的外部代码支持这些不，变体，则这种情况发生的可能性更高。<br>
///
/// ```
/// fn prepare_inputs(divisors: &mut Vec<u32>) {
///     // Note to future-self when making changes: The invariant established here is NOT checked in `do_computation()`; <br>更改时，注意 future-self: 这里建立的不变量没有在 `do_computation()` 中检查;<br> if this changes, you HAVE to change `do_computation()`. <br>如果这种情况发生变化，您必须更改 `do_computation()`。<br>
/////
/////
///     divisors.retain(|divisor| *divisor != 0)
/// }
///
/// /// # Safety
/// /// All elements of `divisor` must be non-zero. <br>`divisor` 的所有元素都必须非零。<br>
/// unsafe fn do_computation(i: u32, divisors: &[u32]) -> u32 {
///     divisors.iter().fold(i, |acc, divisor| {
///         // Convince the compiler that a division by zero can't happen here and a check is not needed below. <br>让编译器相信这里不会发生被零除，并且下面不需要检查。<br>
/////
///         if *divisor == 0 {
///             // Safety: `divisor` can't be zero because of `prepare_inputs`, but the compiler does not know about this. <br>安全性: 由于 `prepare_inputs`，`divisor` 不能为零，但编译器不知道这一点。<br>
///             // We *promise* that we always call `prepare_inputs`. <br>我们 *承诺* 我们总是调用 `prepare_inputs`。<br>
/////
///             std::hint::unreachable_unchecked()
///         }
///         // The compiler would normally introduce a check here that prevents a division by zero. <br>编译器通常会在此处引入一个检查，以防止被零除。<br>
///         // However, if `divisor` was zero, the branch above would reach what we explicitly marked as unreachable. <br>但是，如果 `divisor` 为零，则上面的分支将到达我们明确标记为不可达的地方。<br>
///         // The compiler concludes that `divisor` can't be zero at this point and removes the - now proven useless - check. <br>编译器得出结论，此时 `divisor` 不能为零，并删除 - 现在证明无用 - 检查。<br>
/////
/////
///         acc / divisor
///     })
/// }
///
/// let mut divisors = vec![2, 0, 4];
/// prepare_inputs(&mut divisors);
/// let result = unsafe {
///     // Safety: prepare_inputs() guarantees that divisors is non-zero <br>安全性: prepare_inputs() 保证除数不为零<br>
///     do_computation(100, &divisors)
/// };
/// assert_eq!(result, 12);
///
/// ```
///
/// While using `unreachable_unchecked()` is perfectly sound in the following example, the compiler is able to prove that a division by zero is not possible. <br>虽然在以下示例中使用 `unreachable_unchecked()` 非常合理，但编译器能够证明除以零是不可能的。<br> Benchmarking reveals that `unreachable_unchecked()` provides no benefit over using [`unreachable!`], while the latter does not introduce the possibility of Undefined Behavior. <br>基准测试表明 `unreachable_unchecked()` 与使用 [`unreachable!`] 相比没有任何好处，而后者没有引入未定义行为的可能性。<br>
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` is always positive (not zero), hence `checked_div` will never return `None`. <br>`b.saturating_add(1)` 始终为正 (非零)，因此 `checked_div` 永远不会返回 `None`。<br>
/////
///     // Therefore, the else branch is unreachable. <br>因此，else 分支不可访问。<br>
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_stable(feature = "const_unreachable_unchecked", since = "1.57.0")]
#[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces <br>即使没有 panic，这也有助于 Miri 回溯<br>
pub const unsafe fn unreachable_unchecked() -> ! {
    // SAFETY: the safety contract for `intrinsics::unreachable` must be upheld by the caller. <br>调用者必须遵守 `intrinsics::unreachable` 的安全保证。<br>
    //
    unsafe {
        intrinsics::assert_unsafe_precondition!("hint::unreachable_unchecked must never be reached", () => false);
        intrinsics::unreachable()
    }
}

/// Emits a machine instruction to signal the processor that it is running in a busy-wait spin-loop ("spin lock"). <br>发出一条机器指令，以向处理器发送信号，指示其正在忙于等待的自旋循环 (自旋锁) 中运行。<br>
///
/// Upon receiving the spin-loop signal the processor can optimize its behavior by, for example, saving power or switching hyper-threads. <br>在接收到自旋环信号后，处理器可以通过例如节省功率或切换 hyper 线程来优化其行为。<br>
///
/// This function is different from [`thread::yield_now`] which directly yields to the system's scheduler, whereas `spin_loop` does not interact with the operating system. <br>此函数不同于 [`thread::yield_now`]，后者直接产生系统的调度程序，而 `spin_loop` 不与操作系统交互。<br>
///
/// A common use case for `spin_loop` is implementing bounded optimistic spinning in a CAS loop in synchronization primitives. <br>`spin_loop` 的一个常见用例是在同步原语的 CAS 循环中实现有界乐观旋转。<br>
/// To avoid problems like priority inversion, it is strongly recommended that the spin loop is terminated after a finite amount of iterations and an appropriate blocking syscall is made. <br>为避免优先级倒置之类的问题，强烈建议在有限次数的迭代后终止旋转循环，并进行适当的阻塞系统调用。<br>
///
///
/// **Note**: On platforms that do not support receiving spin-loop hints this function does not do anything at all. <br>在不支持接收自旋循环提示的平台上，此函数完全不执行任何操作。<br>
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // A shared atomic value that threads will use to coordinate <br>线程将用于协调的共享原子值<br>
/// let live = Arc::new(AtomicBool::new(false));
///
/// // In a background thread we'll eventually set the value <br>在后台线程中，我们最终将设置该值<br>
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Do some work, then make the value live <br>做一些工作，然后创造值<br>
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Back on our current thread, we wait for the value to be set <br>回到我们当前的线程，我们等待该值被设置<br>
/// while !live.load(Ordering::Acquire) {
///     // The spin loop is a hint to the CPU that we're waiting, but probably not for very long <br>自旋循环是对我们正在等待的 CPU 的提示，但可能不会持续很长时间<br>
/////
///     hint::spin_loop();
/// }
///
/// // The value is now set <br>现在设置该值<br>
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(target_arch = "x86")]
    {
        // SAFETY: the `cfg` attr ensures that we only execute this on x86 targets. <br>`cfg` 属性确保我们仅在 x86 目标上执行此操作。<br>
        unsafe { crate::arch::x86::_mm_pause() };
    }

    #[cfg(target_arch = "x86_64")]
    {
        // SAFETY: the `cfg` attr ensures that we only execute this on x86_64 targets. <br>`cfg` 属性确保我们仅在 x86_64 目标上执行此操作。<br>
        unsafe { crate::arch::x86_64::_mm_pause() };
    }

    // RISC-V platform spin loop hint implementation <br>RISC-V 平台自旋循环提示实现<br>
    {
        // RISC-V RV32 and RV64 share the same PAUSE instruction, but they are located in different modules in `core::arch`. <br>RISC-V RV32 和 RV64 共享相同的 PAUSE 指令，但它们位于 `core::arch` 中的不同模块中。<br>
        //
        // In this case, here we call `pause` function in each core arch module. <br>在这种情况下，我们在每个核心 arch 模块中调用 `pause` 函数。<br>
        #[cfg(target_arch = "riscv32")]
        {
            crate::arch::riscv32::pause();
        }
        #[cfg(target_arch = "riscv64")]
        {
            crate::arch::riscv64::pause();
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SAFETY: the `cfg` attr ensures that we only execute this on aarch64 targets. <br>`cfg` 属性确保我们仅在 aarch64 目标上执行此操作。<br>
            unsafe { crate::arch::aarch64::__isb(crate::arch::aarch64::SY) };
        }
        #[cfg(target_arch = "arm")]
        {
            // SAFETY: the `cfg` attr ensures that we only execute this on arm targets with support for the v6 feature. <br>`cfg` 属性确保我们仅在支持 v6 特性的 arm 目标上执行此操作。<br>
            //
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// An identity function that *__hints__* to the compiler to be maximally pessimistic about what `black_box` could do. <br>一个标识函数，*__hints__* 编译器对 `black_box` 能做的事情保持最大限度的悲观。<br>
///
/// Unlike [`std::convert::identity`], a Rust compiler is encouraged to assume that `black_box` can use `dummy` in any possible valid way that Rust code is allowed to without introducing undefined behavior in the calling code. <br>与 [`std::convert::identity`] 不同，鼓励 Rust 编译器假定 `black_box` 可以以允许 Rust 代码使用的任何可能有效方式使用 `dummy`，而不会在调用代码中引入未定义的行为。<br>
///
/// This property makes `black_box` useful for writing code in which certain optimizations are not desired, such as benchmarks. <br>此属性使 `black_box` 可用于编写不需要进行某些优化 (例如基准测试) 的代码。<br>
///
/// Note however, that `black_box` is only (and can only be) provided on a "best-effort" basis. <br>但是请注意，`black_box` 仅 (并且只能) 以 "best-effort" 为基础提供。<br> The extent to which it can block optimisations may vary depending upon the platform and code-gen backend used. <br>它可以阻止优化的程度可能会有所不同，具体取决于所使用的平台和代码源后端。<br>
/// Programs cannot rely on `black_box` for *correctness*, beyond it behaving as the identity function. <br>程序不能依赖 `black_box` 的*正确性*，除了它作为身份函数。<br>
///
/// [`std::convert::identity`]: crate::convert::identity
///
/// # When is this useful? <br>这什么时候有用?<br>
///
/// First and foremost: `black_box` does _not_ guarantee any exact behavior and, in some cases, may do nothing at all. <br>首先也是最重要的: `black_box` 不保证任何确切的行为，在某些情况下，可能根本不做任何事情。<br>
/// As such, it **must not be relied upon to control critical program behavior.** This _immediately_ precludes any direct use of this function for cryptographic or security purposes. <br>因此，**不得依赖它来控制关键程序行为。**这立即排除了将此函数直接用于加密或安全目的的任何可能性。<br>
///
/// While not suitable in those mission-critical cases, `back_box`'s functionality can generally be relied upon for benchmarking, and should be used there. <br>虽然不适合那些关键任务的情况，但通常可以依赖 back_box 的功能进行基准测试，并且应该在那里使用。<br>
/// It will try to ensure that the compiler doesn't optimize away part of the intended test code based on context. <br>它将尝试确保编译器不会根据上下文优化部分预期的测试代码。<br>
/// For example: <br>例如：<br>
///
/// ```
/// fn contains(haystack: &[&str], needle: &str) -> bool {
///     haystack.iter().any(|x| x == &needle)
/// }
///
/// pub fn benchmark() {
///     let haystack = vec!["abc", "def", "ghi", "jkl", "mno"];
///     let needle = "ghi";
///     for _ in 0..10 {
///         contains(&haystack, needle);
///     }
/// }
/// ```
///
/// The compiler could theoretically make optimizations like the following: <br>编译器理论上可以进行如下优化:<br>
///
/// - `needle` and `haystack` are always the same, move the call to `contains` outside the loop and delete the loop <br>`needle` 和 `haystack` 一直一样，把调用移到循环外的 `contains`，删除循环<br>
/// - Inline `contains`
/// - `needle` and `haystack` have values known at compile time, `contains` is always true. <br>`needle` 和 `haystack` 的值在编译时已知，`contains` 始终为真。<br> Remove the call and replace with `true` <br>去掉调用，换成 `true`<br>
/// - Nothing is done with the result of `contains`: delete this function call entirely <br>`contains` 的结果没有做任何事情: 完全删除这个函数调用<br>
/// - `benchmark` now has no purpose: delete this function <br>`benchmark` 现在没有任何意义: 删除这个函数<br>
///
/// It is not likely that all of the above happens, but the compiler is definitely able to make some optimizations that could result in a very inaccurate benchmark. <br>上述所有情况不太可能发生，但编译器肯定能够进行一些优化，这可能会导致基准测试非常不准确。<br> This is where `black_box` comes in: <br>这就是 `black_box` 的用武之地:<br>
///
/// ```
/// use std::hint::black_box;
///
/// // Same `contains` function <br>相同 `contains` 函数<br>
/// fn contains(haystack: &[&str], needle: &str) -> bool {
///     haystack.iter().any(|x| x == &needle)
/// }
///
/// pub fn benchmark() {
///     let haystack = vec!["abc", "def", "ghi", "jkl", "mno"];
///     let needle = "ghi";
///     for _ in 0..10 {
///         // Adjust our benchmark loop contents <br>调整我们的基准循环内容<br>
///         black_box(contains(black_box(&haystack), black_box(needle)));
///     }
/// }
/// ```
///
/// This essentially tells the compiler to block optimizations across any calls to `black_box`. <br>这实质上告诉编译器阻止对 `black_box` 的任何调用的优化。<br>
/// So, it now: <br>所以，它现在:<br>
///
/// - Treats both arguments to `contains` as unpredictable: the body of `contains` can no longer be optimized based on argument values <br>将参数到 `contains` 都视为不可预测: `contains` 的主体不能再根据参数值进行优化<br>
/// - Treats the call to `contains` and its result as volatile: the body of `benchmark` cannot optimize this away <br>将调用 `contains` 及其结果视为易变的: `benchmark` 的主体无法优化它<br>
///
/// This makes our benchmark much more realistic to how the function would be used in situ, where arguments are usually not known at compile time and the result is used in some way. <br>这使我们的基准测试更现实地了解函数如何在原位使用，其中函数通常在编译时未知，结果以某种方式使用。<br>
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "bench_black_box", since = "1.66.0")]
#[rustc_const_unstable(feature = "const_black_box", issue = "none")]
pub const fn black_box<T>(dummy: T) -> T {
    crate::intrinsics::black_box(dummy)
}

/// An identity function that causes an `unused_must_use` warning to be triggered if the given value is not used (returned, stored in a variable, etc) by the caller. <br>如果调用者未使用给定值 (返回、存储在变量中等)，则会触发 `unused_must_use` 警告的标识函数。<br>
///
/// This is primarily intended for use in macro-generated code, in which a [`#[must_use]` attribute][must_use] either on a type or a function would not be convenient. <br>这主要用于宏生成的代码，其中类型或函数上的 [`#[must_use]` 属性][must_use] 不方便。<br>
///
/// [must_use]: https://doc.rust-lang.org/reference/attributes/diagnostics.html#the-must_use-attribute
///
/// # Example
///
/// ```
/// #![feature(hint_must_use)]
///
/// use core::fmt;
///
/// pub struct Error(/* ... */);
///
/// #[macro_export]
/// macro_rules! make_error {
///     ($($args:expr),*) => {
///         core::hint::must_use({
///             let error = $crate::make_error(core::format_args!($($args),*));
///             error
///         })
///     };
/// }
///
/// // Implementation detail of make_error! <br>make_error 的实现细节!<br> macro.
/// #[doc(hidden)]
/// pub fn make_error(args: fmt::Arguments<'_>) -> Error {
///     Error(/* ... */)
/// }
///
/// fn demo() -> Option<Error> {
///     if true {
///         // Oops, meant to write `return Some(make_error!("..."));` <br>哎呀，本来想写 `return Some(make_error!("..."));`<br>
///         Some(make_error!("..."));
///     }
///     None
/// }
/// #
/// # // Make rustdoc not wrap the whole snippet in fn main, so that $crate::make_error works <br>使 rustdoc 不在 fn main 中包装整个片段，以便 $crate::make_error 工作<br>
/// # fn main() {}
/// ```
///
/// In the above example, we'd like an `unused_must_use` lint to apply to the value created by `make_error!`. <br>在上面的示例中，我们希望 `unused_must_use` lint 应用于 `make_error!` 创建的值。<br>
/// However, neither `#[must_use]` on a struct nor `#[must_use]` on a function is appropriate here, so the macro expands using `core::hint::must_use` instead. <br>但是，结构体上的 `#[must_use]` 和函数上的 `#[must_use]` 都不适用于这里，因此宏使用 `core::hint::must_use` 进行扩展。<br>
///
/// - We wouldn't want `#[must_use]` on the `struct Error` because that would make the following unproblematic code trigger a warning: <br>我们不希望在 `struct Error` 上使用 `#[must_use]`，因为这会使以下无问题的代码触发警告:<br>
///
///   ```
///   # struct Error;
///   #
///   fn f(arg: &str) -> Result<(), Error>
///   # { Ok(()) }
///
///   #[test]
///   fn t() {
///       // Assert that `f` returns error if passed an empty string. <br>如果传递一个空字符串，则断言 `f` 将返回错误。<br>
///       // A value of type `Error` is unused here but that's not a problem. <br>这里没有使用 `Error` 类型的值，但这不是问题。<br>
///       f("").unwrap_err();
///   }
///   ```
///
/// - Using `#[must_use]` on `fn make_error` can't help because the return value *is* used, as the right-hand side of a `let` statement. <br>在 `fn make_error` 上使用 `#[must_use]` 无济于事，因为返回值 *is* 被用作 `let` 语句的右侧。<br>
/// The `let` statement looks useless but is in fact necessary for ensuring that temporaries within the `format_args` expansion are not kept alive past the creation of the `Error`, as keeping them alive past that point can cause autotrait issues in async code: <br>`let` 语句看起来毫无用处，但实际上对于确保 `format_args` 扩展中的临时对象在创建 `Error` 之后不会保持活动状态是必要的，因为在创建 `Error` 之后保持它们活动可能会导致异步代码中的 autotrait 问题:<br>
///
///
///   ```
///   # #![feature(hint_must_use)]
///   #
///   # struct Error;
///   #
///   # macro_rules! make_error {
///   #     ($($args:expr),*) => {
///   #         core::hint::must_use({
///   #             // If `let` isn't used, then `f()` produces a non-Send future. <br>如果不使用 `let`，则 `f()` 生成一个不发送的 future。<br>
///   #             let error = make_error(core::format_args!($($args),*));
///   #             error
///   #         })
///   #     };
///   # }
///   #
///   # fn make_error(args: core::fmt::Arguments<'_>) -> Error {
///   #     Error
///   # }
///   #
///   async fn f() {
///       // Using `let` inside the make_error expansion causes temporaries like `unsync()` to drop at the semicolon of that `let` statement, which is prior to the await point. <br>在 make_error 扩展中使用 `let` 会导致诸如 `unsync()` 之类的临时变量在 `let` 语句的分号处，该分号位于 await 点之前。<br>
///       // They would otherwise stay around until the semicolon on *this* statement, which is after the await point, and the enclosing Future would not implement Send. <br>否则它们会一直停留在 *this* 语句的分号上，也就是在 await 点之后，并且封闭的 Future 不会实现 Send。<br>
/////
/////
/////
///       log(make_error!("look: {:p}", unsync())).await;
///   }
///
///   async fn log(error: Error) {/* ... */}
///
///   // Returns something without a Sync impl. <br>返回没有 Sync impl 的内容。<br>
///   fn unsync() -> *const () {
///       0 as *const ()
///   }
///   #
///   # fn test() {
///   #     fn assert_send(_: impl Send) {}
///   #     assert_send(f());
///   # }
///   ```
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "hint_must_use", issue = "94745")]
#[rustc_const_unstable(feature = "hint_must_use", issue = "94745")]
#[must_use] // <-- :)
#[inline(always)]
pub const fn must_use<T>(value: T) -> T {
    value
}
