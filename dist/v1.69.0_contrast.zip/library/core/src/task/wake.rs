#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// A `RawWaker` allows the implementor of a task executor to create a [`Waker`] which provides customized wakeup behavior. <br>`RawWaker` 允许任务执行器的实现者创建 [`Waker`]，该 [`Waker`] 提供自定义的唤醒行为。<br>
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// It consists of a data pointer and a [virtual function pointer table (vtable)][vtable] that customizes the behavior of the `RawWaker`. <br>它由一个数据指针和一个自定义 `RawWaker` 行为的 [虚函数指针表 (vtable)][vtable] 组成。<br>
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// A data pointer, which can be used to store arbitrary data as required by the executor. <br>数据指针，可用于根据执行程序的要求存储任意数据。<br>
    /// This could be e.g. <br>这可能是，例如<br>
    /// a type-erased pointer to an `Arc` that is associated with the task. <br>指向与任务关联的 `Arc` 的类型擦除的指针。<br>
    /// The value of this field gets passed to all functions that are part of the vtable as the first parameter. <br>该字段的值作为第一个参数传递给 vtable 一部分的所有函数。<br>
    ///
    data: *const (),
    /// Virtual function pointer table that customizes the behavior of this waker. <br>虚拟函数指针表，可自定义此唤醒程序的行为。<br>
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Creates a new `RawWaker` from the provided `data` pointer and `vtable`. <br>根据提供的 `data` 指针和 `vtable` 创建新的 `RawWaker`。<br>
    ///
    /// The `data` pointer can be used to store arbitrary data as required by the executor. <br>`data` 指针可用于存储执行程序所需的任意数据。<br> This could be e.g. <br>这可能是，例如<br>
    /// a type-erased pointer to an `Arc` that is associated with the task. <br>指向与任务关联的 `Arc` 的类型擦除的指针。<br>
    /// The value of this pointer will get passed to all functions that are part of the `vtable` as the first parameter. <br>该指针的值将作为第一个参数传递给 `vtable` 一部分的所有函数。<br>
    ///
    /// The `vtable` customizes the behavior of a `Waker` which gets created from a `RawWaker`. <br>`vtable` 自定义从 `RawWaker` 创建的 `Waker` 的行为。<br>
    /// For each operation on the `Waker`, the associated function in the `vtable` of the underlying `RawWaker` will be called. <br>对于 `Waker` 上的每个操作，将调用底层 `RawWaker` 的 `vtable` 中的关联函数。<br>
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[must_use]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }

    /// Get the `data` pointer used to create this `RawWaker`. <br>获取用于创建此 `RawWaker` 的 `data` 指针。<br>
    #[inline]
    #[must_use]
    #[unstable(feature = "waker_getters", issue = "87021")]
    pub fn data(&self) -> *const () {
        self.data
    }

    /// Get the `vtable` pointer used to create this `RawWaker`. <br>获取用于创建此 `RawWaker` 的 `vtable` 指针。<br>
    #[inline]
    #[must_use]
    #[unstable(feature = "waker_getters", issue = "87021")]
    pub fn vtable(&self) -> &'static RawWakerVTable {
        self.vtable
    }
}

/// A virtual function pointer table (vtable) that specifies the behavior of a [`RawWaker`]. <br>虚拟函数指针表 (vtable)，用于指定 [`RawWaker`] 的行为。<br>
///
/// The pointer passed to all functions inside the vtable is the `data` pointer from the enclosing [`RawWaker`] object. <br>传递给 vtable 内所有函数的指针是来自封闭的 [`RawWaker`] 对象的 `data` 指针。<br>
///
/// The functions inside this struct are only intended to be called on the `data` pointer of a properly constructed [`RawWaker`] object from inside the [`RawWaker`] implementation. <br>仅应在 [`RawWaker`] 实现内部从正确构造的 [`RawWaker`] 对象的 `data` 指针上调用此结构体内部的函数。<br>
/// Calling one of the contained functions using any other `data` pointer will cause undefined behavior. <br>使用任何其他 `data` 指针调用所包含的函数之一将导致未定义的行为。<br>
///
/// These functions must all be thread-safe (even though [`RawWaker`] is <code>\![Send] + \![Sync]</code>) because [`Waker`] is <code>[Send] + [Sync]</code>, and thus wakers may be moved to arbitrary threads or invoked by `&` reference. <br>这些函数都必须是线程安全的 (即使 [`RawWaker`] 是 <code>\![Send] + \![Sync]</code>)，因为 [`Waker`] 是 <code>[Send] + [Sync]</code>，因此唤醒器可以移动到任意线程或由 `&` 引用调用。<br>
///
/// For example, this means that if the `clone` and `drop` functions manage a reference count, they must do so atomically. <br>例如，这意味着如果 `clone` 和 `drop` 函数管理一个引用计数，它们必须以原子方式进行。<br>
///
///
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// This function will be called when the [`RawWaker`] gets cloned, e.g. when the [`Waker`] in which the [`RawWaker`] is stored gets cloned. <br>克隆 [`RawWaker`] 时，例如克隆存储 [`RawWaker`] 的 [`Waker`] 时，将调用此函数。<br>
    ///
    /// The implementation of this function must retain all resources that are required for this additional instance of a [`RawWaker`] and associated task. <br>此函数的实现必须保留 [`RawWaker`] 的此附加实例和关联任务所需的所有资源。<br>
    /// Calling `wake` on the resulting [`RawWaker`] should result in a wakeup of the same task that would have been awoken by the original [`RawWaker`]. <br>在生成的 [`RawWaker`] 上调用 `wake` 应该会唤醒原 [`RawWaker`] 会唤醒的相同任务。<br>
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// This function will be called when `wake` is called on the [`Waker`]. <br>在 [`Waker`] 上调用 `wake` 时将调用此函数。<br>
    /// It must wake up the task associated with this [`RawWaker`]. <br>它必须唤醒与此 [`RawWaker`] 相关的任务。<br>
    ///
    /// The implementation of this function must make sure to release any resources that are associated with this instance of a [`RawWaker`] and associated task. <br>此函数的实现必须确保释放与该 [`RawWaker`] 实例和关联任务相关联的所有资源。<br>
    ///
    ///
    wake: unsafe fn(*const ()),

    /// This function will be called when `wake_by_ref` is called on the [`Waker`]. <br>在 [`Waker`] 上调用 `wake_by_ref` 时将调用此函数。<br>
    /// It must wake up the task associated with this [`RawWaker`]. <br>它必须唤醒与此 [`RawWaker`] 相关的任务。<br>
    ///
    /// This function is similar to `wake`, but must not consume the provided data pointer. <br>该函数与 `wake` 相似，但不能消耗提供的数据指针。<br>
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// This function gets called when a [`Waker`] gets dropped. <br>当 [`Waker`] 得到抛弃时，这个函数被调用。<br>
    ///
    /// The implementation of this function must make sure to release any resources that are associated with this instance of a [`RawWaker`] and associated task. <br>此函数的实现必须确保释放与该 [`RawWaker`] 实例和关联任务相关联的所有资源。<br>
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Creates a new `RawWakerVTable` from the provided `clone`, `wake`, `wake_by_ref`, and `drop` functions. <br>从提供的 `clone`，`wake`，`wake_by_ref` 和 `drop` 函数创建新的 `RawWakerVTable`。<br>
    ///
    /// These functions must all be thread-safe (even though [`RawWaker`] is <code>\![Send] + \![Sync]</code>) because [`Waker`] is <code>[Send] + [Sync]</code>, and thus wakers may be moved to arbitrary threads or invoked by `&` reference. <br>这些函数都必须是线程安全的 (即使 [`RawWaker`] 是 <code>\![Send] + \![Sync]</code>)，因为 [`Waker`] 是 <code>[Send] + [Sync]</code>，因此唤醒器可以移动到任意线程或由 `&` 引用调用。<br>
    ///
    /// For example, this means that if the `clone` and `drop` functions manage a reference count, they must do so atomically. <br>例如，这意味着如果 `clone` 和 `drop` 函数管理一个引用计数，它们必须以原子方式进行。<br>
    ///
    /// # `clone`
    ///
    /// This function will be called when the [`RawWaker`] gets cloned, e.g. when the [`Waker`] in which the [`RawWaker`] is stored gets cloned. <br>克隆 [`RawWaker`] 时，例如克隆存储 [`RawWaker`] 的 [`Waker`] 时，将调用此函数。<br>
    ///
    /// The implementation of this function must retain all resources that are required for this additional instance of a [`RawWaker`] and associated task. <br>此函数的实现必须保留 [`RawWaker`] 的此附加实例和关联任务所需的所有资源。<br>
    /// Calling `wake` on the resulting [`RawWaker`] should result in a wakeup of the same task that would have been awoken by the original [`RawWaker`]. <br>在生成的 [`RawWaker`] 上调用 `wake` 应该会唤醒原 [`RawWaker`] 会唤醒的相同任务。<br>
    ///
    /// # `wake`
    ///
    /// This function will be called when `wake` is called on the [`Waker`]. <br>在 [`Waker`] 上调用 `wake` 时将调用此函数。<br>
    /// It must wake up the task associated with this [`RawWaker`]. <br>它必须唤醒与此 [`RawWaker`] 相关的任务。<br>
    ///
    /// The implementation of this function must make sure to release any resources that are associated with this instance of a [`RawWaker`] and associated task. <br>此函数的实现必须确保释放与该 [`RawWaker`] 实例和关联任务相关联的所有资源。<br>
    ///
    /// # `wake_by_ref`
    ///
    /// This function will be called when `wake_by_ref` is called on the [`Waker`]. <br>在 [`Waker`] 上调用 `wake_by_ref` 时将调用此函数。<br>
    /// It must wake up the task associated with this [`RawWaker`]. <br>它必须唤醒与此 [`RawWaker`] 相关的任务。<br>
    ///
    /// This function is similar to `wake`, but must not consume the provided data pointer. <br>该函数与 `wake` 相似，但不能消耗提供的数据指针。<br>
    ///
    /// # `drop`
    ///
    /// This function gets called when a [`Waker`] gets dropped. <br>当 [`Waker`] 得到抛弃时，这个函数被调用。<br>
    ///
    /// The implementation of this function must make sure to release any resources that are associated with this instance of a [`RawWaker`] and associated task. <br>此函数的实现必须确保释放与该 [`RawWaker`] 实例和关联任务相关联的所有资源。<br>
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// The context of an asynchronous task. <br>异步任务的上下文。<br>
///
/// Currently, `Context` only serves to provide access to a [`&Waker`](Waker) which can be used to wake the current task. <br>目前，`Context` 仅用于提供对可用于唤醒当前任务的 [`&Waker`](Waker) 的访问。<br>
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "Context"]
pub struct Context<'a> {
    waker: &'a Waker,
    // Ensure we future-proof against variance changes by forcing the lifetime to be invariant (argument-position lifetimes are contravariant while return-position lifetimes are covariant). <br>通过强制生命周期不变，确保我们能够抵御未来的变化 (参数位置生命周期是逆变的，而返回位置生命周期是协变的)。<br>
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
    // Ensure `Context` is `!Send` and `!Sync` in order to allow for future `!Send` and / or `!Sync` fields. <br>确保 `Context` 是 `!Send` 和 `!Sync`，以便允许 future `!Send` 或者 `!Sync` 字段。<br>
    //
    _marker2: PhantomData<*mut ()>,
}

impl<'a> Context<'a> {
    /// Create a new `Context` from a [`&Waker`](Waker). <br>从 [`&Waker`](Waker) 创建一个新的 `Context`。<br>
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_waker", issue = "102012")]
    #[must_use]
    #[inline]
    pub const fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData, _marker2: PhantomData }
    }

    /// Returns a reference to the [`Waker`] for the current task. <br>返回对当前任务的 [`Waker`] 的引用。<br>
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_waker", issue = "102012")]
    #[must_use]
    #[inline]
    pub const fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// A `Waker` is a handle for waking up a task by notifying its executor that it is ready to be run. <br>`Waker` 是通过通知执行者准备运行来唤醒任务的句柄。<br>
///
/// This handle encapsulates a [`RawWaker`] instance, which defines the executor-specific wakeup behavior. <br>该句柄封装了 [`RawWaker`] 实例，该实例定义了特定于执行者的唤醒行为。<br>
///
/// The typical life of a `Waker` is that it is constructed by an executor, wrapped in a [`Context`], then passed to [`Future::poll()`]. <br>`Waker` 的典型生命周期是它由执行程序构造，包裹在 [`Context`] 中，然后传递给 [`Future::poll()`]。<br>
/// Then, if the future chooses to return [`Poll::Pending`], it must also store the waker somehow and call [`Waker::wake()`] when the future should be polled again. <br>然后，如果 future 选择返回 [`Poll::Pending`]，它还必须以某种方式存储唤醒器，并在应该再次轮询 future 时调用 [`Waker::wake()`]。<br>
///
///
/// Implements [`Clone`], [`Send`], and [`Sync`]; <br>实现 [`Clone`]、[`Send`] 和 [`Sync`];<br> therefore, a waker may be invoked from any thread, including ones not in any way managed by the executor. <br>因此，可以从任何线程调用唤醒器，包括不以任何方式由执行程序管理的线程。<br>
/// For example, this might be done to wake a future when a blocking function call completes on another thread. <br>例如，当阻塞函数调用在另一个线程上完成时，可以这样做以唤醒 future。<br>
///
/// [`Future::poll()`]: core::future::Future::poll
/// [`Poll::Pending`]: core::task::Poll::Pending
///
///
///
///
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Wake up the task associated with this `Waker`. <br>唤醒与此 `Waker` 相关的任务。<br>
    ///
    /// As long as the executor keeps running and the task is not finished, it is guaranteed that each invocation of [`wake()`](Self::wake) (or [`wake_by_ref()`](Self::wake_by_ref)) will be followed by at least one [`poll()`] of the task to which this `Waker` belongs. <br>只要 executor 一直在运行，任务还没有完成，就保证每次调用 [`wake()`](Self::wake) (或者 [`wake_by_ref()`](Self::wake_by_ref))) 之后都会至少跟这个 `Waker` 所属的任务的一个 [`poll()`]。<br>
    /// This makes it possible to temporarily yield to other tasks while running potentially unbounded processing loops. <br>这使得在运行潜在的无限处理循环时可以暂时让步给其他任务。<br>
    ///
    /// Note that the above implies that multiple wake-ups may be coalesced into a single [`poll()`] invocation by the runtime. <br>请注意，以上暗示多个唤醒可能会被运行时合并为单个 [`poll()`] 调用。<br>
    ///
    /// Also note that yielding to competing tasks is not guaranteed: it is the executor’s choice which task to run and the executor may choose to run the current task again. <br>另请注意，不能保证屈服于竞争任务: 执行者选择运行哪个任务，执行者可以选择再次运行当前任务。<br>
    ///
    /// [`poll()`]: crate::future::Future::poll
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // The actual wakeup call is delegated through a virtual function call to the implementation which is defined by the executor. <br>实际的唤醒调用通过虚拟函数调用委托给执行程序定义的实现。<br>
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Don't call `drop` -- the waker will be consumed by `wake`. <br>不要调用 `drop` - `wake` 将消耗唤醒器。<br>
        crate::mem::forget(self);

        // SAFETY: This is safe because `Waker::from_raw` is the only way to initialize `wake` and `data` requiring the user to acknowledge that the contract of `RawWaker` is upheld. <br>这是安全的，因为 `Waker::from_raw` 是初始化 `wake` 和 `data` 的唯一方法，要求用户确认 `RawWaker` 的契约已得到遵守。<br>
        //
        //
        unsafe { (wake)(data) };
    }

    /// Wake up the task associated with this `Waker` without consuming the `Waker`. <br>唤醒与此 `Waker` 相关的任务，而不消耗 `Waker`。<br>
    ///
    /// This is similar to [`wake()`](Self::wake), but may be slightly less efficient in the case where an owned `Waker` is available. <br>这类似于 [`wake()`](Self::wake)，但在拥有 `Waker` 可用的情况下效率可能会稍低。<br>
    /// This method should be preferred to calling `waker.clone().wake()`. <br>此方法应该比调用 `waker.clone().wake()` 更可取。<br>
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // The actual wakeup call is delegated through a virtual function call to the implementation which is defined by the executor. <br>实际的唤醒调用通过虚拟函数调用委托给执行程序定义的实现。<br>
        //

        // SAFETY: see `wake` <br>请参见 `wake`<br>
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Returns `true` if this `Waker` and another `Waker` would awake the same task. <br>如果此 `Waker` 和另一个 `Waker` 将唤醒相同的任务，则返回 `true`。<br>
    ///
    /// This function works on a best-effort basis, and may return false even when the `Waker`s would awaken the same task. <br>该函数在尽力而为的基础上起作用，即使 `Waker`s 唤醒相同的任务，也可能返回 false。<br>
    /// However, if this function returns `true`, it is guaranteed that the `Waker`s will awaken the same task. <br>但是，如果此函数返回 `true`，则可以确保 Waker 唤醒相同的任务。<br>
    ///
    /// This function is primarily used for optimization purposes. <br>该函数主要用于优化目的。<br>
    ///
    #[inline]
    #[must_use]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Creates a new `Waker` from [`RawWaker`]. <br>从 [`RawWaker`] 创建一个新的 `Waker`。<br>
    ///
    /// The behavior of the returned `Waker` is undefined if the contract defined in [`RawWaker`]'s and [`RawWakerVTable`]'s documentation is not upheld. <br>如果未遵守 [`RawWaker`] 和 [`RawWakerVTable`] 文档中定义的契约，则返回的 `Waker` 的行为是不确定的。<br>
    ///
    /// Therefore this method is unsafe. <br>因此，此方法是不安全的。<br>
    #[inline]
    #[must_use]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_waker", issue = "102012")]
    pub const unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }

    /// Get a reference to the underlying [`RawWaker`]. <br>获取对底层 [`RawWaker`] 的引用。<br>
    #[inline]
    #[must_use]
    #[unstable(feature = "waker_getters", issue = "87021")]
    pub fn as_raw(&self) -> &RawWaker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SAFETY: This is safe because `Waker::from_raw` is the only way to initialize `clone` and `data` requiring the user to acknowledge that the contract of [`RawWaker`] is upheld. <br>这是安全的，因为 `Waker::from_raw` 是初始化 `clone` 和 `data` 的唯一方法，要求用户确认 [`RawWaker`] 的契约已得到遵守。<br>
            //
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SAFETY: This is safe because `Waker::from_raw` is the only way to initialize `drop` and `data` requiring the user to acknowledge that the contract of `RawWaker` is upheld. <br>这是安全的，因为 `Waker::from_raw` 是初始化 `drop` 和 `data` 的唯一方法，要求用户确认 `RawWaker` 的契约已得到遵守。<br>
        //
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}
