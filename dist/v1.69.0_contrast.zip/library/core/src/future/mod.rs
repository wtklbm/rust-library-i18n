#![stable(feature = "futures_api", since = "1.36.0")]

//! Asynchronous basic functionality. <br>异步基本功能。<br>
//!
//! Please see the fundamental [`async`] and [`await`] keywords and the [async book] for more information on asynchronous programming in Rust. <br>有关 Rust 中异步编程的更多信息，请参见基本 [`async`] 和 [`await`] 关键字以及 [async book]。<br>
//!
//!
//! [`async`]: ../../std/keyword.async.html
//! [`await`]: ../../std/keyword.await.html
//! [async book]: https://rust-lang.github.io/async-book/

use crate::ptr::NonNull;
use crate::task::Context;

mod future;
mod into_future;
mod join;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "future_join", issue = "91642")]
pub use self::join::join;

#[stable(feature = "into_future", since = "1.64.0")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[stable(feature = "future_poll_fn", since = "1.64.0")]
pub use poll_fn::{poll_fn, PollFn};

/// This type is needed because: <br>之所以需要这种类型，是因为：<br>
///
/// a) Generators cannot implement `for<'a, 'b> Generator<&'a mut Context<'b>>`, so we need to pass a raw pointer (see <https://github.com/rust-lang/rust/issues/68923>). <br>Generators 不能实现 `for<'a, 'b> Generator<&'a mut Context<'b>>`，所以我们需要传递一个裸体路径 (见 <https://github.com/rust-lang/rust/issues/68923>)。<br>
///
/// b) Raw pointers and `NonNull` aren't `Send` or `Sync`, so that would make every single future non-Send/Sync as well, and we don't want that. <br>裸指针和 `NonNull` 不是 `Send` 或 `Sync`，因此每个 future non-Send/Sync 也是如此，我们不想要那样。<br>
///
/// It also simplifies the HIR lowering of `.await`. <br>它还简化了 `.await` 的 HIR 降低。<br>
///
#[lang = "ResumeTy"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[must_use]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SAFETY: the caller must guarantee that `cx.0` is a valid pointer that fulfills all the requirements for a mutable reference. <br>调用者必须保证 `cx.0` 是满足可变引用所有要求的有效指针。<br>
    //
    unsafe { &mut *cx.0.as_ptr().cast() }
}

// FIXME(swatinem): This fn is currently needed to work around shortcomings in type and lifetime inference. <br>目前需要此 fn 来解决类型和生命周期推断中的缺点。<br>
// See the comment at the bottom of `LoweringContext::make_async_expr` and <https://github.com/rust-lang/rust/issues/104826>. <br>请参见 `LoweringContext::make_async_expr` 和 <https://github.com/rust-lang/rust/issues/104826> 底部的注释。<br>
//
//
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
#[lang = "identity_future"]
pub const fn identity_future<O, Fut: Future<Output = O>>(f: Fut) -> Fut {
    f
}
