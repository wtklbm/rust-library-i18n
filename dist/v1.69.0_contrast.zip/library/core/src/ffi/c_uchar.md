Equivalent to C's `unsigned char` type. <br>等效于 C 的 `unsigned char` 类型。<br>

This type will always be [`u8`], but is included for completeness. <br>此类型将始终为 [`u8`]，但出于完整性考虑将其包括在内。<br> It is defined as being an unsigned integer the same size as a C [`char`]. <br>它定义为与 C [`char`] 大小相同的无符号整数。<br>

[`char`]: c_char
