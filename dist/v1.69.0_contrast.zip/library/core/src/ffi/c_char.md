Equivalent to C's `char` type. <br>等效于 C 的 `char` 类型。<br>

[C's `char` type] is completely unlike [Rust's `char` type]; <br>[C 的 char 类型][C's `char` type] 与 [Rust 的 char 类型][Rust's `char` type] 完全不同；<br> while Rust's type represents a unicode scalar value, C's `char` type is just an ordinary integer. <br>Rust 的类型表示一个 Unicode 标量值，而 C 的 `char` 类型只是一个普通整数。<br> On modern architectures this type will always be either [`i8`] or [`u8`], as they use byte-addresses memory with 8-bit bytes. <br>在现代体系结构中，这种类型将始终是 [`i8`] 或 [`u8`]，因为它们使用具有 8 位字节的字节地址内存。<br>

C chars are most commonly used to make C strings. <br>C 字符最常用于制作 C 字符串。<br> Unlike Rust, where the length of a string is included alongside the string, C strings mark the end of a string with the character `'\0'`. <br>与 Rust 不同，Rust 的字符串长度包含在字符串的旁边，而 C 字符串则用字符 `'\0'` 标记字符串的结尾。<br> See `CStr` for more information. <br>有关详细信息，请参见 `CStr`。<br>

[C's `char` type]: https://en.wikipedia.org/wiki/C_data_types#Basic_types
[Rust's `char` type]: char
