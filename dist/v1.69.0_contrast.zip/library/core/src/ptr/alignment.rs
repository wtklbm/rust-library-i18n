use crate::convert::{TryFrom, TryInto};
use crate::intrinsics::assert_unsafe_precondition;
use crate::num::NonZeroUsize;
use crate::{cmp, fmt, hash, mem, num};

/// A type storing a `usize` which is a power of two, and thus represents a possible alignment in the rust abstract machine. <br>一种存储 `usize` 的类型，它是 2 的幂，因此表示 rust 抽象机中可能的对齐方式。<br>
///
/// Note that particularly large alignments, while representable in this type, are likely not to be supported by actual allocators and linkers. <br>请注意，虽然在这种类型中可以表示特别大的对齐，但实际分配器和链接器可能不支持。<br>
///
///
#[unstable(feature = "ptr_alignment_type", issue = "102070")]
#[derive(Copy, Clone, Eq)]
#[derive_const(PartialEq)]
#[repr(transparent)]
pub struct Alignment(AlignmentEnum);

// Alignment is `repr(usize)`, but via extra steps. <br>对齐是 `repr(usize)`，但需要额外的步骤。<br>
const _: () = assert!(mem::size_of::<Alignment>() == mem::size_of::<usize>());
const _: () = assert!(mem::align_of::<Alignment>() == mem::align_of::<usize>());

fn _alignment_can_be_structurally_matched(a: Alignment) -> bool {
    matches!(a, Alignment::MIN)
}

impl Alignment {
    /// The smallest possible alignment, <br>尽可能小的对齐方式，<br> 1.
    ///
    /// All addresses are always aligned at least this much. <br>所有地址总是至少对齐这么多。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ptr_alignment_type)]
    /// use std::ptr::Alignment;
    ///
    /// assert_eq!(Alignment::MIN.as_usize(), 1);
    /// ```
    #[unstable(feature = "ptr_alignment_type", issue = "102070")]
    pub const MIN: Self = Self(AlignmentEnum::_Align1Shl0);

    /// Returns the alignment for a type. <br>返回类型的对齐方式。<br>
    ///
    /// This provides the same numerical value as [`mem::align_of`], but in an `Alignment` instead of a `usize`. <br>这提供与 [`mem::align_of`] 相同的数值，但在 `Alignment` 而不是 `usize` 中。<br>
    ///
    #[unstable(feature = "ptr_alignment_type", issue = "102070")]
    #[inline]
    pub const fn of<T>() -> Self {
        // SAFETY: rustc ensures that type alignment is always a power of two. <br>rustc 确保类型对齐始终是 2 的幂。<br>
        unsafe { Alignment::new_unchecked(mem::align_of::<T>()) }
    }

    /// Creates an `Alignment` from a `usize`, or returns `None` if it's not a power of two. <br>从 `usize` 创建 `Alignment`，如果不是 2 的幂，则返回 `None`。<br>
    ///
    ///
    /// Note that `0` is not a power of two, nor a valid alignment. <br>请注意，`0` 不是 2 的幂，也不是有效的对齐方式。<br>
    #[unstable(feature = "ptr_alignment_type", issue = "102070")]
    #[inline]
    pub const fn new(align: usize) -> Option<Self> {
        if align.is_power_of_two() {
            // SAFETY: Just checked it only has one bit set <br>刚刚检查它只有一个位设置<br>
            Some(unsafe { Self::new_unchecked(align) })
        } else {
            None
        }
    }

    /// Creates an `Alignment` from a power-of-two `usize`. <br>从 `usize` 的二次幂创建 `Alignment`。<br>
    ///
    /// # Safety
    ///
    /// `align` must be a power of two. <br>`align` 必须是 2 的幂。<br>
    ///
    /// Equivalently, it must be `1 << exp` for some `exp` in `0..usize::BITS`. <br>等效地，对于 `0..usize::BITS` 中的某些 `exp`，它必须是 `1 << exp`。<br>
    /// It must *not* be zero. <br>它必须不为零。<br>
    #[unstable(feature = "ptr_alignment_type", issue = "102070")]
    #[rustc_const_unstable(feature = "ptr_alignment_type", issue = "102070")]
    #[inline]
    pub const unsafe fn new_unchecked(align: usize) -> Self {
        // SAFETY: Precondition passed to the caller. <br>传递给调用者的前提条件。<br>
        unsafe {
            assert_unsafe_precondition!(
               "Alignment::new_unchecked requires a power of two",
                (align: usize) => align.is_power_of_two()
            )
        };

        // SAFETY: By precondition, this must be a power of two, and our variants encompass all possible powers of two. <br>作为先决条件，这必须是 2 的幂，并且我们的变体包含所有可能的 2 幂。<br>
        //
        unsafe { mem::transmute::<usize, Alignment>(align) }
    }

    /// Returns the alignment as a [`usize`] <br>将对齐方式返回为 [`usize`]<br>
    #[unstable(feature = "ptr_alignment_type", issue = "102070")]
    #[rustc_const_unstable(feature = "ptr_alignment_type", issue = "102070")]
    #[inline]
    pub const fn as_usize(self) -> usize {
        self.0 as usize
    }

    /// Returns the alignment as a [`NonZeroUsize`] <br>将对齐方式返回为 [`NonZeroUsize`]<br>
    #[unstable(feature = "ptr_alignment_type", issue = "102070")]
    #[inline]
    pub const fn as_nonzero(self) -> NonZeroUsize {
        // SAFETY: All the discriminants are non-zero. <br>所有的判别式都是非零的。<br>
        unsafe { NonZeroUsize::new_unchecked(self.as_usize()) }
    }

    /// Returns the base-2 logarithm of the alignment. <br>返回对齐的 base-2 对数。<br>
    ///
    /// This is always exact, as `self` represents a power of two. <br>这总是准确的，因为 `self` 代表 2 的幂。<br>
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ptr_alignment_type)]
    /// use std::ptr::Alignment;
    ///
    /// assert_eq!(Alignment::of::<u8>().log2(), 0);
    /// assert_eq!(Alignment::new(1024).unwrap().log2(), 10);
    /// ```
    #[unstable(feature = "ptr_alignment_type", issue = "102070")]
    #[inline]
    pub fn log2(self) -> u32 {
        self.as_nonzero().trailing_zeros()
    }
}

#[unstable(feature = "ptr_alignment_type", issue = "102070")]
impl fmt::Debug for Alignment {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:?} (1 << {:?})", self.as_nonzero(), self.log2())
    }
}

#[unstable(feature = "ptr_alignment_type", issue = "102070")]
impl TryFrom<NonZeroUsize> for Alignment {
    type Error = num::TryFromIntError;

    #[inline]
    fn try_from(align: NonZeroUsize) -> Result<Alignment, Self::Error> {
        align.get().try_into()
    }
}

#[unstable(feature = "ptr_alignment_type", issue = "102070")]
impl TryFrom<usize> for Alignment {
    type Error = num::TryFromIntError;

    #[inline]
    fn try_from(align: usize) -> Result<Alignment, Self::Error> {
        Self::new(align).ok_or(num::TryFromIntError(()))
    }
}

#[unstable(feature = "ptr_alignment_type", issue = "102070")]
impl From<Alignment> for NonZeroUsize {
    #[inline]
    fn from(align: Alignment) -> NonZeroUsize {
        align.as_nonzero()
    }
}

#[unstable(feature = "ptr_alignment_type", issue = "102070")]
impl From<Alignment> for usize {
    #[inline]
    fn from(align: Alignment) -> usize {
        align.as_usize()
    }
}

#[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
#[unstable(feature = "ptr_alignment_type", issue = "102070")]
impl const cmp::Ord for Alignment {
    #[inline]
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        self.as_nonzero().get().cmp(&other.as_nonzero().get())
    }
}

#[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
#[unstable(feature = "ptr_alignment_type", issue = "102070")]
impl const cmp::PartialOrd for Alignment {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<cmp::Ordering> {
        Some(self.cmp(other))
    }
}

#[unstable(feature = "ptr_alignment_type", issue = "102070")]
impl hash::Hash for Alignment {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_nonzero().hash(state)
    }
}

#[cfg(target_pointer_width = "16")]
type AlignmentEnum = AlignmentEnum16;
#[cfg(target_pointer_width = "32")]
type AlignmentEnum = AlignmentEnum32;
#[cfg(target_pointer_width = "64")]
type AlignmentEnum = AlignmentEnum64;

#[derive(Copy, Clone, Eq)]
#[derive_const(PartialEq)]
#[repr(u16)]
enum AlignmentEnum16 {
    _Align1Shl0 = 1 << 0,
    _Align1Shl1 = 1 << 1,
    _Align1Shl2 = 1 << 2,
    _Align1Shl3 = 1 << 3,
    _Align1Shl4 = 1 << 4,
    _Align1Shl5 = 1 << 5,
    _Align1Shl6 = 1 << 6,
    _Align1Shl7 = 1 << 7,
    _Align1Shl8 = 1 << 8,
    _Align1Shl9 = 1 << 9,
    _Align1Shl10 = 1 << 10,
    _Align1Shl11 = 1 << 11,
    _Align1Shl12 = 1 << 12,
    _Align1Shl13 = 1 << 13,
    _Align1Shl14 = 1 << 14,
    _Align1Shl15 = 1 << 15,
}

#[derive(Copy, Clone, Eq)]
#[derive_const(PartialEq)]
#[repr(u32)]
enum AlignmentEnum32 {
    _Align1Shl0 = 1 << 0,
    _Align1Shl1 = 1 << 1,
    _Align1Shl2 = 1 << 2,
    _Align1Shl3 = 1 << 3,
    _Align1Shl4 = 1 << 4,
    _Align1Shl5 = 1 << 5,
    _Align1Shl6 = 1 << 6,
    _Align1Shl7 = 1 << 7,
    _Align1Shl8 = 1 << 8,
    _Align1Shl9 = 1 << 9,
    _Align1Shl10 = 1 << 10,
    _Align1Shl11 = 1 << 11,
    _Align1Shl12 = 1 << 12,
    _Align1Shl13 = 1 << 13,
    _Align1Shl14 = 1 << 14,
    _Align1Shl15 = 1 << 15,
    _Align1Shl16 = 1 << 16,
    _Align1Shl17 = 1 << 17,
    _Align1Shl18 = 1 << 18,
    _Align1Shl19 = 1 << 19,
    _Align1Shl20 = 1 << 20,
    _Align1Shl21 = 1 << 21,
    _Align1Shl22 = 1 << 22,
    _Align1Shl23 = 1 << 23,
    _Align1Shl24 = 1 << 24,
    _Align1Shl25 = 1 << 25,
    _Align1Shl26 = 1 << 26,
    _Align1Shl27 = 1 << 27,
    _Align1Shl28 = 1 << 28,
    _Align1Shl29 = 1 << 29,
    _Align1Shl30 = 1 << 30,
    _Align1Shl31 = 1 << 31,
}

#[derive(Copy, Clone, Eq)]
#[derive_const(PartialEq)]
#[repr(u64)]
enum AlignmentEnum64 {
    _Align1Shl0 = 1 << 0,
    _Align1Shl1 = 1 << 1,
    _Align1Shl2 = 1 << 2,
    _Align1Shl3 = 1 << 3,
    _Align1Shl4 = 1 << 4,
    _Align1Shl5 = 1 << 5,
    _Align1Shl6 = 1 << 6,
    _Align1Shl7 = 1 << 7,
    _Align1Shl8 = 1 << 8,
    _Align1Shl9 = 1 << 9,
    _Align1Shl10 = 1 << 10,
    _Align1Shl11 = 1 << 11,
    _Align1Shl12 = 1 << 12,
    _Align1Shl13 = 1 << 13,
    _Align1Shl14 = 1 << 14,
    _Align1Shl15 = 1 << 15,
    _Align1Shl16 = 1 << 16,
    _Align1Shl17 = 1 << 17,
    _Align1Shl18 = 1 << 18,
    _Align1Shl19 = 1 << 19,
    _Align1Shl20 = 1 << 20,
    _Align1Shl21 = 1 << 21,
    _Align1Shl22 = 1 << 22,
    _Align1Shl23 = 1 << 23,
    _Align1Shl24 = 1 << 24,
    _Align1Shl25 = 1 << 25,
    _Align1Shl26 = 1 << 26,
    _Align1Shl27 = 1 << 27,
    _Align1Shl28 = 1 << 28,
    _Align1Shl29 = 1 << 29,
    _Align1Shl30 = 1 << 30,
    _Align1Shl31 = 1 << 31,
    _Align1Shl32 = 1 << 32,
    _Align1Shl33 = 1 << 33,
    _Align1Shl34 = 1 << 34,
    _Align1Shl35 = 1 << 35,
    _Align1Shl36 = 1 << 36,
    _Align1Shl37 = 1 << 37,
    _Align1Shl38 = 1 << 38,
    _Align1Shl39 = 1 << 39,
    _Align1Shl40 = 1 << 40,
    _Align1Shl41 = 1 << 41,
    _Align1Shl42 = 1 << 42,
    _Align1Shl43 = 1 << 43,
    _Align1Shl44 = 1 << 44,
    _Align1Shl45 = 1 << 45,
    _Align1Shl46 = 1 << 46,
    _Align1Shl47 = 1 << 47,
    _Align1Shl48 = 1 << 48,
    _Align1Shl49 = 1 << 49,
    _Align1Shl50 = 1 << 50,
    _Align1Shl51 = 1 << 51,
    _Align1Shl52 = 1 << 52,
    _Align1Shl53 = 1 << 53,
    _Align1Shl54 = 1 << 54,
    _Align1Shl55 = 1 << 55,
    _Align1Shl56 = 1 << 56,
    _Align1Shl57 = 1 << 57,
    _Align1Shl58 = 1 << 58,
    _Align1Shl59 = 1 << 59,
    _Align1Shl60 = 1 << 60,
    _Align1Shl61 = 1 << 61,
    _Align1Shl62 = 1 << 62,
    _Align1Shl63 = 1 << 63,
}
