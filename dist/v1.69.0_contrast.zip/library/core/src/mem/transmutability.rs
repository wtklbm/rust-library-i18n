/// Are values of a type transmutable into values of another type? <br>一种类型的值是否可以转换为另一种类型的值?<br>
///
/// This trait is implemented on-the-fly by the compiler for types `Src` and `Self` when the bits of any value of type `Self` are safely transmutable into a value of type `Dst`, in a given `Context`, notwithstanding whatever safety checks you have asked the compiler to [`Assume`] are satisfied. <br>当 `Self` 类型的任何值的位在给定的 `Context` 中可以安全地转换为 `Dst` 类型的值时，此 trait 由编译器针对 `Src` 和 `Self` 类型即时实现，尽管您已要求编译器进行任何安全检查对 [`Assume`] 很满意。<br>
///
///
#[unstable(feature = "transmutability", issue = "99571")]
#[lang = "transmute_trait"]
#[rustc_on_unimplemented(
    message = "`{Src}` cannot be safely transmuted into `{Self}` in the defining scope of `{Context}`.",
    label = "`{Src}` cannot be safely transmuted into `{Self}` in the defining scope of `{Context}`."
)]
pub unsafe trait BikeshedIntrinsicFrom<Src, Context, const ASSUME: Assume = { Assume::NOTHING }>
where
    Src: ?Sized,
{
}

/// What transmutation safety conditions shall the compiler assume that *you* are checking? <br>编译器应假定 *你* 正在检查哪些转换安全条件?<br>
#[unstable(feature = "transmutability", issue = "99571")]
#[lang = "transmute_opts"]
#[derive(PartialEq, Eq, Clone, Copy, Debug)]
pub struct Assume {
    /// When `true`, the compiler assumes that *you* are ensuring (either dynamically or statically) that destination referents do not have stricter alignment requirements than source referents. <br>当 `true` 时，编译器假定 *你* 确保 (动态或静态) 目标引用对象没有比源引用对象更严格的对齐要求。<br>
    ///
    pub alignment: bool,

    /// When `true`, the compiler assume that *you* are ensuring that lifetimes are not extended in a manner that violates Rust's memory model. <br>当 `true` 时，编译器假设 *你* 确保生命周期不会以违反 Rust 内存模型的方式扩展。<br>
    ///
    pub lifetimes: bool,

    /// When `true`, the compiler assumes that *you* have ensured that it is safe for you to violate the type and field privacy of the destination type (and sometimes of the source type, too). <br>当 `true` 时，编译器假定 *你* 已确保您可以安全地违反目标类型 (有时也是源类型) 的类型和字段隐私。<br>
    ///
    pub safety: bool,

    /// When `true`, the compiler assumes that *you* are ensuring that the source type is actually a valid instance of the destination type. <br>当 `true` 时，编译器假定 *你* 确保源类型实际上是目标类型的有效实例。<br>
    ///
    pub validity: bool,
}

impl Assume {
    /// Do not assume that *you* have ensured any safety properties are met. <br>不要假设*您*已确保满足任何安全属性。<br>
    #[unstable(feature = "transmutability", issue = "99571")]
    pub const NOTHING: Self =
        Self { alignment: false, lifetimes: false, safety: false, validity: false };

    /// Assume only that alignment conditions are met. <br>仅假设满足对齐条件。<br>
    #[unstable(feature = "transmutability", issue = "99571")]
    pub const ALIGNMENT: Self = Self { alignment: true, ..Self::NOTHING };

    /// Assume only that lifetime conditions are met. <br>假设仅满足生命周期条件。<br>
    #[unstable(feature = "transmutability", issue = "99571")]
    pub const LIFETIMES: Self = Self { lifetimes: true, ..Self::NOTHING };

    /// Assume only that safety conditions are met. <br>仅假设满足安全条件。<br>
    #[unstable(feature = "transmutability", issue = "99571")]
    pub const SAFETY: Self = Self { safety: true, ..Self::NOTHING };

    /// Assume only that dynamically-satisfiable validity conditions are met. <br>仅假设满足动态可满足的有效性条件。<br>
    #[unstable(feature = "transmutability", issue = "99571")]
    pub const VALIDITY: Self = Self { validity: true, ..Self::NOTHING };

    /// Assume both `self` and `other_assumptions`. <br>假设 `self` 和 `other_assumptions`。<br>
    #[unstable(feature = "transmutability", issue = "99571")]
    pub const fn and(self, other_assumptions: Self) -> Self {
        Self {
            alignment: self.alignment || other_assumptions.alignment,
            lifetimes: self.lifetimes || other_assumptions.lifetimes,
            safety: self.safety || other_assumptions.safety,
            validity: self.validity || other_assumptions.validity,
        }
    }

    /// Assume `self`, excepting `other_assumptions`. <br>假设 `self`，`other_assumptions` 除外。<br>
    #[unstable(feature = "transmutability", issue = "99571")]
    pub const fn but_not(self, other_assumptions: Self) -> Self {
        Self {
            alignment: self.alignment && !other_assumptions.alignment,
            lifetimes: self.lifetimes && !other_assumptions.lifetimes,
            safety: self.safety && !other_assumptions.safety,
            validity: self.validity && !other_assumptions.validity,
        }
    }
}

// FIXME(jswrenn): This const op is not actually usable. <br>这个 const op 实际上是不可用的。<br> Why?
// https://github.com/rust-lang/rust/pull/100726#issuecomment-1219928926
#[unstable(feature = "transmutability", issue = "99571")]
#[rustc_const_unstable(feature = "transmutability", issue = "99571")]
impl const core::ops::Add for Assume {
    type Output = Assume;

    fn add(self, other_assumptions: Assume) -> Assume {
        self.and(other_assumptions)
    }
}

// FIXME(jswrenn): This const op is not actually usable. <br>这个 const op 实际上是不可用的。<br> Why?
// https://github.com/rust-lang/rust/pull/100726#issuecomment-1219928926
#[unstable(feature = "transmutability", issue = "99571")]
#[rustc_const_unstable(feature = "transmutability", issue = "99571")]
impl const core::ops::Sub for Assume {
    type Output = Assume;

    fn sub(self, other_assumptions: Assume) -> Assume {
        self.but_not(other_assumptions)
    }
}
