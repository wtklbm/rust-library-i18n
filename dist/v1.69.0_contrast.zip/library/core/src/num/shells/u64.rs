//! Redundant constants module for the [`u64` primitive type][u64]. <br>[`u64` primitive type][u64] 的冗余常量模块。<br>
//!
//! New code should use the associated constants directly on the primitive type. <br>新代码应直接在原始类型上使用关联的常量。<br>

#![stable(feature = "rust1", since = "1.0.0")]
#![deprecated(
    since = "TBD",
    note = "all constants in this module replaced by associated constants on `u64`"
)]

int_module! { u64 }
