//! This is an internal module used by the ifmt! <br>这是 ifmt 使用的内部模块！<br> runtime. These structures are emitted to static arrays to precompile format strings ahead of time. <br>运行时。这些结构会被发送到静态数组，以提前对格式字符串进行预编译。<br>
//!
//! These definitions are similar to their `ct` equivalents, but differ in that these can be statically allocated and are slightly optimized for the runtime <br>这些定义与它们的 `ct` 等效项相似，但不同之处在于它们可以静态分配，并针对运行时进行了略微优化。<br>
//!
//!
#![allow(missing_debug_implementations)]

#[cfg_attr(not(bootstrap), lang = "format_placeholder")]
#[derive(Copy, Clone)]
// FIXME: Rename this to Placeholder <br>将其重命名为占位符<br>
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

impl Argument {
    #[inline(always)]
    pub const fn new(
        position: usize,
        fill: char,
        align: Alignment,
        flags: u32,
        precision: Count,
        width: Count,
    ) -> Self {
        Self { position, format: FormatSpec { fill, align, flags, precision, width } }
    }
}

/// Possible alignments that can be requested as part of a formatting directive. <br>可以作为格式设置指令的一部分请求的可能的对齐方式。<br>
#[cfg_attr(not(bootstrap), lang = "format_alignment")]
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indication that contents should be left-aligned. <br>指示内容应左对齐。<br>
    Left,
    /// Indication that contents should be right-aligned. <br>指示内容应右对齐。<br>
    Right,
    /// Indication that contents should be center-aligned. <br>指示内容应居中对齐。<br>
    Center,
    /// No alignment was requested. <br>没有要求对齐。<br>
    Unknown,
}

/// Used by [width](https://doc.rust-lang.org/std/fmt/#width) and [precision](https://doc.rust-lang.org/std/fmt/#precision) specifiers. <br>由 [width](https://doc.rust-lang.org/std/fmt/#width) 和 [precision](https://doc.rust-lang.org/std/fmt/#precision) 说明符使用。<br>
#[cfg_attr(not(bootstrap), lang = "format_count")]
#[derive(Copy, Clone)]
pub enum Count {
    /// Specified with a literal number, stores the value <br>用字面量数字指定，存储该值<br>
    Is(usize),
    /// Specified using `$` and `*` syntaxes, stores the index into `args` <br>使用 `$` 和 `*` 语法指定，将索引存储到 `args`<br>
    Param(usize),
    /// Not specified <br>未标明<br>
    Implied,
}
