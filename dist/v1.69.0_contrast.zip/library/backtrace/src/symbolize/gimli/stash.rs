// only used on Linux right now, so allow dead code elsewhere <br>目前仅在 Linux 上使用，因此允许在其他地方使用无效代码<br>
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use super::Mmap;
use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// A simple arena allocator for byte buffers. <br>一个简单的舞台分配器，用于字节缓冲区。<br>
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
    mmap_aux: UnsafeCell<Option<Mmap>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
            mmap_aux: UnsafeCell::new(None),
        }
    }

    /// Allocates a buffer of the specified size and returns a mutable reference to it. <br>分配指定大小的缓冲区，并向其返回可变引用。<br>
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: this is the only function that ever constructs a mutable reference to `self.buffers`. <br>这是创建 `self.buffers` 的可变引用的唯一函数。<br>
        //
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SAFETY: we never remove elements from `self.buffers`, so a reference to the data inside any buffer will live as long as `self` does. <br>我们从不从 `self.buffers` 中删除元素，因此只要 `self` 起作用，对任何缓冲区中的数据的引用都将有效。<br>
        //
        &mut buffers[i]
    }

    /// Stores a `Mmap` for the lifetime of this `Stash`, returning a pointer which is scoped to just this lifetime. <br>为这个 `Stash` 的生命周期存储一个 `Mmap`，返回一个指针，该指针的范围仅限于这个生命周期。<br>
    ///
    pub fn set_mmap_aux(&self, map: Mmap) -> &[u8] {
        // SAFETY: this is the only location for a mutable pointer to `mmap_aux`, and this structure isn't threadsafe to shared across threads either. <br>这是唯一的位置，并且指向 `mmap_aux` 的指针，这个结构体也不是线程安全的，不能跨线程共享。<br>
        // This also is careful to store at most one `mmap_aux` since overwriting a previous one would invalidate the previous pointer. <br>这也很小心，最多存储一个 `mmap_aux`，因为覆盖前一个会使前一个指针无效。<br>
        // Given that though we can safely return a pointer to our interior-owned contents. <br>鉴于我们可以安全地返回一个指向我们内部拥有所有权的内容的指针。<br>
        //
        //
        //
        unsafe {
            let mmap_aux = &mut *self.mmap_aux.get();
            assert!(mmap_aux.is_none());
            *mmap_aux = Some(map);
            mmap_aux.as_ref().unwrap()
        }
    }
}
