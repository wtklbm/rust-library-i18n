//! Support for symbolication using the `gimli` crate on crates.io <br>在 crates.io 上使用 `gimli` crate 支持符号化<br>
//!
//! This is the default symbolication implementation for Rust. <br>这是 Rust 的默认符号实现。<br>

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "haiku",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
        target_os = "illumos",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'static lifetime is a lie to hack around lack of support for self-referential structs. <br>静态生命周期是一个谎言，它可以绕过缺乏对自引用结构的支持。<br>
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

enum Either<A, B> {
    #[allow(dead_code)]
    A(A),
    B(B),
}

impl Mapping {
    /// Creates a `Mapping` by ensuring that the `data` specified is used to create a `Context` and it can only borrow from that or the `Stash` of decompressed sections or auxiliary data. <br>通过确保指定的 `data` 用于创建 `Context` 来创建 `Mapping`，并且只能从该 `data` 或已解压部分或辅助数据的 `Stash` 中借用。<br>
    ///
    ///
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> FnOnce(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        Mapping::mk_or_other(data, move |data, stash| {
            let cx = mk(data, stash)?;
            Some(Either::B(cx))
        })
    }

    /// Creates a `Mapping` from `data`, or if the closure decides to, returns a different mapping. <br>从 `data` 创建一个 `Mapping`，或者如果闭包决定，返回一个不同的映射。<br>
    ///
    fn mk_or_other<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> FnOnce(&'a [u8], &'a Stash) -> Option<Either<Mapping, Context<'a>>>,
    {
        let stash = Stash::new();
        let cx = match mk(&data, &stash)? {
            Either::A(mapping) => return Some(mapping),
            Either::B(cx) => cx,
        };
        Some(Mapping {
            // Convert to 'static lifetimes since the symbols should only borrow `map` and `stash` and we're preserving them below. <br>转换为静态生命周期，因为这些符号仅应借用 `map` 和 `stash`，我们将其保留在下面。<br>
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(
        stash: &'data Stash,
        object: Object<'data>,
        sup: Option<Object<'data>>,
    ) -> Option<Context<'data>> {
        let mut sections = gimli::Dwarf::load(|id| -> Result<_, ()> {
            let data = object.section(stash, id.name()).unwrap_or(&[]);
            Ok(EndianSlice::new(data, Endian))
        })
        .ok()?;

        if let Some(sup) = sup {
            sections
                .load_sup(|id| -> Result<_, ()> {
                    let data = sup.section(stash, id.name()).unwrap_or(&[]);
                    Ok(EndianSlice::new(data, Endian))
                })
                .ok()?;
        }
        let dwarf = addr2line::Context::from_dwarf(sections).ok()?;

        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        mod coff;
        use self::coff::Object;
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        mod macho;
        use self::macho::Object;
    } else {
        mod elf;
        use self::elf::Object;
    }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        mod libs_windows;
        use libs_windows::native_libraries;
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        mod libs_macos;
        use libs_macos::native_libraries;
    } else if #[cfg(target_os = "illumos")] {
        mod libs_illumos;
        use libs_illumos::native_libraries;
    } else if #[cfg(all(
        any(
            target_os = "linux",
            target_os = "fuchsia",
            target_os = "freebsd",
            target_os = "openbsd",
            all(target_os = "android", feature = "dl_iterate_phdr"),
        ),
        not(target_env = "uclibc"),
    ))] {
        mod libs_dl_iterate_phdr;
        use libs_dl_iterate_phdr::native_libraries;
    } else if #[cfg(target_env = "libnx")] {
        mod libs_libnx;
        use libs_libnx::native_libraries;
    } else if #[cfg(target_os = "haiku")] {
        mod libs_haiku;
        use libs_haiku::native_libraries;
    } else {
        // Everything else should doesn't know how to load native libraries. <br>其他的一切都不应该知道如何加载本机库。<br>
        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// All known shared libraries that have been loaded. <br>已加载的所有已知共享库。<br>
    libraries: Vec<Library>,

    /// Mappings cache where we retain parsed dwarf information. <br>映射缓存，其中保留了解析的矮人信息。<br>
    ///
    /// This list has a fixed capacity for its entire lifetime which never increases. <br>该列表在其整个生命周期中具有固定容量，且容量从不增加。<br>
    /// The `usize` element of each pair is an index into `libraries` above where `usize::max_value()` represents the current executable. <br>每对中的 `usize` 元素是 `libraries` 的索引，以上 `usize::max_value()` 表示当前可执行文件。<br>
    ///
    /// The `Mapping` is corresponding parsed dwarf information. <br>`Mapping` 是相应的解析后的矮人信息。<br>
    ///
    /// Note that this is basically an LRU cache and we'll be shifting things around in here as we symbolize addresses. <br>请注意，这基本上是一个 LRU 缓存，我们将在这里对地址进行符号化，以表示地址。<br>
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segments of this library loaded into memory, and where they're loaded. <br>该库的各段已加载到内存中以及它们的加载位置。<br>
    segments: Vec<LibrarySegment>,
    /// The "bias" of this library, typically where it's loaded into memory. <br>该库的 "bias"，通常是它被加载到内存中的位置。<br>
    /// This value is added to each segment's stated address to get the actual virtual memory address that the segment is loaded into. <br>将此值添加到每个段的声明地址中，以获取该段加载到的实际虚拟内存地址。<br>
    /// Additionally this bias is subtracted from real virtual memory addresses to index into debuginfo and the symbol table. <br>另外，从实际虚拟内存地址中减去此偏差以将其索引到 debuginfo 和符号表中。<br>
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// The stated address of this segment in the object file. <br>对象文件中此段的指定地址。<br>
    /// This is not actually where the segment is loaded, but rather this address plus the containing library's `bias` is where to find it. <br>实际上，这不是加载该段的位置，而是在该地址加上包含库的 `bias` 所在的位置。<br>
    ///
    stated_virtual_memory_address: usize,
    /// The size of this segment in memory. <br>此段在内存中的大小。<br>
    len: usize,
}

// unsafe because this is required to be externally synchronized <br>不安全，因为需要从外部进行同步<br>
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // unsafe because this is required to be externally synchronized <br>不安全，因为需要从外部进行同步<br>
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // A very small, very simple LRU cache for debug info mappings. <br>一个非常小，非常简单的 LRU 缓存，用于调试信息映射。<br>
        //
        // The hit rate should be very high, since the typical stack doesn't cross between many shared libraries. <br>命中率应该很高，因为典型的栈不会在许多共享库之间交叉。<br>
        //
        // The `addr2line::Context` structures are pretty expensive to create. <br>`addr2line::Context` 结构的创建成本非常高。<br>
        // Its cost is expected to be amortized by subsequent `locate` queries, which leverage the structures built when constructing `addr2line::Context`s to get nice speedups. <br>预期其成本将由后续的 `locate` 查询摊销，这些查询将利用在构建 `addr2line::Context`s 时构建的结构来获得良好的加速效果。<br>
        //
        // If we didn't have this cache, that amortization would never happen, and symbolicating backtraces would be ssssllllooooowwww. <br>如果我们没有此缓存，则摊销将永远不会发生，而象征性回溯将是 ssssllllooooowwww。<br>
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // First up, test if this `lib` has any segment containing the `addr` (handling relocation). <br>首先，测试此 `lib` 是否具有包含 `addr` 的任何段 (处理重定位)。<br> If this check passes then we can continue below and actually translate the address. <br>如果此检查通过，那么我们可以继续下面的内容并实际翻译地址。<br>
                //
                // Note that we're using `wrapping_add` here to avoid overflow checks. <br>请注意，我们在这里使用 `wrapping_add` 以避免溢出检查。<br> It's been seen in the wild that the SVMA + bias computation overflows. <br>疯狂地看到 SVMA + 偏差计算会溢出。<br>
                // It seems a bit odd that would happen but there's not a huge amount we can do about it other than probably just ignore those segments since they're likely pointing off into space. <br>这似乎有点奇怪，但除了可能忽略这些片段，因为它们可能指向太空之外，我们对此无能为力。<br>
                //
                // This originally came up in rust-lang/backtrace-rs#329. <br>这最初是在 rust-lang/backtrace-rs#329 中出现的。<br>
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Now that we know `lib` contains `addr`, we can offset with the bias to find the stated virtual memory address. <br>现在我们知道 `lib` 包含 `addr`，我们可以用偏差进行偏移以找到指定的虚拟内存地址。<br>
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: after this conditional completes without early returning from an error, the cache entry for this path is at index <br>不变性: 在此条件完成后且未提前从错误中返回后，此路径的缓存条目位于索引处<br> 0.
        //

        if let Some(idx) = idx {
            // When the mapping is already in the cache, move it to the front. <br>当映射已经在缓存中时，将其移到最前面。<br>
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // When the mapping is not in the cache, create a new mapping, insert it into the front of the cache, and evict the oldest cache entry if necessary. <br>当映射不在高速缓存中时，请创建一个新的映射，将其插入高速缓存的前面，并在必要时逐出最旧的高速缓存条目。<br>
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // don't leak the `'static` lifetime, make sure it's scoped to just ourselves <br>不要泄漏 `'static` 的生命周期，请确保它仅限于我们自己<br>
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Extend the lifetime of `sym` to `'static` since we are unfortunately required to here, but it's only ever going out as a reference so no reference to it should be persisted beyond this frame anyway. <br>将 `sym` 的生命周期延长到 `'static`，因为不幸的是这里要求我们这样做，但它只是作为一个引用，所以无论如何，不应在此框架之外持续对它的引用。<br>
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Finally, get a cached mapping or create a new mapping for this file, and evaluate the DWARF info to find the file/line/name for this address. <br>最后，获取缓存的映射或为此文件创建新的映射，并评估 DWARF 信息以查找该地址的 file/line/name。<br>
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                let name = match frame.function {
                    Some(f) => Some(f.name.slice()),
                    None => cx.object.search_symtab(addr as u64),
                };
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name,
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// We were able to locate frame information for this symbol, and `addr2line`'s frame internally has all the nitty gritty details. <br>我们能够找到该符号的框架信息，并且 `addr2line` 的框架内部具有所有细腻的细节。<br>
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Couldn't find debug information, but we found it in the symbol table of the elf executable. <br>找不到调试信息，但是我们在 elf 可执行文件的符号表中找到了它。<br>
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}
