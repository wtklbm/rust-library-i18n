#![feature(no_core)]
#![no_core]

// 有关为何需要此 crate 的信息，请参见 rustc-std-workspace-core。

// 重命名 crate 以避免与 liballoc 中的 alloc 模块冲突。
extern crate alloc as foo;

pub use foo::*;