// 目前仅在 Linux 上使用，因此允许在其他地方使用无效代码
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// 一个简单的舞台分配器，用于字节缓冲区。
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// 分配指定大小的缓冲区，并向其返回可变引用。
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: 这是创建 `self.buffers` 的可变引用的唯一函数。
        //
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SAFETY: 我们从不从 `self.buffers` 中删除元素，因此只要 `self` 起作用，对任何缓冲区中的数据的引用都将有效。
        //
        &mut buffers[i]
    }
}