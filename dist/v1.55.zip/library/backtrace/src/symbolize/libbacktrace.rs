//! 在 libbacktrace 中使用 DWARF 解析代码的符号化策略。
//!
//! 通常与 gcc 一起分发的 libbacktrace C 库不仅支持生成回溯 (我们实际上没有使用过)，而且还支持回溯的符号化和处理有关内联帧之类的东西的矮小的调试信息。
//!
//!
//! 由于这里存在许多各种各样的问题，所以这相对复杂，但是基本思想是:
//!
//! * 首先我们调用 `backtrace_syminfo`。如果可以的话，这将从动态符号表中获取符号信息。
//! * 接下来，我们调用 `backtrace_pcinfo`。这将解析 debuginfo 表 (如果有)，并允许我们恢复有关内联框架，文件名，行号等的信息。
//!
//! 将侏儒表放入 libbacktrace 有很多技巧，但是希望它不是世界末日，并且在阅读下面的内容时已经足够清楚了。
//!
//! 这是非 MSVC 和非 OSX 平台的默认符号策略。尽管在 libstd 中，这是 OSX 的默认策略。
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // 如果可能的话，最好使用来自 debuginfo 的 `function` 名称，例如，对于内联框架，它通常更准确。
                // 如果不存在，则回退到 `symname` 中指定的符号表名称。
                //
                // 请注意，有时 `function` 的准确性可能会有所降低，例如，被列为 `std::panicking::try::do_call` 的 `try<i32,closure>` 代表。
                //
                // 尚不清楚原因，但总体而言 `function` 名称似乎更准确。
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // 现在什么也不做
}

/// 传递给 `syminfo_cb` 的 `data` 指针的类型
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // 当我们开始解析时，一旦从 `backtrace_syminfo` 调用了此回调，我们将进一步调用 `backtrace_pcinfo`。
    // `backtrace_pcinfo` 函数将查询调试信息，并尝试执行诸如恢复 file/line 信息以及内联框架之类的操作。
    // 请注意，尽管没有调试信息，但 `backtrace_pcinfo` 可能失败或失败很多，因此，如果发生这种情况，我们一定要使用 `syminfo_cb` 中的至少一个符号来调用回调。
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// 传递给 `pcinfo_cb` 的 `data` 指针的类型
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace API 支持创建状态，但不支持销毁状态。
// 我个人认为这意味着一个国家将被创造，然后永远存在。
//
// 我很想注册一个 at_exit() 处理程序来清理此状态，但是 libbacktrace 没有提供这样做的方法。
//
// 由于这些限制，此函数具有静态缓存的状态，该状态是在首次请求此状态时计算的。
//
// 请记住，所有回溯都是按顺序进行的 (一个锁)。
//
// 请注意，此处缺少同步是由于需要对 `resolve` 进行外部同步。
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // 不要使用 libbacktrace 的线程安全功能，因为我们总是以同步方式调用它。
        //
        0,
        error_cb,
        ptr::null_mut(), // 没有多余的数据
    );

    return STATE;

    // 请注意，要使 libbacktrace 完全起作用，它需要找到当前可执行文件的 DWARF 调试信息。它通常通过多种机制来做到这一点，包括但不限于:
    //
    // * /proc/self/exe 在支持的平台上
    // * 创建状态时显式传递的文件名
    //
    // libbacktrace 库是一大堆 C 代码。这自然意味着它具有内存安全漏洞，尤其是在处理格式错误的 debuginfo 时。
    // 从历史上看，Libstd 已经遇到了很多此类情况。
    //
    // 如果使用 /proc/self/exe，则通常可以忽略这些，因为我们假设 libbacktrace 是 "mostly correct"，否则对于 "attempted to be correct" 矮调试信息不会做奇怪的事情。
    //
    //
    // 但是，如果我们传递文件名，则在某些平台 (例如 BSD) 上，恶意行为者可能会导致将任意文件放置在该位置，这是可能的。
    // 这意味着，如果我们告诉 libbacktrace 有关文件名的信息，那么它可能正在使用任意文件，可能会导致段错误。
    // 如果我们不告诉 libbacktrace 任何东西，那么它将在不支持 /proc/self/exe 之类的平台上不做任何事情!
    //
    // 考虑到所有这些，我们尽可能不传递文件名，但是我们必须在完全不支持 /proc/self/exe 的平台上运行。
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // 请注意，理想情况下，我们将使用 `std::env::current_exe`，但此处我们不需要 `std`。
            //
            // 使用 `_NSGetExecutablePath` 将当前的可执行路径加载到静态区域 (如果它太小，则放弃)。
            //
            //
            // 请注意，我们非常信任这里的 libbacktrace 不会死于损坏的可执行文件，但是它确实可以...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows 具有打开文件的模式，该文件在打开后无法删除。
            // 总的来说，这就是我们想要的，因为我们希望确保在将可执行文件移交给 libbacktrace 之后，可执行文件不会从我们下面改变出来，希望减轻将任意数据传递到 libbacktrace 中的能力 (这可能会被错误处理)。
            //
            //
            // 鉴于我们在这里进行了一些跳舞，试图对自己的形象有所了解:
            //
            // * 获取当前进程的句柄，加载其文件名。
            // * 使用正确的标志打开一个具有该文件名的文件。
            // * 重新加载当前进程的文件名，确保它是相同的
            //
            // 如果所有这些通过了，那么我们理论上确实已经打开了进程的文件，并且可以保证它不会改变。FWIW 从历史上从 libstd 复制了一堆，所以这是我对正在发生的事情的最好解释。
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // 这驻留在静态内存中，因此我们可以将其返回。
                static mut BUF: [i8; N] = [0; N];
                // ... 由于它是临时的，因此存在于栈中
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // 故意在这里泄漏 `handle`，因为打开该文件会保留我们对该文件名的锁定。
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // 我们想返回一个 nul 终止的切片，因此，如果所有内容都已填写且等于总长度，则将其等同于失败。
                //
                //
                // 否则，返回成功时，请确保在切片中包含 nul 字节。
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // 当前回溯错误已被清除
    let state = init_state();
    if state.is_null() {
        return;
    }

    // 调用 `backtrace_syminfo` API，该 API (通过读取代码) 应该恰好调用一次 `syminfo_cb` (或者可能会因错误而失败)。
    // 然后，我们在 `syminfo_cb` 中处理更多内容。
    //
    // 请注意，我们这样做是因为 `syminfo` 将查询符号表，即使二进制文件中没有调试信息，也会查找符号名称。
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}