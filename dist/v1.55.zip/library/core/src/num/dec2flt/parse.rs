//! 解析浮点数的函数。

use crate::num::dec2flt::common::{is_8digits, AsciiStr, ByteSlice};
use crate::num::dec2flt::float::RawFloat;
use crate::num::dec2flt::number::Number;

const MIN_19DIGIT_INT: u64 = 100_0000_0000_0000_0000;

/// 解析 8 位数字，以小端顺序加载为字节。
///
/// 这使用了每个数字都在 [0x030, 0x39] 中的技巧，因此可以在 3 次乘法中解析，比正常的 8 次要快得多。
///
/// 这是基于 "Fast numeric string to int" 中描述的算法，可在此处获得: <https://johnnylee-sde.github.io/Fast-numeric-string-to-int/>.
///
///
///
fn parse_8digits(mut v: u64) -> u64 {
    const MASK: u64 = 0x0000_00FF_0000_00FF;
    const MUL1: u64 = 0x000F_4240_0000_0064;
    const MUL2: u64 = 0x0000_2710_0000_0001;
    v -= 0x3030_3030_3030_3030;
    v = (v * 10) + (v >> 8); // 不会溢出，适合 63 位
    let v1 = (v & MASK).wrapping_mul(MUL1);
    let v2 = ((v >> 16) & MASK).wrapping_mul(MUL2);
    ((v1.wrapping_add(v2) >> 32) as u32) as u64
}

/// 解析数字直到找到非数字字符。
fn try_parse_digits(s: &mut AsciiStr<'_>, x: &mut u64) {
    // 可能会导致溢出，稍后处理
    s.parse_digits(|digit| {
        *x = x.wrapping_mul(10).wrapping_add(digit as _);
    });
}

/// 解析最多 19 位数字 (可以存储在 64 位整数中的最大值)。
fn try_parse_19digits(s: &mut AsciiStr<'_>, x: &mut u64) {
    while *x < MIN_19DIGIT_INT {
        if let Some(&c) = s.as_ref().first() {
            let digit = c.wrapping_sub(b'0');
            if digit < 10 {
                *x = (*x * 10) + digit as u64; // 这里没有溢出
                // SAFETY: 不能为空
                unsafe {
                    s.step();
                }
            } else {
                break;
            }
        } else {
            break;
        }
    }
}

/// 尝试使用优化算法一次解析 8 位数字。
fn try_parse_8digits(s: &mut AsciiStr<'_>, x: &mut u64) {
    // 可能会导致溢出，稍后处理
    if let Some(v) = s.read_u64() {
        if is_8digits(v) {
            *x = x.wrapping_mul(1_0000_0000).wrapping_add(parse_8digits(v));
            // SAFETY: 已经确保缓冲区在 read_u64 中 >= 8 个字节。
            unsafe {
                s.step_by(8);
            }
            if let Some(v) = s.read_u64() {
                if is_8digits(v) {
                    *x = x.wrapping_mul(1_0000_0000).wrapping_add(parse_8digits(v));
                    // SAFETY: 已经确保 try_read_u64 中的缓冲区 >= 8 个字节。
                    unsafe {
                        s.step_by(8);
                    }
                }
            }
        }
    }
}

/// 解析浮点数的科学记数法组件。
fn parse_scientific(s: &mut AsciiStr<'_>) -> Option<i64> {
    let mut exponent = 0_i64;
    let mut negative = false;
    if let Some(&c) = s.as_ref().get(0) {
        negative = c == b'-';
        if c == b'-' || c == b'+' {
            // SAFETY: s 不能为空
            unsafe {
                s.step();
            }
        }
    }
    if s.first_isdigit() {
        s.parse_digits(|digit| {
            // 这里没有溢出，在溢出之前饱和
            if exponent < 0x10000 {
                exponent = 10 * exponent + digit as i64;
            }
        });
        if negative { Some(-exponent) } else { Some(exponent) }
    } else {
        None
    }
}

/// 解析部分非特殊浮点数。
///
/// 这将创建浮点数表示为有效数字和十进制指数。
///
fn parse_partial_number(s: &[u8], negative: bool) -> Option<(Number, usize)> {
    let mut s = AsciiStr::new(s);
    let start = s;
    debug_assert!(!s.is_empty());

    // 解析点之前的初始数字
    let mut mantissa = 0_u64;
    let digits_start = s;
    try_parse_digits(&mut s, &mut mantissa);
    let mut n_digits = s.offset_from(&digits_start);

    // 用以下数字处理点
    let mut n_after_dot = 0;
    let mut exponent = 0_i64;
    let int_end = s;
    if s.first_is(b'.') {
        // SAFETY: 由于 first_is，s 不能为空
        unsafe { s.step() };
        let before = s;
        try_parse_8digits(&mut s, &mut mantissa);
        try_parse_digits(&mut s, &mut mantissa);
        n_after_dot = s.offset_from(&before);
        exponent = -n_after_dot as i64;
    }

    n_digits += n_after_dot;
    if n_digits == 0 {
        return None;
    }

    // 处理科学格式
    let mut exp_number = 0_i64;
    if s.first_is2(b'e', b'E') {
        // SAFETY: s 不能为空
        unsafe {
            s.step();
        }
        // 如果没有，我们在指数之后没有尾随数字，或者一个无效的浮点数。
        exp_number = parse_scientific(&mut s)?;
        exponent += exp_number;
    }

    let len = s.offset_from(&start) as _;

    // 处理多位数的罕见情况
    if n_digits <= 19 {
        return Some((Number { exponent, mantissa, negative, many_digits: false }, len));
    }

    n_digits -= 19;
    let mut many_digits = false;
    let mut p = digits_start;
    while p.first_is2(b'0', b'.') {
        // SAFETY: 由于 first_is2，p 不能为空
        unsafe {
            // '0' = b'.' + 2
            n_digits -= p.first_unchecked().saturating_sub(b'0' - 1) as isize;
            p.step();
        }
    }
    if n_digits > 0 {
        // 此时我们有超过 19 位有效数字，让我们再试一次
        many_digits = true;
        mantissa = 0;
        let mut s = digits_start;
        try_parse_19digits(&mut s, &mut mantissa);
        exponent = if mantissa >= MIN_19DIGIT_INT {
            // 大整数
            int_end.offset_from(&s)
        } else {
            // SAFETY: 下一个字节必须存在并且是 '.' 我们知道这是真的，因为我们之前有超过 19 位数字，所以我们溢出了一个 64 位整数，但只解析整数位产生少于 19 位数字。
            // 这意味着我们必须有一个小数点，并且至少有 1 个小数位。
            //
            //
            //
            //
            unsafe { s.step() };
            let before = s;
            try_parse_19digits(&mut s, &mut mantissa);
            -s.offset_from(&before)
        } as i64;
        // 添加回显式部分
        exponent += exp_number;
    }

    Some((Number { exponent, mantissa, negative, many_digits }, len))
}

/// 尝试解析一个非特殊的浮点数。
pub fn parse_number(s: &[u8], negative: bool) -> Option<Number> {
    if let Some((float, rest)) = parse_partial_number(s, negative) {
        if rest == s.len() {
            return Some(float);
        }
    }
    None
}

/// 解析特殊的非有限浮点数的部分表示。
fn parse_partial_inf_nan<F: RawFloat>(s: &[u8]) -> Option<(F, usize)> {
    fn parse_inf_rest(s: &[u8]) -> usize {
        if s.len() >= 8 && s[3..].as_ref().eq_ignore_case(b"inity") { 8 } else { 3 }
    }
    if s.len() >= 3 {
        if s.eq_ignore_case(b"nan") {
            return Some((F::NAN, 3));
        } else if s.eq_ignore_case(b"inf") {
            return Some((F::INFINITY, parse_inf_rest(s)));
        }
    }
    None
}

/// 尝试解析一个特殊的、非有限的浮点数。
pub fn parse_inf_nan<F: RawFloat>(s: &[u8], negative: bool) -> Option<F> {
    if let Some((mut float, rest)) = parse_partial_inf_nan::<F>(s) {
        if rest == s.len() {
            if negative {
                float = -float;
            }
            return Some(float);
        }
    }
    None
}