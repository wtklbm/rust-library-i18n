//! 可共享的可变容器。
//!
//! Rust 内存安全基于以下规则: 给定对象 `T`，则只能具有以下之一:
//!
//! - 对对象具有多个不可变引用 (`&T`) (也称为别名)。
//! - 对对象有一个可变引用 (`&mut T`) (也称为 **可变性**)。
//!
//! 这由 Rust 编译器强制执行。但是，在某些情况下，此规则不够灵活。有时需要对一个对象进行多次引用，然后对其进行可变的。
//!
//! 存在共享的可变容器以允许以受控的方式进行可变性，即使在出现混叠的情况下也是如此。[`Cell<T>`] 和 [`RefCell<T>`] 都允许以单线程方式执行此操作。
//! 但是，`Cell<T>` 和 `RefCell<T>` 都不是线程安全的 (它们不实现 [`Sync`])。
//! 如果需要在多个线程之间进行别名和可变的，则可以使用 [`Mutex<T>`]，[`RwLock<T>`] 或 [`atomic`] 类型。
//!
//! `Cell<T>` 和 `RefCell<T>` 类型的值可以通过共享引用 (例如
//! 常见的 `&T` 类型)，而大多数 Rust 类型只能通过唯一的 (`&mut T`) 引用进行可变的。
//! 我们说 `Cell<T>` 和 `RefCell<T>` 提供了内部可变性，而典型的 Rust 类型却表现出继承的可变性。
//!
//! Cell 类型有两种: `Cell<T>` 和 `RefCell<T>`。`Cell<T>` 通过将值移入和移出 `Cell<T>` 来实现内部可变性。
//! 要使用 quot 代替值，必须使用 `RefCell<T>` 类型，在可变之前获取一个写锁。`Cell<T>` 提供了检索和更改当前内部值的方法:
//!
//!  - 对于实现 [`Copy`] 的类型，[`get`](Cell::get) 方法检索当前内部值。
//!  - 对于实现 [`Default`] 的类型，[`take`](Cell::take) 方法将当前内部值替换为 [`Default::default()`]，然后返回替换后的值。
//!  - 对于所有类型，[`replace`](Cell::replace) 方法将替换当前内部值并返回替换后的值，而 [`into_inner`](Cell::into_inner) 方法将使用 `Cell<T>` 并返回内部值。
//!  此外，[`set`](Cell::set) 方法替换内部值，丢弃替换后的值。
//!
//! `RefCell<T>` 使用 Rust 的生命周期实现动态借用，这一过程使人们可以要求临时，排他，可变地访问内部值。
//! 借用 for`RefCell<T>s 是在` 运行时 ` 被跟踪的，这与 Rust 的原生引用类型不同，后者在编译时是完全静态跟踪的。
//! 由于 `RefCell<T>` 借用是动态的，因此可以尝试借用已经可变借用的值; 发生这种情况时，将导致线程 panic。
//!
//! # 何时选择内部可变性
//!
//! 更常见的继承的可变性 (其中必须具有对值的唯一访问权) 是使 Rust 能够强烈考虑指针别名的关键语言元素之一，从而可以静态地防止崩溃错误。
//! 因此，首选继承的可变性，而内部可变性则是不得已而为之。
//! 由于细胞类型可以实现原本不允许的可变的，因此有时可能需要内部可变性，甚至必须 *使用*
//!
//! * 介绍事物的可变性 'inside'
//! * 逻辑不可变方法的实现细节。
//! * 更改 [`Clone`] 的实现。
//!
//! ## 介绍事物的可变性 'inside'
//!
//! 许多共享的智能指针类型，包括 [`Rc<T>`] 和 [`Arc<T>`]，都提供了可以在多方之间克隆和共享的容器。
//! 由于所包含的值可能会被乘以别名，因此只能通过 `&` 借用，而不能通过 `&mut` 借用。
//! 没有单元，根本不可能在这些智能指针中对数据进行可变的。
//!
//! 然后将 `RefCell<T>` 放在共享指针类型中以重新引入可变性是很常见的:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // 创建一个新块以限制动态借用的作用域
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // 请注意，如果我们没有让缓存的上一次借用离开作用域，那么后续的借用将导致动态线程 panic。
//!     //
//!     // 这是使用 `RefCell` 的主要危险。
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! 请注意，此示例使用 `Rc<T>` 而不是 `Arc<T>`。`RefCell<T>`s 用于单线程方案。如果在多线程情况下需要共享可变性，请考虑使用 [`RwLock<T>`] 或 [`Mutex<T>`]。
//!
//! ## 逻辑不可变方法的实现细节
//!
//! 有时可能希望不要在 API 中公开 "under the hood" 发生了可变的。
//! 这可能是因为逻辑上该操作是不可变的，但是例如，缓存会强制实现执行可变的; 或因为必须使用可变来实现最初定义为采用 `&self` 的 trait 方法。
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // 昂贵的计算在这里
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## 改变 `Clone` 的实现
//!
//! 这只是前一种情况的一种特殊情况 - 但很常见 - 在看起来不可变的操作中隐藏了可变性。
//! 预期 [`clone`](Clone::clone) 方法不会更改源值，并声明采用 `&self`，而不是 `&mut self`。
//! 因此，在 `clone` 方法中发生的任何可变的都必须使用细胞类型。
//! 例如，[`Rc<T>`] 在 `Cell<T>` 内保持其引用计数。
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: crate::sync::atomic
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// 可变的内存位置。
///
/// # Examples
///
/// 在此示例中，您可以看到 `Cell<T>` 启用了不可变结构体内部的可变的。
/// 换句话说，它实现了内部可变性。
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERROR: `my_struct` 是不可变 my_struct.regular_field =new_value;
/////
///
/// // WORKS: 尽管 `my_struct` 是不可变的，但是 `special_field` 是 `Cell`，可以随时对其进行修改
/////
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// 有关更多信息，请参见 [module-level documentation](self)。
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// 创建一个 `Cell<T>`，其 T 值为 `Default`。
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// 创建一个包含给定值的新 `Cell`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.24.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// 设置包含的值。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// 交换两个 Cell 的值。
    /// 与 `std::mem::swap` 的区别在于此函数不需要 `&mut` 引用。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SAFETY: 如果从单独的线程中调用，可能会有风险，但是 `Cell` 是 `!Sync`，因此不会发生。
        // 这也不会使任何指针无效，因为 `Cell` 确保没有其他指针指向这些 `Cell` 中的任何一个。
        //
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// 用 `val` 替换包含的值，并返回旧的包含值。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SAFETY: 如果从单独的线程中调用，则可能导致数据竞争，但是 `Cell` 是 `!Sync`，因此不会发生。
        //
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// 取消包装的值。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// 返回所包含值的副本。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SAFETY: 如果从单独的线程中调用，则可能导致数据竞争，但是 `Cell` 是 `!Sync`，因此不会发生。
        //
        unsafe { *self.value.get() }
    }

    /// 使用函数更新包含的值并返回新值。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// 返回此 cell 中基础数据的裸指针。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// 返回对基础数据的可变引用。
    ///
    /// 这个调用借用 `Cell` 是可变的 (在编译时)，这保证了我们拥有唯一的引用。
    ///
    /// 但是要小心: 此方法要求 `self` 为附属 0，而使用 `Cell` 时通常不是这种情况。
    /// 如果您需要通过引用进行内部养性，可以考虑使用 `RefCell`，它通过其 [`borrow_mut`] 方法提供运行时检查的附属借用。
    ///
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// 从 `&mut T` 返回 `&Cell<T>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SAFETY: `&mut` 确保唯一访问。
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// 获取 cell 的值，将 `Default::default()` 保留在其位置。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// 从 `&Cell<[T]>` 返回 `&[Cell<T>]`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SAFETY: `Cell<T>` 具有与 `T` 相同的内存布局。
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// 具有动态检查借用规则的可变内存位置
///
/// 有关更多信息，请参见 [module-level documentation](self)。
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    // 存储当前最早活动借用的位置。
    // 每当我们从零借用变为单一借用时，这个就会更新。
    // 当借用发生时，这将包含在生成的 `BorrowError/`BorrowMutError` 中
    //
    #[cfg(feature = "debug_refcell")]
    borrowed_at: Cell<Option<&'static crate::panic::Location<'static>>>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] 返回的错误。
#[stable(feature = "try_borrow", since = "1.13.0")]
#[non_exhaustive]
pub struct BorrowError {
    #[cfg(feature = "debug_refcell")]
    location: &'static crate::panic::Location<'static>,
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut builder = f.debug_struct("BorrowError");

        #[cfg(feature = "debug_refcell")]
        builder.field("location", self.location);

        builder.finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] 返回的错误。
#[stable(feature = "try_borrow", since = "1.13.0")]
#[non_exhaustive]
pub struct BorrowMutError {
    #[cfg(feature = "debug_refcell")]
    location: &'static crate::panic::Location<'static>,
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut builder = f.debug_struct("BorrowMutError");

        #[cfg(feature = "debug_refcell")]
        builder.field("location", self.location);

        builder.finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// 正值表示 `Ref` 有效的数量。负值表示 `RefMut` 活动的数量。
// 如果多个 `RefMut` 引用 `RefCell` 的不同，不重叠的组件 (例如，切片的不同范围)，则一次只能处于活动状态。
//
// `Ref` 和 `RefMut` 都是两个字，因此可能不会有足够的 `Ref` 或 `RefMut` 来溢出 `usize` 范围的一半。
// 因此，`BorrowFlag` 可能永远不会上溢或下溢。
// 但是，这并不是保证，因为 pathological 程序可能会反复创建，然后 mem::forget Ref 或 `RefMut`。
// 因此，所有代码都必须显式检查上溢和下溢，以避免不安全，或者至少在发生上溢或下溢的情况下正确运行 (例如，参见 BorrowRef::new)。
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// 创建一个包含 `value` 的新 `RefCell`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.24.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell {
            value: UnsafeCell::new(value),
            borrow: Cell::new(UNUSED),
            #[cfg(feature = "debug_refcell")]
            borrowed_at: Cell::new(None),
        }
    }

    /// 消耗 `RefCell`，返回包装的值。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // 由于此函数按值取 `self` (`RefCell`)，因此编译器将静态验证其当前未借用。
        //
        self.value.into_inner()
    }

    /// 将包装的值替换为新的值，并返回老的值，而无需对其中一个进行初始化。
    ///
    ///
    /// 该函数对应于 [`std::mem::replace`](../mem/fn.replace.html)。
    ///
    /// # Panics
    ///
    /// 如果当前的值是借来的，就会出现 panic。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// 用从 `f` 计算出的新值替换包装后的值，并返回旧值，而无需对这两个值进行任何初始化。
    ///
    ///
    /// # Panics
    ///
    /// 如果当前的值是借来的，就会出现 panic。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// 将 `self` 的包装值与 `other` 的包装值交换，而无需对其中之一进行初始化。
    ///
    ///
    /// 该函数对应于 [`std::mem::swap`](../mem/fn.swap.html)。
    ///
    /// # Panics
    ///
    /// 如果当前借用了任一 `RefCell` 中的值，则会出现 panic。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// 不变地借用包装的值。
    ///
    /// 借用一直持续到返回的 `Ref` 退出角色域为止。
    /// 可以同时取出多个不可变借用。
    ///
    /// # Panics
    ///
    /// 如果值当前是可变借用的，则出现 panic。
    /// 对于没有 panic 的成员，请使用 [`try_borrow`](#method.try_borrow)。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic 的示例:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // 这导致 panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// 不可变地借用包装的值，如果当前可变地借用该值，则返回错误。
    ///
    ///
    /// 借用一直持续到返回的 `Ref` 退出角色域为止。
    /// 可以同时取出多个不可变借用。
    ///
    /// 这是 [`borrow`](#method.borrow) 的没有 panic 的成员。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    #[cfg_attr(feature = "debug_refcell", track_caller)]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            Some(b) => {
                #[cfg(feature = "debug_refcell")]
                {
                    // `borrowed_at` 总是第一个主动借用
                    if b.borrow.get() == 1 {
                        self.borrowed_at.set(Some(crate::panic::Location::caller()));
                    }
                }

                // SAFETY: `BorrowRef` 确保借用时只能不可变地访问该值。
                //
                Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b })
            }
            None => Err(BorrowError {
                // 如果发生借用，那么我们肯定已经有一个未偿还的借用，所以 `borrowed_at` 就是 `Some`
                //
                #[cfg(feature = "debug_refcell")]
                location: self.borrowed_at.get().unwrap(),
            }),
        }
    }

    /// 可以借用包装的值。
    ///
    /// 借用一直持续到返回的 `RefMut` 或从中衍生的所有 `RefMut` 退出作用域为止。
    ///
    /// 该借用处于活动状态时，不能借用该值。
    ///
    /// # Panics
    ///
    /// 如果当前的值是借来的，就会出现 panic。
    /// 对于没有 panic 的成员，请使用 [`try_borrow_mut`](#method.try_borrow_mut)。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic 的示例:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // 这导致 panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// 可变地借用包装的值，如果当前借用该值，则返回错误。
    ///
    ///
    /// 借用一直持续到返回的 `RefMut` 或从中衍生的所有 `RefMut` 退出作用域为止。
    /// 该借用处于活动状态时，不能借用该值。
    ///
    /// 这是 [`borrow_mut`](#method.borrow_mut) 的没有 panic 的成员。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    #[cfg_attr(feature = "debug_refcell", track_caller)]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            Some(b) => {
                #[cfg(feature = "debug_refcell")]
                {
                    self.borrowed_at.set(Some(crate::panic::Location::caller()));
                }

                // SAFETY: `BorrowRef` 保证唯一访问。
                Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b })
            }
            None => Err(BorrowMutError {
                // 如果发生借用，那么我们肯定已经有一个未偿还的借用，所以 `borrowed_at` 就是 `Some`
                //
                #[cfg(feature = "debug_refcell")]
                location: self.borrowed_at.get().unwrap(),
            }),
        }
    }

    /// 返回此 cell 中基础数据的裸指针。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// 返回对基础数据的可变引用。
    ///
    /// 该调用借用 `RefCell` 是可变的 (在编译时)，因此不需要动态检查。
    ///
    /// 但是要小心: 此方法期望 `self` 是可变的，使用 `RefCell` 时通常不是这种情况。
    ///
    /// 如果 `self` 不是可变的，请查看 [`borrow_mut`] 方法。
    ///
    /// 另外，请注意，此方法仅适用于特殊情况，通常不是您想要的。
    /// 如有疑问，请改用 [`borrow_mut`]。
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// 撤消泄漏的守卫对 `RefCell` 借用状态的影响。
    ///
    /// 该调用与 [`get_mut`] 相似，但更加专业。
    /// 它借用 `RefCell` 以确保不存在借用，然后重置状态跟踪共享借用。
    /// 如果某些 `Ref` 或 `RefMut` 借用已泄漏，则这是相关的。
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// 不可变地借用包装的值，如果当前可变地借用该值，则返回错误。
    ///
    /// # Safety
    ///
    /// 与 `RefCell::borrow` 不同，此方法是不安全的，因为它不返回 `Ref`，从而使借用标志保持不变。
    /// 当此方法返回的引用仍然有效时，借用 `RefCell` 是未定义的行为。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SAFETY: 我们检查现在没有人在主动写入，但是调用者有责任确保没有人写入，直到返回的引用不再使用。
            //
            // 同样，`self.value.get()` 是指 `self` 拥有的值，因此可以保证对于 `self` 的生命周期有效。
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError {
                // 如果发生借用，那么我们肯定已经有一个未偿还的借用，所以 `borrowed_at` 就是 `Some`
                //
                #[cfg(feature = "debug_refcell")]
                location: self.borrowed_at.get().unwrap(),
            })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// 获取包装的值，将 `Default::default()` 留在其位置。
    ///
    /// # Panics
    ///
    /// 如果当前的值是借来的，就会出现 panic。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// 如果值当前是可变借用的，则出现 panic。
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }

    /// # Panics
    ///
    /// 如果当前 `other` 是可变借用的，则会 panic。
    #[inline]
    #[track_caller]
    fn clone_from(&mut self, other: &Self) {
        self.get_mut().clone_from(&other.borrow())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// 创建一个 `RefCell<T>`，其 T 值为 `Default`。
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// 如果当前借用了任一 `RefCell` 中的值，则会出现 panic。
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// 如果当前借用了任一 `RefCell` 中的值，则会出现 panic。
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// 如果当前借用了任一 `RefCell` 中的值，则会出现 panic。
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// 如果当前借用了任一 `RefCell` 中的值，则会出现 panic。
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// 如果当前借用了任一 `RefCell` 中的值，则会出现 panic。
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// 如果当前借用了任一 `RefCell` 中的值，则会出现 panic。
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// 如果当前借用了任一 `RefCell` 中的值，则会出现 panic。
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // 在以下情况下，增加借用可能会导致未读值 (<= 0):
            // 1. 它小于 0，即正在写借用，因此由于 Rust 的引用别名规则，我们不允许读取借用
            // 2.
            // 它是 isize::MAX (最大读取借用量)，并且溢出到 isize::MIN (最大写入借用量) 中，因此我们不允许额外的读取借用，因为 isize 不能表示那么多读取借用 (这只能在以下情况下发生: 您的 mem::forget 大于常量的少量常量，这不是很好的做法)
            //
            //
            //
            //
            None
        } else {
            // 在以下情况下，增加借用可能会导致读取值 (> 0) :
            // 1. 它是 = 0，即它不是借来的，我们正在获取第一个 read 借用
            // 2. 它是 > 0 且 < isize::MAX，即
            // 有 read 借用，并且 isize 足够大，可以代表再有一次 read 借用
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // 由于该 Ref 存在，因此我们知道借用标志是 reading 借用。
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // 防止借用计数器溢出到 writing 借用中。
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// 在 `RefCell` box 中将借用的引用括起来。
/// 从 `RefCell<T>` 不变借来的值的包装器类型。
///
/// 有关更多信息，请参见 [module-level documentation](self)。
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// 复制 `Ref`。
    ///
    /// `RefCell` 已经被不可改变地借用了，因此这不会失败。
    ///
    /// 这是一个关联函数，需要用作 `Ref::clone(...)`。
    /// `Clone` 的实现或方法将干扰 `r.borrow().clone()` 的广泛使用，以克隆 `RefCell` 的内容。
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// 为借用数据的组件制作新的 `Ref`。
    ///
    /// `RefCell` 已经被不可改变地借用了，因此这不会失败。
    ///
    /// 这是一个关联函数，需要用作 `Ref::map(...)`。
    /// 方法会干扰通过 `Deref` 使用的 `RefCell` 内容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// 为借用数据的可选组件制作新的 `Ref`。
    /// 如果闭包返回 `None`，则原始守卫将作为 `Err(..)` 返回。
    ///
    /// `RefCell` 已经被不可改变地借用了，因此这不会失败。
    ///
    /// 这是一个关联函数，需要用作 `Ref::filter_map(...)`。
    /// 方法会干扰通过 `Deref` 使用的 `RefCell` 内容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// 将 `Ref` 拆分为多个 `Ref`，以用于借用数据的不同组成部分。
    ///
    /// `RefCell` 已经被不可改变地借用了，因此这不会失败。
    ///
    /// 这是一个关联函数，需要用作 `Ref::map_split(...)`。
    /// 方法会干扰通过 `Deref` 使用的 `RefCell` 内容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// 转换为对基础数据的引用。
    ///
    /// 底层的 `RefCell` 永远不会再被可变借用，并且总是看起来已经是不可更改的借用。
    ///
    /// 泄漏超过一定数量的引用不是一个好主意。
    /// 如果总共只发生了少量的泄漏，则可以再次借用 `RefCell`。
    ///
    /// 这是一个关联函数，需要用作 `Ref::leak(...)`。
    /// 方法会干扰通过 `Deref` 使用的 `RefCell` 内容中的同名方法。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // 通过忘记此引用，我们确保 RefCell 中的借用计数器不会返回到生命周期 `'b` 中的未使用状态。
        // 重置引用跟踪状态将需要对借用的 RefCell 进行唯一引用。
        // 无法从原始 cell 创建更多的可变引用。
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// 为借用数据的一部分 (例如枚举成员) 创建一个新的 `RefMut`。
    ///
    /// `RefCell` 已经是可变借用的，因此这不会失败。
    ///
    /// 这是一个关联函数，需要用作 `RefMut::map(...)`。
    /// 方法会干扰通过 `Deref` 使用的 `RefCell` 内容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): 修复借用检查
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// 为借用数据的可选组件制作新的 `RefMut`。
    /// 如果闭包返回 `None`，则原始守卫将作为 `Err(..)` 返回。
    ///
    /// `RefCell` 已经是可变借用的，因此这不会失败。
    ///
    /// 这是一个关联函数，需要用作 `RefMut::filter_map(...)`。
    /// 方法会干扰通过 `Deref` 使用的 `RefCell` 内容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): 修复借用检查
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SAFETY: 在通过 `orig` 进行调用的过程中，函数将保留排他引用，并且仅在函数调用内部取消对指针的引用，而永不允许对排他引用进行转义。
        //
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SAFETY: 与上述相同。
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// 将 `RefMut` 拆分为多个 `RefMut`，以用于借用数据的不同组成部分。
    ///
    /// 底层 `RefCell` 将保持可变借用状态，直到两个返回的 RefMut 离开作用域。
    ///
    /// `RefCell` 已经是可变借用的，因此这不会失败。
    ///
    /// 这是一个关联函数，需要用作 `RefMut::map_split(...)`。
    /// 方法会干扰通过 `Deref` 使用的 `RefCell` 内容中的同名方法。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// 转换为基础数据的可变引用。
    ///
    /// 基础 `RefCell` 不能再次借用，并且总是看起来已经可变地借用了，从而使返回的引用成为内部的唯一方法。
    ///
    ///
    /// 这是一个关联函数，需要用作 `RefMut::leak(...)`。
    /// 方法会干扰通过 `Deref` 使用的 `RefCell` 内容中的同名方法。
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // 通过忘记此 BorrowRefMut，我们确保 RefCell 中的借用计数器不能在生命周期 `'b` 内返回未使用状态。
        // 重置引用跟踪状态将需要对借用的 RefCell 进行唯一引用。
        // 无法从该生命周期内的原始 cell 中创建更多引用，从而使当前借用成为剩余生命周期的唯一引用。
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: 与 BorrowRefMut::clone 不同，调用 new 来创建初始变量引用，因此当前必须不存在引用。
        // 因此，尽管克隆增加了可变引用计数，但在这里我们明确只允许从 UNUSED 到 UNUSED-1。
        //
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // 克隆 `BorrowRefMut`。
    //
    // 仅当每个 `BorrowRefMut` 用于跟踪变量引用到原始对象的不同的，不重叠的范围时，此方法才有效。
    //
    // 这不在 Clone 隐含中，因此代码不会隐式调用此代码。
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // 防止借用计数器下溢。
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// 从 `RefCell<T>` 可变借来的值的包装器类型。
///
/// 有关更多信息，请参见 [module-level documentation](self)。
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust 中内部可变性的核心原语。
///
/// 如果您使用的是 `&T`，则通常在 Rust 中，编译器基于 `&T` 指向不可变数据的知识来执行优化。例如通过别名或通过将 `&T` 转换为 `&mut T` 来可变的该数据，被认为是未定义的行为。
/// `UnsafeCell<T>` 选择不使用 `&T` 的不可替代保证: 共享的 `&UnsafeCell<T>` 可能指向正在可变的的数据。这称为内部可变性。
///
/// 所有其他允许内部可变性的类型 (例如 `Cell<T>` 和 `RefCell<T>`) 在内部都使用 `UnsafeCell` 封装其数据。
///
/// 请注意，仅 `UnsafeCell` 会影响共享引证的不可变性保证。可变引用的唯一性保证不受影响。没有合法的方法来获得 `&mut` 的别名，即使使用 `UnsafeCell<T>` 也没有。
///
/// `UnsafeCell` API 本身在技术上非常简单: [`.get()`] 为其内容提供了裸指针 `*mut T`。正确使用该裸指针取决于您。
///
/// [`.get()`]: `UnsafeCell::get`
///
/// 精确的 Rust 别名规则有些变化，但是要点并不存在争议:
///
/// - 如果使用生命周期 `'a` (`&T` 或 `&mut T` 引用) 创建可以通过安全代码访问的安全引用 (例如，由于返回了它)，则不得以任何与该引用的引用相矛盾的方式访问数据 `'a` 的其余部分。
/// 例如，这意味着如果您从 `UnsafeCell<T>` 中取出 `*mut T` 并将其转换为 `&T`，则 `T` 中的数据必须保持不可变 (当然，对 `T` 中找到的任何 `UnsafeCell` 数据取模)，直到引用的生命周期到期为止。
/// 同样，如果您创建的 `&mut T` 引用已发布为安全代码，则在引用终止之前，您不得访问 `UnsafeCell` 中的数据。
///
/// - 在任何时候，您都必须避免数据竞争。如果多个线程可以访问同一个 `UnsafeCell`，那么任何写操作都必须在与所有其他访问 (或使用原子) 相关之前发生正确的事件。
///
/// 为了帮助进行正确的设计，以下情况明确声明为单线程代码合法:
///
/// 1. `&T` 引用可以释放为安全代码，并且可以与其他 `&T` 引用共存，但不能与 `&mut T` 共存
///
/// 2. `&mut T` 引用可以发布为安全代码，前提是其他 `&mut T` 和 `&T` 都不共存。`&mut T` 必须始终是唯一的。
///
/// 请注意，虽然可以更改 `&UnsafeCell<T>` 的内容 (即使其他 `&UnsafeCell<T>` 引用了该 cell 的别名) 也可以 (只要以其他方式实现上述不变式即可)，但是具有多个 `&mut UnsafeCell<T>` 别名仍然是未定义的行为。
/// 也就是说，`UnsafeCell` 是一个包装器，旨在通过 `&UnsafeCell<_>` 与 _shared_ accesses (_i.e._ 进行特殊交互 (引用) ; 通过 `&mut UnsafeCell<_>` 处理 _exclusive_ accesses (_e.g._ 时没有任何魔术) : 在该 `&mut` 借用期间， cell 和包装值都不能被别名。
///
/// [`.get_mut()`] 访问器展示了这一点，该访问器是产生 `&mut T` 的 _safe_ getter。
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// 这是一个示例，展示了如何对 `UnsafeCell<_>` 的内容进行合理的可变的，尽管该单元存在多个引用别名:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // 对同一个 `x` 获取多个 / 并发 / 共享引用。
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SAFETY: 在此作用域内，对 x 的内容没有其他引用，因此我们的内容实际上是唯一的。
/////
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- 借用 --+
///     *p1_exclusive += 27; // |
/// } // <---------- 不能超出这一点 --- ----------------+
///
/// unsafe {
///     // SAFETY: 在此作用域内，没有人期望对 x 的内容具有独占访问权，因此我们可以同时进行多个共享访问。
/////
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// 以下示例展示了对 `UnsafeCell<T>` 的独占访问意味着对其 `T` 的独占访问的事实:
///
/// ```rust
/// #![forbid(unsafe_code)] // 具有独占访问权，
///                         // `UnsafeCell` 是透明的无操作包装器，因此这里不需要 `unsafe`。
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // 获得对 `x` 进行编译时检查的唯一引用。
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // 使用独家引用，我们可以免费更改内容。
/// *p_unique.get_mut() = 0;
/// // 或者，等效地:
/// x = UnsafeCell::new(0);
///
/// // 当我们拥有该值时，我们可以免费提取内容。
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// 创建 `UnsafeCell` 的新实例，该实例将包装指定的值。
    ///
    ///
    /// 通过方法对内部值的所有访问都是 `unsafe`。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline(always)]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// 取消包装的值。
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline(always)]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// 获取指向包装值的可变指针。
    ///
    /// 可以将其强制转换为任何类型的指针。
    /// 强制转换为 `&mut T` 时，访问是唯一的 (无活动的引用，可变或不活动)，并确保转换为 `&T` 时没有发生任何可变的或可变别名。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline(always)]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // 由于 #[repr(transparent)]，我们只能将指针从 `UnsafeCell<T>` 转换为 `T`。
        // 这利用了 libstd 的特殊状态，无法保证用户代码可以在 future 版本的编译器中正常工作!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// 返回对基础数据的可变引用。
    ///
    /// 这个调用借用 `UnsafeCell` (在编译时) 是可变的，这保证了我们拥有唯一的引用。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline(always)]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// 获取指向包装值的可变指针。
    /// 与 [`get`] 的不同之处在于此函数接受裸指针，这对于避免创建临时引用很有用。
    ///
    /// 结果可以转换为任何类型的指针。
    /// 强制转换为 `&mut T` 时，访问是唯一的 (无活动的引用，可变性或非活动性)，并确保转换为 `&T` 时没有发生任何可变的或可变别名。
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` 的逐步初始化需要 `raw_get`，因为调用 `get` 需要对未初始化的数据创建引用:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline(always)]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // 由于 #[repr(transparent)]，我们只能将指针从 `UnsafeCell<T>` 转换为 `T`。
        // 这利用了 libstd 的特殊状态，无法保证用户代码可以在 future 版本的编译器中正常工作!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// 创建一个 `UnsafeCell`，其 T 值为 `Default`。
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}