//! 为 *emscripten* 目标展开。
//!
//! Rust 的 Unix 平台通常的展开实现直接调用 libunwind API，而在 Emscripten 上，我们改为调用 C++ 展开 API。
//! 这只是一种权宜之计，因为 Emscripten 的运行时始终实现那些 API，而不实现 libunwind。
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// 这与 C++ 中 std::type_info 的布局匹配
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // 这里的前导 `\x01` 字节实际上是向 LLVM 发出的神奇信号，*不* 应用任何其他操作，例如以 `_` 字符作为前缀。
    //
    //
    // 此符号是 C++ `std::type_info` 使用的 vtable。
    // `std::type_info` 类型的对象 (类型描述符) 具有指向此表的指针。
    // 类型描述符由上面定义的 C++ EH 结构引用，并在下面构造。
    //
    // 请注意，实际大小大于 3 usize，但是我们只需要 vtable 指向第三个元素。
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info 对于 rust_panic 类
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // 通常我们会使用.as_ptr ()。add (2)，但这在 const 上下文中不起作用。
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // 因为我们不希望 C++ 能够产生或捕获 Rust panics，所以这有意不使用普通名称处理方案。
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // 这是必需的，因为 C++ 代码可以使用 std::exception_ptr 捕获我们的执行并将其重新抛出多次，甚至可能在另一个线程中也是如此。
    //
    //
    caught: AtomicBool,

    // 这必须是一个选项，因为对象的生命周期遵循 C++ 语义：当 catch_unwind 将 Box 移出异常时，它仍必须保持异常对象处于有效状态，因为它的析构函数仍将由 __cxa_end_catch 调用。
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try 实际上为我们提供了一个指向该结构体的指针。
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // 由于不允许将 cleanup() 用作 panic，因此我们只需终止。
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}
