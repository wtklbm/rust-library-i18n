use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// 拥有和自包含的回溯的表示形式。
///
/// 此结构体可用于捕获程序中各个点的回溯，然后用于检查当时的回溯。
///
///
/// `Backtrace` 通过 `Debug` 实现支持回溯的漂亮打印。
///
/// # 必备功能
///
/// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // 此处的帧从栈的顶部到底部列出
    frames: Vec<BacktraceFrame>,
    // 我们认为索引是回溯的实际开始，省略了 `Backtrace::new` 和 `backtrace::trace` 之类的框架。
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// 回溯中帧的捕获版本。
///
/// 从 `Backtrace::frames` 作为列表返回此类型，它表示捕获的回溯中的一个栈帧。
///
/// # 必备功能
///
/// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// 回溯中捕获的符号版本。
///
/// 此类型从 `BacktraceFrame::symbols` 作为列表返回，并表示回溯中符号的元数据。
///
/// # 必备功能
///
/// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// 在此函数的调用位置捕获回溯，并返回一个拥有的表示形式。
    ///
    /// 此函数对于将回溯表示为 Rust 中的对象很有用。此返回值可以跨线程发送并在其他位置打印，并且该值的目的是完全独立的。
    ///
    /// 请注意，在某些平台上，获取完整的回溯并加以解决可能非常昂贵。
    /// 如果对您的应用程序来说成本太高，建议改用 `Backtrace::new_unresolved()`，它避免了符号解析步骤 (通常花费最长的时间)，并允许将其推迟到以后的日期。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // 要确保这里有一个框架要删除
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// 与 `new` 相似，除了它不解析任何符号外，它仅将回溯捕获为地址列表。
    ///
    /// 在以后的时间，可以调用 `resolve` 函数来将回溯的符号解析为可读的名称。
    /// 此函数之所以存在，是因为解析过程有时会花费大量时间，而任何一个回溯都可能很少打印。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // 没有符号名称
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // 现在显示符号名称
    /// ```
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    ///
    ///
    #[inline(never)] // 要确保这里有一个框架要删除
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// 返回捕获此回溯时的帧。
    ///
    /// 该切片的第一个条目可能是函数 `Backtrace::new`，而最后一帧则可能与此线程或主函数的启动方式有关。
    ///
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// 如果此回溯是从 `new_unresolved` 创建的，则此函数会将回溯中的所有地址解析为其符号名称。
    ///
    ///
    /// 如果此回溯先前已解决或通过 `new` 创建，则此函数不执行任何操作。
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl From<crate::Frame> for BacktraceFrame {
    fn from(frame: crate::Frame) -> BacktraceFrame {
        BacktraceFrame {
            frame: Frame::Raw(frame),
            symbols: None,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// 与 `Frame::ip` 相同
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// 与 `Frame::symbol_address` 相同
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// 与 `Frame::module_base_address` 相同
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// 返回此框架对应的符号列表。
    ///
    /// 通常，每帧只有一个符号，但是有时如果将多个函数内联到一个帧中，则会返回多个符号。
    /// 列出的第一个符号是最内层的函数，而最后一个符号是最外面的 (最后一个调用者)。
    ///
    /// 请注意，如果此框架来自未解决的回溯，则将返回一个空列表。
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// 与 `Symbol::name` 相同
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// 与 `Symbol::addr` 相同
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// 与 `Symbol::filename` 相同
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// 与 `Symbol::lineno` 相同
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// 与 `Symbol::colno` 相同
    ///
    /// # 必备功能
    ///
    /// 此函数需要启用 `backtrace` crate 的 `std` 功能，并且默认情况下启用 `std` 功能。
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // 在打印路径时，我们尝试剥离 cwd (如果存在)，否则我们仅按原样打印路径。
        // 请注意，我们也只对短格式执行此操作，因为如果已写满，则可能要打印所有内容。
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_frame_conversion() {
        let mut frames = vec![];
        crate::trace(|frame| {
            let converted = BacktraceFrame::from(frame.clone());
            frames.push(converted);
            true
        });

        let mut manual = Backtrace::from(frames);
        manual.resolve();
        let frames = manual.frames();

        for frame in frames {
            println!("{:?}", frame.ip());
            println!("{:?}", frame.symbol_address());
            println!("{:?}", frame.module_base_address());
            println!("{:?}", frame.symbols());
        }
    }
}
