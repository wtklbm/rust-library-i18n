//! 展示字符 {}

use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` 可以具有的最高有效代码点。
    ///
    /// `char` 是 [Unicode 标量值][Unicode Scalar Value]，这意味着它是 [代码点][Code Point]，但仅在一定范围内。
    /// `MAX` 是有效 [Unicode 标量值][Unicode Scalar Value] 的最高有效代码点。
    ///
    /// [Unicode Scalar Value]: https://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: https://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () 在 Unicode 中用于表示解码错误。
    ///
    /// 例如，当将格式错误的 UTF-8 字节提供给 [`String::from_utf8_lossy`](../std/string/struct.String.html#method.from_utf8_lossy) 时，就会发生这种情况。
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char` 和 `str` 方法的 Unicode 部分所基于的 [Unicode](https://www.unicode.org/) 版本。
    ///
    /// Unicode 的新版本会定期发布，随后会更新标准库中取决于 Unicode 的所有方法。
    /// 因此，某些 `char` 和 `str` 方法的行为以及该常量的值会随时间变化。
    /// 这不是一个突破性的改变。
    ///
    /// 版本编号方案在 [Unicode 11.0 或更高版本，第 3.1 节 Unicode 标准版本](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) 中进行了说明。
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// 在 `iter` 中的 UTF-16 编码的代码点上创建一个迭代器，将不成对的代理返回为 `Err`s。
    ///
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v)
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// 通过用替换字符替换 `Err` 结果，可以获得有损解码器:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v)
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// 将 `u32` 转换为 `char`。
    ///
    /// 请注意，所有的 `char`s 都是有效的 [`u32`]，并且可以使用以下命令将其强制转换为 1
    /// [`as`](../std/keyword.as.html):
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// 但是，相反的情况并非如此：并非所有有效的 [u32] 都是有效的 char。
    /// `from_u32()` 如果输入的值不是 `char` 的有效值，则将返回 `None`。
    ///
    /// 有关忽略这些检查的该函数的不安全版本，请参见 [`from_u32_unchecked`]。
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// 当输入不是有效的 `char` 时返回 `None`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[must_use]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// 将 `u32` 转换为 `char`，而忽略有效性。
    ///
    /// 请注意，所有的 `char`s 都是有效的 [`u32`]，并且可以使用以下命令将其强制转换为 1
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// 但是，相反的情况并非如此：并非所有有效的 [u32] 都是有效的 char。
    /// `from_u32_unchecked()` 会忽略这一点，并盲目地将其强制转换为 `char`，从而可能创建无效的 `char`。
    ///
    ///
    /// # Safety
    ///
    /// 该函数是不安全的，因为它可能创建无效的 `char` 值。
    ///
    /// 有关此函数的安全版本，请参见 [`from_u32`] 函数。
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[must_use]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SAFETY: 调用者必须坚持安全保证。
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// 将给定基数中的数字转换为 `char`。
    ///
    /// 这里的 'radix' 有时也称为 'base'。
    /// 基数 2 表示二进制数，以十进制表示的十进制，以十六进制表示十六进制的基数，以给出一些公共值。
    ///
    /// 支持任意基数。
    ///
    /// `from_digit()` 如果输入不是给定基数中的数字，则将返回 `None`。
    ///
    /// # Panics
    ///
    /// Panics (如果基数大于 36)。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // 十进制 11 是以 16 为底的一位数字
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// 当输入不是数字时返回 `None`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// 传递较大的基数，导致 panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // 这个 panics
    /// let _c = char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[must_use]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// 检查 `char` 是否为给定基数中的数字。
    ///
    /// 这里的 'radix' 有时也称为 'base'。
    /// 基数 2 表示二进制数，以十进制表示的十进制，以十六进制表示十六进制的基数，以给出一些公共值。
    ///
    /// 支持任意基数。
    ///
    /// 与 [`is_numeric()`] 相比，此函数仅识别字符 `0-9`，`a-z` 和 `A-Z`。
    ///
    /// 'Digit' 被定义为仅以下字符:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 要更全面地了解 'digit'，请参见 [`is_numeric()`]。
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics (如果基数大于 36)。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// 传递较大的基数，导致 panic:
    ///
    /// ```should_panic
    /// // 这个 panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// 将 `char` 转换为给定基数的数字。
    ///
    /// 这里的 'radix' 有时也称为 'base'。
    /// 基数 2 表示二进制数，以十进制表示的十进制，以十六进制表示十六进制的基数，以给出一些公共值。
    ///
    /// 支持任意基数。
    ///
    /// 'Digit' 被定义为仅以下字符:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// 如果 `char` 未引用给定基数中的数字，则返回 `None`。
    ///
    /// # Panics
    ///
    /// Panics (如果基数大于 36)。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// 传递非数字会导致失败:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// 传递较大的基数，导致 panic:
    ///
    /// ```should_panic
    /// // 这个 panics
    /// let _ = '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "this returns the result of the operation, \
                  without modifying the original"]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // 如果不是数字，则将创建一个大于基数的数字。
        let mut digit = (self as u32).wrapping_sub('0' as u32);
        if radix > 10 {
            if digit < 10 {
                return Some(digit);
            }
            // 强制设置第 6 位以确保 ascii 是小写的。
            digit = (self as u32 | 0b10_0000).wrapping_sub('a' as u32).saturating_add(10);
        }
        (digit < radix).then_some(digit)
    }

    /// 返回一个迭代器，该迭代器将字符的十六进制 Unicode 转义生成为 `char`s。
    ///
    /// 这将使用 `\u{NNNNNN}` 格式的 Rust 语法对字符进行转义，其中 `NNNNNN` 是十六进制表示形式。
    ///
    ///
    /// # Examples
    ///
    /// 作为迭代器:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// 两者都等同于:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// 使用 [`to_string`](../std/string/trait.ToString.html#tymethod.to_string):
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[must_use = "this returns the escaped char as an iterator, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 确保在 c == 0 时代码计算出应该打印一位，并且 (相同) 避免 (31-32) 下溢
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // 最高有效十六进制数字的索引
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug` 的扩展版本，可选择允许转义扩展字素代码点、单引号和双引号。
    /// 这允许我们在字符串开头时更好地格式化像非空格标记这样的字符，并允许转义字符中的单引号和字符串中的双引号。
    ///
    ///
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, args: EscapeDebugExtArgs) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' => EscapeDefaultState::Backslash(self),
            '"' if args.escape_double_quote => EscapeDefaultState::Backslash(self),
            '\'' if args.escape_single_quote => EscapeDefaultState::Backslash(self),
            _ if args.escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// 返回一个迭代器，该迭代器将字符的字面量转义码生成为 `char`s。
    ///
    /// 这将转义类似于 `str` 或 `char` 的 [`Debug`](core::fmt::Debug) 实现的字符。
    ///
    ///
    /// # Examples
    ///
    /// 作为迭代器:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// 两者都等同于:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// 使用 [`to_string`](../std/string/trait.ToString.html#tymethod.to_string):
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[must_use = "this returns the escaped char as an iterator, \
                  without modifying the original"]
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(EscapeDebugExtArgs::ESCAPE_ALL)
    }

    /// 返回一个迭代器，该迭代器将字符的字面量转义码生成为 `char`s。
    ///
    /// 选择默认值时会偏向于生成在多种语言 (包括 C++ 11 和类似的 C 系列语言) 中都合法的字面量。
    /// 确切的规则是:
    ///
    /// * 制表符被转义为 `\t`。
    /// * 回车符被转义为 `\r`。
    /// * 换行符转为 `\n`。
    /// * 单引号转义为 `\'`。
    /// * 双引号转义为 `\"`。
    /// * 反斜杠转义为 `\\`。
    /// * `可打印 ASCII` 范围 `0x20` .. 中的任何字符 `0x7e` (含 `0x7e`) 不会转义。
    /// * 所有其他字符均使用十六进制 Unicode 转义; 请参见 [`escape_unicode`]。
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// 作为迭代器:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// 两者都等同于:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// 使用 [`to_string`](../std/string/trait.ToString.html#tymethod.to_string):
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[must_use = "this returns the escaped char as an iterator, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// 返回以 UTF-8 编码时此 `char` 所需的字节数。
    ///
    /// 该字节数始终在 1 到 4 之间 (含 1 和 4)。
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` 类型保证其内容为 UTF-8，因此我们可以比较将每个代码点表示为 `char` 相对于 `&str` 本身所花费的长度:
    ///
    ///
    /// ```
    /// // 作为字符
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // 两者都可以表示为三个字节
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // 作为 &str，这两个编码为 UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // 我们可以看到它们总共占用了六个字节...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... 就像 &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// 返回以 UTF-16 编码时 `char` 所需的 16 位代码单元的数量。
    ///
    ///
    /// 有关此概念的更多说明，请参见 [`len_utf8()`] 的文档。
    /// 该函数是一个镜像，但是用于 UTF-16 而不是 UTF-8。
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// 将此字符编码为 UTF-8 到提供的字节缓冲区中，然后返回包含编码字符的缓冲区的子切片。
    ///
    ///
    /// # Panics
    ///
    /// Panics (如果缓冲区不够大)。
    /// 长度为四的缓冲区足够大，可以对任何 `char` 进行编码。
    ///
    /// # Examples
    ///
    /// 在这两个示例中，'ß' 占用两个字节进行编码。
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// 缓冲区太小:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // 这个 panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SAFETY: `char` 不是代理，所以这是有效的 UTF-8。
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// 将此字符编码为 UTF-16 到提供的 `u16` 缓冲区中，然后返回包含编码字符的缓冲区的子切片。
    ///
    ///
    /// # Panics
    ///
    /// Panics (如果缓冲区不够大)。
    /// 长度为 2 的缓冲区足够大，可以对任何 `char` 进行编码。
    ///
    /// # Examples
    ///
    /// 在这两个示例中，'𝕊' 都需要两个 u16 进行编码。
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// 缓冲区太小:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // 这个 panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// 如果此 `char` 具有 `Alphabetic` 属性，则返回 `true`。
    ///
    /// `Alphabetic` 在 [Unicode 标准][Unicode Standard] 的第 4 章 (字符属性) 中进行了说明，并在 [Unicode 字符数据库][ucd] [`DerivedCoreProperties.txt`] 中进行了指定。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // love 有很多东西，但它不是按字母顺序排列的
    /// assert!(!c.is_alphabetic());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// 如果此 `char` 具有 `Lowercase` 属性，则返回 `true`。
    ///
    /// `Lowercase` 在 [Unicode 标准][Unicode Standard] 的第 4 章 (字符属性) 中进行了说明，并在 [Unicode 字符数据库][ucd] [`DerivedCoreProperties.txt`] 中进行了指定。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // 各种中文脚本和标点符号没有大小写，因此:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// 如果此 `char` 具有 `Uppercase` 属性，则返回 `true`。
    ///
    /// `Uppercase` 在 [Unicode 标准][Unicode Standard] 的第 4 章 (字符属性) 中进行了说明，并在 [Unicode 字符数据库][ucd] [`DerivedCoreProperties.txt`] 中进行了指定。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // 各种中文脚本和标点符号没有大小写，因此:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// 如果此 `char` 具有 `White_Space` 属性，则返回 `true`。
    ///
    /// `White_Space` 在 [Unicode 字符数据库][ucd] [`PropList.txt`] 中指定。
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // 一个不间断空格
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// 如果此 `char` 满足 [`is_alphabetic()`] 或 [`is_numeric()`]，则返回 `true`。
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// 如果此 `char` 具有控制代码的常规类别，则返回 `true`。
    ///
    /// [Unicode 标准] 的第 4 章 (字符属性) 中描述了控制代码 (具有 `Cc` 的常规类别的代码点)，并在 [Unicode 字符数据库][ucd] [`UnicodeData.txt`] 中进行了指定。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// // U+009C, 终止符
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// 如果此 `char` 具有 `Grapheme_Extend` 属性，则返回 `true`。
    ///
    /// `Grapheme_Extend` 在 [Unicode 标准附件 #29 (Unicode 文本分割)][uax29] 中进行了说明，并在 [Unicode 字符数据库][ucd] [`DerivedCoreProperties.txt`] 中进行了指定。
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[must_use]
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// 如果此 `char` 具有数字的常规类别之一，则返回 `true`。
    ///
    /// 在 [Unicode 字符数据库][ucd] [`UnicodeData.txt`] 中指定了数字的常规类别 (`Nd` 表示十进制数字，`Nl` 表示类似字母的数字字符，`No` 表示其他数字字符)。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// 基本用法:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// 返回一个迭代器，该迭代器将这个 `char` 的小写字母映射为一个或多个
    /// `char`s.
    ///
    /// 如果此 `char` 没有小写映射，则迭代器将产生相同的 `char`。
    ///
    /// 如果此 `char` 具有 [Unicode 字符数据库][ucd] [`UnicodeData.txt`] 给出的一对一小写映射，则迭代器将产生该 `char`。
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// 如果此 `char` 需要特殊考虑 (例如，多个 char)，则迭代器将产生 [`SpecialCasing.txt`] 给定的 char。
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// 此操作无需裁剪即可执行无条件映射。即，转换独立于上下文和语言。
    ///
    /// 在 [Unicode 标准][Unicode Standard] 中，第 4 章 (字符属性) 通常讨论大小写映射，而第 3 章 (一致性) 讨论大小写转换的默认算法。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// 作为迭代器:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// 两者都等同于:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// 使用 [`to_string`](../std/string/trait.ToString.html#tymethod.to_string):
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // 有时结果是多个字符:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // 同时没有大写和小写字母的字符会转换成自己。
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the lowercase character as a new iterator, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// 返回一个迭代器，该迭代器将这个 `char` 的大写映射生成为一个或多个
    /// `char`s.
    ///
    /// 如果此 `char` 没有大写映射，则迭代器生成相同的 `char`。
    ///
    /// 如果此 `char` 具有 [Unicode 字符数据库][ucd] [`UnicodeData.txt`] 给出的一对一大写映射，则迭代器将产生该 `char`。
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// 如果此 `char` 需要特殊考虑 (例如，多个 char)，则迭代器将产生 [`SpecialCasing.txt`] 给定的 char。
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// 此操作无需裁剪即可执行无条件映射。即，转换独立于上下文和语言。
    ///
    /// 在 [Unicode 标准][Unicode Standard] 中，第 4 章 (字符属性) 通常讨论大小写映射，而第 3 章 (一致性) 讨论大小写转换的默认算法。
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// 作为迭代器:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// 直接使用 `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// 两者都等同于:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// 使用 [`to_string`](../std/string/trait.ToString.html#tymethod.to_string):
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // 有时结果是多个字符:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // 同时没有大写和小写字母的字符会转换成自己。
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # 关于语言环境说明
    ///
    /// 在土耳其语中，相当于 'i' 的拉丁语具有 5 种形式，而不是 2 种形式:
    ///
    /// * 'Dotless': I / ı，有时写成 ï
    /// * 'Dotted': İ / i
    ///
    /// 注意，小写的点缀 'i' 与拉丁字母相同。Therefore:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// `upper_i` 的值在此取决于文本的语言：如果我们在 `en-US` 中，则应为 `"I"`，但如果我们在 `tr_TR` 中，则应为 `"İ"`。
    /// `to_uppercase()` 没有考虑到这一点，因此:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// 适用于多种语言。
    ///
    ///
    ///
    ///
    #[must_use = "this returns the uppercase character as a new iterator, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// 检查该值是否在 ASCII 范围内。
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// 使值的副本等效于其 ASCII 大写字母。
    ///
    /// ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不变。
    ///
    /// 要就地将值大写，请使用 [`make_ascii_uppercase()`]。
    ///
    /// 要除非 ASCII 字符外还使用大写 ASCII 字符，请使用 [`to_uppercase()`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[must_use = "to uppercase the value in-place, use `make_ascii_uppercase()`"]
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// 以等效的 ASCII 小写形式复制值。
    ///
    /// ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不变。
    ///
    /// 要就地小写该值，请使用 [`make_ascii_lowercase()`]。
    ///
    /// 要除非 ASCII 字符外还使用小写 ASCII 字符，请使用 [`to_lowercase()`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[must_use = "to lowercase the value in-place, use `make_ascii_lowercase()`"]
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// 检查两个值是否为 ASCII 不区分大小写的匹配。
    ///
    /// 相当于 <code>[to_ascii_lowercase]\(a) == [to_ascii_lowercase]\(b)</code>。
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    ///
    /// [to_ascii_lowercase]: #method.to_ascii_lowercase
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// 将此类型就地转换为其 ASCII 大写等效项。
    ///
    /// ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不变。
    ///
    /// 要返回新的大写值而不修改现有值，请使用 [`to_ascii_uppercase()`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// 将此类型就地转换为其 ASCII 小写等效项。
    ///
    /// ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不变。
    ///
    /// 要返回新的小写值而不修改现有值，请使用 [`to_ascii_lowercase()`]。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// 检查值是否为 ASCII 字母字符:
    ///
    /// - U+0041 'A' ..= U+005A 'Z'，或
    /// - U+0061 'a' ..= U+007A 'z'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// 检查值是否为 ASCII 大写字符:
    /// U+0041 'A' ..= U+005A 'Z'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// 检查值是否为 ASCII 小写字符:
    /// U+0061 'a' ..= U+007A 'z'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// 检查值是否为 ASCII 字母数字字符:
    ///
    /// - U+0041 'A' ..= U+005A 'Z'，或
    /// - U+0061 'a' ..= U+007A 'z'，或
    /// - U+0030 '0' ..= U+0039 '9'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// 检查值是否为 ASCII 十进制数字:
    /// U+0030 '0' ..= U+0039 '9'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// 检查值是否为 ASCII 十六进制数字:
    ///
    /// - U+0030 '0' ..= U+0039 '9'，或
    /// - U+0041 'A' ..= U+0046 'F'，或
    /// - U+0061 'a' ..= U+0066 'f'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// 检查值是否为 ASCII 标点符号:
    ///
    /// - U+0021 ..= U+002F `! " # $ % & ' ( ) * + , - . /`，或
    /// - U+003A ..= U+0040 `: ; < = > ? @`，或
    /// - U+005B ..= U+0060`[\] ^ _```，或
    /// - U+007B ..= U+007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// 检查值是否为 ASCII 图形字符:
    /// U+0021 '!' ..= U+007E '~'。
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// 检查值是否为 ASCII 空格字符:
    /// U+0020 空格，U+0009 水平制表符，U+000A 行进纸，U+000C 表格进纸或 U+000D 回车。
    ///
    /// Rust 使用 WhatWG 基础标准的 [ASCII 空格的定义][infra-aw]。还有其他几种广泛使用的定义。
    /// 例如，[POSIX 语言环境][pct] 包括 U+000B 垂直标签以及所有上述字符，但是 - 从相同的规格来看 -[Bourne shell 中 "field splitting" 的默认规则][bfs] 仅考虑空格，水平标签和 LINE FEED 作为空白。
    ///
    ///
    /// 如果要编写将处理现有文件格式的程序，请在使用此函数之前检查该格式的空格定义。
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// 检查值是否为 ASCII 控制字符:
    /// U+0000 NUL ..= U+001F 单元分隔符，或 U+007F DELETE。
    /// 请注意，大多数 ASCII 空格字符是控制字符，而 SPACE 不是。
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[must_use]
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

pub(crate) struct EscapeDebugExtArgs {
    /// 转义扩展字素代码点？
    pub(crate) escape_grapheme_extended: bool,

    /// 转义单引号？
    pub(crate) escape_single_quote: bool,

    /// 转义双引号？
    pub(crate) escape_double_quote: bool,
}

impl EscapeDebugExtArgs {
    pub(crate) const ESCAPE_ALL: Self = Self {
        escape_grapheme_extended: true,
        escape_single_quote: true,
        escape_double_quote: true,
    };
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// 将原始 u32 值编码为 UTF-8 到提供的字节缓冲区中，然后返回包含编码字符的缓冲区的子切片。
///
///
/// 与 `char::encode_utf8` 不同，此方法还处理代理范围内的代码点。
/// (在代理范围内创建 `char` 是 UB。) 结果是有效的 [广义的 UTF-8]，但无效的 UTF-8。
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics (如果缓冲区不够大)。
/// 长度为四的缓冲区足够大，可以对任何 `char` 进行编码。
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// 将原始 u32 值编码为 UTF-16 到提供的 `u16` 缓冲区中，然后返回包含编码字符的缓冲区的子切片。
///
///
/// 与 `char::encode_utf16` 不同，此方法还处理代理范围内的代码点。
/// (在代理范围内创建 `char` 是 UB。)
///
/// # Panics
///
/// Panics (如果缓冲区不够大)。
/// 长度为 2 的缓冲区足够大，可以对任何 `char` 进行编码。
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SAFETY: 每个 arm 检查是否有足够的位可写入
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP 失败了
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // 辅助展开分解为代理。
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}
