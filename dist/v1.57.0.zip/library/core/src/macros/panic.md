Panics 当前线程。

这允许程序立即终止并向程序的调用者提供反馈。
`panic!` 当程序达到不可恢复的状态时应使用。

此宏是在示例代码和测试中声明条件的理想方法。
`panic!` 与 [`Option`][ounwrap] 和 [`Result`][runwrap] 枚举的 `unwrap` 方法紧密相关。
两种实现都将 `panic!` 设置为 [`None`] 或 [`Err`] 成员时。

使用 `panic!()` 时，你可以指定一个字符串 payload，它是使用 [`format!`] 语法构建的。
当将 panic 注入到调用的 Rust 线程中时，将使用这个 payload，从而导致该线程完全变为 panic。

默认 `std` hook 的行为，即
在调用 panic 之后直接运行的代码是将消息 payload 以及 `panic!()` 调用的文件、行、列信息打印到 `stderr`。

您可以使用 [`std::panic::set_hook()`] 覆盖 panic hook。
在 hook 内部，可以将 panic 作为 `&dyn Any + Send` 进行访问，其中包含用于常规 `panic!()` 调用的 `&str` 或 `String`。
对于具有其他类型值的 panic，可以使用 [`panic_any`]。

[`Result`] 与使用 `panic!` 宏相比，枚举通常是从错误中恢复的更好解决方案。
应该使用此宏来避免继续使用不正确的值，例如来自外部来源的值。
有关错误处理的详细信息，请参见 [书][book]。

另请参见宏 [`compile_error!`]，以获取编译期间的错误。

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# 当前实现

如果主线程为 panics，它将终止您的所有线程并以代码 `101` 结束您的程序。

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```
